import { useState, useEffect, useRef } from "react";
import { registerPlugin, Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";

const Apps = registerPlugin("Apps");

const C = {
  bg: "#0d0d0d", bar: "#161616", card: "#1c1c1c", border: "#2a2a2a",
  text: "#e9e9e9", sub: "#8c8c8c", date: "#7c7c7c", active: "#ffffff",
  nav: "#c9c9c9", acc: "#34C759", blue: "#1e88e5", green: "#43a047", divider: "#2c2c2c",
};
const TABS = ["ИЗБРАННОЕ", "ПРИЛОЖЕНИЯ", "ИГРЫ", "ЭМУЛЯТОРЫ", "НЕ СВЯЗАННЫЕ"];
const DEMO = [
  { packageName: "com.android.chrome", label: "Chrome", versionName: "126.0", lastUpdate: Date.now() },
  { packageName: "org.telegram.messenger", label: "Telegram", versionName: "11.1.0", lastUpdate: Date.now() - 864e5 },
];

const pad = (n) => String(n).padStart(2, "0");
const fmtDate = (ms) => { if (!ms) return ""; const d = new Date(ms); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; };
const tileColor = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return `hsl(${h % 360} 42% 30%)`; };

// архитектуры устройства (для выбора нужного apk)
let DEVICE_ABIS = [];
Apps.deviceAbis().then((r) => { DEVICE_ABIS = r.abis || []; }).catch(() => {});
const ABI_TOKENS = { "arm64-v8a": ["arm64", "arm8a", "aarch64", "v8a"], "armeabi-v7a": ["arm7a", "armeabi", "armv7", "v7a"], "x86_64": ["x86_64", "x86-64", "x64"], "x86": ["x86"] };
function fileForDevice(name) {
  const n = (name || "").toLowerCase();
  if (!/(arm64|arm7a|armeabi|armv7|x86|aarch64|v8a|v7a)/.test(n)) return true;
  for (const abi of DEVICE_ABIS) for (const t of (ABI_TOKENS[abi] || [])) if (n.includes(t)) return true;
  return false;
}

// ссылки 4pda / play
const q4 = (app) => encodeURIComponent(app.label || app.packageName);
const topicUrl = (app) => app.topicId ? `https://4pda.to/forum/index.php?showtopic=${app.topicId}` : `https://4pda.to/forum/index.php?act=search&query=${q4(app)}`;
const openTopicApp = (app) => Apps.openWeb({ url: topicUrl(app) }).catch(() => {});
const openPlay = (app) => Apps.openUrl({ url: `market://details?id=${app.packageName}` }).catch(() => Apps.openUrl({ url: `https://play.google.com/store/apps/details?id=${app.packageName}` }));

// --- парсинг темы 4pda ---
function parseTopic(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const firstBody = doc.querySelector(".post_body") || doc.querySelector(".postcolor");
  // скриншоты (прикреплённые картинки) — отдельной лентой
  const screenshots = [];
  if (firstBody) {
    firstBody.querySelectorAll("img.linked-image, a.ipb-attach img, .post-block img").forEach((im) => {
      const src = im.getAttribute("data-src") || im.getAttribute("src") || "";
      const full = im.getAttribute("data-preview") || src;
      if (src && src.indexOf("http") === 0) screenshots.push({ thumb: src, full });
      im.remove();
    });
  }
  let descHtml = firstBody ? firstBody.innerHTML : "";
  descHtml = descHtml.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "");
  const tmp = document.createElement("div"); tmp.innerHTML = descHtml;
  const descText = (tmp.textContent || "").replace(/\s+/g, " ").trim();
  let ver4pda = "";
  const vm = descText.match(/верси[яию]\s*:?\s*([0-9][0-9.]*)/i);
  if (vm) ver4pda = vm[1];

  const scope = firstBody || doc;
  const seen = new Set();
  const files = [];
  scope.querySelectorAll("a.attach-file").forEach((a) => {
    let url = a.getAttribute("href") || "";
    if (!url) return;
    if (url.indexOf("//") === 0) url = "https:" + url;
    if (url.indexOf("http") !== 0) url = "https://4pda.to" + (url[0] === "/" ? "" : "/") + url;
    const m = url.match(/\/dl\/post\/(\d+)\/([^?#]+)/i);
    if (!m || seen.has(m[1])) return;
    seen.add(m[1]);
    let name = decodeURIComponent(m[2]).replace(/\+/g, " ").trim();
    if (!/\.(apk|apks|xapk|zip|obb|rar|7z)$/i.test(name)) return;
    let size = "";
    let sib = a.nextSibling, guard = 0;
    while (sib && guard < 4 && !size) { if (sib.nodeType === 3) { const s = (sib.textContent || "").match(/\(([^)]+)\)/); if (s) size = s[1].trim(); } sib = sib.nextSibling; guard++; }
    let dl = "";
    const el = a.nextElementSibling;
    if (el && (el.className || "").indexOf("desc") >= 0) dl = (el.textContent || "").replace(/\D/g, "");
    files.push({ id: m[1], name, url: url.replace(/&amp;/g, "&"), size, downloads: dl });
  });
  if (!ver4pda && files[0]) { const fm = files[0].name.match(/([0-9]+(?:\.[0-9]+)+)/); if (fm) ver4pda = fm[1]; }
  return { descHtml, descText, ver4pda, files, screenshots };
}
const playPkg = (html) => {
  let m = html.match(/play\.google\.com\/store\/apps\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  if (m) return m[1];
  m = html.match(/market:\/\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  return m ? m[1] : null;
};
function topicIds(html) {
  const ids = [], seen = new Set();
  // современный формат 4pda /forum/topic/<id>-slug/ И старый index.php?showtopic=<id>
  const re = /\/forum\/(?:index\.php\?showtopic=|topic\/)(\d{3,})/gi;
  let m; while ((m = re.exec(html)) !== null) if (!seen.has(m[1])) { seen.add(m[1]); ids.push(m[1]); }
  return ids;
}

// поиск темы: собираем кандидатов из поиска 4pda (пакет+название) и Google (site:4pda.to),
// берём ТОЛЬКО тему, где в шапке ссылка Play с этим пакетом. "captcha" | {topicId,html} | null
async function resolveTopic(app, maxCand = 5, useGoogle = true) {
  const ids = [];
  const add = (arr) => { for (const id of arr) if (!ids.includes(id)) ids.push(id); };
  const queries = [app.packageName];
  if (app.label && app.label !== app.packageName) queries.push(app.label);
  for (const query of queries) {
    try {
      const sr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?act=search&source=all&query=${encodeURIComponent(query)}` });
      if (sr.captcha) return "captcha";
      add(topicIds(sr.body || ""));
    } catch {}
    if (ids.length >= 3) break;
  }
  if (useGoogle && ids.length < 3) {
    try {
      const gr = await Apps.httpGet({ url: `https://www.google.com/search?q=${encodeURIComponent(app.packageName + " site:4pda.to")}` });
      if (!gr.captcha) add(topicIds(gr.body || ""));
    } catch {}
  }
  if (!ids.length) return null;
  for (let i = 0; i < Math.min(ids.length, maxCand); i++) {
    try {
      const tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${ids[i]}` });
      if (tr.captcha) return "captcha";
      if (playPkg(tr.body || "") === app.packageName) return { topicId: ids[i], matched: true, html: tr.body };
    } catch {}
  }
  return null;
}
async function fetchPlayVersion(pkg) {
  // 1) через gplayapi (анонимно, без входа) — точная версия
  try { const r = await Apps.playVersion({ packageName: pkg }); if (r && r.versionName) return r.versionName; } catch {}
  // 2) откат: парсинг HTML Play (ненадёжно)
  for (const hl of ["ru", "en"]) {
    try {
      const r = await Apps.httpGet({ url: `https://play.google.com/store/apps/details?id=${pkg}&hl=${hl}&gl=US` });
      const b = r.body || "";
      let m = b.match(/\[\[\["([0-9][0-9A-Za-z.\-_]*)"\]\],\s*\[/);
      if (m) return m[1];
      m = b.match(/"softwareVersion"\s*:\s*"([^"]+)"/i); if (m) return m[1].trim();
      m = b.match(/Current Version[\s\S]{0,120}?([0-9]+\.[0-9][0-9A-Za-z.\-_]*)/i); if (m) return m[1];
    } catch {}
  }
  return null;
}

// --- кэш пакет→тема (localStorage) ---
const CKEY = "t4_cache_v1";
function readCache() { try { return JSON.parse(localStorage.getItem(CKEY) || "{}"); } catch { return {}; } }

function Icon({ app, size = 56 }) {
  const box = { width: size, height: size, borderRadius: size * 0.25, flexShrink: 0, overflow: "hidden" };
  if (app.icon) return <img src={app.icon} alt="" style={{ ...box, objectFit: "cover" }} />;
  const letter = (app.label || app.packageName || "?").trim().charAt(0).toUpperCase();
  return <div style={{ ...box, background: tileColor(app.packageName || app.label || "?"), display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#eaeaea", fontWeight: 800, fontSize: size * 0.43 }}>{letter}</span></div>;
}

const Mini = ({ kind }) => {
  if (kind === "inst") return <svg width="14" height="14" viewBox="0 0 24 24"><path fill={C.green} d="M18 2H8.83c-.53 0-1.04.21-1.41.59L2.59 7.41C2.21 7.79 2 8.3 2 8.83V20c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8 6H8V4h2v4zm3 0h-2V4h2v4zm3 0h-2V4h2v4z" /></svg>;
  if (kind === "4pda") return <span style={{ width: 14, height: 14, borderRadius: 3, background: C.blue, color: "#fff", fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>4</span>;
  return <svg width="13" height="13" viewBox="0 0 24 24"><path fill={C.green} d="M4 3.2l15 8.8-15 8.8z" /></svg>;
};

function VerBar({ inst, v4, vp }) {
  const cell = (kind, val, i) => (
    <div key={i} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "6px 4px", borderRight: i < 2 ? `1px solid ${C.divider || "#2c2c2c"}` : "none" }}>
      <Mini kind={kind} /><span style={{ fontSize: 12.5, color: val ? "#cfcfcf" : "#6a6a6a", whiteSpace: "nowrap" }}>{val || "—"}</span>
    </div>
  );
  return <div style={{ display: "flex", borderTop: `1px solid #2c2c2c` }}>{cell("inst", inst, 0)}{cell("4pda", v4, 1)}{cell("play", vp, 2)}</div>;
}

function AppCard({ app, info, onOpen, onMenu }) {
  const hasVer = info && (info.ver4pda || info.verPlay);
  const sub = (info && info.desc) ? info.desc : app.packageName;
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7 }}>
      <div style={{ display: "flex", padding: "9px 10px", gap: 10, alignItems: "center", cursor: "pointer" }} onClick={() => onOpen(app)}>
        <Icon app={app} size={44} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: C.text, fontSize: 16, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
          <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{sub}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", flexShrink: 0, alignSelf: "stretch", justifyContent: "space-between", paddingTop: 2 }}>
          <span style={{ color: C.date, fontSize: 12 }}>{fmtDate(app.lastUpdate)}</span>
          <div onClick={(e) => { e.stopPropagation(); onMenu(app); }} style={{ width: 26, height: 22, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3 }}>
            {[0, 1, 2].map((i) => <span key={i} style={{ width: 3.5, height: 3.5, borderRadius: 4, background: "#9a9a9a" }} />)}
          </div>
        </div>
      </div>
      {hasVer && <div style={{ padding: "0 10px 8px" }}><VerBar inst={app.versionName} v4={info.ver4pda} vp={info.verPlay} /></div>}
    </div>
  );
}

function NavBtn({ title, onClick, children }) {
  const [p, setP] = useState(false);
  return <div title={title} onClick={onClick} onPointerDown={() => setP(true)} onPointerUp={() => setP(false)} onPointerLeave={() => setP(false)} style={{ padding: "10px 9px", cursor: "pointer", opacity: p ? 0.5 : 1, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</div>;
}
const sw = (color) => ({ fill: "none", stroke: color, strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" });
const IBot = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="11" width="18" height="10" rx="2.5" /><path d="M12 7v4" /><circle cx="12" cy="5" r="2" /><circle cx="8.5" cy="16" r="1.1" fill={color} stroke="none" /><circle cx="15.5" cy="16" r="1.1" fill={color} stroke="none" /></svg>);
const IEyeOff = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19" /><path d="M6.61 6.61A18.6 18.6 0 0 0 2 12s3 8 10 8a9.1 9.1 0 0 0 5.39-1.61" /><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" /><path d="M2 2l20 20" /></svg>);
const IEye = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M2 12s3-8 10-8 10 8 10 8-3 8-10 8-10-8-10-8Z" /><circle cx="12" cy="12" r="3" /></svg>);
const ICatalog = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>);
const IDownload = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M7 10l5 5 5-5" /><path d="M12 15V3" /></svg>);
const ISearch = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>);
const IRefresh = ({ color = C.nav }) => (<svg width="23" height="23" viewBox="0 0 24 24" {...sw(color)}><path d="M21 12a9 9 0 1 1-2.64-6.36" /><path d="M21 3v6h-6" /></svg>);
const I4 = () => (<div style={{ width: 26, height: 26, borderRadius: 6, background: C.blue, color: "#fff", fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>4</div>);
const IPlayStore = () => (<svg width="24" height="24" viewBox="0 0 24 24"><path fill={C.acc} d="M4 3.2l15 8.8-15 8.8z" /></svg>);

function VerChip({ label, value, accent }) {
  return <div style={{ flex: 1, background: "#141414", border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
    <div style={{ color: C.sub, fontSize: 11, letterSpacing: 0.3 }}>{label}</div>
    <div style={{ color: accent || C.text, fontSize: 14, fontWeight: 600, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{value}</div>
  </div>;
}

function ContextMenu({ app, onClose }) {
  const item = (label, fn, danger) => <div onClick={() => { fn(); onClose(); }} style={{ padding: "15px 20px", color: danger ? "#e5534b" : C.text, fontSize: 16, cursor: "pointer" }}>{label}</div>;
  return <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 60, display: "flex", alignItems: "flex-end" }}>
    <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", background: "#1c1c1c", borderTopLeftRadius: 16, borderTopRightRadius: 16, paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div style={{ padding: "16px 20px 8px", color: C.sub, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
      {item("Открыть на 4pda", () => openTopicApp(app))}
      {item("Google Play", () => openPlay(app))}
      {item("О приложении", () => Apps.openAppInfo({ packageName: app.packageName }).catch(() => {}))}
      {item("Удалить", () => Apps.uninstallApp({ packageName: app.packageName }).catch(() => {}), true)}
    </div>
  </div>;
}

function Downloads({ onClose }) {
  const [files, setFiles] = useState(null);
  useEffect(() => { Apps.listDownloads().then((r) => setFiles((r.files || []).slice().sort((a, b) => (b.date || 0) - (a.date || 0)))).catch(() => setFiles([])); }, []);
  const sz = (b) => (b >= 1048576 ? (b / 1048576).toFixed(1) + " МБ" : Math.max(1, Math.round(b / 1024)) + " КБ");
  return <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 55 }}>
    <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Загрузки</span></div></div>
    <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 0" }}>
      {files === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : files.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Нет скачанных файлов</div> :
        files.map((f) => <div key={f.path} onClick={() => Apps.installApk({ path: f.path }).catch(() => {})} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 10, padding: 14, cursor: "pointer" }}><div style={{ color: C.text, fontSize: 15, fontWeight: 500, wordBreak: "break-all" }}>{f.name}</div><div style={{ color: C.sub, fontSize: 13, marginTop: 4 }}>{sz(f.size)} · {fmtDate(f.date)}</div></div>)}
      <div style={{ height: 12 }} />
    </div>
  </div>;
}

// экран «ФАЙЛЫ» — список файлов; тап открывает инфо-окно
function FilesDialog({ app, files, onClose }) {
  const [picked, setPicked] = useState(null);
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 70, display: "flex", alignItems: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxHeight: "80%", overflowY: "auto", background: "#1c1c1c", borderTopLeftRadius: 16, borderTopRightRadius: 16, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ padding: "16px 18px 8px", color: C.text, fontSize: 18, fontWeight: 600 }}>Скачать</div>
        {(!files || files.length === 0) ? <div style={{ padding: "8px 18px 20px", color: C.sub, fontSize: 14 }}>Файлы в теме не найдены.</div> :
          files.map((f, i) => {
            const mine = fileForDevice(f.name);
            return <div key={i} onClick={() => setPicked(f)} style={{ padding: "12px 18px", cursor: "pointer", borderTop: i ? `1px solid ${C.border}` : "none" }}>
              <div style={{ color: C.text, fontSize: 15, wordBreak: "break-all" }}>{f.name}</div>
              <div style={{ marginTop: 3, fontSize: 13, color: C.sub, display: "flex", gap: 10, flexWrap: "wrap" }}>
                <span>{[f.size, f.downloads ? "скачиваний: " + f.downloads : ""].filter(Boolean).join(" · ")}</span>
                {mine && <span style={{ color: C.acc }}>✓ для вашего устройства</span>}
              </div>
            </div>;
          })}
      </div>

      {picked && (
        <div onClick={(e) => { e.stopPropagation(); setPicked(null); }} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 80, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: "#1e1e1e", borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 17, fontWeight: 600, marginBottom: 12 }}>Начать закачку?</div>
            <Row k="Название" v={app.label || app.packageName} />
            <Row k="Имя файла" v={picked.name} />
            {picked.size && <Row k="Размер" v={picked.size} />}
            {picked.downloads && <Row k="Скачиваний" v={picked.downloads} />}
            <Row k="Пакет" v={app.packageName} />
            <Row k="Для устройства" v={fileForDevice(picked.name) ? "да" : "возможно, не подходит"} />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 18, marginTop: 16 }}>
              <div onClick={() => setPicked(null)} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 4px" }}>ОТМЕНА</div>
              <div onClick={() => { Apps.download({ url: picked.url, name: picked.name }).catch(() => {}); setPicked(null); onClose(); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 4px" }}>СКАЧАТЬ</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
function Row({ k, v }) {
  return <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>{k}:</span><span style={{ color: C.text, wordBreak: "break-all" }}>{v}</span></div>;
}

function Detail({ app, onClose, onCache, onFiles }) {
  const [td, setTd] = useState({ phase: "loading" });
  const [retKey, setRetKey] = useState(0);

  useEffect(() => {
    let alive = true;
    (async () => {
      setTd({ phase: "loading" });
      try {
        const cache = readCache()[app.packageName] || {};
        let topicId = cache.topicId, matched = cache.matched, html = null;
        if (cache.notfound && !topicId) { setTd({ phase: "notfound" }); return; }
        if (!topicId) {
          const r = await resolveTopic(app);
          if (!alive) return;
          if (r === "captcha") { setTd({ phase: "captcha" }); return; }
          if (!r) { onCache(app.packageName, { notfound: true }); setTd({ phase: "notfound" }); return; }
          topicId = r.topicId; matched = r.matched; html = r.html;
          onCache(app.packageName, { topicId, matched, notfound: false });
        }
        if (!html) {
          const tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${topicId}` });
          if (!alive) return;
          if (tr.captcha) { setTd({ phase: "captcha" }); return; }
          html = tr.body || "";
        }
        const p = parseTopic(html);
        onCache(app.packageName, { ver4pda: p.ver4pda, desc: p.descText.slice(0, 140) });
        setTd({ phase: "ok", descHtml: p.descHtml, files: p.files, ver4pda: p.ver4pda, screenshots: p.screenshots, verPlay: cache.verPlay || "" });
        if (!cache.verPlay) {
          fetchPlayVersion(app.packageName).then((v) => { if (v) { onCache(app.packageName, { verPlay: v }); if (alive) setTd((t) => (t && t.phase === "ok" ? { ...t, verPlay: v } : t)); } }).catch(() => {});
        }
      } catch (e) { if (alive) setTd({ phase: "error", msg: (e && e.message) || "ошибка" }); }
    })();
    return () => { alive = false; };
  }, [retKey]);

  const note = (txt, btn) => <div style={{ textAlign: "center", marginTop: 30, padding: "0 10px" }}><div style={{ color: C.sub, fontSize: 14, marginBottom: 14 }}>{txt}</div>{btn}</div>;
  const btn = (label, fn) => <div onClick={fn} style={{ display: "inline-block", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 14, padding: "10px 16px", borderRadius: 10, cursor: "pointer" }}>{label}</div>;

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 50 }}>
      <style>{".topic-desc img{max-width:100%;height:auto;border-radius:6px} .topic-desc a{color:#4da3ff} .topic-desc{word-break:break-word}"}</style>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ color: C.text, fontSize: 19, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}{app.versionName ? ` [${app.versionName}]` : ""}</div>
            <div style={{ color: C.sub, fontSize: 12.5 }}>Обновление: {fmtDate(app.lastUpdate)}</div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14 }}>
          <Icon app={app} />
          <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 18, fontWeight: 600 }}>{app.label || app.packageName}</div><div style={{ color: C.sub, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.packageName}</div></div>
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <VerChip label="УСТАНОВЛЕНО" value={app.versionName || "—"} accent={C.acc} />
          <VerChip label="4PDA" value={td.phase === "ok" ? (td.ver4pda || "—") : "…"} />
          <VerChip label="GOOGLE PLAY" value={td.verPlay || "—"} />
        </div>

        <div style={{ color: C.text, fontSize: 13, fontWeight: 700, letterSpacing: 0.4, marginBottom: 8 }}>ОПИСАНИЕ</div>
        {td.phase === "loading" && <div style={{ color: C.sub, fontSize: 14 }}>Загрузка темы с 4pda…</div>}
        {td.phase === "captcha" && note("4pda просит проверку. Открой 4pda, войди/реши капчу и вернись.", <span>{btn("Открыть 4pda", () => openTopicApp(app))} <span style={{ display: "inline-block", width: 8 }} />{btn("Повторить", () => setRetKey((k) => k + 1))}</span>)}
        {td.phase === "notfound" && <div style={{ color: C.sub, fontSize: 14 }}>Связь с 4pda не установлена — приложение в разделе «Не связанные».</div>}
        {td.phase === "error" && note("Не удалось загрузить: " + td.msg, btn("Повторить", () => setRetKey((k) => k + 1)))}
        {td.phase === "ok" && <>
          <div className="topic-desc" style={{ color: "#d3d3d3", fontSize: 14, lineHeight: 1.45 }} dangerouslySetInnerHTML={{ __html: td.descHtml || "—" }} />
          {td.screenshots && td.screenshots.length > 0 && <>
            <div style={{ color: C.text, fontSize: 13, fontWeight: 700, letterSpacing: 0.4, margin: "16px 0 8px" }}>СКРИНШОТЫ</div>
            <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 6 }}>
              {td.screenshots.map((s, i) => <img key={i} src={s.thumb} alt="" onClick={() => Apps.openUrl({ url: s.full }).catch(() => {})} style={{ height: 200, borderRadius: 8, flexShrink: 0, cursor: "pointer" }} />)}
            </div>
          </>}
        </>}
        <div style={{ height: 20 }} />
      </div>

      <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", height: 58 }}>
          <div onClick={() => openTopicApp(app)} title="4pda" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><I4 /></div>
          <div onClick={() => (td.phase === "ok" ? onFiles({ app, files: td.files }) : openTopicApp(app))} style={{ flex: 1, textAlign: "center", color: C.acc, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>ФАЙЛЫ</div>
          <div onClick={() => openPlay(app)} title="Google Play" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><IPlayStore /></div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState(1);
  const [apps, setApps] = useState(null);
  const [sys, setSys] = useState(false);
  const [hid, setHid] = useState(false);
  const [sel, setSel] = useState(null);
  const [menuApp, setMenuApp] = useState(null);
  const [dlScreen, setDlScreen] = useState(false);
  const [filesData, setFilesData] = useState(null);
  const [topics, setTopics] = useState(() => readCache());
  const [dir, setDir] = useState(1);
  const updates = 0;
  const gotoTab = (i) => { setDir(i >= active ? 1 : -1); setActive(i); };

  // аппаратная «Назад» — закрыть верхний экран/меню, иначе выйти
  useEffect(() => {
    let handle;
    CapApp.addListener("backButton", () => {
      if (filesData) setFilesData(null);
      else if (menuApp) setMenuApp(null);
      else if (dlScreen) setDlScreen(false);
      else if (sel) setSel(null);
      else CapApp.exitApp();
    }).then((h) => { handle = h; });
    return () => { if (handle) handle.remove(); };
  }, [filesData, menuApp, dlScreen, sel]);

  const onCache = (pkg, patch) => setTopics((prev) => { const next = { ...prev, [pkg]: { ...(prev[pkg] || {}), ...patch } }; try { localStorage.setItem(CKEY, JSON.stringify(next)); } catch {} return next; });

  const load = async (system, hidden) => {
    try {
      const r = await Apps.getInstalledApps({ icons: true, system, hidden });
      const list = (r.apps || []).slice().sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0));
      setApps(list);
    } catch { setApps(Capacitor.getPlatform() === "web" ? DEMO : []); }
  };
  useEffect(() => { load(false, false); }, []);

  // щадящий фоновый автоподбор тем для первых приложений (стоп на капче)
  useEffect(() => {
    if (!apps || apps.length === 0) return;
    let stop = false;
    (async () => {
      const cache = readCache();
      const todo = apps.filter((a) => a.packageName && !cache[a.packageName]?.topicId && !cache[a.packageName]?.notfound).slice(0, 10);
      for (const a of todo) {
        if (stop) break;
        try {
          const r = await resolveTopic(a, 3, false);
          if (r === "captcha") break;
          if (!r) { onCache(a.packageName, { notfound: true }); }
          else { const p = parseTopic(r.html); onCache(a.packageName, { topicId: r.topicId, matched: r.matched, ver4pda: p.ver4pda, desc: p.descText.slice(0, 140) }); }
        } catch {}
        // версия Google Play (без входа, best-effort) — чтобы колонка Play заполнялась
        try { const pv = await fetchPlayVersion(a.packageName); if (pv) onCache(a.packageName, { verPlay: pv }); } catch {}
        await new Promise((res) => setTimeout(res, 900));
      }
    })();
    return () => { stop = true; };
  }, [apps]);

  const toggleSys = () => { const v = !sys; setSys(v); load(v, hid); };
  const toggleHid = () => { const v = !hid; setHid(v); load(sys, v); };

  const touch = useRef({ x: 0, y: 0 });
  const onTouchStart = (e) => { const t = e.touches[0]; touch.current = { x: t.clientX, y: t.clientY }; };
  const onTouchEnd = (e) => { const t = e.changedTouches[0]; const dx = t.clientX - touch.current.x, dy = t.clientY - touch.current.y; if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) { if (dx < 0) setActive((a) => Math.min(a + 1, TABS.length - 1)); else setActive((a) => Math.max(a - 1, 0)); } };

  return (
    <div style={{ height: "100vh", background: C.bg, display: "flex", flexDirection: "column", fontFamily: "Roboto, system-ui, sans-serif", overflow: "hidden" }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "0 16px", height: 56 }}>
          <div style={{ width: 26, height: 20, display: "flex", flexDirection: "column", justifyContent: "space-between", cursor: "pointer" }}>{[0, 1, 2].map((i) => <span key={i} style={{ height: 2, borderRadius: 2, background: "#e0e0e0" }} />)}</div>
          <span style={{ color: C.text, fontSize: 22, fontWeight: 600 }}>4PDApps</span>
        </div>
      </div>

      <div style={{ display: "flex", background: C.bar, overflowX: "auto", borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
        {TABS.map((t, i) => <div key={i} onClick={() => gotoTab(i)} style={{ padding: "14px 18px", whiteSpace: "nowrap", position: "relative", cursor: "pointer" }}><span style={{ color: i === active ? C.active : "#7f7f7f", fontSize: 14, fontWeight: 600, letterSpacing: 0.4 }}>{t}</span>{i === active && <div style={{ position: "absolute", left: 14, right: 14, bottom: 0, height: 3, borderRadius: 3, background: "#8a8a8a" }} />}</div>)}
      </div>

      <style>{"@keyframes slR{from{transform:translateX(26px);opacity:.35}to{transform:translateX(0);opacity:1}}@keyframes slL{from{transform:translateX(-26px);opacity:.35}to{transform:translateX(0);opacity:1}}"}</style>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
        <div key={active} style={{ animation: (dir > 0 ? "slR" : "slL") + " .2s ease" }}>
          {(() => {
            const linked = (a) => topics[a.packageName] && topics[a.packageName].topicId;
            let list = null;
            if (active === 1) list = apps;
            else if (active === 4) list = apps ? apps.filter((a) => !linked(a)) : apps;
            const msg = (t) => <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>{t}</div>;
            if (list === null) return msg("—");
            if (apps === null) return msg("Загрузка…");
            if (list.length === 0) return msg(active === 4 ? "Все приложения связаны с 4pda" : (hid ? "Скрытых приложений нет" : "Приложения не найдены"));
            return list.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName]} onOpen={setSel} onMenu={setMenuApp} />);
          })()}
        </div>
        <div style={{ height: 12 }} />
      </div>

      <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around", height: 58 }}>
          <NavBtn title="Системные" onClick={toggleSys}><IBot color={sys ? C.acc : C.nav} /></NavBtn>
          <NavBtn title="Скрытые" onClick={toggleHid}>{hid ? <IEye color={C.acc} /> : <IEyeOff color={C.nav} />}</NavBtn>
          <NavBtn title="Каталог"><ICatalog /></NavBtn>
          <NavBtn title="Загрузки" onClick={() => setDlScreen(true)}><IDownload /></NavBtn>
          <NavBtn title="Поиск" onClick={() => Apps.openWeb({ url: "https://4pda.to/forum/index.php?act=search" }).catch(() => {})}><ISearch /></NavBtn>
          <NavBtn title="Обновить"><IRefresh /></NavBtn>
          <NavBtn title="Обновления"><div style={{ minWidth: 32, height: 32, padding: "0 8px", borderRadius: 16, border: "2px solid #5a5a5a", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#d0d0d0", fontSize: 15, fontWeight: 600 }}>{updates}</span></div></NavBtn>
        </div>
      </div>

      {sel && <Detail app={sel} onClose={() => setSel(null)} onCache={onCache} onFiles={setFilesData} />}
      {menuApp && <ContextMenu app={menuApp} onClose={() => setMenuApp(null)} />}
      {dlScreen && <Downloads onClose={() => setDlScreen(false)} />}
      {filesData && <FilesDialog app={filesData.app} files={filesData.files} onClose={() => setFilesData(null)} />}
    </div>
  );
}
