import { useState, useEffect, useRef } from "react";
import { registerPlugin, Capacitor } from "@capacitor/core";

const Apps = registerPlugin("Apps");

const C = {
  bg: "#0d0d0d",
  bar: "#161616",
  card: "#1c1c1c",
  border: "#2a2a2a",
  text: "#e9e9e9",
  sub: "#8c8c8c",
  date: "#7c7c7c",
  active: "#ffffff",
  nav: "#c9c9c9",
  acc: "#34C759",
};

const TABS = ["ОБНОВЛЁННОЕ", "ПРИЛОЖЕНИЯ", "ИГРЫ", "ЭМУЛЯТОРЫ", "НОВИНКИ"];

const DEMO = [
  { packageName: "com.android.chrome", label: "Chrome", versionName: "126.0", lastUpdate: Date.now() },
  { packageName: "com.whatsapp", label: "WhatsApp", versionName: "2.24.15", lastUpdate: Date.now() - 864e5 },
  { packageName: "org.telegram.messenger", label: "Telegram", versionName: "11.1.0", lastUpdate: Date.now() - 2 * 864e5 },
];

const pad = (n) => String(n).padStart(2, "0");
const fmtDate = (ms) => {
  if (!ms) return "";
  const d = new Date(ms);
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
};

const tileColor = (s) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return `hsl(${h % 360} 42% 30%)`;
};

function Icon({ app }) {
  const box = { width: 56, height: 56, borderRadius: 14, flexShrink: 0, overflow: "hidden" };
  if (app.icon) return <img src={app.icon} alt="" style={{ ...box, objectFit: "cover" }} />;
  const letter = (app.label || app.packageName || "?").trim().charAt(0).toUpperCase();
  return (
    <div style={{ ...box, background: tileColor(app.packageName || app.label || "?"), display: "flex", alignItems: "center", justifyContent: "center" }}>
      <span style={{ color: "#eaeaea", fontWeight: 800, fontSize: 24 }}>{letter}</span>
    </div>
  );
}

function AppCard({ app, onOpen, onMenu }) {
  const sub = [app.versionName ? "v" + app.versionName : "", app.packageName].filter(Boolean).join("  •  ");
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 10 }}>
      <div style={{ display: "flex", padding: 12, gap: 12, alignItems: "center", cursor: "pointer" }} onClick={() => onOpen(app)}>
        <Icon app={app} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: C.text, fontSize: 19, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
          <div style={{ color: C.sub, fontSize: 14, marginTop: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{sub}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", flexShrink: 0, alignSelf: "stretch", justifyContent: "space-between" }}>
          <span style={{ color: C.date, fontSize: 13.5 }}>{fmtDate(app.lastUpdate)}</span>
          <div onClick={(e) => { e.stopPropagation(); onMenu(app); }} style={{ width: 28, height: 26, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3 }}>
            {[0, 1, 2].map((i) => <span key={i} style={{ width: 4, height: 4, borderRadius: 4, background: "#9a9a9a" }} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

// ссылки 4pda: тема по номеру (когда будет подбор), иначе поиск по названию
const q4 = (app) => encodeURIComponent(app.label || app.packageName);
const topicUrl = (app) => app.topicId ? `https://4pda.to/forum/index.php?showtopic=${app.topicId}` : `https://4pda.to/forum/index.php?act=search&query=${q4(app)}`;
const openTopicApp = (app) => Apps.openWeb({ url: topicUrl(app) }).catch(() => {});     // внутри приложения
const openTopicBrowser = (app) => Apps.openUrl({ url: topicUrl(app) }).catch(() => {}); // системный браузер
const openPlay = (app) => Apps.openUrl({ url: `market://details?id=${app.packageName}` }).catch(() => Apps.openUrl({ url: `https://play.google.com/store/apps/details?id=${app.packageName}` }));

function VerChip({ label, value, accent }) {
  return (
    <div style={{ flex: 1, background: "#141414", border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
      <div style={{ color: C.sub, fontSize: 11, letterSpacing: 0.3 }}>{label}</div>
      <div style={{ color: accent || C.text, fontSize: 14, fontWeight: 600, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{value}</div>
    </div>
  );
}

function Detail({ app, onClose }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 50 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, lineHeight: 1, width: 28 }}>←</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ color: C.text, fontSize: 19, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}{app.versionName ? ` [${app.versionName}]` : ""}</div>
            <div style={{ color: C.sub, fontSize: 12.5 }}>Обновление: {fmtDate(app.lastUpdate)}</div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14 }}>
          <Icon app={app} />
          <div style={{ minWidth: 0 }}>
            <div style={{ color: C.text, fontSize: 18, fontWeight: 600 }}>{app.label || app.packageName}</div>
            <div style={{ color: C.sub, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.packageName}</div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <VerChip label="УСТАНОВЛЕНО" value={app.versionName || "—"} accent={C.acc} />
          <VerChip label="4PDA" value="—" />
          <VerChip label="GOOGLE PLAY" value="—" />
        </div>

        <div style={{ color: C.text, fontSize: 13, fontWeight: 700, letterSpacing: 0.4, marginBottom: 8 }}>ОПИСАНИЕ</div>
        <div style={{ color: C.sub, fontSize: 14, lineHeight: 1.4 }}>
          Описание и скриншоты из темы 4pda появятся здесь позже. Пока: «ФАЙЛЫ» — открыть тему на 4pda внутри приложения, «4PDA» — тема в браузере, «GOOGLE PLAY» — страница в Play.
        </div>
      </div>

      <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", height: 58 }}>
          <div onClick={() => openTopicApp(app)} title="4pda" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><I4 /></div>
          <div onClick={() => openTopicApp(app)} style={{ flex: 1, textAlign: "center", color: C.acc, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>ФАЙЛЫ</div>
          <div onClick={() => openPlay(app)} title="Google Play" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><IPlayStore /></div>
        </div>
      </div>
    </div>
  );
}

function ContextMenu({ app, onClose }) {
  const item = (label, fn, danger) => (
    <div onClick={() => { fn(); onClose(); }} style={{ padding: "15px 20px", color: danger ? "#e5534b" : C.text, fontSize: 16, cursor: "pointer" }}>{label}</div>
  );
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 60, display: "flex", alignItems: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", background: "#1c1c1c", borderTopLeftRadius: 16, borderTopRightRadius: 16, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ padding: "16px 20px 8px", color: C.sub, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
        {item("Открыть на 4pda", () => openTopicApp(app))}
        {item("Google Play", () => openPlay(app))}
        {item("О приложении", () => Apps.openAppInfo({ packageName: app.packageName }).catch(() => {}))}
        {item("Удалить", () => Apps.uninstallApp({ packageName: app.packageName }).catch(() => {}), true)}
      </div>
    </div>
  );
}

function Downloads({ onClose }) {
  const [files, setFiles] = useState(null);
  useEffect(() => {
    Apps.listDownloads().then((r) => setFiles((r.files || []).slice().sort((a, b) => (b.date || 0) - (a.date || 0)))).catch(() => setFiles([]));
  }, []);
  const fmtSize = (b) => (b >= 1048576 ? (b / 1048576).toFixed(1) + " МБ" : Math.max(1, Math.round(b / 1024)) + " КБ");
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 55 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div>
          <span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Загрузки</span>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 0" }}>
        {files === null ? (
          <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>Загрузка…</div>
        ) : files.length === 0 ? (
          <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>Нет скачанных файлов</div>
        ) : (
          files.map((f) => (
            <div key={f.path} onClick={() => Apps.installApk({ path: f.path }).catch(() => {})} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 10, padding: 14, cursor: "pointer" }}>
              <div style={{ color: C.text, fontSize: 15, fontWeight: 500, wordBreak: "break-all" }}>{f.name}</div>
              <div style={{ color: C.sub, fontSize: 13, marginTop: 4 }}>{fmtSize(f.size)} · {fmtDate(f.date)}</div>
            </div>
          ))
        )}
        <div style={{ height: 12 }} />
      </div>
    </div>
  );
}

function NavBtn({ title, onClick, children }) {
  const [p, setP] = useState(false);
  return (
    <div
      title={title}
      onClick={onClick}
      onPointerDown={() => setP(true)}
      onPointerUp={() => setP(false)}
      onPointerLeave={() => setP(false)}
      style={{ padding: "10px 9px", cursor: "pointer", opacity: p ? 0.5 : 1, display: "flex", alignItems: "center", justifyContent: "center" }}
    >
      {children}
    </div>
  );
}

const sw = (color) => ({ fill: "none", stroke: color, strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" });
const IBot = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="11" width="18" height="10" rx="2.5"/><path d="M12 7v4"/><circle cx="12" cy="5" r="2"/><circle cx="8.5" cy="16" r="1.1" fill={color} stroke="none"/><circle cx="15.5" cy="16" r="1.1" fill={color} stroke="none"/></svg>);
const IEyeOff = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M6.61 6.61A18.6 18.6 0 0 0 2 12s3 8 10 8a9.1 9.1 0 0 0 5.39-1.61"/><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M2 2l20 20"/></svg>);
const IEye = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M2 12s3-8 10-8 10 8 10 8-3 8-10 8-10-8-10-8Z"/><circle cx="12" cy="12" r="3"/></svg>);
const ICatalog = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>);
const IDownload = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>);
const ISearch = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>);
const IRefresh = ({ color = C.nav }) => (<svg width="23" height="23" viewBox="0 0 24 24" {...sw(color)}><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>);
const I4 = () => (<div style={{ width: 26, height: 26, borderRadius: 6, background: "#1e88e5", color: "#fff", fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>4</div>);
const IPlayStore = () => (<svg width="24" height="24" viewBox="0 0 24 24"><path fill="#34C759" d="M4 3.2l15 8.8-15 8.8z"/></svg>);

export default function App() {
  const [active, setActive] = useState(1);
  const [apps, setApps] = useState(null);
  const [sys, setSys] = useState(false);
  const [hid, setHid] = useState(false);
  const [sel, setSel] = useState(null);
  const [menuApp, setMenuApp] = useState(null);
  const [dl, setDl] = useState(false);
  const updates = 0;

  const load = async (system, hidden) => {
    try {
      const r = await Apps.getInstalledApps({ icons: true, system, hidden });
      const list = (r.apps || []).slice().sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0));
      setApps(list);
    } catch (e) {
      setApps(Capacitor.getPlatform() === "web" ? DEMO : []);
    }
  };

  useEffect(() => { load(false, false); }, []);

  const toggleSys = () => { const v = !sys; setSys(v); load(v, hid); };
  const toggleHid = () => { const v = !hid; setHid(v); load(sys, v); };

  // свайпы по вкладкам (горизонтальный жест на области списка; вертикальный скролл не трогаем)
  const touch = useRef({ x: 0, y: 0 });
  const onTouchStart = (e) => { const t = e.touches[0]; touch.current = { x: t.clientX, y: t.clientY }; };
  const onTouchEnd = (e) => {
    const t = e.changedTouches[0];
    const dx = t.clientX - touch.current.x;
    const dy = t.clientY - touch.current.y;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) {
      if (dx < 0) setActive((a) => Math.min(a + 1, TABS.length - 1));
      else setActive((a) => Math.max(a - 1, 0));
    }
  };

  return (
    <div style={{ height: "100vh", background: C.bg, display: "flex", flexDirection: "column", fontFamily: "Roboto, system-ui, sans-serif", overflow: "hidden" }}>

      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "0 16px", height: 56 }}>
          <div style={{ width: 26, height: 20, display: "flex", flexDirection: "column", justifyContent: "space-between", cursor: "pointer" }}>
            {[0, 1, 2].map((i) => <span key={i} style={{ height: 2, borderRadius: 2, background: "#e0e0e0" }} />)}
          </div>
          <span style={{ color: C.text, fontSize: 22, fontWeight: 600 }}>4PDApps</span>
        </div>
      </div>

      <div style={{ display: "flex", background: C.bar, overflowX: "auto", borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
        {TABS.map((t, i) => (
          <div key={i} onClick={() => setActive(i)} style={{ padding: "14px 18px", whiteSpace: "nowrap", position: "relative", cursor: "pointer" }}>
            <span style={{ color: i === active ? C.active : "#7f7f7f", fontSize: 14, fontWeight: 600, letterSpacing: 0.4 }}>{t}</span>
            {i === active && <div style={{ position: "absolute", left: 14, right: 14, bottom: 0, height: 3, borderRadius: 3, background: "#8a8a8a" }} />}
          </div>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 0" }} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
        {active !== 1 ? (
          <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>—</div>
        ) : apps === null ? (
          <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>Загрузка…</div>
        ) : apps.length === 0 ? (
          <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>{hid ? "Скрытых приложений нет" : "Приложения не найдены"}</div>
        ) : (
          apps.map((a) => <AppCard key={a.packageName} app={a} onOpen={setSel} onMenu={setMenuApp} />)
        )}
        <div style={{ height: 12 }} />
      </div>

      <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around", height: 58 }}>
          <NavBtn title="Системные" onClick={toggleSys}><IBot color={sys ? C.acc : C.nav} /></NavBtn>
          <NavBtn title="Скрытые" onClick={toggleHid}>{hid ? <IEye color={C.acc} /> : <IEyeOff color={C.nav} />}</NavBtn>
          <NavBtn title="Каталог"><ICatalog /></NavBtn>
          <NavBtn title="Загрузки" onClick={() => setDl(true)}><IDownload /></NavBtn>
          <NavBtn title="Поиск" onClick={() => Apps.openWeb({ url: "https://4pda.to/forum/index.php?act=search" }).catch(() => {})}><ISearch /></NavBtn>
          <NavBtn title="Обновить"><IRefresh /></NavBtn>
          <NavBtn title="Обновления">
            <div style={{ minWidth: 32, height: 32, padding: "0 8px", borderRadius: 16, border: "2px solid #5a5a5a", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#d0d0d0", fontSize: 15, fontWeight: 600 }}>{updates}</span>
            </div>
          </NavBtn>
        </div>
      </div>

      {sel && <Detail app={sel} onClose={() => setSel(null)} />}
      {menuApp && <ContextMenu app={menuApp} onClose={() => setMenuApp(null)} />}
      {dl && <Downloads onClose={() => setDl(false)} />}

    </div>
  );
}
