package leshugan.a4pda

import android.content.Context
import com.aurora.gplayapi.data.models.AuthData
import com.aurora.gplayapi.helpers.AppDetailsHelper
import com.google.gson.Gson
import okhttp3.Cache
import java.io.File

object PlayApi {
    private const val AUTH_URL = "https://auroraoss.com/api/auth"

    @Volatile
    private var cachedAuth: AuthData? = null

    // Версия приложения из Google Play без входа в аккаунт. null при любой ошибке.
    @JvmStatic
    fun version(context: Context, pkg: String): String? {
        return try {
            val gson = Gson()
            val client = PlayHttpClient(Cache(File(context.cacheDir, "playcache"), 2L * 1024 * 1024))
            val authData = auth(context, gson, client)
            val app = AppDetailsHelper(authData).using(client).getAppByPackageName(pkg)
            val v = app.versionName
            if (v.isNullOrEmpty()) null else v
        } catch (e: Throwable) {
            null
        }
    }

    private fun auth(context: Context, gson: Gson, client: PlayHttpClient): AuthData {
        cachedAuth?.let { return it }
        val props = NativeDeviceInfoProvider(context).getNativeDeviceProperties()
        val resp = client.postAuth(AUTH_URL, gson.toJson(props).toByteArray())
        if (!resp.isSuccessful) throw IllegalStateException("auth ${resp.code}")
        val data = gson.fromJson(String(resp.responseBytes), AuthData::class.java)
        cachedAuth = data
        return data
    }
}
