package leshugan.a4pda;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.URLUtil;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

import androidx.core.content.FileProvider;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    // Список установленных на устройстве приложений.
    // Параметры: icons (грузить ли base64-иконки, по умолчанию true),
    //            system (включать ли системные, по умолчанию false — только запускаемые пользовательские).
    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        boolean withIcons = Boolean.TRUE.equals(call.getBoolean("icons", true));
        boolean incSystem = Boolean.TRUE.equals(call.getBoolean("system", false));
        boolean incHidden = Boolean.TRUE.equals(call.getBoolean("hidden", false));
        PackageManager pm = getContext().getPackageManager();

        JSArray apps = new JSArray();
        List<PackageInfo> pkgs;
        try {
            pkgs = pm.getInstalledPackages(0);
        } catch (Exception e) {
            call.reject("getInstalledPackages: " + e.getMessage());
            return;
        }

        String self = getContext().getPackageName();
        for (PackageInfo pi : pkgs) {
            try {
                ApplicationInfo ai = pi.applicationInfo;
                if (ai == null) continue;
                if (pi.packageName.equals(self)) continue;

                boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean launchable = pm.getLaunchIntentForPackage(pi.packageName) != null;

                // Что показываем:
                //  - обычные (не системные, с ярлыком) — всегда;
                //  - скрытые (не системные, без ярлыка) — если incHidden;
                //  - системные — если incSystem.
                boolean show;
                if (isSystem) show = incSystem;
                else if (!launchable) show = incHidden;
                else show = true;
                if (!show) continue;

                JSObject o = new JSObject();
                o.put("packageName", pi.packageName);
                o.put("label", String.valueOf(ai.loadLabel(pm)));
                o.put("versionName", pi.versionName == null ? "" : pi.versionName);
                long vc = (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : (long) pi.versionCode;
                o.put("versionCode", vc);
                o.put("system", isSystem);
                o.put("launchable", launchable);
                o.put("enabled", ai.enabled);
                o.put("firstInstall", pi.firstInstallTime);
                o.put("lastUpdate", pi.lastUpdateTime);
                if (withIcons) {
                    try { o.put("icon", drawableToBase64(pm.getApplicationIcon(ai))); } catch (Exception ignored) {}
                }
                apps.put(o);
            } catch (Exception ignored) {}
        }

        JSObject ret = new JSObject();
        ret.put("apps", apps);
        ret.put("count", apps.length());
        call.resolve(ret);
    }

    // Открыть ссылку во внешнем браузере (тема 4pda и т.п.)
    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // Открыть 4pda внутри приложения (поиск/тема, с сохранением логина, скачивание по тапу)
    @PluginMethod
    public void openWeb(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            Intent i = new Intent(getContext(), WebViewActivity.class);
            i.putExtra("url", url);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // Системный экран «О приложении»
    @PluginMethod
    public void openAppInfo(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Удалить приложение (системный диалог)
    @PluginMethod
    public void uninstallApp(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Список скачанных apk в папке «Загрузки»
    @PluginMethod
    public void listDownloads(PluginCall call) {
        JSArray files = new JSArray();
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File[] arr = dir != null ? dir.listFiles() : null;
            if (arr != null) {
                for (File f : arr) {
                    if (f.isFile() && f.getName().toLowerCase().endsWith(".apk")) {
                        JSObject o = new JSObject();
                        o.put("name", f.getName());
                        o.put("path", f.getAbsolutePath());
                        o.put("size", f.length());
                        o.put("date", f.lastModified());
                        files.put(o);
                    }
                }
            }
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("files", files);
        call.resolve(ret);
    }

    // Установить apk по пути (системный установщик)
    @PluginMethod
    public void installApk(PluginCall call) {
        String path = call.getString("path");
        if (path == null) { call.reject("no path"); return; }
        try {
            File f = new File(path);
            if (!f.exists()) { call.reject("file not found"); return; }
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Поддерживаемые архитектуры устройства (для выбора нужного apk)
    @PluginMethod
    public void deviceAbis(PluginCall call) {        JSArray arr = new JSArray();
        try {
            String[] abis = (Build.VERSION.SDK_INT >= 21) ? Build.SUPPORTED_ABIS : new String[]{ Build.CPU_ABI };
            if (abis != null) for (String a : abis) arr.put(a);
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("abis", arr);
        call.resolve(ret);
    }

    // Версия приложения из Google Play БЕЗ входа в аккаунт:
    // анонимный токен с раздатчика auroraoss + gplayapi (AppDetailsHelper).
    @PluginMethod
    public void playVersion(final PluginCall call) {
        final String pkg = call.getString("packageName");
        if (pkg == null || pkg.isEmpty()) { call.reject("no package"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String v = PlayApi.version(getContext(), pkg);
                    if (v == null || v.isEmpty()) { call.reject("no version"); return; }
                    JSObject ret = new JSObject();
                    ret.put("versionName", v);
                    call.resolve(ret);
                } catch (Throwable e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }


    // Скачать файл из темы 4pda (с cookie логина) в «Загрузки»
    @PluginMethod
    public void download(PluginCall call) {
        String url = call.getString("url");
        String name = call.getString("name");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            r.addRequestHeader("User-Agent", UA);
            if (name == null || name.isEmpty()) name = URLUtil.guessFileName(url, null, null);
            r.setTitle(name);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.allowScanningByMediaScanner();
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) dm.enqueue(r);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Браузерный UA, как у ForPDA — чтобы 4pda не отдавал bot-заглушку
    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    // Нативный GET страницы 4pda с браузерным UA + cookie из WebView-логина.
    // Возвращает body (в правильной кодировке), status, финальный url и флаг captcha.
    @PluginMethod
    public void httpGet(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                java.net.HttpURLConnection c = null;
                try {
                    java.net.URL u = new java.net.URL(url);
                    c = (java.net.HttpURLConnection) u.openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", UA);
                    c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                    c.setRequestProperty("Accept-Language", "ru,en;q=0.9");
                    c.setRequestProperty("Accept-Encoding", "gzip, deflate");
                    String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
                    if (cookie != null) c.setRequestProperty("Cookie", cookie);

                    int code = c.getResponseCode();
                    java.io.InputStream is = (code >= 400) ? c.getErrorStream() : c.getInputStream();
                    if (is == null) is = c.getInputStream();
                    String enc = c.getContentEncoding();
                    if (enc != null && enc.toLowerCase().contains("gzip")) is = new java.util.zip.GZIPInputStream(is);
                    else if (enc != null && enc.toLowerCase().contains("deflate")) is = new java.util.zip.InflaterInputStream(is);

                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n;
                    while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
                    is.close();
                    byte[] raw = bos.toByteArray();

                    // кодировка: форум 4pda — windows-1251; определяем по Content-Type / meta
                    String charset = "UTF-8";
                    String ct = c.getContentType();
                    String head = new String(raw, 0, Math.min(raw.length, 2048), java.nio.charset.StandardCharsets.ISO_8859_1).toLowerCase();
                    if ((ct != null && (ct.toLowerCase().contains("1251") || ct.toLowerCase().contains("windows-1251")))
                            || head.contains("charset=windows-1251") || head.contains("charset=cp1251")) {
                        charset = "windows-1251";
                    }
                    String body = new String(raw, charset);
                    boolean captcha = body.contains("g-recaptcha") || body.contains("recaptcha/api") || body.contains("www.google.com/recaptcha");

                    JSObject ret = new JSObject();
                    ret.put("status", code);
                    ret.put("url", c.getURL().toString());
                    ret.put("captcha", captcha);
                    ret.put("charset", charset);
                    ret.put("body", body);
                    call.resolve(ret);
                } catch (Exception e) {
                    call.reject(e.getMessage());
                } finally {
                    if (c != null) try { c.disconnect(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    // ---- иконки → data:image/png;base64 (уменьшаем до 144px) ----

    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 144) {
            float sc = 144f / mx;
            b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try {
            if (d instanceof android.graphics.drawable.BitmapDrawable) {
                Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap();
                if (bm != null) return bm;
            }
        } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        return b;
    }
}
