package leshugan.a4pda;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.util.List;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    // Список установленных на устройстве приложений.
    // Параметры: icons (грузить ли base64-иконки, по умолчанию true),
    //            system (включать ли системные, по умолчанию false — только запускаемые пользовательские).
    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        boolean withIcons = Boolean.TRUE.equals(call.getBoolean("icons", true));
        boolean incSystem = Boolean.TRUE.equals(call.getBoolean("system", false));
        boolean incHidden = Boolean.TRUE.equals(call.getBoolean("hidden", false));
        PackageManager pm = getContext().getPackageManager();

        JSArray apps = new JSArray();
        List<PackageInfo> pkgs;
        try {
            pkgs = pm.getInstalledPackages(0);
        } catch (Exception e) {
            call.reject("getInstalledPackages: " + e.getMessage());
            return;
        }

        String self = getContext().getPackageName();
        for (PackageInfo pi : pkgs) {
            try {
                ApplicationInfo ai = pi.applicationInfo;
                if (ai == null) continue;
                if (pi.packageName.equals(self)) continue;

                boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean launchable = pm.getLaunchIntentForPackage(pi.packageName) != null;

                // Что показываем:
                //  - обычные (не системные, с ярлыком) — всегда;
                //  - скрытые (не системные, без ярлыка) — если incHidden;
                //  - системные — если incSystem.
                boolean show;
                if (isSystem) show = incSystem;
                else if (!launchable) show = incHidden;
                else show = true;
                if (!show) continue;

                JSObject o = new JSObject();
                o.put("packageName", pi.packageName);
                o.put("label", String.valueOf(ai.loadLabel(pm)));
                o.put("versionName", pi.versionName == null ? "" : pi.versionName);
                long vc = (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : (long) pi.versionCode;
                o.put("versionCode", vc);
                o.put("system", isSystem);
                o.put("launchable", launchable);
                o.put("enabled", ai.enabled);
                o.put("firstInstall", pi.firstInstallTime);
                o.put("lastUpdate", pi.lastUpdateTime);
                if (withIcons) {
                    try { o.put("icon", drawableToBase64(pm.getApplicationIcon(ai))); } catch (Exception ignored) {}
                }
                apps.put(o);
            } catch (Exception ignored) {}
        }

        JSObject ret = new JSObject();
        ret.put("apps", apps);
        ret.put("count", apps.length());
        call.resolve(ret);
    }

    // ---- иконки → data:image/png;base64 (уменьшаем до 144px) ----

    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 144) {
            float sc = 144f / mx;
            b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try {
            if (d instanceof android.graphics.drawable.BitmapDrawable) {
                Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap();
                if (bm != null) return bm;
            }
        } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        return b;
    }
}
