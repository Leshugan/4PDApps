import React, { useState, useEffect, useRef, useMemo } from "react";
import { registerPlugin, Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";

const Apps = registerPlugin("Apps");
// ==== Клавиатура: её высота лежит в CSS-переменной --t4-kb ====
// Экраны с полем ввода укорачиваются снизу на --t4-kb, поэтому шапка и список остаются в видимой
// области, а не уезжают вверх за границу экрана вместе с окном (панорамирование системы).
// Источник 1 — visualViewport (клавиатура накрывает страницу). Источник 2 — инсет IME из Android
// (window.__t4kbNative, пишет MainActivity). Если систему уже укоротила само окно — вычитать нечего.
(function () {
  try {
    const root = document.documentElement;
    let baseH = window.innerHeight, baseW = window.innerWidth;
    const apply = () => {
      const ih = window.innerHeight, iw = window.innerWidth;
      if (iw !== baseW) { baseW = iw; baseH = ih; }        // поворот экрана — эталон высоты заново
      if (ih > baseH) baseH = ih;
      const resized = baseH - ih > 60;                     // окно уже уменьшено системой (adjustResize)
      let kb = 0;
      const vv = window.visualViewport;
      if (vv) kb = Math.max(0, Math.round(ih - vv.height - vv.offsetTop));
      if (kb < 60 && !resized) kb = Math.round(window.__t4kbNative || 0);
      if (kb < 60) kb = 0;                                 // мелкие расхождения — это не клавиатура
      root.style.setProperty("--t4-kb", kb + "px");
    };
    window.t4kb = apply;
    if (window.visualViewport) { window.visualViewport.addEventListener("resize", apply); window.visualViewport.addEventListener("scroll", apply); }
    window.addEventListener("resize", apply);
    apply();
  } catch {}
})();
let _notifySet = null;                       // окно-уведомление в стиле приложения (вместо системного alert)
const notify = (text) => { if (_notifySet) _notifySet(String(text)); else { try { alert(text); } catch {} } };
function NotifyBox() {
  const [msg, setMsg] = useState("");
  useEffect(() => { _notifySet = setMsg; return () => { _notifySet = null; }; }, []);
  if (!msg) return null;
  return (
    <div onClick={() => setMsg("")} style={{ position: "fixed", inset: 0, background: C.dim, display: "flex", alignItems: "center", justifyContent: "center", padding: 24, zIndex: 90 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: 18 }}>
        <div style={{ color: C.text, fontSize: 14.5, lineHeight: 1.45, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>{msg}</div>
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 16 }}>
          <div onClick={() => setMsg("")} style={{ color: C.acc, fontSize: 14.5, fontWeight: 700, padding: "6px 10px", cursor: "pointer" }}>ОК</div>
        </div>
      </div>
    </div>
  );
}

// Полноценные темы (палитры, как у ProPDA) — каждая целиком меняет вид, а не только акцент.
const THEMES = [
  { id: "dark",       name: "Тёмная",     bg: "#161009", bar: "#20180f", card: "#241a11", border: "#342617", text: "#e9e6e2", sub: "#9a8f82", date: "#887d70", active: "#ffffff", nav: "#cbc3ba", acc: "#c8892e", blue: "#1e88e5", green: "#43a047", divider: "#342617", light: false },
  { id: "amoled",     name: "AMOLED",     bg: "#000000", bar: "#000000", card: "#0c0c0c", border: "#1e1a15", text: "#d4d1cc", sub: "#8a8178", date: "#786f65", active: "#e4e1dc", nav: "#aaa299", acc: "#c8892e", blue: "#1e88e5", green: "#43a047", divider: "#141414", light: false },
  { id: "light",      name: "Светлая",    bg: "#eef1f4", bar: "#ffffff", card: "#ffffff", border: "#d3d8de", text: "#1e2329", sub: "#6b7280", date: "#6b7280", active: "#1e2329", nav: "#3d4754", acc: "#2f80ed", blue: "#2f80ed", green: "#2e7d32", divider: "#e2e6ea", light: true },   // эталон — светлая тема YevGallery (бело-голубая)
  { id: "gruvbox",    name: "Gruvbox",    bg: "#282828", bar: "#32302f", card: "#3c3836", border: "#504945", text: "#ebdbb2", sub: "#a89984", date: "#a89984", active: "#fbf1c7", nav: "#d5c4a1", acc: "#fe8019", blue: "#83a598", green: "#b8bb26", divider: "#504945", light: false },
  { id: "dracula",    name: "Dracula",    bg: "#282a36", bar: "#343746", card: "#44475a", border: "#4d5066", text: "#f8f8f2", sub: "#a9adc4", date: "#a9adc4", active: "#ffffff", nav: "#d0d2e0", acc: "#bd93f9", blue: "#8be9fd", green: "#50fa7b", divider: "#44475a", light: false },
  { id: "nord",       name: "Nord",       bg: "#2e3440", bar: "#3b4252", card: "#3b4252", border: "#434c5e", text: "#eceff4", sub: "#a9b1c2", date: "#a9b1c2", active: "#ffffff", nav: "#d8dee9", acc: "#88c0d0", blue: "#81a1c1", green: "#a3be8c", divider: "#434c5e", light: false },
  { id: "rosepine",   name: "Rosé Pine",  bg: "#191724", bar: "#1f1d2e", card: "#26233a", border: "#302d44", text: "#e0def4", sub: "#a29fc0", date: "#a29fc0", active: "#ffffff", nav: "#d5d3ea", acc: "#c4a7e7", blue: "#9ccfd8", green: "#31748f", divider: "#26233a", light: false },
  { id: "solarized",  name: "Solarized",  bg: "#002b36", bar: "#073642", card: "#073642", border: "#0e4b5a", text: "#93a1a1", sub: "#6a8286", date: "#6a8286", active: "#eee8d5", nav: "#93a1a1", acc: "#268bd2", blue: "#268bd2", green: "#859900", divider: "#0e4b5a", light: false },
  { id: "sepia",      name: "Sepia",      bg: "#f4ecd8", bar: "#fff9ee", card: "#fff9ee", border: "#d6c5ae", text: "#5b4636", sub: "#8a7359", date: "#8a7359", active: "#3b2c1e", nav: "#6b5842", acc: "#8a5a2b", blue: "#4f7896", green: "#6b7d3a", divider: "#e2d4bd", light: true },
  { id: "greencare",  name: "Green Care", bg: "#c8e6c9", bar: "#dff0e1", card: "#dff0e1", border: "#aacdad", text: "#1b3a2b", sub: "#4a6b52", date: "#4a6b52", active: "#0f2a1c", nav: "#3a5a44", acc: "#2e7d4f", blue: "#2b6ca0", green: "#2e7d32", divider: "#b8d6bb", light: true },
];
const THEME_BY = {}; THEMES.forEach((t) => { THEME_BY[t.id] = t; });
// Material You (Monet): палитра берётся из системы (Android 12+) через native monetPalette и кэшируется.
// Из тонов system_accent1/neutral1/neutral2 собираются две полноценные темы приложения.
function buildMonetThemes(pal) {
  try {
    if (!pal || !pal.ok) return false;
    const g = (k, d) => pal[k] || d;
    const L = { id: "monet_light", name: "Monet светлая",
      bg: g("n1_50", "#f0f0f4"), bar: g("n1_10", "#fbfbff"), card: g("n1_10", "#fbfbff"),
      border: g("n2_200", "#d5d5dc"), divider: g("n1_100", "#e4e4ea"),
      text: g("n1_900", "#1b1b1f"), active: g("n1_900", "#1b1b1f"),
      sub: g("n2_600", "#5c5f66"), date: g("n2_600", "#5c5f66"), nav: g("n2_700", "#45474e"),
      acc: g("a1_600", "#2f80ed"), blue: g("a1_600", "#2f80ed"), green: "#2e7d32", light: true };
    const D = { id: "monet_dark", name: "Monet тёмная",
      bg: g("n1_900", "#1b1b1f"), bar: g("n1_800", "#2f3033"), card: g("n1_800", "#2f3033"),
      border: g("n2_700", "#45474e"), divider: g("n2_700", "#45474e"),
      text: g("n1_50", "#f0f0f4"), active: g("n1_10", "#fbfbff"),
      sub: g("n2_200", "#c6c6d0"), date: g("n2_300", "#aaabb4"), nav: g("n2_100", "#e2e2ec"),
      acc: g("a1_200", "#9fc2ff"), blue: g("a1_200", "#9fc2ff"), green: "#7bd88f", light: false };
    THEME_BY[L.id] = L; THEME_BY[D.id] = D;
    if (!THEMES.some((t) => t.id === L.id)) THEMES.splice(3, 0, L, D);   // после «Светлой»
    return true;
  } catch { return false; }
}
try { buildMonetThemes(JSON.parse(localStorage.getItem("t4_monet") || "null")); } catch {}
const C = { ...THEME_BY.dark };
function resolveThemeId(id) {
  if (id === "system") {
    if (typeof window.__t4night === "boolean") return window.__t4night ? "dark" : "light";   // нативный uiMode — надёжнее matchMedia в WebView
    try { return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark"; } catch { return "dark"; }
  }
  return THEME_BY[id] ? id : "dark";
}
function applyTheme(id) {
  const rid = resolveThemeId(id || localStorage.getItem("t4_theme") || "dark");
  const t = THEME_BY[rid];
  Object.assign(C, t);
  // производные: контрастный текст на акценте, мягкая подложка выделения, выключенный тумблер
  try { const h = C.acc.replace("#", ""); const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
        C.onAcc = (0.299 * r + 0.587 * g + 0.114 * b) > 160 ? "#1c1710" : "#ffffff";
        C.accSoft = `rgba(${r},${g},${b},${C.light ? 0.14 : 0.18})`; } catch { C.onAcc = "#ffffff"; C.accSoft = C.card; }
  C.off = C.light ? "#c9c1b6" : "#454545";
  C.input = C.light ? "#ffffff" : "#222";   // подложка полей ввода: в светлых темах белая, иначе текст цвета C.text сливался с фоном
  // производные под светлые темы: раньше эти места были захардкожены тёмными и оставались чёрными пятнами
  C.menu = C.light ? "#ffffff" : "#241a11";                                   // выпадающие меню и всплывающие плашки
  C.shadow = C.light ? "0 8px 28px rgba(30,35,41,.18)" : "0 8px 28px rgba(0,0,0,.55)";
  C.red = C.light ? "#d14343" : "#e5675e";                                    // ошибки, «нет файла», чужой процессор
  C.info = C.light ? "#2f80ed" : "#5ab0d8";                                   // иная подпись, служебные ссылки
  C.star = C.light ? "#2f80ed" : "#4d9fff";                                   // избранное
  C.verDiv = C.light ? "#d3d8de" : "#4a4a4a";                                 // разделители в строке версий
  C.hintBg = C.light ? "#e8f1fd" : "#2a2010";                                 // подсказка «каталог ещё не загружен»
  C.hintTx = C.light ? "#2f6fbf" : "#c8b48a";
  C.dbgBg = C.light ? "#e9edf1" : "#1a130b";                                  // плашка диагностики
  C.ink = C.light ? "#3d4754" : "#dcdcdc";                                    // мягкий текст строк файлов (в светлой не чисто-чёрный)
  C.dim = C.light ? "rgba(30,35,41,.35)" : "rgba(0,0,0,.55)";                 // затемнение под модалками
  try { document.documentElement.style.background = C.bg; document.body.style.background = C.bg; } catch {}
  try { window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Apps && window.Capacitor.Plugins.Apps.setBars && window.Capacitor.Plugins.Apps.setBars({ bg: C.bar, light: !!C.light }); } catch {} // системные панели под тему
}
try { applyTheme(); } catch {}
// интервал перепроверки версий (как auto_check_time у ag4pda): недавно проверенные темы пропускаются
const checkTtlMs = () => (parseInt(localStorage.getItem("t4_check_ttl") || "6", 10) || 6) * 3600 * 1000;
// Умный интервал: если версия темы не менялась много проверок подряд (c.nochg), проверяем её реже —
// активные темы остаются под ежедневным контролем, «мёртвые» перестают съедать время прохода.
const checkTtlFor = (c) => { const n = (c && c.nochg) || 0; const k = n >= 8 ? 12 : n >= 5 ? 6 : n >= 3 ? 3 : 1; return checkTtlMs() * k; };
const checkFresh = (c) => c && c.chk && (Date.now() - c.chk) < checkTtlFor(c);
const BUILD_TAG = "09.08-IA7";  // скрытый внутренний номер сборки (только для нас) — меняю на -B,-C… каждый новый установщик
const TABS = ["ИЗБРАННОЕ", "ПРИЛОЖЕНИЯ", "ИГРЫ", "ЭМУЛЯТОРЫ", "НЕ СВЯЗАННЫЕ"];
const DEMO = [
  { packageName: "com.android.chrome", label: "Chrome", versionName: "126.0", lastUpdate: Date.now() },
  { packageName: "org.telegram.messenger", label: "Telegram", versionName: "11.1.0", lastUpdate: Date.now() - 864e5 },
];

const pad = (n) => String(n).padStart(2, "0");
const fmtDate = (ms) => { if (!ms) return ""; const d = new Date(ms); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; };
// сокращение длинных версий (2026.07.06.943847899.1-release → 2026.07.06), обычные не трогаем
const apkVerName = (name) => { const m = (name || "").match(/(\d+(?:\.\d+){1,}(?:[\s._-]*(?:build|beta|alpha|rc|b)[\s._-]*\d+)?)/i); return m ? m[1].replace(/[\s._-]*(build|beta|alpha|rc|b)[\s._-]*(\d+)$/i, (q, w, d2) => " " + w.toLowerCase() + " " + d2) : ""; };
const shortVer = (v) => {
  if (!v) return v;
  if (/(beta|alpha|rc)[\s._-]*\d+/i.test(String(v))) return String(v).trim(); // пре-релиз с номером — целиком
  let s = String(v).replace(/[\s_-]*(release|stable|final|full|beta|rc)\b.*$/i, "").trim();
  if (/\bbuild\b/i.test(s)) return s; // «X.Y build NNN» показываем целиком (как ag4pda)
  const parts = s.split(".");
  if (s.length > 14 || parts.some((p) => p.replace(/\D/g, "").length >= 6)) return parts.slice(0, 3).join(".");
  return s;
};
const tileColor = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return `hsl(${h % 360} 42% 30%)`; };

// сравнение версий: 1 если a>b, -1 если a<b, 0 равны
function verCmp(a, b) {
  if (!a || !b) return 0;
  const norm = (v) => {                                    // «5.3 beta 10»: база [5,3], пре-ранг beta=2, пре-номер 10; релиз без суффикса — ранг 9
    const s = String(v).toLowerCase();
    const pm = s.match(/(alpha|beta|rc|preview|b)\s*[._-]?\s*(\d+)/);
    const base = s.replace(/(alpha|beta|rc|preview|b)\s*[._-]?\s*\d+.*/,"");
    const nums = (base.match(/\d+/g) || []).map(Number);
    const rank = pm ? ({ alpha: 1, preview: 1, b: 2, beta: 2, rc: 3 })[pm[1]] : 9;
    return { nums, rank, pn: pm ? +pm[2] : 0 };
  };
  const A = norm(a), B = norm(b);
  const n = Math.max(A.nums.length, B.nums.length);
  for (let i = 0; i < n; i++) { const x = A.nums[i] || 0, y = B.nums[i] || 0; if (x > y) return 1; if (x < y) return -1; }
  if (A.rank !== B.rank) return A.rank > B.rank ? 1 : -1;  // релиз новее беты той же базы
  if (A.pn !== B.pn) return A.pn > B.pn ? 1 : -1;          // beta10 новее beta9
  return 0;
}
const hideForum = (f) => !!(f && (f.hideAll || f.hideForum));
const hidePlay = (f) => !!(f && (f.hideAll || f.hidePlay));
const EMU_RE = /(emulator|emulador|эмулятор|retroarch|ppsspp|dolphin|epsxe|drastic|citra|yuzu|ryujinx|pcsx|redream|duckstation|mupen|melonds|dosbox|scummvm|winlator|exagear|\bmame\b|fpse|nostalgia|reicast|flycast|aethersx|eka2l1|vita3k|snes9|nesoid|gameboy|\bgba\b|vgba|gbanext|john\s?(nes|gba|snes)|matsu|myboy|my\s?boy|\bnds\b|\bn64\b|\bpsx\b|\bpsp\b|\bnes\b|\bsnes\b|\bgbc\b|\bsega\b|megadrive|genesis|dolphin|pizza\s?boy|lemuroid|classicboy|md\.emu|nds4droid|citrondb|skyline|xbsx2|damon|octopus|happychick|gamesir)/i;
const isEmu = (a) => !!a && (EMU_RE.test(a.packageName || "") || EMU_RE.test(a.label || ""));
// жанровый тег в НАЗВАНИИ ТЕМЫ 4pda — почти безошибочный маркер игры (ложных на прогах ~0%); ловит игры, залитые в программные разделы
// дата обновления (правки шапки) связанной темы — из базы, мгновенно
function normD(v) {                                      // единый формат дат везде: DD.MM.YY
  const m = (v || "").match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!m) return "";
  let y = +m[3]; if (y >= 100) y = y % 100;
  return `${String(+m[1]).padStart(2, "0")}.${String(+m[2]).padStart(2, "0")}.${String(y).padStart(2, "0")}`;
}
function catDateFor(a) {
  try {
    const c = readCache()[a.packageName];
    return normD(c && c.du);                               // ТОЛЬКО живая дата (правка шапки с проверки); каталожные даты не используются
  } catch {}
  return "";
}
// категория приложения: если тема связана — по её разделу на 4pda (эмуляторы/игры/программы), иначе по имени
function kindApp(a) {
  try {
    const c = readCache()[a.packageName];
    if (c && c.topicId) { const e = catById()[String(c.topicId)]; if (e && e.f) { const k = kindOf(e); if (k === "emu" || k === "games" || k === "apps") return k; } }
    if (c && c.kf) { const k2 = kindOf({ f: c.kf }); if (k2 === "emu" || k2 === "games" || k2 === "apps") return k2; }   // раздел пришёл от сервера — каталог не нужен
  } catch (e) {}
  return isEmu(a) ? "emu" : (a.isGame ? "games" : "apps");
}
const upd4 = (app, info) => !!(info && info.ver4pda && verCmp(info.ver4pda, app.versionName) > 0);
// быстрое извлечение версии из шапки БЕЗ парсинга DOM (регексп по тексту) — на порядки быстрее, чем полный parseTopic
// живая дата правки шапки: блок «Сообщение отредактировал» ищем СТРОГО в границах первого поста
// (граница = от первого post_body/postcolor до следующего); иначе при неправленой шапке взяли бы чужую правку
const quickHatDate = (html) => {
  try {
    const h = html || "";
    let mk = "post_body"; let a = h.indexOf(mk); if (a < 0) { mk = "postcolor"; a = h.indexOf(mk); } if (a < 0) return "";
    let b = h.indexOf(mk, a + mk.length); if (b < 0) b = h.length;   // граница — следующий пост ТЕМ ЖЕ маркером (postcolor в цитатах не рвёт)
    const i = h.indexOf("Сообщение отредактировал", a);
    if (i < 0 || i > b) return "";                        // у шапки правок нет — живую дату не пишем
    const seg = h.slice(i, i + 500).replace(/<[^>]+>/g, " ");
    const d = seg.match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!d) return "";
    const dd = +d[1], mm = +d[2]; let y = +d[3]; if (y < 100) y += 2000;
    if (dd < 1 || dd > 31 || mm < 1 || mm > 12 || y < 2005 || y > new Date().getFullYear()) return "";
    return normD(d[0]);
  } catch { return ""; }
};
const quickVer = (html) => {
  const txt = (html || "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/&#?\w+;/g, " ");
  // «Версия[ чего-то]: [v]X.Y[.Z]» — допускаем короткую вставку и префикс v; число обязательно с точкой; не дата
  let m = txt.match(/верси[яию][^\d\n]{0,25}?v?\s*([0-9]+(?:\.[0-9]+)+(?:\s*(?:build|beta|alpha|rc|b)\s*[._-]?\s*\d+)?)/i);
  if (m && !/^\d{1,2}\.\d{1,2}\.\d{2,4}$/.test(m[1])) return m[1].replace(/\.+$/, "");
  // из имени apk-файла в шапке
  m = (html || "").match(/[-_ v(\/]([0-9]+(?:\.[0-9]+)+)[^\s"'<>]*?\.(?:apk|apks|xapk)/i);
  if (m) return m[1];
  return "";
};
const updP = (app, info) => !!(info && info.verPlay && verCmp(info.verPlay, app.versionName) > 0);
// нужно ли обновление (новее установленной и не скрыто пользователем)
const needsUpdate = (app, info) => {
  if (!info || !app) return false;
  const f = info.flags || {};
  if (f.hidden) return false; // приложение скрыто пользователем — в «Доступных обновлениях» не показываем
  return (upd4(app, info) && !hideForum(f)) || (updP(app, info) && !hidePlay(f));
};

// архитектуры устройства (для выбора нужного apk)
let DEVICE_ABIS = [];
Apps.deviceAbis().then((r) => { DEVICE_ABIS = r.abis || []; }).catch(() => {});
const ABI_TOKENS = { "arm64-v8a": ["arm64", "arm8a", "aarch64", "v8a"], "armeabi-v7a": ["arm7a", "armeabi", "armv7", "v7a"], "x86_64": ["x86_64", "x86-64", "x64"], "x86": ["x86"] };
const SDK_VER = { 9: "2.3", 10: "2.3", 14: "4.0", 15: "4.0", 16: "4.1", 17: "4.2", 18: "4.3", 19: "4.4", 21: "5.0", 22: "5.1", 23: "6.0", 24: "7.0", 25: "7.1", 26: "8.0", 27: "8.1", 28: "9", 29: "10", 30: "11", 31: "12", 32: "12L", 33: "13", 34: "14", 35: "15" };
function fileForDevice(name) {
  const n = (name || "").toLowerCase();
  if (!/(arm64|arm7a|armeabi|armv7|x86|aarch64|v8a|v7a)/.test(n)) return true;
  for (const abi of DEVICE_ABIS) for (const t of (ABI_TOKENS[abi] || [])) if (n.includes(t)) return true;
  return false;
}
// какие ABI указаны в имени файла (пусто = универсальный, метки нет)
function fileAbis(name) {
  const n = (name || "").toLowerCase();
  const r = [];
  if (/arm64|aarch64|v8a|arm8a/.test(n)) r.push("arm64-v8a");
  if (/armeabi|armv7|arm7a|v7a/.test(n)) r.push("armeabi-v7a");
  if (/x86[_-]?64|\bx64\b/.test(n)) r.push("x86_64");
  else if (/x86/.test(n)) r.push("x86");
  return r;
}
// ABI из строки apkInfo.abis (реальные папки lib/<abi> в apk)
function parseAbis(s) {
  const t = (s || "").toLowerCase(); const r = [];
  if (/arm64-v8a|arm64|aarch64|v8a/.test(t)) r.push("arm64-v8a");
  if (/armeabi-v7a|armeabi|armv7|v7a/.test(t)) r.push("armeabi-v7a");
  if (/x86_64|x86-64/.test(t)) r.push("x86_64"); if (/x86(?!_?64|-64)/.test(t)) r.push("x86");
  if (/mips64/.test(t)) r.push("mips64"); if (/mips(?!64)/.test(t)) r.push("mips");
  return r;
}
function devSupportsAbi(abi) {
  const a = String(abi || "").toLowerCase();
  const list = (DEVICE_ABIS || []).map((d) => String(d || "").toLowerCase());
  if (list.some((d) => d === a)) return true;
  // 64-битные процессоры запускают и 32-битные сборки: arm64 берёт armeabi/v7a, x86_64 берёт x86
  if ((a === "armeabi" || a === "armeabi-v7a") && list.some((d) => d.startsWith("arm"))) return true;
  if (a === "x86" && list.some((d) => d.startsWith("x86"))) return true;
  return false;
}


// ссылки 4pda / play
const q4 = (app) => encodeURIComponent(app.label || app.packageName);
const topicUrl = (app) => app.topicId ? `https://4pda.to/forum/index.php?showtopic=${app.topicId}` : `https://4pda.to/forum/index.php?act=search&query=${q4(app)}`;
const openTopicApp = (app) => Apps.openWeb({ url: topicUrl(app) }).catch(() => {});
const openPlay = (app) => Apps.openUrl({ url: `market://details?id=${app.packageName}` }).catch(() => Apps.openUrl({ url: `https://play.google.com/store/apps/details?id=${app.packageName}` }));

// --- парсинг темы 4pda ---
// извлечь apk-ссылки из любого DOM-узла (шапка или пост-анонс)
function apksFromScope(scope, postUrl) {
  const out = [], seen = new Set();
  if (!scope) return out;
  scope.querySelectorAll("a[href]").forEach((a) => {
    let url = a.getAttribute("href") || "";
    if (!url) return;
    const text = (a.textContent || "").replace(/\s+/g, " ").trim();
    const isDl = /\/dl\/post\/|\/dl\/|act=attach|attach_id=|getattach|code=attach/i.test(url);
    const apkInUrl = /\.(apk|apks|xapk|zip|obb)(\?|#|$)/i.test(url);
    const apkInText = /\.(apk|apks|xapk|zip|obb)\b/i.test(text);
    if (!isDl && !apkInUrl && !apkInText) return;
    if (url.indexOf("//") === 0) url = "https:" + url;
    if (url.indexOf("http") !== 0) url = "https://4pda.to" + (url[0] === "/" ? "" : "/") + url;
    let name = "";
    const um = url.match(/\/dl\/post\/\d+\/([^?#]+)/i) || url.match(/\/([^\/?#]+\.(?:apk|apks|xapk|zip|obb))(?:\?|#|$)/i);
    if (um) { try { name = decodeURIComponent(um[1]); } catch { name = um[1].replace(/%[0-9a-f]{0,2}/gi, ""); } }
    if (!/\.(apk|apks|xapk|zip|obb)$/i.test(name)) { const tm = text.match(/([^\s][^\n]*?\.(?:apk|apks|xapk|zip|obb))\b/i); if (tm) name = tm[1].trim(); }
    if (!/\.(apk|apks|xapk|zip|obb)$/i.test(name)) return;
    name = name.replace(/\+/g, " ").trim();
    const key = url.replace(/&amp;/g, "&");
    if (seen.has(key)) return; seen.add(key);
    let size = "";
    let sib = a.nextSibling, guard = 0;
    while (sib && guard < 5 && !size) { if (sib.nodeType === 3) { const tt = sib.textContent || ""; const s = tt.match(/\(([^)]*(?:МБ|MB|КБ|KB)[^)]*)\)/i) || tt.match(/\(([\d.,]+\s*[A-Za-zА-Яа-я]+)\)/); if (s) size = s[1].trim(); } sib = sib.nextSibling; guard++; }
    // версия из текста рядом (заголовок «AppName 3.7.0» / «Версия: 3.7.0») — для файлов без версии в имени
    let fver = "";
    { let txt = ""; for (let p = a.previousSibling, g = 0; p && g < 10; p = p.previousSibling, g++) { if (p.nodeType === 1 && p.tagName === "A") { const h = p.getAttribute("href") || ""; if (/\/dl\/post\/|\.(apk|apks|xapk)/i.test(h)) break; } txt = (p.textContent != null ? p.textContent : (p.nodeValue || "")) + " " + txt; if (txt.length > 220) break; }
      let m = txt.match(/верси[яию][^\d\n]{0,20}?v?\s*([0-9]+(?:\.[0-9]+)+(?:\s*(?:build|b)\s*\d+)?)/i);
      if (!m) { const cands = txt.match(/\b[0-9]+(?:\.[0-9]+){1,}\b/g) || []; for (let i = cands.length - 1; i >= 0; i--) { if (!/^\d{1,2}\.\d{1,2}\.\d{2,4}$/.test(cands[i])) { m = [null, cands[i]]; break; } } }
      if (m) fver = m[1];
    }
    // файл из шапки (postUrl пуст): рядом стоит ссылка-заголовок версии на пост (findpost) — она и есть пост этого файла
    let pu = postUrl || "";
    if (!pu) { const isFp = (h) => /view=findpost|act=findpost|[?&]p=\d/i.test(h || ""); const isDlLink = (h) => /\/dl\/post\/|act=attach|getattach|\.(apk|apks|xapk|zip|obb)(\?|#|$)/i.test(h || ""); let near = "";
      for (let p = a.previousElementSibling, g = 0; p && g < 14 && !near; p = p.previousElementSibling, g++) {
        if (p.tagName === "A") { const h = p.getAttribute("href") || ""; if (isFp(h)) { near = h; break; } if (isDlLink(h)) break; }
        else if (p.querySelectorAll) { const fs = p.querySelectorAll("a[href]"); let stop = false; for (let i = fs.length - 1; i >= 0; i--) { const h = fs[i].getAttribute("href") || ""; if (isFp(h)) { near = h; break; } if (isDlLink(h)) { stop = true; break; } } if (near || stop) break; }
      }
      if (near) { if (near.indexOf("//") === 0) near = "https:" + near; else if (near.indexOf("http") !== 0) near = "https://4pda.to" + (near[0] === "/" ? "" : "/") + near; pu = near.replace(/&amp;/g, "&"); }
    }
    out.push({ name, url: key, size, downloads: "", postUrl: pu, ver: fver });
  });
  return out;
}
// извлечь apk из конкретного поста-анонса (страница findpost)
function parseApkLinks(html, postUrl) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const pid = postUrl && ((postUrl.match(/[?&]p=(\d+)/) || postUrl.match(/pid=(\d+)/) || postUrl.match(/entry(\d+)/) || [])[1]);
  let out = [];
  if (pid) {
    const post = doc.querySelector("#entry" + pid) || doc.querySelector('a[name="entry' + pid + '"]') || doc.querySelector("#p" + pid) || doc.querySelector('[data-post="' + pid + '"]') || doc.querySelector('[id*="' + pid + '"]');
    if (post) {
      let scope = (post.classList && (post.classList.contains("post_body") || post.classList.contains("postcolor"))) ? post : (post.querySelector ? post.querySelector(".post_body, .postcolor") : null);
      if (!scope && post.closest) scope = post.closest(".post_body, .postcolor");
      if (!scope) { const bodies = Array.from(doc.querySelectorAll(".post_body, .postcolor")); for (const b of bodies) { if (post.compareDocumentPosition(b) & 4) { scope = b; break; } } } // тело поста сразу после якоря entry{pid}
      if (scope) {
        // вложения поста («Прикреплённые файлы») лежат ВНЕ тела — поднимаемся к контейнеру поста, пока в нём ровно одно тело
        let cont = scope, up = scope.parentElement, g = 0;
        while (up && g < 4) { let nb = 99; try { nb = up.querySelectorAll(".post_body, .postcolor").length; } catch {} if (nb > 1) break; cont = up; up = up.parentElement; g++; }
        return apksFromScope(cont, postUrl); // тело + вложения этого поста; чужие посты не подмешиваем
      }
      return []; // тела/apk нет — это не пост-анонс
    }
  }
  // пост по id не найден (или postUrl не findpost) — собираем apk со всех сообщений страницы
  doc.querySelectorAll(".post_body, .postcolor").forEach((b) => { out = out.concat(apksFromScope(b, postUrl)); });
  const seen = new Set(); out = out.filter((f) => { if (seen.has(f.url)) return false; seen.add(f.url); return true; });
  return out;
}

async function startDownload(opts) {
  // ссылка вида /forum/dl/post/... требует входа на сайт. Если у файла известен номер вложения,
  // берём у служебного сервера ПРЯМУЮ ссылку с ключом — она качается без авторизации
  try {
    // ПРОВЕРЕНО: гостю служебный сервер ссылку на вложение НЕ даёт (нужен вход в самом протоколе),
    // поэтому качаем по обычной ссылке форума с сессией — как и раньше
    if (false) {}
  } catch {}
  // «всегда спрашивать, куда сохранить» — сначала выбор папки для этой загрузки
  try {
    if (localStorage.getItem("t4_dl_ask") === "1") {
      const r = await Apps.pickDownloadFolder();
      if (r && r.ok && r.uri) opts = { ...opts, saveDir: r.uri };
      else if (r && r.ok === false) return; // выбор отменён — не качаем
    }
  } catch {}
  try { await Apps.dlStart(opts); } catch {}
}
function parseTopic(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const firstBody = doc.querySelector(".post_body") || doc.querySelector(".postcolor");
  let hatIcon = "";
  let forumDate = "";
  try { const og = doc.querySelector('meta[property="og:image"], meta[name="twitter:image"], meta[property="twitter:image"], link[rel="image_src"]'); const c = og && (og.getAttribute("content") || og.getAttribute("href")); if (c) hatIcon = c.trim(); } catch {}
  if (!hatIcon && firstBody) { try { const im = firstBody.querySelector("img"); const src = im && (im.getAttribute("src") || im.src); if (src) hatIcon = src.trim(); } catch {} }
  if (hatIcon) { if (hatIcon.startsWith("//")) hatIcon = "https:" + hatIcon; else if (hatIcon.startsWith("/")) hatIcon = "https://4pda.to" + hatIcon; }
  try { const pd = doc.querySelector(".post_date"); if (pd) forumDate = (pd.textContent || "").replace(/\s+/g, " ").trim(); } catch {}
  // картинки: всё, что НЕ под спойлером, убираем из описания; под спойлером — оставляем на месте
  if (firstBody) {
    firstBody.querySelectorAll("img").forEach((im) => {
      if (im.closest && im.closest('[class*="spoil"], .sp-wrap, .sp-body, .block-spoiler')) return;
      im.remove();
    });
  }
  const screenshots = []; // отдельной ленты скриншотов нет — картинки под спойлером остаются в описании
  let descHtml = firstBody ? firstBody.innerHTML : "";
  descHtml = descHtml.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "");
  descHtml = descHtml.replace(/<span[^>]*class="[^"]*edit[^"]*"[\s\S]*?<\/span>/gi, "");
  descHtml = descHtml.replace(/Сообщение отредактировал[\s\S]*?(?:Причина редактирования:[^<]*)?(?=<div|<br|<span|<p|$)/gi, "");
  descHtml = descHtml.replace(/<div[^>]*class="[^"]*signature[^"]*"[\s\S]*?<\/div>/gi, "");
  const tmp = document.createElement("div"); tmp.innerHTML = descHtml;
  const descText = (tmp.textContent || "").replace(/\s+/g, " ").trim();
  let ver4pda = "";
  const vm = descText.match(/верси[яию]\s*:?\s*v?\s*([0-9][0-9.]*(?:\s*(?:build|b)\s*\d+)?)/i);
  if (vm) ver4pda = vm[1];
  // название приложения уже в шапке — убираем ведущий заголовок с названием (до блока «Версия», если он в начале)
  { const cutText = descText.search(/Верси[яию]\s*(?:программы|приложения)?\s*:/i); if (cutText >= 0 && cutText < 200) { const cut = descHtml.search(/Верси[яию]\s*(?:программы|приложения)?\s*:/i); if (cut > 0) { let s = cut; const back = descHtml.lastIndexOf("<", cut); if (back >= 0 && cut - back < 40) s = back; descHtml = descHtml.slice(s); } } }

  const scope = firstBody || doc;
  const files = apksFromScope(scope, "");
  for (const f of files) { if (!f.ver && ver4pda) f.ver = ver4pda; } // файлы из шапки помечаем версией шапки (у многих в имени файла версии нет)
  // ссылки на посты-анонсы версий (там лежат apk у тем вроде Instagram) + версия из текста рядом
  const dlPosts = []; const dseen = new Set();
  scope.querySelectorAll("a[href]").forEach((a) => {
    let href = a.getAttribute("href") || "";
    if (!/findpost|[?&]pid=\d|#entry\d|act=findpost/i.test(href)) return;
    if (href.indexOf("//") === 0) href = "https:" + href;
    if (href.indexOf("http") !== 0) href = "https://4pda.to" + (href[0] === "/" ? "" : "/") + href;
    const key = href.replace(/&amp;/g, "&");
    if (dseen.has(key)) return; dseen.add(key);
    let ver = "";
    const selfT = (a.textContent || "").trim();
    let sm = selfT.match(/верси[яию]\s*:?\s*([0-9]+(?:\.[0-9]+)+(?:\s*(?:build|b)\s*\d+)?)/i) || selfT.match(/^v?\s*([0-9]+(?:\.[0-9]+)+(?:\s*(?:build|b)\s*\d+)?)\s*[»)\]]*$/i); // текст ссылки = просто версия («3.7.0 »»)
    if (sm) ver = sm[1];
    let prev = a.previousSibling, guard = 0;
    while (prev && guard < 4 && !ver) { const t = (prev.textContent != null ? prev.textContent : (prev.nodeValue || "")); const m = t.match(/верси[яию]\s*:?\s*([0-9][0-9.]+(?:\s*(?:build|b)\s*\d+)?)/i); if (m) ver = m[1]; prev = prev.previousSibling; guard++; }
    if (!ver && a.parentElement) { const pt = (a.parentElement.textContent || ""); if (pt.length <= 200) { const m = pt.match(/верси[яию]\s*:?\s*([0-9][0-9.]+(?:\s*(?:build|b)\s*\d+)?)/i); if (m) ver = m[1]; } } // длинный родитель = весь пост, его версию чужим ссылкам не приписываем
    dlPosts.push({ url: key, ver });
  });
  if (!ver4pda && files[0]) { ver4pda = apkVerName(files[0].name); }
  // краткое описание как у ag4pda: блок «Краткое описание …» до следующего раздела; иначе пусто (без версии/дат)
  let short = "";
  const sm = descText.match(/краткое описание\s*:?\s*(.+?)(?:\s*(?:полное\s+описание|^описание\b|описание\s*:|системные требования|требовани|что нового|русский интерфейс|разработчик|версия\s*:|официальн|скриншот)|$)/i);
  if (sm) short = sm[1];
  else { const dm = descText.match(/описание\s*:?\s*(.{8,}?)(?:\s*(?:системные требовани|требовани|что нового|версия\s*:|скриншот)|$)/i); if (dm) short = dm[1]; }
  short = short.replace(/^[\s:–\-—]+/, "").replace(/\s+/g, " ").trim().slice(0, 140);
  if (!short) { const parts = descText.split(/(?:\.\s+|\n|;\s+|•|·)/).map((s) => s.trim()).filter((s) => s.length >= 25 && !/^(верси|текущ|разработ|категори|цена|систем|требова|русск|что нов|скачать|google|домашн|автор|обновл|размер|прошив|android|поддерж|локализ|перевод|сборк|исходн|официальн|рейтинг|жанр|оценк)/i.test(s)); if (parts.length) short = parts[0].replace(/\s+/g, " ").trim().slice(0, 140); }
  // дата обновления шапки/темы (как post_update у ag4pda) — пробуем несколько формулировок, берём самую свежую
  let hatDate = "";
  try {
    const curY = new Date().getFullYear();
    const dnumLocal = (v) => { const m = (v || "").match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!m) return 0; const dd = +m[1], mm = +m[2]; if (dd < 1 || dd > 31 || mm < 1 || mm > 12) return 0; let y = +m[3]; if (y < 100) y += 2000; if (y < 2005 || y > curY) return 0; return y * 10000 + mm * 100 + dd; }; // диапазон года отсекает версии вида «2.8.99»
    // основной источник (как в каталоге): «Сообщение отредактировал <ник> - DD.MM.YY, HH:MM» — однозначно дата, не версия
    const flat = (descText || "").replace(/\s+/g, " ");
    const em = flat.match(/Сообщение отредактировал[^-–—]*[-–—]\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/);
    if (em && dnumLocal(em[1])) hatDate = em[1];
    if (!hatDate) {
      const dates = [];
      const reList = [/шапк[еи]\s*:?\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/ig, /обновление\s+шапки\s*:?\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/ig, /(\d{1,2}\.\d{1,2}\.\d{2,4})\s*(?:г\.?)?\s*(?:—|-)?\s*обновл/ig];
      for (const re of reList) { let m; while ((m = re.exec(descText)) !== null) { const v = m[1]; const d = dnumLocal(v); if (d) dates.push([d, v]); } }
      if (dates.length) { dates.sort((a, b) => b[0] - a[0]); hatDate = dates[0][1]; }
    }
  } catch {}
  let title = "";
  try { const t = doc.querySelector("title"); if (t) title = (t.textContent || "").replace(/\s*[-–|]\s*4PDA.*$/i, "").replace(/&amp;/g, "&").trim(); } catch {}
  // основное описание (как у ag4pda): блок «Описание …» до следующего раздела; чистим от версии/требований/чейнджлога
  const SECT = "(?:что нового|нововведени|системные требовани|требовани|особенности|поддерживаем|скриншот|снимк|разработчик|версия\\s*:|последнее обновление|перевод|автор перевода|сборк|скачать|download)";
  let descMain = "";
  const dmm = descText.match(new RegExp("(?:краткое описание[\\s\\S]*?)?(?:^|[\\s.:])описание\\s*:?\\s*([\\s\\S]+?)(?=" + SECT + "|$)", "i"));
  if (dmm && dmm[1].trim().length > 20) descMain = dmm[1].trim();
  else { descMain = descText.split(new RegExp(SECT, "i"))[0].replace(/^краткое описание\s*:?/i, "").trim(); }
  descMain = descMain.replace(/^[\s:–\-—]+/, "").slice(0, 2500);
  return { descHtml, descMain, descText, short, ver4pda, hatDate, forumDate, title, hatIcon, files, dlPosts, screenshots };
}
// windows-1251 URL-кодирование (форумный поиск 4pda требует cp1251)
function cp1251(str) {
  let out = "";
  for (const ch of str) {
    const c = ch.charCodeAt(0);
    let byte = -1;
    if (c < 128) { out += encodeURIComponent(ch); continue; }
    else if (c >= 0x0410 && c <= 0x044F) byte = c - 0x0410 + 0xC0;
    else if (c === 0x0401) byte = 0xA8;
    else if (c === 0x0451) byte = 0xB8;
    if (byte < 0) { out += encodeURIComponent(ch); continue; }
    out += "%" + byte.toString(16).toUpperCase().padStart(2, "0");
  }
  return out;
}
// правильный URL форумного поиска 4pda (noform=1 => сразу результаты, а не форма)
const searchUrl4pda = (query, source = "all", forums = [212], subforums = true, st = 0) =>
  `https://4pda.to/forum/index.php?act=search&result=topics&source=${source}&query=${cp1251(query)}${(forums || []).map((f) => `&forums=${f}`).join("")}${subforums ? "&subforums=1" : ""}&noform=1&st=${st}&exclude_trash=0`;

// разбор страницы результатов поиска: [{topicId, title}] за один запрос
function parseSearchResults(html) {
  if (!html) return [];
  if (/не дал никаких результатов|ничего не найдено|По вашему запросу ничего/i.test(html)) return [];
  const doc = new DOMParser().parseFromString(html, "text/html");
  const out = [], seen = new Set();
  const nonAndroid = /\[(ios|iphone|ipad|ipados|desktop|windows|win(?:32|64)?|wp7|wp8|wp10|wp7-10|wp|mac(?:os)?|symbian|linux|web(?:os)?|java|bada|blackberry|bb10?|tizen|kaios)\]/i;
  // 1) старый десктопный формат с data-topic
  doc.querySelectorAll("[data-topic]").forEach((div) => {
    const topicId = div.getAttribute("data-topic");
    if (!topicId || !/^\d{3,}$/.test(topicId) || seen.has(topicId)) return;
    const a = div.querySelector('a[href*="showtopic="]') || div.querySelector("a");
    const title = ((a && a.textContent) || "").replace(/\s+/g, " ").trim();
    if (title.length < 2 || nonAndroid.test(title)) return;
    const dsc = div.querySelector(".topic_desc");
    const forumId = dsc ? ((dsc.innerHTML.match(/showforum=(\d+)/) || [])[1] || "") : "";
    let short = "";
    if (dsc) { const t = (dsc.textContent || "").replace(/\s+/g, " "); const fm = t.split(/форум\s*:/i)[0].trim(); if (fm && fm.length > 2) short = fm.slice(0, 140); }
    if (short && nonAndroid.test(short)) return; // тег чужой ОС в описании (напр. [iPhone])
    seen.add(topicId);
    out.push({ topicId, title, forumId, short });
  });
  if (out.length) return out;
  // 2) текущий десктопный формат: берём ВСЕ ссылки тем на странице (узкий блок «Результаты поиска» терял часть строк); лишнее отсечёт фильтр релевантности и форума
  const marker = /^(новые|новый|последн|перейти|ответить|цитата|»+|«+|→|\d+|\.+)$/i;
  let scope = null;
  const heads = doc.querySelectorAll(".maintitle, .cat_name, .category");
  for (const h of heads) { if (/Результаты поиска/i.test(h.textContent || "")) { scope = h.closest(".borderwrap") || (h.parentElement ? h.parentElement : null); break; } }
  const root = doc;
  root.querySelectorAll('a[href*="showtopic="], a[href*="/forum/topic/"]').forEach((a) => {
    const href = a.getAttribute("href") || "";
    if (/view=getnewpost|view=getlastpost|view=findpost|&pid=|#entry|act=|&p=\d/i.test(href)) return;
    const m = href.match(/(?:showtopic=|\/forum\/topic\/)(\d{3,})/);
    if (!m || seen.has(m[1])) return;
    const title = (a.textContent || "").replace(/\s+/g, " ").trim();
    if (title.length < 3 || marker.test(title) || nonAndroid.test(title)) return;
    // короткое описание + форум результата (для отсева не-Android без загрузки темы)
    let short = "", forumTxt = "";
    const row = a.closest("tr, .topic, li, div");
    if (row) {
      const rt = (row.textContent || "").replace(/\s+/g, " ").replace(title, "").trim();
      const fa = row.querySelector('a[href*="showforum="]');
      const fname = fa && fa.textContent ? fa.textContent.trim() : "";
      let rtShort = rt;
      // отрезаем всё, начиная с названия форума и/или даты-статистики (чтобы не липло "Архив программАвтор...")
      if (fname && fname.length > 2 && rtShort.indexOf(fname) > 3) rtShort = rtShort.slice(0, rtShort.indexOf(fname));
      rtShort = rtShort.split(/\d{2}\.\d{2}\.\d{2,4}/)[0].replace(/\s+/g, " ").trim();
      if (rtShort.length > 4) short = rtShort.slice(0, 140);
      forumTxt = (fname || rt).toLowerCase();
    }
    // если форум явно не Android — пропускаем
    if (/iphone|ipad|ipod|ios|apple|mac\s?os|windows|symbian|bada|blackberry|tizen|java\b|wp\d/.test(forumTxt) && !/android/.test(forumTxt)) return;
    if (short && nonAndroid.test(short)) return; // тег чужой ОС в описании (напр. [iPhone])
    seen.add(m[1]);
    out.push({ topicId: m[1], title, short });
  });
  return out;
}

const playPkg = (html) => {
  if (!html) return null;
  const PKG = "([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+){1,})";
  // 1) пакет прямо в шапке текстом: «Имя пакета: com.x.y» / «packageName: com.x.y»
  let m = html.match(new RegExp("Имя\\s*пакета[\\s\\S]{0,30}?" + PKG, "i"))
       || html.match(new RegExp("package\\s*name[\\s\\S]{0,30}?" + PKG, "i"))
       || html.match(new RegExp("packageName['\":\\s]{0,8}" + PKG, "i"));
  if (m) return m[1];
  // 2) ссылка Google Play / market
  m = html.match(/play\.google\.com\/store\/apps\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  if (m) return m[1];
  m = html.match(/market:\/\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  return m ? m[1] : null;
};
function topicIds(html) {
  const ids = [], seen = new Set();
  // showtopic=<id> (в т.ч. относительные ссылки) И новый формат /forum/topic/<id>
  const re = /(?:showtopic=|\/forum\/topic\/)(\d{3,})/gi;
  let m; while ((m = re.exec(html)) !== null) if (!seen.has(m[1])) { seen.add(m[1]); ids.push(m[1]); }
  return ids;
}

// поиск темы: собираем кандидатов из поиска 4pda (пакет+название) и Google (site:4pda.to),
// берём ТОЛЬКО тему, где в шапке ссылка Play с этим пакетом. "captcha" | {topicId,html} | null
const isAppPage = (html) => !!(playPkg(html) || /dw_button|onclick="dw\(|nav_download|attach_id=|Загрузить с сервера|"attachment"|post-attach/i.test(html));
// тема именно про Android (а не iOS/Windows/Symbian)
const isAndroidTopic = (html) => {
  if (!html) return true;
  const android = /Требуется\s*Android|Android\s*[\d.]+\s*(?:и выше|\+)|play\.google\.com|market:\/\/|\.apk\b|\.apks\b|\.xapk\b|Имя\s*пакета/i.test(html);
  const otherOs = /Требуется\s*iOS|Требуется\s*iPhone|Совместимо с iOS|App Store|itunes\.apple|Windows\s*Phone|Требуется\s*Windows|\.ipa\b|Cydia|jailbreak|Symbian/i.test(html);
  if (android) return true;
  if (otherOs) return false;
  return true;
};

// ==================== БЫСТРАЯ ПРОВЕРКА (тумблер «Быстрая проверка» в настройках) ====================
// Идея: не открывать каждую тему, а читать СПИСКИ ТЕМ разделов — в заголовке темы почти всегда есть
// версия («Simple Keyboard [125.2]»). Один запрос на раздел вместо десятков запросов по темам.
// Листаем страницы раздела (сортировка по последнему сообщению), пока даты новее прошлой отметки.
const dnQ0 = (v) => { const m = (v || "").match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!m) return 0; let y = +m[3]; if (y < 100) y += 2000; return y * 10000 + (+m[2]) * 100 + (+m[1]); };
const tdy0 = () => { const d = new Date(); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };
const fastOn = () => true;   // быстрая проверка включена всегда   // включена по умолчанию: 4pda режет по числу запросов, а не по объёму
const FSCAN_KEY = "t4_fscan";                                   // forumId -> дата (yyyymmdd), на которой закончили прошлый раз
const fscanRead = () => { try { return JSON.parse(localStorage.getItem(FSCAN_KEY) || "{}"); } catch { return {}; } };
const fscanWrite = (o) => { try { localStorage.setItem(FSCAN_KEY, JSON.stringify(o)); } catch {} };
const dnum = (v) => { const m = (v || "").match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!m) return 0; let y = +m[3]; if (y < 100) y += 2000; return y * 10000 + (+m[2]) * 100 + (+m[1]); };
// версия из ЗАГОЛОВКА темы: берём последние скобки с цифрой, нормализуем как имена файлов (беты понимает)
const titleVer = (title) => {
  const t = String(title || "");
  const br = t.match(/\[([^\[\]]*\d[^\[\]]*)\]/g);
  if (!br || !br.length) return "";
  for (let i = br.length - 1; i >= 0; i--) {
    const inner = br[i].slice(1, -1);
    if (/^(?:android|ios|русск|rus|eng|mod|premium|pro|beta|free|платн|бесплат)/i.test(inner.trim())) continue;
    const v = apkVerName(inner);
    if (v) return v;
  }
  return "";
};
// разбор страницы списка тем раздела: topicId + заголовок + дата последнего сообщения
function parseForumList(html) {
  const out = new Map();
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll('a[href*="showtopic="], a[href*="index.php?t"]').forEach((a) => {
      const m = (a.getAttribute("href") || "").match(/showtopic=(\d+)|[?&]t(\d+)\b/);
      if (!m) return;
      const tid = m[1] || m[2];
      const title = (a.textContent || "").replace(/\s+/g, " ").trim();
      if (!tid || !title || title.length < 3) return;
      const row = (a.closest && a.closest("tr")) || a.parentElement;
      const ts = dnum(((row && row.textContent) || "").replace(/\s+/g, " "));
      const prev = out.get(tid);
      if (!prev || title.length > prev.title.length) out.set(tid, { topicId: tid, title, ts: ts || (prev && prev.ts) || 0 });
    });
  } catch {}
  return [...out.values()];
}
// один проход по разделам: возвращает Map topicId -> версия из заголовка
async function fastScanForums(forums, stat, alive) {
  const found = new Map();
  const marks = fscanRead();
  const jobs = [...forums.entries()];
  let ji = 0;
  const one = async ([fid, need]) => {
    if (!alive()) return;
    const stopAt = marks[fid] || 0;
    let newest = 0, got = 0;
    for (let page = 0; page < 2 && alive(); page++) {
      // сперва ЛЁГКАЯ lofi-страница раздела (5-15КБ вместо 200-300КБ), обычная — только если lofi пуст
      let r = null, list = [];
      if (protoOn() && page === 0) {                                  // сперва служебный сервер: список тем раздела одним запросом
        try {
          const pr = await Apps.protoForum({ host: "app.4pda.to", port: 993, forumIds: [String(fid)], from: 0, count: 30, ver: protoVer(), waitMs: 15000 });
          const raw = (((pr && pr.items) || [])[0] || {}).raw || "";
          const re = /\[(\d),(\d{3,9}),"((?:[^"\\]|\\.)*)"/g; let m;
          while ((m = re.exec(raw))) { const ttl = protoClean(m[3]); if (ttl.length > 2) list.push({ topicId: m[2], title: ttl, ts: 0 }); }
        } catch {}
      }
      if (!list.length) { try { r = await t4http(`https://4pda.to/forum/lofiversion/index.php?f${fid}&st=${page * 30}`, true); } catch {}
        list = parseForumList((r && r.body) || ""); }
      if (!list.length) {
        try { r = await t4http(`https://4pda.to/forum/index.php?showforum=${fid}&prune_day=100&sort_by=Z-A&sort_key=last_post&st=${page * 30}`, true); } catch {}
        list = parseForumList((r && r.body) || "");
      }
      if (!list.length) break;
      stat.pages++;
      let oldPage = true;
      for (const it of list) {
        if (it.ts) { if (it.ts > newest) newest = it.ts; if (it.ts >= stopAt) oldPage = false; }
        else oldPage = false;
        if (!need.has(it.topicId)) continue;
        const v = titleVer(it.title);
        if (v) { found.set(it.topicId, v); got++; }
        need.delete(it.topicId);
      }
      if (!need.size) break;                       // все нужные темы раздела уже нашлись
      if (stopAt && oldPage) break;                // страница целиком старше прошлой отметки — дальше не листаем
    }
    if (newest) { marks[fid] = newest; }
    stat.sect++; stat.fromSect += got;
  };
  const runner = async () => { while (alive()) { const i = ji++; if (i >= jobs.length) break; await one(jobs[i]); } };
  await Promise.all(Array.from({ length: 4 }, runner));   // 4 раздела одновременно
  fscanWrite(marks);
  return found;
}
// дайджесты 4pda (программы/игры) — одна страница на каждый, как подстраховка
async function fastScanDigest(needIds, stat, alive) {
  const found = new Map();
  for (const tid of ["127361", "381335"]) {
    if (!alive() || !needIds.size) break;
    let r = null;
    try { r = await t4http(`https://4pda.to/forum/index.php?showtopic=${tid}`, true); } catch {}
    const body = (r && r.body) || "";
    if (!body) continue;
    stat.pages++;
    const re = /showtopic=(\d+)[^<>]*>([^<]{3,120})<\/a>/gi;
    let m;
    while ((m = re.exec(body))) {
      const id = m[1];
      if (!needIds.has(id) || found.has(id)) continue;
      const v = titleVer(m[2]);
      if (v) { found.set(id, v); stat.digest++; }
    }
  }
  return found;
}
// ==== Канал официального приложения 4pda (служебный сервер, минуя сайт) ====
// Ответ на запрос темы приходит списком, где есть название темы и текст первого поста (шапки).
// Версию берём из шапки тем же разбором, что и раньше; дату правки — из строки «Последнее обновление…».
const protoOn = () => localStorage.getItem("t4_proto") !== "0";   // включено по умолчанию
// Версия официального клиента, которой мы представляемся. НЕ зашита намертво: раз в сутки
// приложение само читает шапку темы официального клиента (673755) и берёт номер оттуда.
const PROTO_VER_TOPIC = "673755";
const protoVer = () => localStorage.getItem("t4_proto_ver") || "1.9.43";
const protoVerStale = () => Date.now() - (+(localStorage.getItem("t4_proto_ver_chk") || 0)) > 24 * 3600e3;
// Разбор ответа поиска: [номер,0,ВСЕГО,[[тип,topicId,"название","описание",…],…]]
// В названиях сервер подсвечивает совпадения служебными символами и BB-тегами — чистим.
function decodeEnt(x) {                                    // &#33; &amp; &quot; и т.п. в названиях тем
  return String(x || "")
    .replace(/&#(\d+);/g, (_, d) => { try { return String.fromCharCode(+d); } catch { return ""; } })
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => { try { return String.fromCharCode(parseInt(h, 16)); } catch { return ""; } })
    .replace(/&quot;/gi, '"').replace(/&apos;/gi, "'").replace(/&nbsp;/gi, " ")
    .replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&amp;/gi, "&");
}
function protoClean(t) {
  return decodeEnt(String(t || ""))
    .replace(/\[\/?(?:backgroud|background|color|size|b|i|u)[^\]]*\]/gi, "")
    .replace(/\\u000[23]/gi, "")          // подсветка совпадения приходит текстом «\u0002…\u0003»
    .replace(/[\u0002\u0003]/g, "")
    .replace(/\s+/g, " ").trim();
}
function parseProtoSearch(raw) {
  const out = { total: 0, items: [] };
  try {
    if (!raw) return out;
    const head = raw.match(/^\[\d+,0,(\d+),/);
    if (head) out.total = +head[1];
    const re = /\[(\d+),(\d{3,9}),"((?:[^"\\]|\\.)*)","((?:[^"\\]|\\.)*)"/g;
    let m;
    while ((m = re.exec(raw))) {
      const title = protoClean(m[3]);
      if (!title || title.length < 2) continue;
      out.items.push({ topicId: String(m[2]), title, short: protoClean(m[4]) });
      if (out.items.length >= 200) break;
    }
  } catch {}
  return out;
}
// Файлы темы через служебный сервер: читаем посты темы и собираем из них вложения.
// Прямую ссылку на файл даёт сервер по номеру вложения — качается без входа на сайт.
async function protoTopicFiles(topicId, from, count) {
  try {
    const r = await Apps.protoAttach({ host: "app.4pda.to", port: 993, topicId: String(topicId), from: from || 0, count: count || 20, last: true, ver: protoVer(), waitMs: 12000 });
    const raw = (r && r.posts) || "";
    const out = []; const seen = new Set();
    const re = /attachment=\\?"(\d{4,12}):([^"\\]+)/g; let m;
    while ((m = re.exec(raw))) {
      if (seen.has(m[1])) continue; seen.add(m[1]);
      const name = m[2];
      if (!/\.(apk|apks|xapk)$/i.test(name)) continue;
      out.push({ name, aid: +m[1], url: `https://4pda.to/forum/dl/post/${m[1]}/${name}` });
    }
    out.sort((a, b) => b.aid - a.aid);
    return out;
  } catch { return []; }
}
// Прямая ссылка на вложение (с ключом от сервера) — для скачивания без входа
async function protoFileLink(attachId) {
  try {
    const r = await Apps.protoAttach({ host: "app.4pda.to", port: 993, attachIds: [String(attachId)], ver: protoVer(), waitMs: 9000 });
    const l = (r && r.links) || [];
    return l.length ? l[0] : "";
  } catch { return ""; }
}
// Сведения о файлах темы с сервера App&Game: подпись, версия, размер, минимальный Android, процессоры.
// РАБОЧАЯ ФОРМА: номер темы идёт В АДРЕСЕ запроса (в теле — не работает).
// СВЯЗИ ПО ИМЕНИ ПАКЕТА: сервер App&Game по списку пакетов отдаёт тему, название, описание,
// версию, дату обновления, категорию и ссылку на иконку. Пакеты идут В АДРЕСЕ через «|».
async function agSearch(query, page) {
  const out = { total: 0, items: [] };
  try {
    const r = await Apps.agRequest({ srv: 1, method: "getAppInfo.php", params: "", q: `search_name=${encodeURIComponent(String(query || "").trim())}${page ? `&page=${page}` : ""}` });
    const o = JSON.parse((r && r.body) || "{}");
    try { for (const m of (o.meta || [])) if (m && m.found_rows) out.total = +m.found_rows; } catch {}
    for (const x of (Array.isArray(o.data) ? o.data : [])) {
      const tid = String(x.topic_id || ""); if (!tid) continue;
      out.items.push({
        topicId: tid,
        title: String(x.name || ""),
        short: String(x.description || ""),
        ver: String(x.ver || ""),
        icon: String(x.icon || "").replace(/^http:/, "https:"),
        upd: String(x.forum_update || ""),
        pkg: String(x.pack_name || ""),
        group: String(x.group_name || ""),
      });
    }
  } catch {}
  return out;
}
async function agApps(pkgs) {
  try {                                              // что уже есть в бэкапе — у сервера не спрашиваем
    const gh = JSON.parse(localStorage.getItem(AGGH_KEY) || "{}");
    const local = JSON.parse(localStorage.getItem(AGAPPS_KEY) || "{}");
    const have = {}; const rest = [];
    for (const p2 of (pkgs || [])) {
      const h = local[p2] || gh[p2];
      if (h && h.topicId && (h.ver || h.desc)) have[p2] = { topicId: String(h.topicId), title: h.title || h.name || "", desc: h.desc || "", ver: h.ver || "", icon: h.icon || "", group: h.group || "", groupId: h.groupId || 0, upd: h.upd || "", updMs: h.updMs || 0 };
      else rest.push(p2);
    }
    if (!rest.length) return have;
    const fresh = await agAskServer(rest);
    return { ...have, ...fresh };
  } catch {}
  return await agAskServer(pkgs);
}
async function agAskServer(pkgs) {
  const out = {};
  try {
    const list = (pkgs || []).filter(Boolean).slice(0, 40);
    if (!list.length) return out;
    const r = await Apps.agRequest({ srv: 1, method: "getAppInfo.php", params: "", q: `packages=${encodeURIComponent(list.join("|"))}` });
    const o = JSON.parse((r && r.body) || "{}");
    for (const x of (Array.isArray(o.data) ? o.data : [])) {
      const pkg = String(x.pack_name || "");
      if (!pkg) continue;
      out[pkg] = {
        topicId: String(x.topic_id || ""),
        title: String(x.name || ""),
        desc: String(x.description || ""),
        ver: String(x.ver || ""),
        icon: String(x.icon || "").replace(/^http:/, "https:"),
        group: String(x.group_name || ""),
        groupId: +(x.group_id || 0),
        upd: String(x.forum_update || ""),
        updMs: +(x.forum_upd || 0),
      };
    }
  } catch {}
  agAppsSave(out);
  return out;
}
const AGGH_URL = "https://raw.githubusercontent.com/Leshugan/4PDApps/main/ag4pda_fucker.json";
const AGGH_KEY = "t4_aggh";                          // база, собранная роботом на GitHub
async function agGithubLoad() {
  try {
    const chk = +(localStorage.getItem("t4_aggh_chk") || 0);
    if (Date.now() - chk < 12 * 3600e3) return;      // не чаще раза в 12 часов
    const r = await Apps.httpGet({ url: AGGH_URL });
    const o = JSON.parse((r && r.body) || "{}");
    if (o && o.apps) {
      localStorage.setItem(AGGH_KEY, JSON.stringify(o.apps));
      try { const rf = await Apps.httpGet({ url: AGGH_URL.replace("ag4pda_fucker.json", "ag4pda_files.json") }); const of2 = JSON.parse((rf && rf.body) || "{}"); if (of2 && of2.files) localStorage.setItem("t4_aggh_files", JSON.stringify(of2.files)); } catch {}
      localStorage.setItem("t4_aggh_chk", String(Date.now()));
    }
  } catch {}
}
const agGithub = () => { try { return JSON.parse(localStorage.getItem(AGGH_KEY) || "{}"); } catch { return {}; } };
let AG_DATE_IDX = null;
function agDateByTopic() {                       // строится один раз: тема → дата (ГГГГММДД)
  if (AG_DATE_IDX) return AG_DATE_IDX;
  const m = new Map();
  const add = (o) => { for (const k in o) { const v = o[k]; if (v && v.topicId && v.upd) m.set(String(v.topicId), String(v.upd)); } };
  try { add(JSON.parse(localStorage.getItem("t4_agapps") || "{}")); } catch {}
  try { add(JSON.parse(localStorage.getItem("t4_aggh") || "{}")); } catch {}
  AG_DATE_IDX = m;
  return m;
}
const AGAPPS_KEY = "t4_agapps";                      // накопитель связей пакет→тема с сервера App&Game
function agAppsSave(map) {
  try {
    const db = JSON.parse(localStorage.getItem(AGAPPS_KEY) || "{}");
    for (const k in map) db[k] = { ...map[k], t: Date.now() };
    localStorage.setItem(AGAPPS_KEY, JSON.stringify(db));
  } catch {}
}
const AGDB_KEY = "t4_agdb";                          // накопитель сведений с сервера App&Game
function agdbSave(topicId, arr) {
  try {
    const db = JSON.parse(localStorage.getItem(AGDB_KEY) || "{}");
    db[String(topicId)] = { t: Date.now(), files: arr };
    const keys = Object.keys(db);
    if (keys.length > 1500) { keys.sort((a, b) => (db[a].t || 0) - (db[b].t || 0)); keys.slice(0, keys.length - 1500).forEach((k) => delete db[k]); }
    localStorage.setItem(AGDB_KEY, JSON.stringify(db));
  } catch {}
}
// БЭКАП: наша копия данных App&Game. Сначала смотрим её, к серверу идём только за недостающим —
// когда база наполнится, от сервера можно будет отказаться совсем.
function agBackupFiles(topicId) {
  try {
    const local = JSON.parse(localStorage.getItem(AGDB_KEY) || "{}")[String(topicId)];
    if (local && local.files && local.files.length) return local.files;
    const gh = JSON.parse(localStorage.getItem("t4_aggh_files") || "{}")[String(topicId)];
    if (gh && gh.length) return gh.map((x) => ({
      aid: +(((String(x.url || "").match(/\/dl\/post\/(\d+)\//) || [])[1]) || 0),
      url: x.url, name: String(x.url || "").split("/").pop(), ver: x.ver, code: x.code, pkg: x.pkg,
      sig: x.sig, minSdk: x.minSdk, flags: x.flags, size: x.size, dl: x.dl, crc: x.crc,
    }));
  } catch {}
  return null;
}
async function agFiles(topicId) {
  const backup = agBackupFiles(topicId);
  if (backup && backup.length) return backup;
  try {
    const r = await Apps.agRequest({ srv: 1, method: "getFileInfo.php", params: "", q: `topic_id=${topicId}` });
    const body = String((r && r.body) || "");
    let o = null;
    try { o = JSON.parse(body); } catch (e) {
      const cut = body.lastIndexOf("},");                       // ответ пришёл не целиком — берём последние целые записи
      if (cut > 0) { try { o = JSON.parse(body.slice(0, cut + 1) + "]}"); } catch {} }
      if (!o) { window.__agRaw = `разбор не удался: ${e && e.message}; длина ${body.length}`; return []; }
      window.__agRaw = `ответ обрезан, разобрано частично; длина ${body.length}`;
    }
    if (!o || !Array.isArray(o.data)) { window.__agRaw = `нет списка: ${Object.keys(o || {}).join(",")}; длина ${body.length}`; return []; }
    window.__agRaw = `длина ${body.length}, записей ${o.data.length}`;
    const arr = o.data.map((x) => ({
      aid: +(((String(x.file_name || "").match(/\/dl\/post\/(\d+)\//) || [])[1]) || 0),
      url: String(x.file_name || ""),
      name: String(x.file_name || "").split("/").pop(),
      ver: String(x.version_name || ""),
      code: +(x.version_code || 0),
      pkg: String(x.pack_name || x.package_name || ""),
      sig: String(x.signature || ""),
      minSdk: +(x.min_sdk || 0),
      flags: +(x.flags || 0),
      size: +(x.file_size || 0),
      dl: +(x.downloads_count || 0),
      crc: String(x.crc32 || ""),
      app: String(x.app_name || ""),
    }));
    agdbSave(topicId, arr);
    try {                                                        // копим указатель «имя пакета → тема» — это будущая замена каталога
      const idx = JSON.parse(localStorage.getItem("t4_agpkg") || "{}");
      let ch = false;
      for (const x of arr) if (x.pkg && !idx[x.pkg]) { idx[x.pkg] = String(topicId); ch = true; }
      if (ch) localStorage.setItem("t4_agpkg", JSON.stringify(idx));
    } catch {}
    return arr;
  } catch { return []; }
}
// Поиск тем через служебный сервер (без сайта, без ограничений и капчи)
async function protoFind(query, from, count) {
  try {
    const r = await Apps.protoSearch({ host: "app.4pda.to", port: 993, query: String(query || "").trim(), from: from || 0, count: count || 60, flags: 196611, ver: protoVer(), waitMs: 12000 });
    return parseProtoSearch((r && r.raw) || "");
  } catch { return { total: 0, items: [] }; }
}
// Строка требований в стиле App&Game: минимальный Android и процессоры, поддерживаемые выделены
const SDK_TO_VER = { 5: "2.0", 8: "2.2", 9: "2.3", 14: "4.0", 16: "4.1", 19: "4.4", 21: "5.0", 23: "6.0", 24: "7.0", 26: "8.0", 28: "9", 29: "10", 30: "11", 31: "12", 33: "13", 34: "14", 35: "15" };
const sdkName = (n) => { if (!n) return ""; if (SDK_TO_VER[n]) return SDK_TO_VER[n]; const ks = Object.keys(SDK_TO_VER).map(Number).filter((k) => k <= n); return ks.length ? SDK_TO_VER[Math.max(...ks)] : String(n); };
// ТОЧНЫЕ значения из кода App&Game (i/a.smali): ARM 0x200, ARM64 0x10000, X86 0x2000, X86_64 0x8000, MIPS 0x4000, MIPS64 0x20000
const AG_ARM = 0x200, AG_ARM7 = 0x200, AG_ARM64 = 0x10000, AG_X86 = 0x2000, AG_X64 = 0x8000, AG_MIPS = 0x4000;
const agAbiList = (f) => {
  const out = [];
  if (f & (AG_ARM | AG_ARM7)) out.push("armeabi-v7a");
  if (f & AG_ARM64) out.push("arm64-v8a");
  if (f & AG_X86) out.push("x86");
  if (f & AG_X64) out.push("x86_64");
  return out;
};
const safeDec = (x) => { try { return decodeURIComponent(String(x || "")); } catch { return String(x || ""); } };
function agReqLine(x) {
  if (!x) return null;
  const f = +x.flags || 0;
  const ver = sdkName(x.minSdk);
  // как у ag4pda: поддерживаемые файлом процессоры — жирные, остальные приглушённые; пустые данные не рисуем
  const B = (on, t) => <span style={{ color: on ? C.ink : C.sub, fontWeight: on ? 700 : 400 }}>{t}</span>;
  const abi = f ? <>({B(!!(f & (AG_ARM | AG_ARM7)), "ARM")}/{B(!!(f & AG_ARM64), "64")} {B(!!(f & AG_X86), "X86")}/{B(!!(f & AG_X64), "64")} {B(!!(f & AG_MIPS), "MIPS")})</> : null;
  if (!ver && !abi) return null;                      // показывать нечего — строки не будет
  return <span>{ver ? "Android " + ver + "+" : ""}{ver && abi ? " " : ""}{abi}</span>;
}
function parseProtoTopic(raw) {
  const out = { title: "", ver: "", du: "", desc: "", icon: "", files: [], forumId: 0 };
  try {
    if (!raw) return out;
    const t = raw.match(/,(\d{3,9}),"([^"]{2,120})","/);
    if (t) out.title = t[2];
    const v = raw.match(/Верси[яи][^\n\]]{0,40}?([0-9]+(?:\.[0-9]+)+(?:[\s._-]*(?:build|beta|alpha|rc|b)[\s._-]*\d+)?)/i);
    if (v) out.ver = apkVerName(v[1]) || v[1];
    const d = raw.match(/обновление[^\n]{0,60}?(\d{1,2}\.\d{1,2}\.\d{2,4})/i);
    if (d) out.du = normD(d[1]);
    // краткое описание темы: идёт сразу после названия
    const fm = raw.match(/\[\[1,(\d{2,6}),"/);          // раздел форума приходит вместе с темой
    if (fm) out.forumId = +fm[1];
    const ds = raw.match(/,\d{3,9},"[^"]{2,120}","([^"]{2,300})"/);
    if (ds) out.desc = ds[1].replace(/\s+/g, " ").trim();
    // вложения шапки: [attachment="35949556:icon_200.png"] → прямая ссылка на файл
    try {
      const re = /attachment=\\?"(\d{4,12}):([^"\\]+)/g; let m;
      while ((m = re.exec(raw))) {
        const url = `https://4pda.to/forum/dl/post/${m[1]}/${m[2]}`;
        if (/\.(png|jpg|jpeg|gif|webp)$/i.test(m[2])) { if (!out.icon) out.icon = `https://4pda.to/forum/index.php?act=attach&type=post&id=${m[1]}`; }   // картинки поста отдаются по другому адресу
        else out.files.push({ name: m[2], url, aid: +m[1] });
      }
    } catch {}
    if (!out.icon) {                                  // в части тем иконка вставлена обычной картинкой, а не вложением
      const im = raw.match(/\[img\]\s*(https?:\/\/[^\[\]\s"']+\.(?:png|jpe?g|gif|webp))/i)
             || raw.match(/(https?:\/\/[^\s"'\[\]]+\/(?:uploads|static)\/[^\s"'\[\]]+\.(?:png|jpe?g|gif|webp))/i);
      if (im) out.icon = im[1];
    }
    return out;
  } catch { return out; }
}
const realTopic = (b) => !!b && (b.indexOf("post_body") >= 0 || b.indexOf("postcolor") >= 0);

// Индекс = перебор ВСЕХ тем твоих каталогов 4pda по очереди (вкл. Архив программ 1109), с накоплением.
// 4pda-поиск пословный (Habitica по habit не отдаёт) — по индексу ищем подстрокой и суммируем с живым поиском.
const INDEX_FORUMS = { apps: [1109, 212, 550, 284, 1198, 320], games: [213], emu: [529] };
async function buildAppIndex(kind, capPerForum, onProgress) {
  const forums = INDEX_FORUMS[kind] || [];
  let seen = {};
  try { const ex = JSON.parse(localStorage.getItem("t4_idx_" + kind) || "[]"); for (const e of ex) if (e && e.t && !/^[\d#]+$/.test(e.n || "")) seen[e.t] = e.n; } catch {}
  const save = () => { try { localStorage.setItem("t4_idx_" + kind, JSON.stringify(Object.keys(seen).map((t) => ({ t, n: seen[t] })))); } catch {} };
  const cap = capPerForum || 250;
  for (const f of forums) {
    let emptyStreak = 0, noNewStreak = 0;
    for (let p = 0; p < cap; p++) {
      while (window.__searching) { await new Promise((r) => setTimeout(r, 700)); } // уступаем живому поиску
      const url = `https://4pda.to/forum/index.php?showforum=${f}&prune_day=1000000&sort_by=last_post&sort_order=desc&st=${p * 30}`;
      let body = "";
      try { const hr = await t4http(url, true); body = hr.body || ""; if (hr.__rate || /Just a moment|challenge-platform|cf-browser/i.test(body)) body = ""; } catch {}
      // без WebView-фолбэка в фоне — он забивает сеть; просто пропускаем страницу
      if (!body) { if (++emptyStreak >= 3) break; else continue; }
      emptyStreak = 0;
      let m, found = 0, any = 0;
      const re = /showtopic=(\d+)[^>]*>\s*([^<]{2,120}?)\s*<\/a>/g;
      while ((m = re.exec(body)) !== null) {
        any++;
        const tid = m[1]; let name = m[2].replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#\d+;/g, "").replace(/\s+/g, " ").trim();
        if (name.length < 2 || /^[\d#]+$/.test(name) || /^(тема|сообщени|показать|скрыт|цитата|profile|member|каталог|дайджест|поиск|правила|набор|подписаться|послед|ответ|прикреплено|важно|опрос|стр\.|новости из мира|обсуждение новост)/i.test(name)) continue;
        if (!seen[tid]) { seen[tid] = name; found++; }
      }
      if (onProgress) onProgress(f, p + 1, Object.keys(seen).length);
      if (any === 0) { if (++emptyStreak >= 2) break; }        // страница без тем — конец раздела
      else if (found === 0) { if (++noNewStreak >= 7) break; } // 4 страницы подряд без новых — конец
      else noNewStreak = 0;
      if (p % 5 === 4) save();
      await new Promise((r) => setTimeout(r, 400));
    }
    save();
  }
  try { localStorage.setItem("t4_idx_" + kind + "_ts", String(Date.now())); } catch {}
  return Object.keys(seen).length;
}
// Вся база 4pda — в ОДНОМ файле catalog.json на GitHub (внутри: версия + приложения с пакетом/версией/описанием/иконкой).
// «Обновилось ли» проверяем дёшево через GitHub API (последний коммит файла); саму базу качаем только при изменении.
const GH_CATALOG = "https://raw.githubusercontent.com/Leshugan/4PDApps/main/catalog.json";
const GH_COMMITS = "https://api.github.com/repos/Leshugan/4PDApps/commits?path=catalog.json&per_page=1";
let _catCache = [];
let _catForums = null;
let VERMAP = {};
let VERMULTI = {};
let NAMEMAP = {};
try { VERMAP = JSON.parse(localStorage.getItem("t4_vermap") || "{}"); } catch { VERMAP = {}; }
function catForumSet() {
  if (_catForums && _catForums.__n === (_catCache ? _catCache.length : 0)) return _catForums;
  const s = new Set((_catCache || []).map((e) => String(e.f))); s.__n = _catCache ? _catCache.length : 0; _catForums = s; return s;
}
let _catById = null;
function catById() {
  if (_catById && _catById.__n === (_catCache ? _catCache.length : 0)) return _catById;
  const m = {}; for (const e of (_catCache || [])) if (e && e.t) m[String(e.t)] = e; m.__n = _catCache ? _catCache.length : 0; _catById = m; return m;
}
function buildVermap(apps) {
  const m = {}, nm = {}, dup = {}, multi = {};
  for (const a of apps) {
    if (!a) continue;
    if (a.pkg) {
      if (m[a.pkg]) (multi[a.pkg] || (multi[a.pkg] = [m[a.pkg]])).push([String(a.t), a.v || "", a.n || ""]); // пакет-тёзка (темы-сборники пишут чужие пакеты)
      else m[a.pkg] = [String(a.t), a.v || "", a.n || ""];
    }
    const key = appNameFor(a.n || "").toLowerCase().trim();
    if (key.length >= 3) { if (nm[key] || dup[key]) { delete nm[key]; dup[key] = 1; } else nm[key] = String(a.t); }
  }
  VERMAP = m; NAMEMAP = nm; VERMULTI = multi;
  try { localStorage.setItem("t4_vermap", JSON.stringify(m)); } catch {}
}
const COLLECTION_RE = /каталог|сборник|подборка|общая тема|faq|шапк|программ для|список/i;   // маркеры тем-сборников — их привязка почти всегда чужая
function pickTopicForApp(a) {
  const p = a.packageName; if (!p) return null;
  const cands = VERMULTI[p]; const base = VERMAP[p];
  if (!cands) return base || null;
  const nrm = (x) => (x || "").toLowerCase().replace(/[^a-zа-яё0-9]+/gi, "");
  const lbl = nrm(appNameFor(a.label || ""));
  let best = base, bestScore = -1e9;
  for (const cnd of cands) {
    const nm = nrm(appNameFor(cnd[2] || ""));
    let sc = 0;
    if (lbl && nm) { if (nm === lbl) sc += 100; else if (nm.indexOf(lbl) >= 0 || lbl.indexOf(nm) >= 0) sc += 50; else { const pre = lbl.slice(0, 6); if (pre && nm.indexOf(pre) >= 0) sc += 20; } }
    if (COLLECTION_RE.test(cnd[2] || "")) sc -= 60;                      // сборник — вниз
    if (sc > bestScore) { bestScore = sc; best = cnd; }
  }
  return best;
}
async function loadCatFromFile() {
  try { const r = await Apps.readCache({ name: "cat.json" }); _catCache = JSON.parse(r.text || "[]"); } catch { _catCache = []; }
  window.__catLoad = "каталог с диска: " + (_catCache ? _catCache.length : 0);
  if (_catCache && _catCache.length) buildVermap(_catCache);
  return _catCache ? _catCache.length : 0;
}
function catArr() { return _catCache; }
function catCount() { return _catCache && _catCache.length ? _catCache.length : (+(localStorage.getItem("t4_ghcat_n") || 0)); }
async function saveCat(apps) { try { for (const e of (apps || [])) if (e && e.v && (!/^[0-9]/.test(String(e.v)) || String(e.v).length > 40)) delete e.v; } catch {} // страховка: испорченные версии (SVG-мусор) не показываем
  _catCache = apps; try { localStorage.setItem("t4_ghcat_n", String(apps.length)); } catch {} try { await Apps.writeCache({ name: "cat.json", text: JSON.stringify(apps) }); } catch {} }
async function fetchGhCatalog(force) {
  try {
    // Проверка идёт при КАЖДОМ запуске: сначала дешёвый запрос последнего коммита,
    // и только если sha изменился — качаем сам каталог. Прежний 4-часовой пропуск снят.
    localStorage.setItem("t4_ghcat_chk", String(Date.now()));
    let have = catArr().length;
    // дёшево: последний коммит catalog.json через GitHub API — чтобы не качать всю базу зря
    let sha = "";
    try { const cr = await Apps.httpGet({ url: GH_COMMITS + "&t=" + Date.now() }); const arr = JSON.parse(cr.body || "[]"); if (Array.isArray(arr) && arr[0]) sha = arr[0].sha || ""; } catch {}
    const localSha = localStorage.getItem("t4_ghcat_sha") || "";
    if (have && sha && sha === localSha && !force) return have; // не менялось — базу не качаем
    // качаем единый файл
    const r = await Apps.httpGet({ url: GH_CATALOG + "?t=" + Date.now() });
    const j = JSON.parse(r.body || "{}");
    const apps = (Array.isArray(j) ? j : (j.apps || []));
    if (apps.length) {
      await saveCat(apps);
      buildVermap(apps);
      localStorage.setItem("t4_ghcat_ver", String(j.version || Date.now()));
      if (sha) localStorage.setItem("t4_ghcat_sha", sha);
    }
    return apps.length;
  } catch { return 0; }
}
// имя приложения без хвоста «от Разработчик» (4pda дописывает разработчика в заголовок; по нему были ложные совпадения)
const appNameFor = (s) => (s || "").replace(/\s+от\s+.+$/i, "").trim();
// разделы игр и эмуляторов (остальное — программы)
const GAME_F = new Set(["1149", "523", "519", "524", "526", "528", "520", "525", "522", "521", "527", "530", "812", "1164", "213"]);
const EMU_F = new Set(["529", "539", "537", "540"]);
const DENY_F = new Set(["373", "813", "141", "142", "4", "283", "140", "635", "139", "645", "887", "279", "93", "763", "442", "144", "203", "103", "48", "295", "281", "1192", "214", "910", "380", "551", "1143", "1158"]); // мусорные разделы: iOS/новости/железо/мета/dev-обсуждения
// iOS/Windows/чужие/мусорные разделы 4pda — их результаты отсекаем (не Android)
const DROP_F = new Set(["373", "813", "141", "142", "4", "283", "140", "635", "139", "645", "887", "279", "93", "763", "442", "144", "203", "103", "48", "295", "281", "1192", "214", "910", "380", "551", "1143", "1158", "270", "271", "365", "366", "367"]);
function kindOf(e) { const f = String((e && e.f) || ""); if (DROP_F.has(f)) return "drop"; if (EMU_F.has(f)) return "emu"; if (GAME_F.has(f)) return "games"; return "apps"; }
function catalogMatches(kind, query, field) {
  try {
    const arr = catArr();
    const ql = query.toLowerCase().trim();
    const qw = ql.split(/\s+/).filter((w) => w.length > 1);
    const pick = (e) => kindOf(e) === kind;
    const nonAndroid = /\[(ios|iphone|ipad|ipados|desktop|windows|win(?:32|64)?|wp7|wp8|wp10|wp|mac(?:os)?|symbian|linux|web(?:os)?|java|bada|blackberry|bb10?|tizen|kaios)\]/i;
    return arr.filter((e) => {
      if (!pick(e)) return false;
      if (nonAndroid.test(e.n || "")) return false;
      const s = (field === "name" ? appNameFor(e.n) : field === "desc" ? (e.d || "") : appNameFor(e.n) + " " + (e.d || "")).toLowerCase();
      return s.indexOf(ql) >= 0 || qw.some((w) => s.indexOf(w) >= 0);
    }).map((e) => ({ topicId: String(e.t), title: e.n, short: e.d || "", icon: e.ic || "", ver4pda: e.v || "", pkg: e.pkg || "" }));
  } catch { return []; }
}
// ==== Троттлер 4pda: все запросы через одну очередь (~2.5/с), при «Too Many Requests» — глобальная пауза 60с ====
let T4_LAST = 0, T4_COOL = 0; const T4_Q = [];
let T4_PAR = 2;   // одновременных запросов к 4pda — фиксировано, без разгона                  // сколько запросов к 4pda идёт одновременно (адаптивно 1..6)
let T4_RUN = 0;                  // сейчас в работе
let T4_OK = 0, T4_FAIL = 0;                   // успехов подряд без «Too Many Requests» — по ним поднимаем параллельность
let T4_WEB = false;              // WebView-запрос — эксклюзивный, остальные ждут
const T4_MAX = 2, T4_MIN = 1;
const t4Sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const t4Banned = (b) => /Too Many Requests|rate.?limit|Ray ID:|Что-то пошло не так/i.test((b || "").slice(0, 2500));   // «Ой! Что-то пошло не так» — та же блокировка, только другой страницей
const t4Gap = () => Math.round(1000 / Math.max(1, T4_PAR));   // ~2 запроса в секунду — заведомо в пределах, 4pda не ругается   // минимальный промежуток между СТАРТАМИ запросов
function t4Enqueue(kind, url, noAuth, opts) { return new Promise((res) => { T4_Q.push({ kind, url, noAuth: !!noAuth, opts: opts || null, res }); t4Pump(); }); }
// Пул воркеров: запросы идут параллельно, но с общим темпом стартов.
// Ловим «Too Many Requests» → мгновенно откатываемся к одному потоку и минуте тишины.
function t4Pump() {
  // ВАЖНО: задачу СНАЧАЛА смотрим, и только потом снимаем с очереди. Раньше web-задача при занятых
  // воркерах возвращалась обратно через unshift, T4_RUN не менялся — и этот while крутился вечно,
  // намертво вешая интерфейс (браузерный поток был занят пустым циклом).
  while (!T4_WEB && T4_RUN < T4_PAR && T4_Q.length) {
    const j = T4_Q[0];
    if (j.kind === "web") { if (T4_RUN > 0) break; T4_WEB = true; }   // WebView — строго в одиночку, ждём освобождения
    T4_Q.shift();
    t4Worker(j);
  }
}
async function t4Worker(j) {
  if (!j) return;
  T4_RUN++;
  try {
    const now = Date.now();
    const wait = Math.max(T4_COOL - now, T4_LAST + t4Gap() - now, 0);
    if (wait > 0) await t4Sleep(wait);
    T4_LAST = Date.now();
    let r = { body: "", captcha: false };
    try { r = await (j.kind === "web" ? Apps.webGet({ url: j.url, noAuth: j.noAuth || false }) : Apps.httpGet(Object.assign({ url: j.url, noAuth: j.noAuth || false }, j.opts || {}))); } catch {}
    if (r && t4Banned(r.body)) {
      T4_COOL = Date.now() + 60000; T4_PAR = T4_MIN; T4_OK = 0;                 // сайт ограничил — один поток и минута тишины
      r = { body: "", captcha: true, __rate: true };
    } else if (r && !r.body && !r.__timeout) {                                   // сервер отдал пустоту — вероятно, режет частоту
      T4_FAIL = (T4_FAIL || 0) + 1;
      if (T4_FAIL >= 5) { T4_PAR = Math.max(T4_MIN, T4_PAR - 1); T4_FAIL = 0; T4_COOL = Date.now() + 5000; }
    } else { T4_FAIL = 0; T4_OK++; }                                            // разгона нет: темп изначально в пределах, которые 4pda не режет
    j.res(r || { body: "", captcha: false });
  } finally {
    T4_RUN--; if (j.kind === "web") T4_WEB = false;
    t4Pump();
  }
}
const t4http = (url, noAuth, opts) => t4Enqueue("http", url, noAuth, opts);   // opts: maxBytes / ifNoneMatch / ifModifiedSince
const t4web = (url, noAuth) => t4Enqueue("web", url, noAuth);   // noAuth=true — WebView без сессионных кук (Cloudflare проходим, история чистая)
async function fetchUrl4pda(url) {   // осталась только у страниц, где сессия нужна осознанно (профиль и т.п.)
  let tr = await t4http(url);
  if ((tr.captcha || !realTopic(tr.body)) && !tr.__rate) { try { tr = await t4web(url); } catch {} }
  return tr && tr.body ? tr.body : "";
}
// ПРОГРЕВ Cloudflare БЕЗ метки в истории: t4web(тема) шёл через WebView с СЕССИЕЙ — 4pda помечал тему
// посещённой (жалоба «мусорит в истории»). Челлендж решаем на ГЛАВНОЙ форума (визит туда историю тем
// не трогает), cf-куки лягут в CookieManager, noAuth-клиент их переиспользует — и повторяем запрос без сессии.
let T4_WARM = 0;
async function t4webWarm() {
  const now = Date.now();
  if (now - T4_WARM < 10 * 60 * 1000) return;   // не чаще раза в 10 минут
  T4_WARM = now;
  try { await t4web("https://4pda.to/forum/index.php"); } catch {}
}
// Юзерское открытие темы/поста — ВСЕГДА без авторизации (сессия только для скачивания).
// Если обычный запрос упёрся в Cloudflare, страницу грузит WebView в ГОСТЕВОМ режиме:
// сессионные куки на время загрузки снимаются, поэтому тема не попадает в историю на 4pda.
async function fetchUrl4pdaUser(url) {
  const html = await fetchUrl4pdaAnon(url);
  if (realTopic(html)) return html;
  try { const r = await t4web(url, true); if (r && realTopic(r.body)) return r.body; } catch {}
  return html;
}
// Анонимная загрузка страницы темы: НИКОГДА не ходит в WebView с сессией
async function fetchUrl4pdaAnon(url) {
  let tr = await t4http(url, true);
  if ((tr.captcha || !realTopic(tr.body)) && !tr.__rate) {
    await t4webWarm();
    try { tr = await t4http(url, true); } catch {}
  }
  return tr && tr.body ? tr.body : "";
}
// открыть пост в нативном WebView-попапе (как dlg_post_view у ag4pda), но чистым: только тело поста, тёмная тема
async function openPostClean(url, topicId) {
  try {
    const html = await fetchUrl4pdaUser(url);   // просмотр поста: аноним, при заглушке — сессия
    const doc = new DOMParser().parseFromString(html, "text/html");
    const pid = (url.match(/pid=(\d+)/) || url.match(/entry(\d+)/) || [])[1];
    let bodyEl = null;
    if (pid) {
      const anchor = doc.querySelector('a[name="entry' + pid + '"]') || doc.querySelector("#entry" + pid) || doc.querySelector('[id="p' + pid + '"]') || doc.querySelector('[data-post="' + pid + '"]') || doc.querySelector('[id*="' + pid + '"]');
      if (anchor) { let el = anchor; for (let i = 0; i < 10 && el && !bodyEl; i++) { if (el.querySelector) bodyEl = el.querySelector(".post_body, .postcolor"); if (!bodyEl) el = el.parentElement; } if (!bodyEl) { let n = anchor.nextElementSibling, g = 0; while (n && g < 12 && !bodyEl) { if (n.querySelector) bodyEl = n.querySelector(".post_body, .postcolor"); n = n.nextElementSibling; g++; } } }
    }
    if (!bodyEl) bodyEl = doc.querySelector(".post_body, .postcolor");
    let inner = bodyEl ? bodyEl.innerHTML : "";
    inner = inner.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/Сообщение отредактировал[\s\S]*$/i, "");
    if (!inner.trim()) { Apps.openPostView({ url }).catch(() => Apps.openUrl({ url }).catch(() => {})); return; }
    // окно поста красим по текущей теме: в светлой раньше открывалось тёмным пятном
    const pv = C.light
      ? { bg: C.bg, tx: C.text, a: C.acc, b: C.active, box: C.card, line: C.border }
      : { bg: "#1e1e1e", tx: "#d2d2d2", a: "#5ab0d8", b: "#ededed", box: "#242424", line: "#333" };
    const clean = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><style>body{margin:0;padding:14px;background:" + pv.bg + ";color:" + pv.tx + ";font:15px/1.55 -apple-system,Roboto,Arial,sans-serif;word-wrap:break-word;overflow-wrap:break-word}a{color:" + pv.a + ";text-decoration:none}img{max-width:100%;height:auto;border-radius:6px}b,strong{color:" + pv.b + "}.post-block,.spoiler{border:1px solid " + pv.line + ";border-radius:8px;margin:8px 0;padding:8px 10px;background:" + pv.box + "}.block-title,.spoiler-title,.title{font-weight:700;color:" + pv.b + "}hr{border:none;border-top:1px solid " + pv.line + "}</style></head><body>" + inner + "</body></html>";
    await Apps.openPostView({ html: clean });
  } catch { Apps.openPostView({ url }).catch(() => Apps.openUrl({ url }).catch(() => {})); }
}
async function fetchTopicHtml(id) {
  // РЕШЕНИЕ ЮЗЕРА (09.08): темы всегда открываются БЕЗ авторизации — сессия нужна только для скачивания.
  // Раньше открытие карточки шло с сессией и метило тему в истории посещений 4pda.
  return await fetchUrl4pdaUser(`https://4pda.to/forum/index.php?showtopic=${id}`);
}
async function check4pdaLogin() {
  let html = "";
  try {
    const r = await Apps.httpGet({ url: "https://4pda.to/forum/index.php" });
    html = r.body || "";
    if (r.captcha || !/logout/i.test(html) || html.length < 2000) { try { const w = await Apps.webGet({ url: "https://4pda.to/forum/index.php" }); if ((w.body || "").length > html.length) html = w.body; } catch {} }
  } catch {}
  const kk = html.match(/(?:act|action)=logout[^"'<>]*?k=([a-f0-9]{32})/i) || html.match(/logout[^"'<>]{0,40}?[?&]k=([a-f0-9]{32})/i);
  if (!kk) return { loggedIn: false };
  const uid = (html.match(/showuser=(\d+)/) || [])[1] || "";
  let name = "", avatar = "";
  if (uid) {
    try {
      const pr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` });
      let pb = pr.body || "";
      if (pr.captcha || pb.length < 1500) { try { const w = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` }); if ((w.body || "").length > pb.length) pb = w.body; } catch {} }
      name = (pb.match(/<title>\s*([^<]+?)\s*(?:[-–—]\s*Просмотр профиля|<\/title>)/i) || [])[1] || "";
      name = name.replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
      avatar = (pb.match(/<img[^>]+src="([^"]+)"[^>]*class="[^"]*avatar/i)
        || pb.match(/class="[^"]*avatar[^"]*"[^>]*>\s*<img[^>]+src="([^"]+)"/i)
        || pb.match(/src="(https?:\/\/[^"']*\/(?:uploads|avatar)[^"']+\.(?:jpg|jpeg|png|gif|webp))"/i)
        || [])[1] || "";
    } catch {}
  }
  if (!avatar) avatar = (html.match(/<img[^>]+class="[^"]*avatar[^"]*"[^>]+src="([^"]+)"/i) || [])[1] || "";
  if (!avatar) {                                        // запасной путь: ссылка на аватар лежит в профиле пользователя
    const uid = (html.match(/showuser=(\d{3,9})/) || [])[1];
    const m2 = html.match(/(https?:\/\/4pda\.to\/static\/forum\/uploads\/[^"'\s>]+\.(?:jpg|jpeg|png|gif|webp))/i);
    if (m2) avatar = m2[1];
    else if (uid) avatar = "";
  }
  if (avatar && avatar.indexOf("//") === 0) avatar = "https:" + avatar;
  if (!avatar && uid) {                                   // страница профиля: там лежит настоящая картинка
    try {
      const rr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` });
      const ph = String((rr && rr.body) || "");
      const m3 = ph.match(/(https?:\/\/[^"']*\/static\/forum\/uploads\/[^"']+\.(?:jpg|jpeg|png|gif|webp))/i)
             || ph.match(/<img[^>]+src="([^"]+)"[^>]*class="[^"]*(?:avatar|photo)/i)
             || ph.match(/class="[^"]*(?:avatar|photo)[^"]*"[^>]*>\s*<img[^>]+src="([^"]+)"/i);
      if (m3) avatar = m3[1].replace(/^http:/, "https:");
    } catch {}
  }
  name = String(name || "").replace(/\s*[-–—|]\s*4PDA\s*$/i, "").trim();
  return { loggedIn: true, userId: uid, name: name || ("Профиль" + (uid ? " id" + uid : "")), avatar, logoutK: kk[1] };
}
async function logout4pda(k) {
  // как ProPDA: безголовый GET на logout-URL (без WebView → без Cloudflare-редиректа), затем чистим куки
  try { await Apps.httpGet({ url: `https://4pda.to/forum/index.php?act=logout&CODE=03&k=${k}` }); } catch {}
  try { await Apps.clearCookies(); } catch {}
}
function titleScore(title, label) {
  const t = (title || "").toLowerCase().trim(), l = (label || "").toLowerCase().trim();
  if (!t || !l) return 0;
  if (/(клуб|club|чат|\bчата\b|обсужд|fanclub|фан-?клуб|курилк|флудил|вопрос|faq по)/i.test(t)) return 5; // не тема приложения
  if (t === l) return 100;
  if (t === l + " [android]" || t === l + " [андроид]") return 98;
  if (/\[android\]|\[андроид\]/i.test(t) && t.replace(/\s*\[[^\]]*\]\s*/g, "") === l) return 95;
  if (t.replace(/\s*\[[^\]]*\]\s*/g, "").trim() === l) return 90; // «Имя [что-то]» == имя
  if (t.indexOf(l + " ") === 0 || t.indexOf(l + " [") === 0) return 60;
  if (t.indexOf(l) >= 0) return 40;
  return 8;
}
async function resolveTopic(app, maxCand = 8, useGoogle = true) {
  // 1) внешний каталог пакет→тема (как у freeman42, но база твоя) — мгновенно и точно
  if (CATALOG[app.packageName]) {
    const id = CATALOG[app.packageName];
    try { const html = await fetchTopicHtml(id); if (html) return { topicId: id, matched: true, html }; } catch {}
    return { topicId: id, matched: true, html: "" };
  }
  const cands = [];
  const add = (arr) => { for (const r of arr) if (!cands.find((c) => c.topicId === r.topicId)) cands.push(r); };
  const nameQ = app.label && app.label !== app.packageName ? app.label : app.packageName;
  // поиск по названию: сначала в разделах Программы/Игры, затем (если пусто) без ограничения
  try { const sr = await t4web(searchUrl4pda(nameQ, "top", 0, true), false); if (sr.captcha) return "captcha"; add(parseSearchResults(sr.body || "")); } catch {}
  if (!cands.length) { try { const sr = await t4web(searchUrl4pda(nameQ, "top", 0, false), false); add(parseSearchResults(sr.body || "")); } catch {} }
  if (!cands.length) { try { const sr2 = await t4web(searchUrl4pda(app.packageName, "all", 0, false), false); add(parseSearchResults(sr2.body || "")); } catch {} }
  if (!cands.length) return null;
  cands.sort((a, b) => titleScore(b.title, nameQ) - titleScore(a.title, nameQ));
  let best = null;
  for (let i = 0; i < Math.min(cands.length, maxCand); i++) {
    try {
      const html = await fetchTopicHtml(cands[i].topicId);
      if (!html) continue;
      if (playPkg(html) === app.packageName) return { topicId: cands[i].topicId, matched: true, html };
      // запасной вариант — только для тем с сильным совпадением названия (не «Club»/обсуждение)
      if (!best && titleScore(cands[i].title, nameQ) >= 90 && isAppPage(html)) best = { topicId: cands[i].topicId, matched: false, html };
    } catch {}
  }
  return best;
}
async function fetchPlayVersion(pkg) {
  // 1) через gplayapi (анонимно, без входа) — точная версия + код
  try { const r = await Apps.playVersion({ packageName: pkg }); if (r && r.versionName) return { name: r.versionName, code: r.versionCode || "" }; } catch {}
  // 2) откат: парсинг HTML Play (ненадёжно)
  for (const hl of ["ru", "en"]) {
    try {
      const r = await Apps.httpGet({ url: `https://play.google.com/store/apps/details?id=${pkg}&hl=${hl}&gl=US` });
      const b = r.body || "";
      let m = b.match(/\[\[\["([0-9][0-9A-Za-z.\-_]*)"\]\],\s*\[/);
      if (m) return { name: m[1], code: "" };
      m = b.match(/"softwareVersion"\s*:\s*"([^"]+)"/i); if (m) return { name: m[1].trim(), code: "" };
      m = b.match(/Current Version[\s\S]{0,120}?([0-9]+\.[0-9][0-9A-Za-z.\-_]*)/i); if (m) return { name: m[1], code: "" };
    } catch {}
  }
  return null;
}

async function fetchPlayDesc(pkg) {
  for (const hl of ["ru", "en"]) {
    try {
      const r = await Apps.httpGet({ url: `https://play.google.com/store/apps/details?id=${pkg}&hl=${hl}&gl=US` });
      const b = r.body || "";
      let m = b.match(/<meta name="description" content="([^"]+)"/i);
      if (!m) m = b.match(/<meta property="og:description" content="([^"]+)"/i);
      if (m && m[1]) { const s = m[1].replace(/&#0?39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/&gt;/g, ">").replace(/&lt;/g, "<").replace(/\s+/g, " ").trim(); if (s.length > 5) return s.slice(0, 160); }
    } catch {}
  }
  return "";
}
const CKEY = "t4_cache_v1";
// Внешний каталог связей: JSON вида { "com.instagram.android": 236581, ... }.
// URL задаётся в настройках (гамбургер) и хранится локально — базу хостишь где хочешь (raw github и т.п.).
let CATALOG = {};
const catalogUrl = () => { try { return localStorage.getItem("t4_catalog_url") || ""; } catch { return ""; } };
// кэш файлов из постов-анонсов по теме (для предзагрузки в фоне)
const postFilesCache = {};
async function fetchDlPostFiles(topicId, dlPosts, installedVer, mode, onAdd) {
  const key = String(topicId);                                     // один кэш на тему: «Файлы» и «Обновления» делят одну загрузку
  if (!postFilesCache[key]) postFilesCache[key] = { files: [], done: false, running: false, promise: null, subs: [] };
  const c = postFilesCache[key];
  if (onAdd) c.subs.push(onAdd);                                   // real-time: файлы появляются на глазах у всех открытых листов
  if (c.files.length && onAdd) onAdd(c.files.slice());
  if (c.done) return c;
  if (c.running) { try { await c.promise; } catch {} return c; }   // параллельный вызов ЖДЁТ завершения, а не получает пустоту
  c.running = true;
  c.promise = (async () => {
    const posts = (dlPosts || []).slice(0, 12);                    // все посты версий; фильтр «новее установленной» — в интерфейсе
    for (const p of posts) {
      try {
        const html = await fetchUrl4pdaAnon(p.url);   // обход постов версий — без сессии, историю тем не пачкаем
        const apks = parseApkLinks(html, p.url);
        if (apks.length) { const seen = new Set(c.files.map((x) => x.url)); const add = apks.filter((x) => !seen.has(x.url)).map((x) => ({ ...x, ver: x.ver || p.ver || "" })); if (add.length) { c.files.push(...add); const snap = c.files.slice(); for (const f of c.subs) { try { f(snap); } catch {} } } }
      } catch { bg(-1); }
    }
    c.running = false; c.done = true;
  })();
  try { await c.promise; } catch {}
  return c;
}
// фоновый прогрев меток apk (подпись/ABI/minSdk) — чтобы «Файлы»/«Обновления» открывались уже с отличиями
// ВСЕ вложения темы одним запросом (как ag4pda): act=attach&code=showtopic&tid=<тема>
const attachCache = {};
async function fetchTopicAttachments(topicId, opts) {
  const key = String(topicId);
  const wantAll = !!(opts && opts.all);
  const onGrow = (opts && opts.onGrow) || null;
  if (!attachCache[key]) attachCache[key] = { files: [], done: false, full: false, running: false };
  const c = attachCache[key];
  if (c.done && (c.full || !wantAll)) return c;
  if (c.running) { try { await c.promise; } catch {} if (c.full || !wantAll) return c; }   // прогрев уже идёт — дождаться, а не вернуть пустоту
  c.running = true;
  c.promise = (async () => {
  try {
    const seen = new Set(c.files.map((f) => f.url));
    const pageSize = 100;                                          // 4pda отдаёт таблицу вложений постранично
    let page = Math.floor(c.files.length / pageSize);
    const maxPages = wantAll ? 40 : 1;                            // прогрев темы — первая страница; полный обход — из «Файлов»
    for (let pi = 0; pi < maxPages; pi++, page++) {
      const st = page * pageSize;
      const html = await fetchUrl4pdaAnon("https://4pda.to/forum/index.php?act=attach&code=showtopic&tid=" + topicId + (st ? "&st=" + st : ""));   // таблица вложений — тоже без сессии
      if (!html || html.length <= 200) break;
      const doc = new DOMParser().parseFromString(html, "text/html");
      const before = c.files.length;
      doc.querySelectorAll('a[href*="/dl/post/"]').forEach((a) => {
        let url = a.getAttribute("href") || ""; if (!url) return;
        if (url.indexOf("//") === 0) url = "https:" + url; else if (url.indexOf("http") !== 0) url = "https://4pda.to" + (url[0] === "/" ? "" : "/") + url;
        url = url.replace(/&amp;/g, "&");
        if (seen.has(url)) return; seen.add(url);
        let name = ""; const um = url.match(/\/dl\/post\/\d+\/([^?#]+)/i); if (um) { try { name = decodeURIComponent(um[1]); } catch { name = um[1]; } }
        if (!name) name = (a.textContent || "").trim();
        if (!/\.apk$/i.test(name)) return;                                   // как ag4pda (regex apk_list): в списке вложений только .apk
        name = name.replace(/\+/g, " ").trim();
        const tr = (a.closest && (a.closest("tr") || a.closest("li, .attach, .post-attach"))) || a.parentElement;
        // дата «( Добавлено DD.MM.YYYY, HH:MM )» из ячейки файла — единственный ключ сортировки (как ag4pda)
        let added = "", ts = 0;
        { const t = ((tr && tr.textContent) || "").replace(/\s+/g, " ");
          const m = t.match(/Добавлено\s+(\d{1,2})\.(\d{1,2})\.(\d{2,4})(?:,\s*(\d{1,2}):(\d{2}))?/i);
          if (m) { let y = +m[3]; if (y < 100) y += 2000; added = `${m[1].padStart(2, "0")}.${m[2].padStart(2, "0")}.${String(y).slice(2)}`; ts = Date.UTC(y, (+m[2]) - 1, +m[1], +(m[4] || 0), +(m[5] || 0)); } }
        let pid = ""; { const m = ((tr && tr.innerHTML) || "").match(/(?:pid|[?&]p)=(\d+)/); if (m) pid = m[1]; } // пост-владелец вложения (как apk_list у ag4pda)
        let size = "", downloads = "";
        if (tr && tr.querySelectorAll) { for (const td of Array.from(tr.querySelectorAll("td"))) { const tt = (td.textContent || "").replace(/\s+/g, " ").trim(); if (!size) { const m = tt.match(/^([\d.,]+\s*(?:ГБ|МБ|Мб|КБ|Кб|GB|MB|KB))$/i) || tt.match(/([\d.,]+\s*(?:ГБ|МБ|Мб|КБ|Кб|GB|MB|KB))/i); if (m && !/Добавлено/i.test(tt)) { size = m[1]; continue; } } if (!downloads && /^\d{1,7}$/.test(tt)) { downloads = tt; continue; } } }
        if (!size) { const t = ((tr && tr.textContent) || "").replace(/\s+/g, " "); const m = t.match(/([\d.,]+\s*(?:ГБ|МБ|Мб|КБ|Кб|GB|MB|KB))/i); if (m) size = m[1]; }
        const aid = (() => { const m = url.match(/\/dl\/post\/(\d+)\//i); return m ? parseInt(m[1], 10) || 0 : 0; })(); // id вложения — ключ порядка у ag4pda
        c.files.push({ name, url, size, downloads, pid, added, ts, aid, postUrl: pid ? ("https://4pda.to/forum/index.php?act=findpost&pid=" + pid) : "", ver: apkVerName(name) });
      });
      const got = c.files.length - before;
      if (got > 0 && onGrow) { try { onGrow(c.files.slice()); } catch {} }
      if (got < pageSize) { c.full = true; break; }                // неполная страница — вложения кончились
      if (pi < maxPages - 1) await new Promise((r) => setTimeout(r, 250));   // не долбим 4pda без передышки
    }
  } catch {}
  c.running = false; c.done = true;
  })();
  try { await c.promise; } catch {}
  return c;
}
async function loadCatalog() {
  const url = catalogUrl(); if (!url) return 0;
  try {
    const r = await Apps.httpGet({ url });
    const j = JSON.parse(r.body || "{}");
    const map = {};
    // поддержка { pkg: id } и { pkg: {topicId} } и [{package, topicId}]
    if (Array.isArray(j)) { for (const it of j) { const p = it.package || it.pkg || it.packageName; const id = it.topicId || it.topic_id || it.id; if (p && id) map[p] = String(id).replace(/\D/g, ""); } }
    else for (const p in j) { const v = j[p]; const id = (typeof v === "object") ? (v.topicId || v.topic_id || v.id) : v; if (id) map[p] = String(id).replace(/\D/g, ""); }
    CATALOG = map; return Object.keys(map).length;
  } catch { return 0; }
}
function readCache() { try { return JSON.parse(localStorage.getItem(CKEY) || "{}"); } catch { return {}; } }
// РАЗОВАЯ САМОПОЧИНКА: сборки K-серии могли попортить сохранённые привязки на телефоне (перетирали
// topicId/версии значениями из общей базы), и порча переживает переустановку. Один раз чистим: все НЕручные
// привязки сбрасываются и перепривязываются заново из каталога/сервера. Ручные, избранное, скрытые — не трогаются.
try {
  if (localStorage.getItem("t4_fix_relink1") !== "1") {
    const c0 = JSON.parse(localStorage.getItem(CKEY) || "{}");
    let ch0 = false;
    for (const p0 in c0) { const e0 = c0[p0]; if (e0 && e0.topicId && !e0.manual) { delete e0.topicId; delete e0.matched; delete e0.shared; delete e0.ver4pda; delete e0.du; ch0 = true; } }
    if (ch0) localStorage.setItem(CKEY, JSON.stringify(c0));
    localStorage.setItem("t4_fix_relink1", "1");
  }
} catch {}
// разовая перепривязка пакетов-тёзок (после появления pickTopicForApp): прежний «последний побеждает» мог привязать к теме-сборнику
function relinkCollisions(apps) {
  try {
    if (localStorage.getItem("t4_coll_mig") === "done2" || !apps || !apps.length) return;
    if (!Object.keys(VERMULTI).length) { localStorage.setItem("t4_coll_mig", "done2"); return; } // тёзок нет
    const c = readCache(); let ch = 0;
    for (const a of apps) {
      const p = a.packageName; const e = p && c[p];
      if (!e || !e.topicId || e.manual || !VERMULTI[p]) continue;
      const vm = pickTopicForApp(a);
      const tid = vm && String(Array.isArray(vm) ? vm[0] : vm);
      if (tid && tid !== String(e.topicId)) { e.topicId = tid; e.ver4pda = ""; e.du = ""; e.stale = true; delete e.title4pda; delete e.desc; ch++; }
    }
    if (ch) localStorage.setItem(CKEY, JSON.stringify(c));
    localStorage.setItem("t4_coll_mig", "done2");
  } catch {}
}
// одноразовая ГЛУБОКАЯ уборка: сбросить kind/kf И topicId-привязки, накопленные экспериментами сборок B/C —
// кривой topicId в кэше вёл на игровую тему-тёзку и kindApp по свежему каталогу возвращал "games" для программы.
// После сброса всё перепривяжется начисто из актуального каталога (VERMAP по пакету).
try {
  if (localStorage.getItem("t4_kind_mig") !== "relink3") {
    const c = readCache(); let ch = 0;
    for (const p in c) {
      const e = c[p]; if (!e) continue;
      if (e.kind) { delete e.kind; ch++; }
      if (e.kf) { delete e.kf; ch++; }
      if (e.topicId) { delete e.topicId; delete e.matched; ch++; } // сброс привязки — свяжется заново из свежего каталога
    }
    if (ch) localStorage.setItem(CKEY, JSON.stringify(c));
    localStorage.setItem("t4_kind_mig", "relink3");
  }
} catch {}

function Icon({ app, size = 56 }) {
  const box = { width: size, height: size, borderRadius: size * 0.25, flexShrink: 0, overflow: "hidden" };
  const src = app.iconFile ? Capacitor.convertFileSrc(app.iconFile) : (app.icon || null);
  if (src) return <img src={src} alt="" style={{ ...box, objectFit: "cover" }} loading="lazy" />;
  const letter = (app.label || app.packageName || "?").trim().charAt(0).toUpperCase();
  return <div style={{ ...box, background: tileColor(app.packageName || app.label || "?"), display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#eaeaea", fontWeight: 800, fontSize: size * 0.43 }}>{letter}</span></div>;
}

const Mini = ({ kind }) => {
  if (kind === "inst") return <svg width="15" height="15" viewBox="0 0 24 24"><path d="M7 6 L5.8 4.4" stroke={C.green} strokeWidth="1.3" strokeLinecap="round" fill="none" /><path d="M17 6 L18.2 4.4" stroke={C.green} strokeWidth="1.3" strokeLinecap="round" fill="none" /><path d="M6 9a6 6 0 0 1 12 0z" fill={C.green} /><rect x="6.2" y="9.2" width="11.6" height="7.2" rx="1.4" fill={C.green} /><rect x="3" y="9.6" width="2.2" height="5.8" rx="1.1" fill={C.green} /><rect x="18.8" y="9.6" width="2.2" height="5.8" rx="1.1" fill={C.green} /><circle cx="9.6" cy="6.4" r="0.8" fill="#0d0d0d" /><circle cx="14.4" cy="6.4" r="0.8" fill="#0d0d0d" /></svg>;
  if (kind === "4pda") return <span style={{ width: 14, height: 14, borderRadius: 3, background: C.blue, color: "#fff", fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>4</span>;
  return <svg width="13" height="13" viewBox="0 0 24 24"><path d="M3.9 1.5c-.3.2-.5.5-.5 1v19c0 .5.2.8.5 1l10.5-10.5z" fill="#00C3FF" /><path d="M18 8.4 14.4 12l3.6 3.6 4-2.3c1.1-.6 1.1-1.7 0-2.3z" fill="#FFCE00" /><path d="m17.9 15.7-3.5-3.7L3.9 22.5c.4.4 1 .4 1.7.1z" fill="#FF3A44" /><path d="M3.9 1.5 14.4 12 18 8.4 5.6 1.4c-.7-.4-1.3-.3-1.7.1z" fill="#00D97D" /></svg>;
};

function VerBar({ app, info }) {
  const inst = app.versionName;
  const f = (info && info.flags) || {};
  const v4 = info && info.ver4pda, vp = info && info.verPlay;
  // как у ag4pda: установленная — обычная; версия столбца КРАСНАЯ если активное обновление
  // (новее И не скрыто), иначе ЗАЧЁРКНУТА серым (не новее ИЛИ скрыто)
  const cell = (kind, val, i, hidden) => {
    // ЦВЕТА ТОЛЬКО ЯРКИЕ: любой приглушённый тон на тёмных темах читается как чёрный (жалоба повторялась)
    let color = C.active, strike = false;
    if (kind === "inst" || !val) { color = C.active; }
    else {
      const newer = verCmp(val, inst) > 0;
      if (hidden) { color = C.sub; strike = true; }              // как у ag4pda: скрытое — обычный серый + зачёркивание (красный только у активного)
      else if (newer) { color = C.red; }                         // активное обновление — красным
      else { color = C.active; }
    }
    return (
      <div key={i} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "6px 4px", borderRight: i < 2 ? `1px solid ${C.verDiv}` : "none" }}>
        <Mini kind={kind} /><span style={{ fontSize: 12.5, color, textDecoration: strike ? "line-through" : "none", whiteSpace: "nowrap" }}>{val ? shortVer(val) : "—"}</span>
      </div>
    );
  };
  return <div style={{ display: "flex", borderTop: `1px solid ${C.verDiv}` }}>{cell("inst", inst, 0, false)}{cell("4pda", v4, 1, hideForum(f))}{cell("play", vp, 2, hidePlay(f))}</div>;
}

function AppCard({ app, info, onOpen, onMenu, onLong, selMode, selected, onToggleSel }) {
  const catDesc = (() => { try { const tid = info && info.topicId; if (!tid) return ""; const e = catById()[String(tid)]; return (e && e.d) || ""; } catch { return ""; } })();
  const sub = (info && info.desc) || catDesc || app.packageName;         // краткое описание (кэш → каталог), пакет — только если описания нет
  const big = localStorage.getItem("t4_big_cards") === "1";              // опция «Крупные карточки» (как в ag4pda)
  const nu = needsUpdate(app, info);
  const lp = useRef(false), tm = useRef(null);
  const [pressed, setPressed] = useState(false);
  const down = () => { setPressed(true); lp.current = false; if (!onLong) return; tm.current = setTimeout(() => { lp.current = true; onLong(app); }, 450); };
  const up = () => { setPressed(false); if (tm.current) clearTimeout(tm.current); };
  const click = () => { if (lp.current) { lp.current = false; return; } selMode ? onToggleSel(app) : onOpen(app); };
  return (
    <div style={{ background: selected ? C.accSoft : C.card, border: `1.5px solid ${selected ? C.acc : C.border}`, boxShadow: nu ? `inset 3px 0 0 ${C.red}` : "none", borderRadius: 10, marginBottom: 7, WebkitTapHighlightColor: "transparent", contentVisibility: "auto", containIntrinsicSize: big ? "0 114px" : "0 102px", opacity: pressed ? 0.92 : 1 }}>
      <div style={{ display: "flex", padding: big ? "10.5px 11px" : "9px 10px", gap: big ? 11 : 10, alignItems: "center", cursor: "pointer" }} onClick={click} onTouchStart={down} onTouchEnd={up} onTouchMove={up} onContextMenu={(e) => e.preventDefault()}>
        <Icon app={app} size={big ? 52 : 44} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: C.text, fontSize: big ? 17 : 16, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
          <div style={{ color: C.sub, fontSize: big ? 13 : 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{sub}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", flexShrink: 0, alignSelf: "stretch", justifyContent: "space-between", paddingTop: 2 }}>
          <span style={{ color: C.date, fontSize: 12 }}>{catDateFor(app) || fmtDate(app.lastUpdate)}</span>
          <div onClick={(e) => { e.stopPropagation(); if (!selMode && !e.__t4used) onMenu(app, e); }} onTouchStart={(e) => { e.stopPropagation(); if (!selMode) { e.__t4used = 1; onMenu(app, (e.touches && e.touches[0]) || e); } }} onTouchEnd={(e) => e.stopPropagation()} onPointerDown={(e) => e.stopPropagation()} onMouseDown={(e) => e.stopPropagation()} style={{ width: 34, height: 30, marginRight: -4, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3, WebkitTapHighlightColor: "transparent", visibility: selMode ? "hidden" : "visible" }}>
            {[0, 1, 2].map((i) => <span key={i} style={{ width: 3.5, height: 3.5, borderRadius: 4, background: C.sub }} />)}
          </div>
        </div>
      </div>
      <div style={{ padding: "0 10px 8px" }}><VerBar app={app} info={info} /></div>
    </div>
  );
}

function NavBtn({ title, onClick, children }) {
  const [p, setP] = useState(false);
  return <div title={title} onClick={onClick} onPointerDown={() => setP(true)} onPointerUp={() => setP(false)} onPointerLeave={() => setP(false)} style={{ padding: "10px 9px", cursor: "pointer", opacity: p ? 0.5 : 1, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</div>;
}
const sw = (color) => ({ fill: "none", stroke: color, strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" });
const IBot = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="11" width="18" height="10" rx="2.5" /><path d="M12 7v4" /><circle cx="12" cy="5" r="2" /><circle cx="8.5" cy="16" r="1.1" fill={color} stroke="none" /><circle cx="15.5" cy="16" r="1.1" fill={color} stroke="none" /></svg>);
const IEyeOff = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19" /><path d="M6.61 6.61A18.6 18.6 0 0 0 2 12s3 8 10 8a9.1 9.1 0 0 0 5.39-1.61" /><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" /><path d="M2 2l20 20" /></svg>);
const IEye = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M2 12s3-8 10-8 10 8 10 8-3 8-10 8-10-8-10-8Z" /><circle cx="12" cy="12" r="3" /></svg>);
const ICatalogUnused = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>);
const IDownload = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M7 10l5 5 5-5" /><path d="M12 15V3" /></svg>);
const ISearch = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>);
const IRefresh = ({ color = C.nav }) => (<svg width="23" height="23" viewBox="0 0 24 24" {...sw(color)}><path d="M21 12a9 9 0 1 1-2.64-6.36" /><path d="M21 3v6h-6" /></svg>);
const I4 = () => (<div style={{ width: 26, height: 26, borderRadius: 6, background: C.blue, color: "#fff", fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>4</div>);
const IPlayStore = () => (<svg width="22" height="22" viewBox="0 0 24 24"><path d="M3.9 1.5c-.3.2-.5.5-.5 1v19c0 .5.2.8.5 1l10.5-10.5z" fill="#00C3FF" /><path d="M18 8.4 14.4 12l3.6 3.6 4-2.3c1.1-.6 1.1-1.7 0-2.3z" fill="#FFCE00" /><path d="m17.9 15.7-3.5-3.7L3.9 22.5c.4.4 1 .4 1.7.1z" fill="#FF3A44" /><path d="M3.9 1.5 14.4 12 18 8.4 5.6 1.4c-.7-.4-1.3-.3-1.7.1z" fill="#00D97D" /></svg>);
const IStar = ({ filled }) => (<svg width="22" height="22" viewBox="0 0 24 24" fill={filled ? C.star : "none"} stroke={filled ? C.star : C.nav} strokeWidth="2" strokeLinejoin="round"><polygon points="12 2 15.1 8.3 22 9.3 17 14.1 18.2 21 12 17.8 5.8 21 7 14.1 2 9.3 8.9 8.3 12 2" /></svg>);
const IExternal = () => (<svg width="22" height="22" viewBox="0 0 24 24" {...sw(C.nav)}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><path d="M15 3h6v6" /><path d="M10 14L21 3" /></svg>);
const ITrash = () => (<svg width="22" height="22" viewBox="0 0 24 24" {...sw(C.red)}><path d="M3 6h18" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>);
const IOpenApp = () => (<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke={C.nav} strokeWidth="2" /><path d="M10 8.4l6 3.6-6 3.6z" fill={C.nav} /></svg>);
const IGear = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09A1.65 1.65 0 0 0 10 4.6V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>);
const IAndroid = ({ color = C.nav }) => (
  <svg width="24" height="24" viewBox="0 0 24 24">
    <path d="M7 6 L5.6 4.2" stroke={color} strokeWidth="1.6" strokeLinecap="round" fill="none" />
    <path d="M17 6 L18.4 4.2" stroke={color} strokeWidth="1.6" strokeLinecap="round" fill="none" />
    <path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill={color} />
    <rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill={color} />
    <rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill={color} />
    <rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill={color} />
    <circle cx="9.6" cy="8.8" r="0.85" fill="#0d0d0d" />
    <circle cx="14.4" cy="8.8" r="0.85" fill="#0d0d0d" />
  </svg>
);

function VerChip({ label, value, accent }) {
  return <div style={{ flex: 1, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
    <div style={{ color: C.sub, fontSize: 11, letterSpacing: 0.3 }}>{label}</div>
    <div style={{ color: accent || C.text, fontSize: 14, fontWeight: 600, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{value}</div>
  </div>;
}

function ContextMenu({ app, x, y, info, onClose, onInfo, onFlag, onLink }) {
  const flags = (info && info.flags) || {};
  const armed = useRef(false);                          // стало true после НОВОГО касания уже открытого меню
  const born = useRef(Date.now());
  const okBg = () => armed.current || Date.now() - born.current > 500;   // фон можно закрыть и по таймауту (мышь/застревание)
  const okAct = () => armed.current;                    // пункты — строго после нового касания (глотаем «призрак» отпускания)
  const vw = window.innerWidth, vh = window.innerHeight, W = 290;
  const left = Math.max(8, Math.min((x || vw / 2) - W / 2, vw - W - 8));
  const MENU_H = 430;                                  // примерная полная высота меню — чтобы оно ВЛЕЗАЛО целиком и не скроллилось внутри
  const top = Math.max(8, Math.min((y || 80), vh - MENU_H - 8));
  const iconBtn = (child, fn) => <div onClick={(e) => { e.stopPropagation(); if (!okAct()) return; fn(); }} style={{ flex: 1, display: "flex", justifyContent: "center", padding: "13px 0", cursor: "pointer" }}>{child}</div>;
  const check = (label, key) => (
    <div onClick={(e) => { e.stopPropagation(); if (!okAct()) return; onClose(); setTimeout(() => onFlag(app, key, !flags[key]), 0); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", cursor: "pointer", gap: 10 }}>
      <span style={{ color: C.text, fontSize: 14.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      <div style={{ width: 20, height: 20, flexShrink: 0, borderRadius: 4, border: `2px solid ${flags[key] ? C.acc : C.sub}`, background: flags[key] ? C.acc : "transparent", display: "flex", alignItems: "center", justifyContent: "center", color: C.onAcc, fontWeight: 800, fontSize: 13 }}>{flags[key] ? "✓" : ""}</div>
    </div>
  );
  const item = (label, fn) => <div onClick={(e) => { e.stopPropagation(); if (!okAct()) return; fn(); onClose(); }} style={{ padding: "12px 16px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>{label}</div>;
  return (
    <div onTouchStart={() => { armed.current = true; }} onMouseDown={() => { armed.current = true; }} onClick={() => { if (okBg()) onClose(); }} style={{ position: "fixed", inset: 0, zIndex: 95 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left, top, width: W, background: C.card, borderRadius: 12, overflow: "hidden", boxShadow: "0 10px 34px rgba(0,0,0,.55)", maxHeight: "calc(100vh - 16px)", overflowY: "auto", paddingBottom: 2 }}>
        <div style={{ display: "flex", borderBottom: `1px solid ${C.border}` }}>
          {iconBtn(<I4 />, () => { const tid = app.topicId || (readCache()[app.packageName] || {}).topicId; Apps.openUrl({ url: tid ? `https://4pda.to/forum/index.php?showtopic=${tid}` : searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}); onClose(); })}
          {iconBtn(<IPlayStore />, () => { openPlay(app); onClose(); })}
          {iconBtn(<IStar filled={flags.fav} />, () => { onFlag(app, "fav", !flags.fav); onClose(); })}
          {iconBtn(<ITrash />, () => { Apps.uninstallApp({ packageName: app.packageName }).catch(() => {}); onClose(); })}
        </div>
        {item("Открыть приложение", () => Apps.launchApp({ packageName: app.packageName }).catch(() => {}))}
        {item("Доступные связи (связать тему)", () => onLink(app))}
        {flags.hidden ? item("Сделать видимым", () => setTimeout(() => onFlag(app, "hidden", false), 0)) : item("Скрыть приложение", () => setTimeout(() => onFlag(app, "hidden", true), 0))}
        {check("Скрыть все обновления", "hideAll")}
        {check("Скрыть обновления с форума", "hideForum")}
        {check("Скрыть обновления с Google Play", "hidePlay")}
        {item("Информация", () => onInfo(app))}
      </div>
    </div>
  );
}

function InfoDialog({ app, info, onClose }) {
  const [d, setD] = useState(null);
  useEffect(() => { Apps.appDetails({ packageName: app.packageName }).then(setD).catch(() => setD({})); }, []);
  const dt = (ms) => { if (!ms) return ""; const x = new Date(ms); const p = (n) => String(n).padStart(2, "0"); return `${p(x.getDate())}.${p(x.getMonth() + 1)}.${x.getFullYear()} ${p(x.getHours())}:${p(x.getMinutes())}`; };
  const sz = (b) => (!b ? "" : b >= 1048576 ? (b / 1048576).toFixed(1) + " МБ" : Math.round(b / 1024) + " КБ");
  const nf = (info || {});
  const g = (k) => (d && d[k] != null && d[k] !== "" ? d[k] : null);
  const row = (label, value, onClick) => (value || value === 0) ? (
    <div style={{ fontSize: 14.5, marginBottom: 7, lineHeight: 1.35 }}>
      <span style={{ color: C.text, fontWeight: 700 }}>{label}</span>
      <span style={{ color: C.sub }}> : </span>
      <span onClick={onClick} style={{ color: onClick ? "#4db6c4" : C.text, textDecoration: onClick ? "underline" : "none", wordBreak: "break-all", cursor: onClick ? "pointer" : "default" }}>{value}</span>
    </div>
  ) : null;
  const vName = app.versionName || g("versionName");
  const vCode = g("versionCode");
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 75, display: "flex", alignItems: "center", justifyContent: "center", padding: 18 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 460, background: C.light ? C.card : "#3a3a3a", borderRadius: 6, padding: 22, maxHeight: "85%", overflowY: "auto" }}>
        <div style={{ color: C.text, fontSize: 24, fontWeight: 400, marginBottom: 18 }}>Информация</div>
        {row("Имя пакета", app.packageName, () => openPlay(app))}
        {row("Имя приложения", app.label || g("label"))}
        {row("Имя на форуме", nf.title4pda)}
        {row("Версия (код)", vName ? `${vName}${vCode != null ? ` (${vCode})` : ""}` : null)}
        {row("Версия на форуме", nf.ver4pda)}
        {row("Версия в Google Play", nf.verPlay ? `${nf.verPlay}${nf.verPlayCode ? ` (${nf.verPlayCode})` : ""}` : null)}
        {row("Дата на форуме", nf.fdate)}
        {row("Обновление шапки", nf.hatDate)}
        {row("Дата обновления", dt(app.lastUpdate || g("lastUpdate")))}
        {row("Дата установки", dt(app.firstInstall || g("firstInstall")))}
        {row("Размер APK", sz(g("apkSize")))}
        {row("Target / Min SDK", g("targetSdk") ? `${g("targetSdk")}${g("minSdk") ? " / " + g("minSdk") : ""}` : null)}
        {row("Установщик", g("installer"))}
        {row("Связь", nf.topicId, nf.topicId ? () => Apps.openWeb({ url: `https://4pda.to/forum/index.php?showtopic=${nf.topicId}` }).catch(() => {}) : null)}
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 16 }}>
          <div onClick={onClose} style={{ color: "#4db6c4", fontWeight: 700, fontSize: 15, cursor: "pointer", padding: "6px 8px" }}>ЗАКРЫТЬ</div>
        </div>
      </div>
    </div>
  );
}

let DL_HIDDEN = new Set(); // скрытые из списка загрузки — только на текущую сессию (id сбрасываются при перезапуске)
function Downloads({ onClose }) {
  const [items, setItems] = useState(null);
  const [del, setDel] = useState(null);
  const [clearAll, setClearAll] = useState(false);
  const [sigs, setSigs] = useState({});
  const prev = useRef({});
  const sigChecked = useRef({});
  const hidden = () => Array.from(DL_HIDDEN);
  const hide = (id) => { DL_HIDDEN.add(id); };
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await Apps.dlStatus();
        if (!alive) return;
        const now = Date.now();
        const list = (r.items || []).map((it) => {
          const p = prev.current[it.id];
          let speed = 0;
          if (p && it.status === 2 && now > p.t) speed = Math.max(0, (it.done - p.done) / ((now - p.t) / 1000));
          prev.current[it.id] = { done: it.done, t: now };
          return { ...it, speed };
        }).sort((a, b) => (b.date || 0) - (a.date || 0));
        const hid = hidden();
        const live = [];
        for (const it of list) {
          if (it.status === 8) {                                  // готово, но файла на диске уже нет — запись не нужна
            let ok = true;
            try { const chk = await Apps.fileExists({ path: it.path || it.pubPath || "" }); ok = !!(chk && chk.exists); } catch {}
            if (!ok) { hide(it.id); Apps.dlCancel({ id: it.id, deleteFile: false }).catch(() => {}); continue; }
          }
          live.push(it);
        }
        setItems(live.filter((it) => !hid.includes(it.id)));
      } catch { if (alive) setItems([]); }
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => { alive = false; clearInterval(iv); };
  }, []);
  const sz = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + " МБ" : Math.max(1, Math.round(b / 1024)) + " КБ");
  const spd = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + " МБ/с" : Math.round(b / 1024) + " КБ/с");
  const [amap, setAmap] = useState({}); // метаданные apk (иконка/имя/версия) готовых загрузок
  useEffect(() => {
    let alive = true;
    (async () => {
      for (const it of (items || [])) {
        if (it.status !== 8) continue;
        const p = it.path || (String(it.uri || "").indexOf("file://") === 0 ? decodeURIComponent(it.uri.slice(7)) : "");
        if (!p || !/\.apk$/i.test(p) || amap[it.id] !== undefined) continue;
        try { const m = await Apps.apkMeta({ path: p }); if (alive) setAmap((x) => ({ ...x, [it.id]: m || {} })); } catch { if (alive) setAmap((x) => ({ ...x, [it.id]: {} })); }
      }
    })();
    return () => { alive = false; };
  }, [items]);
  const [sigDlg, setSigDlg] = useState(null);
  useEffect(() => {   // итог установки от системного установщика (событие + добор при возврате в приложение)
    const show = (ev) => { if (!ev || ev.ok || ev.status === undefined) return; const m = (ev.message && ev.message !== "null" && ev.message !== "undefined") ? ev.message : ("код " + ev.status); notify("Установка не выполнена: " + m + (ev.pkg && ev.pkg !== "null" ? "\n" + ev.pkg : "")); };
    let h = null, r = null;
    try { h = Apps.addListener && Apps.addListener("installResult", show); } catch {}
    const pull = () => { try { Apps.lastInstallResult && Apps.lastInstallResult().then(show).catch(() => {}); } catch {} };
    try { r = CapApp.addListener("appStateChange", (st) => { if (st && st.isActive) pull(); }); } catch {}
    pull();
    const off = (x) => { try { if (x && x.remove) x.remove(); else if (x && x.then) x.then((y) => y && y.remove && y.remove()); } catch {} };
    return () => { off(h); off(r); };
  }, []);
  const doInstall = (arg) => { Apps.requestInstall && Apps.requestInstall().catch(() => {}); Apps.installApk(arg).catch((e) => { notify("Не удалось установить: " + ((e && (e.message || e.errorMessage)) || "?")) }); };
  const install = (it) => {
    const u = it.uri || "";
    let p = it.path || "";
    if (!p && u.indexOf("file://") === 0) { p = u.slice(7); try { p = decodeURIComponent(p); } catch {} }
    let arg = null;
    // ПЕРЕДАЁМ И ПУТЬ, И content:// — на Android 11+ файл в общих «Загрузках» может быть недоступен по пути,
    // тогда установщик берёт его по content:// (pubUri или найденный в MediaStore по имени)
    const cu = it.pubUri || (String(u).indexOf("content://") === 0 ? u : "");
    if (p || cu || u) arg = Object.assign({}, p ? { path: p } : null, cu ? { uri: cu } : (u && !p ? { uri: u } : null), it.title ? { name: it.title } : null);
    if (!arg) return;
    Apps.checkSignature(arg).then((r) => {
      if (r && r.installed && !r.match) { const sd = Object.assign({ pkg: (r.package || "") }, arg); setSigDlg(sd); }
      else doInstall(arg);
    }).catch(() => doInstall(arg));
  };
  return (
    <div className="t4-screen" style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 66 }}>
      <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Загрузки</span></div></div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 0" }}>
        {items === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : items.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Нет загрузок</div> :
          items.map((it) => {
            const running = it.status === 2 || it.status === 1;
            const pct = it.total > 0 ? Math.min(100, Math.round((it.done / it.total) * 100)) : 0;
            const eta = running && it.speed > 0 && it.total > 0 ? Math.round((it.total - it.done) / it.speed) : 0;
            return (
              <div key={it.id} onClick={() => it.status === 8 && install(it)} style={{ background: C.card, border: `1px solid ${it.status === 16 ? "#7a3a34" : running ? C.acc : C.border}`, borderRadius: 12, marginBottom: 10, overflow: "hidden", cursor: it.status === 8 ? "pointer" : "default" }}>
                {(() => { const m = amap[it.id] || {}; const nm = m.label || (it.title || "").replace(/\.(apk|apks|xapk|zip|obb)$/i, ""); const ver = m.version || (() => { const x = (it.title || "").match(/(\d+(?:\.\d+){1,})/); return x ? x[1] : ""; })(); return (
                  <>
                    <div style={{ display: "flex", gap: 12, alignItems: "center", padding: "11px 12px" }}>
                      {m.icon ? <img src={String(m.icon).indexOf("data:") === 0 ? m.icon : "data:image/png;base64," + m.icon} style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0 }} /> :
                        <div style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, background: "#2c2016", display: "flex", alignItems: "center", justifyContent: "center", color: it.status === 8 ? C.acc : it.status === 16 ? C.red : C.nav }}>
                          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 3v11m0 0 4-4m-4 4-4-4M5 20h14" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        </div>}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ color: C.text, fontSize: 15.5, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{nm}</div>
                        <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it.title}</div>
                      </div>
                    </div>
                    {it.status === 8 && (
                      <div style={{ display: "flex", borderTop: `1px solid ${C.border}` }}>
                        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 7, padding: "9px 12px", color: C.sub, fontSize: 13.5, borderRight: `1px solid ${C.border}` }}>
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" strokeWidth="1.7" /><path d="M9 8h6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg>
                          <span>{ver || "—"}</span>
                        </div>
                        <div style={{ flex: 1, textAlign: "right", padding: "9px 12px", color: C.sub, fontSize: 13.5 }}>{it.total > 0 ? sz(it.total) : ""}</div>
                      </div>
                    )}
                  </>
                ); })()}
                <div style={{ padding: "0 12px 12px" }}>
                {running ? (
                  <div style={{ marginTop: 11 }}>
                    <div style={{ height: 6, borderRadius: 4, background: C.border, overflow: "hidden" }}><div style={{ height: "100%", width: pct + "%", background: C.acc, borderRadius: 4 }} /></div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 5, fontSize: 12.5, color: C.sub }}>
                      <span>{it.status === 1 ? "Ожидание…" : `Осталось ${eta} сек · ${spd(it.speed)}`}</span>
                      <span>{pct}%</span>
                    </div>
                  </div>
                ) : it.status === 16 ? (
                  <div style={{ color: C.red, fontSize: 12.5, marginTop: 7, wordBreak: "break-word" }}>Ошибка{it.error ? ": " + it.error : ""}</div>
                ) : (
                  <div style={{ color: it.status === 8 ? C.acc : C.sub, fontSize: 13, marginTop: 7 }}>{it.status === 8 ? "Готово — нажми, чтобы установить" : "Пауза"}</div>
                )}
                <div style={{ display: "flex", gap: 20, marginTop: 10, justifyContent: "flex-end" }} onClick={(e) => e.stopPropagation()}>
                  
                  {(it.status === 2 || it.status === 1) && <div onClick={() => Apps.dlPause({ id: it.id }).catch(() => {})} style={{ color: C.acc, fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>Пауза</div>}
                  {(it.status === 16 || it.status === 4) && <div onClick={() => Apps.dlResume({ id: it.id }).catch(() => {})} style={{ color: C.acc, fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>Возобновить</div>}
                  <div onClick={() => setDel(it)} style={{ color: C.red, fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>Удалить</div>
                </div>
                </div>
              </div>
            );
          })}
        <div style={{ height: 12 }} />
      </div>
      {items && items.length > 0 && (
        <div onClick={() => setClearAll(true)} style={{ position: "absolute", right: 18, bottom: "calc(var(--sab) + 18px)", width: 52, height: 52, borderRadius: 26, background: C.acc, color: C.onAcc, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", zIndex: 5 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" /></svg>
        </div>
      )}
      {clearAll && (
        <div onClick={() => setClearAll(false)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 90, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "calc(100% - 20px)", maxWidth: 420, background: C.card, borderRadius: 18, padding: "16px 16px 8px" }}>
            <div style={{ color: C.text, fontSize: 17, fontWeight: 600, marginBottom: 10 }}>Очистить загрузки?</div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 16, flexWrap: "wrap" }}>
              <div onClick={() => setClearAll(false)} style={{ color: C.sub, fontWeight: 700, fontSize: 14, padding: "8px 4px", cursor: "pointer" }}>ОТМЕНА</div>
              <div onClick={() => { (items || []).forEach((it) => { hide(it.id); Apps.dlCancel({ id: it.id, deleteFile: false }).catch(() => {}); }); setItems([]); setClearAll(false); }} style={{ color: C.acc, fontWeight: 700, fontSize: 14, padding: "8px 4px", cursor: "pointer" }}>ТОЛЬКО СПИСОК</div>
              <div onClick={() => { (items || []).forEach((it) => { hide(it.id); Apps.dlCancel({ id: it.id, deleteFile: true }).catch(() => {}); }); setItems([]); setClearAll(false); }} style={{ color: C.red, fontWeight: 700, fontSize: 14, padding: "8px 4px", cursor: "pointer" }}>ВМЕСТЕ С ФАЙЛАМИ</div>
            </div>
          </div>
        </div>
      )}
      {del && (
        <div className="t4-dim" onClick={() => setDel(null)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 60, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 360, background: C.card, borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Удалить загрузку</div>
            <div style={{ color: C.sub, fontSize: 13.5, marginBottom: 16, wordBreak: "break-all" }}>{del.title}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <div onClick={() => { hide(del.id); Apps.dlCancel({ id: del.id, deleteFile: true }).catch(() => {}); setItems((prev) => (prev ? prev.filter((x) => x.id !== del.id) : prev)); setDel(null); }} style={{ padding: "12px 10px", color: C.red, fontSize: 14.5, fontWeight: 600, cursor: "pointer" }}>Удалить файл и задачу</div>
              <div onClick={() => { Apps.dlCancel({ id: del.id, deleteFile: false }).catch(() => {}); hide(del.id); setItems((prev) => (prev ? prev.filter((x) => x.id !== del.id) : prev)); setDel(null); }} style={{ padding: "12px 10px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>Убрать из списка (файл оставить)</div>
              <div onClick={() => setDel(null)} style={{ padding: "12px 10px", color: C.sub, fontSize: 14.5, cursor: "pointer", textAlign: "right" }}>Отмена</div>
            </div>
          </div>
        </div>
      )}
      {sigDlg && (
        <div onClick={() => setSigDlg(null)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 61, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 370, background: C.card, borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.acc, fontSize: 16, fontWeight: 600, marginBottom: 8 }}>Подпись не совпадает</div>
            <div style={{ color: C.sub, fontSize: 13.5, marginBottom: 16, lineHeight: 1.4 }}>Подпись у этого файла не совпадает с подписью установленной у вас версии. Перед установкой нужно удалить установленную программу.</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <div onClick={() => { if (sigDlg.pkg) Apps.uninstallApp({ packageName: sigDlg.pkg }).catch(() => {}); setSigDlg(null); }} style={{ padding: "12px 10px", color: C.red, fontSize: 14.5, fontWeight: 600, cursor: "pointer" }}>Удалить установленную</div>
              <div onClick={() => { const pth = sigDlg.path || ""; const uri = sigDlg.uri || ""; setSigDlg(null); doInstall(pth ? { path: pth } : { uri: uri }); }} style={{ padding: "12px 10px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>Всё равно установить</div>
              <div onClick={() => setSigDlg(null)} style={{ padding: "12px 10px", color: C.sub, fontSize: 14.5, cursor: "pointer", textAlign: "right" }}>Отмена</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ArchLine() {
  const dev = (DEVICE_ABIS || []).map((a) => (a || "").toLowerCase()); // реальные ABI устройства (Build.SUPPORTED_ABIS) — что процессор действительно умеет
  const arm = dev.some((d) => d.indexOf("armeabi") >= 0 || d.indexOf("armv7") >= 0 || d.indexOf("v7a") >= 0);
  const arm64 = dev.some((d) => d.indexOf("arm64") >= 0 || d.indexOf("v8a") >= 0);
  const x86 = dev.some((d) => d === "x86");
  const x64 = dev.some((d) => d.indexOf("x86_64") >= 0 || d === "x64");
  const mips = dev.some((d) => d.indexOf("mips") >= 0);
  const t = (o, txt) => <span style={{ color: o ? "#e8e8e8" : C.sub, fontWeight: o ? 700 : 400 }}>{txt}</span>;
  return <span style={{ fontSize: 12.5, color: C.text }}>({t(arm, "ARM")}/{t(arm64, "64")} {t(x86, "X86")}/{t(x64, "64")} {t(mips, "MIPS")})</span>;
}
// экран «ФАЙЛЫ» — список apk; тап по строке — закачка, кнопка «i» — инфо
class DlgGuard extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(e) { return { err: e }; }
  render() {
    if (this.state.err) return <div onClick={this.props.onClose} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 70, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}><div style={{ background: "#2a1414", border: "1px solid #5a2a2a", borderRadius: 12, padding: 16, color: "#f0b0b0", fontSize: 13, lineHeight: 1.4, maxWidth: 420, wordBreak: "break-word" }}>Ошибка списка файлов: {String((this.state.err && (this.state.err.message || this.state.err)) || "?")}<br /><span style={{ fontSize: 11, opacity: 0.85 }}>{String((this.state.err && this.state.err.stack) || "").split("\n").slice(0, 4).join(" ⏎ ").slice(0, 400)}</span><br />Тапни, чтобы закрыть, и пришли этот текст.</div></div>;
    return this.props.children;
  }
}
try { localStorage.removeItem("t4_files_cache"); } catch {}
const FILES_PREFETCH = new Map();                 // тема → обещание списка (готовим заранее)
function prefetchFiles(topicId) {
  const k = String(topicId || ""); if (!k || FILES_PREFETCH.has(k) || FILES_CACHE.has(k)) return;
  FILES_PREFETCH.set(k, Promise.allSettled([
    fetchTopicAttachments(k).then((c) => (c && c.files) || []).catch(() => []),
    agFiles(k),
  ]).then(([a, b]) => {
    try {
      const files = (a.value || []).slice().sort((x, y) => (y.aid || 0) - (x.aid || 0));
      const ag = {}; for (const x of (b.value || [])) { if (x.aid) ag[String(x.aid)] = x; const nm = safeDec(String(x.url || "").split("/").pop() || "").toLowerCase(); if (nm) ag["n:" + nm] = x; }
      if (files.length) FILES_CACHE.set(k, { files, ag });
    } catch {}
  }).catch(() => {}));
}
const FILES_CACHE = new Map();   // тема → { files, ag } — чтобы при повторном открытии не грузить заново
function fcSave(topic, val) { FILES_CACHE.set(String(topic), val); }   // только на время сеанса, на диск не пишем
function FilesDialog({ app, files, dlPosts, mode, onDownloads, onClose }) {
  const [picked, setPicked] = useState(null);
  useEffect(() => { window.__closeFiles = () => { if (picked) { setPicked(null); return true; } return false; }; return () => { window.__closeFiles = null; }; }, [picked]);
  const [askDl, setAskDl] = useState(false);
  const [postPop, setPostPop] = useState(null);
  const [mySig, setMySig] = useState(null); // подпись установленного приложения (sha), "" если не установлено
  const [mySigMd5, setMySigMd5] = useState("");   // та же подпись в виде, который отдаёт сервер App&Game
  const [meta, setMeta] = useState({});     // f.url -> { sig, abis } из apkInfo (кэш подписи/архитектуры файла)
  const topicIdF = (readCache()[app.packageName] || {}).topicId || app.topicId;
  const [postFiles, setPostFiles] = useState(() => { const k = String(topicIdF); return (postFilesCache[k] && postFilesCache[k].files.slice()) || []; });
  const [loadingPosts, setLoadingPosts] = useState(false);
  const apkVer = (name) => { const m = (name || "").match(/(\d+(?:\.\d+){1,}(?:[\s._-]*(?:build|beta|alpha|rc|b)[\s._-]*\d+)?)/i); return m ? m[1].replace(/[\s._-]*(build|beta|alpha|rc|b)[\s._-]*(\d+)$/i, (q, w, d2) => " " + w.toLowerCase() + " " + d2) : ""; };
  const buildCodeFromName = (name) => { const n = String(name || ""); let m = n.match(/\[(\d{5,})\]/); if (m) return +m[1]; m = n.match(/[_-]B(\d{6,})/i); if (m) return +m[1]; return 0; };
  const pkgFromName = (name) => { const m = String(name || "").match(/\b([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*){2,})\b/i); return m && m[1].split(".").every((x) => /[a-z]/i.test(x)) ? m[1] : ""; };
  const topicPre = String((readCache()[app.packageName] || {}).topicId || app.topicId || "");
  const cachedPre = FILES_CACHE.get(topicPre) || null;
  const [attachFiles, setAttachFiles] = useState(cachedPre ? cachedPre.files : []);
  const agWait = useRef(null);
  const fSw = useRef({ on: false });
  const [fTab, setFTab] = useState("all");
  const [fShow, setFShow] = useState(300);
  useEffect(() => { setFShow(300); }, [fTab]);
  const [fAnim, setFAnim] = useState("");                 // направление перелистывания вкладки
  const switchFTab = (k) => {
    if (k === fTab) return;
    const order = ["all", "differ", "arch"];
    setFAnim(order.indexOf(k) > order.indexOf(fTab) ? "t4-sl-in-r" : "t4-sl-in-l");
    setFTab(k);
  };   // «Все файлы» / «Другая подпись»
  const [agInfo, setAgInfo] = useState(cachedPre ? cachedPre.ag : {});   // номер файла → сведения с сервера App&Game
  const [loadingAttach, setLoadingAttach] = useState(!cachedPre);
  useEffect(() => {
    let alive = true;
    if (!topicIdF) { setLoadingAttach(false); return; }
    if (cachedPre && cachedPre.files.length && cachedPre.files.some((f) => f.postUrl) && cachedPre.ag && Object.keys(cachedPre.ag).length) return;   // всё уже есть
    setLoadingAttach(true);
    (async () => {
      try {                                                        // сведения App&Game (подпись, пакет, Android, скачивания) — ВСЕГДА, независимо от источника списка
        agFiles(topicIdF).then((ag) => {
          if (!alive) return;
          // ВАЖНО: сервер хранит ВСЮ историю файлов темы (у MiXplorer это тысячи записей),
          // поэтому список строим по вложениям самой темы — как App&Game, а серверные данные
          // только дополняют строки. Показываем их сразу, лишь пока тема ещё грузится.

          const m2 = {};
          for (const x of ag) {
            if (x.aid) m2[String(x.aid)] = x;
            const nm = safeDec(String(x.url || "").split("/").pop() || "").toLowerCase();
            if (nm) m2["n:" + nm] = x;
          }
          window.__agFiles = `файлы App&Game: ${ag.length} (тема ${topicIdF}) ${window.__agRaw || ""}`;
          setAgInfo(m2);
          try { if (agWait.current) agWait.current(); } catch {}
          try { const cur = FILES_CACHE.get(String(topicIdF)); if (cur) fcSave(topicIdF, { ...cur, ag: m2 }); } catch {}
        }).catch(() => { window.__agFiles = "файлы App&Game: ошибка"; });
      } catch {}
      // оба источника идут ОДНОВРЕМЕННО: что пришло раньше — то и показываем;
      // более полный список (страница вложений) затем заменяет короткий
      let shown = 0;
      const put = (arr) => {
        if (!alive || !arr || !arr.length || arr.length <= shown) return;
        shown = arr.length;
        const sorted = arr.slice().sort((a, b) => (b.aid || 0) - (a.aid || 0));   // порядок как в App&Game
        setAttachFiles(sorted);
        setLoadingAttach(false);
        if (sorted.some((f) => f.postUrl)) fcSave(topicIdF, { files: sorted, ag: agInfo });
      };
      const agReady = new Promise((res) => { agWait.current = res; setTimeout(res, 1500); });   // ждём подписи, но не дольше 1.5с
      const pPostsFirst = protoOn() ? protoTopicFiles(topicIdF, 0, 20).then((pf) => put(pf)).catch(() => {}) : Promise.resolve();
      const pre = FILES_PREFETCH.get(String(topicIdF));
      if (pre) { try { await pre; const c0 = FILES_CACHE.get(String(topicIdF)); if (c0 && c0.files && c0.files.length) { put(c0.files); } } catch {} }
      const pAttach = fetchTopicAttachments(topicIdF, { all: true, onGrow: async (files) => { await agReady; put(files); if (alive) setLoadingAttach(false); } }).then(async (c) => { await agReady; put(c && c.files); if (alive) setLoadingAttach(false); }).catch(() => { if (alive) setLoadingAttach(false); });
      const pPosts = protoOn() ? protoTopicFiles(topicIdF, 0, 20).then(async (pf) => { await agReady; put(pf); }).catch(() => {}) : Promise.resolve();
      setTimeout(() => { if (alive) setLoadingAttach(false); }, 6000);   // страховка: спиннер не крутится вечно (офлайн/молчащая сеть)
      await Promise.all([pPostsFirst, pAttach, pPosts]);
      if (alive) setLoadingAttach(false);
      return;
      if (alive) setLoadingAttach(false);

      try {                                                            // сведения с сервера App&Game: подпись, пакет, минимальный Android, процессоры, скачивания
        const ag = await agFiles(topicIdF);
        if (alive && ag.length) setAgInfo(Object.fromEntries(ag.map((x) => [String(x.aid), x])));
      } catch {}
    })();
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    let alive = true;
    if (!dlPosts || !dlPosts.length || !topicIdF) return;
    const k = String(topicIdF);
    if (postFilesCache[k] && postFilesCache[k].done) { setPostFiles(postFilesCache[k].files.slice()); return; }
    setLoadingPosts(true);
    fetchDlPostFiles(topicIdF, dlPosts, app.versionName, mode, (files) => { if (alive) setPostFiles(files); }).then(() => { if (alive) setLoadingPosts(false); });
    return () => { alive = false; };
  }, []);
  useEffect(() => { let alive = true; (async () => { let ms = ""; try { const r = await Apps.appSignature({ pkg: app.packageName }); ms = (r && r.sig) || ""; } catch {} if (alive) setMySig(ms); try { const rr2 = await Apps.appSignature({ pkg: app.packageName }); if (alive && rr2 && rr2.sigMd5) setMySigMd5(String(rr2.sigMd5).toUpperCase()); } catch {} })(); return () => { alive = false; }; }, []);
  const merged = (() => {
    const byUrl = new Map();
    // «Файлы» — таблица вложений темы (как ag4pda). Файлы из постов/шапки берутся ТОЛЬКО если вложений нет:
    // раньше они показывались первыми (у них нет даты) и в момент открытия вместо свежих версий висел старый хлам.
    const attachReady = attachFiles.length > 0;
    const src = mode === "updates" ? [...attachFiles, ...postFiles]
      : attachReady ? [...attachFiles]
        : (loadingAttach ? [] : [...postFiles, ...(files || [])]);
    for (const f of src) {
      const ex = byUrl.get(f.url);
      if (!ex) byUrl.set(f.url, f);
      else if (!ex.postUrl && f.postUrl) byUrl.set(f.url, f); // предпочитаем запись с постом-анонсом (для попапа «i»)
    }
    return [...byUrl.values()];
  })();
  let list = merged;
  if (mode === "updates") { const pids = new Set((dlPosts || []).map((p) => { const m = (p.url || "").match(/(?:pid|[?&]p)=(\d+)/); return m ? m[1] : ""; }).filter(Boolean)); if (pids.size) list = list.filter((f) => f.postUrl && !f.pid ? true : (f.pid ? pids.has(f.pid) : !!f.postUrl)); } // в обновлениях — только вложения постов версий шапки «Скачать:» (по pid, как ag4pda); чужие вложения обсуждения отпадают
  if (mode === "updates" && app.versionName) list = list.filter((f) => { const v = apkVer(f.name) || f.ver; return v && verCmp(v, app.versionName) > 0; }); // без установленной версии — показываем актуальные как есть
  // опция: показывать только файлы под процессор пользователя (по умолчанию вкл.)
  const onlyMyArch = localStorage.getItem("t4_files_myarch") !== "0";
  if (onlyMyArch) list = list.filter((f) => fileForDevice(f.name));
  // сортировка
  const dev64 = (DEVICE_ABIS || []).some((a) => /arm64|v8a|x86_64|\bx64\b/i.test(a || ""));
  const file64 = (n) => /arm64|v8a|x86_64|\bx64\b/i.test(n || "");
  if (mode === "updates") {
    // приоритет: новее+64 (если устройство поддерживает 64) → новее+любой поддерживаемый → новее+не мой процессор
    const rank = (f) => { if (dev64 && file64(f.name) && fileForDevice(f.name)) return 0; if (fileForDevice(f.name)) return 1; return 2; };
    list = [...list].sort((a, b) => { const r = rank(a) - rank(b); if (r) return r; const va = apkVer(a.name) || a.ver, vb = apkVer(b.name) || b.ver; return (va && vb) ? verCmp(vb, va) : 0; });
  }
  // «Файлы»: порядок как у ag4pda — по id вложения (номер в ссылке /forum/dl/post/<id>/), новые сверху.
  // У ag4pda файлы лежат в SparseArray с ключом file_id и при сборке списка каждый вставляется в одну и ту же
  // позицию → на экране получается обратный порядок ключей. Дата в его списке — только сортировка внутри
  // разбора страницы вложений, конечный порядок задаёт именно id. Версию из имени файла НЕ используем.
  if (mode !== "updates") {
    const dev64b = (DEVICE_ABIS || []).some((a) => /arm64|v8a|x86_64|\bx64\b/i.test(a || ""));
    const file64b = (n) => /arm64|v8a|x86_64|\bx64\b/i.test(n || "");
    const isApk = (n) => /\.(apk|apks|xapk)(\?|#|$)/i.test(n || "");   // apk-типы — выше архивов
    list = [...list].sort((a, b) => {
      const ia = a.aid || 0, ib = b.aid || 0;
      if (ia !== ib) return ib - ia;                                    // id вложения: больше (новее) — выше
      const ta = a.ts || 0, tb = b.ts || 0;
      if (ta !== tb) return tb - ta;                                    // запасной ключ — дата добавления
      const ka = isApk(a.name) ? 0 : 1, kb = isApk(b.name) ? 0 : 1;
      if (ka !== kb) return ka - kb;                                    // без id (файлы из постов/шапки): APK, потом ZIP
      const va = apkVer(a.name) || a.ver, vb = apkVer(b.name) || b.ver;
      if (va && vb) { const c = verCmp(vb, va); if (c) return c; }
      else if (va && !vb) return -1; else if (!va && vb) return 1;
      const ra = (dev64b && file64b(a.name) && fileForDevice(a.name)) ? 0 : (fileForDevice(a.name) ? 1 : 2);
      const rb = (dev64b && file64b(b.name) && fileForDevice(b.name)) ? 0 : (fileForDevice(b.name) ? 1 : 2);
      return ra - rb;
    });
  }
  useEffect(() => {
    // apk по сети НЕ читаем (Range по /dl/post/ 4pda считает за скачивание) — берём только то, что уже лежит в кэше
    const add = {};
    for (const f of list) { if (!f.url || meta[f.url] !== undefined) continue; let c = null; try { c = JSON.parse(localStorage.getItem("t4_apk_" + f.url) || "null"); } catch {} if (c) add[f.url] = c; }
    if (Object.keys(add).length) setMeta((m) => ({ ...m, ...add }));
  }, [list.length]);
  // строка архитектуры (как ag4pda): белым только те ABI, что есть в файле И поддерживаются телефоном
  const archLine = (url, name) => {
    const m = meta[url];
    const abis = Array.from(new Set([...((m && m.abis) ? parseAbis(m.abis) : []), ...fileAbis(name)])); // только реально известное: из самого apk и из имени файла
    if (!abis.length) return null;                       // НИЧЕГО не знаем про процессоры — строку не рисуем совсем (не выдумываем)
    const on = (names) => names.some((n) => abis.includes(n));
    const B = (names, t) => { const w = on(names); return <span style={{ color: w ? C.ink : C.sub, fontWeight: w ? 700 : 400 }}>{t}</span>; };
    const ver = (m && m.minSdk) ? (SDK_VER[m.minSdk] || m.minSdk) : "";
    return <span>{ver ? "Android " + ver + "+ " : ""}({B(["armeabi-v7a"], "ARM")}/{B(["arm64-v8a"], "64")} {B(["x86"], "X86")}/{B(["x86_64"], "64")} {B(["mips", "mips64"], "MIPS")})</span>;
  };
  const iBtn = (fn) => <div onClick={(e) => { e.stopPropagation(); fn(); }} style={{ width: 34, height: 34, borderRadius: "50%", border: `2px solid ${C.sub}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, cursor: "pointer" }}><span style={{ color: C.sub, fontSize: 18, fontWeight: 700, transform: "rotate(180deg)" }}>!</span></div>;
  const topicId = (readCache()[app.packageName] || {}).topicId || app.topicId;
  const openFile4pda = (f) => { let url = f.postUrl; if (!url && topicId) url = `https://4pda.to/forum/index.php?showtopic=${topicId}`; if (!url) url = f.url; Apps.openUrl({ url }).catch(() => {}); };
  const sigOfFile = (f) => {
    const m2 = meta[f.url];
    const ag2 = agInfo[String(f.aid)] || agInfo["n:" + safeDec(f.name).toLowerCase()];
    if (mySig && m2 && m2.sig) return m2.sig === mySig ? "match" : "differ";
    const same = !ag2 || !ag2.pkg || ag2.pkg === app.packageName;
    if (same && mySigMd5 && ag2 && ag2.sig) return String(ag2.sig).toUpperCase() === mySigMd5 ? "match" : "differ";
    return "?";
  };
  const sigCache = new Map();
  const sigFast = (f) => { const k = String(f.aid || f.url); if (!sigCache.has(k)) sigCache.set(k, sigOfFile(f)); return sigCache.get(k); };
  const isArch = (f) => /\.(zip|rar|7z|tar|gz|obb|xapk|apks|apkm)(\?|#|$)/i.test(f.name || "");
  list = (list || []).filter((f) => {
    if (fTab === "arch") return isArch(f);
    if (isArch(f)) return false;                                  // архивы — только в своей вкладке
    return fTab === "differ" ? sigFast(f) === "differ" : sigFast(f) !== "differ";
  });
  const listTotal = list.length;
  list = list.slice(0, fShow);
  return (
    <div className="t4-dim" onClick={onClose} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 70, display: "flex", alignItems: "flex-end" }}>
      <div className="t4-sheet" onClick={(e) => e.stopPropagation()} style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", background: C.card, overflow: "hidden" }}>
        <div style={{ flexShrink: 0, paddingTop: "var(--sat)", background: C.card }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 18px 6px" }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 26 }}>←</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ color: C.text, fontSize: 18, fontWeight: 600 }}>{mode === "updates" ? "Обновления" : "Скачать"}</div>
            {(loadingAttach || loadingPosts) && <svg width="15" height="15" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke={C.acc} strokeWidth="3" strokeLinecap="round" strokeDasharray="40 20"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.9s" repeatCount="indefinite" /></circle></svg>}
          </div>
        </div>
        <div style={{ display: "flex", gap: 18, padding: "0 18px 8px" }}>
          {(() => {
            const base = (merged || []);
            const isA = (f) => /\.(zip|rar|7z|tar|gz|obb|xapk|apks|apkm)(\?|#|$)/i.test(f.name || "");
            const cAll = base.filter((f) => !isA(f) && sigFast(f) !== "differ").length;
            const cDif = base.filter((f) => !isA(f) && sigFast(f) === "differ").length;
            const cArc = base.filter(isA).length;
            return [["all", "Все файлы", cAll], ["differ", "Другая подпись", cDif], ["arch", "Архивы", cArc]];
          })().map(([k, t2, cnt]) => (
            <div key={k} onClick={() => switchFTab(k)} style={{ cursor: "pointer", fontSize: 13.5, fontWeight: fTab === k ? 700 : 500, color: fTab === k ? C.active : C.sub, borderBottom: fTab === k ? `2px solid ${C.acc}` : "2px solid transparent", padding: "4px 0" }}>{t2}{cnt ? ` ${cnt}` : ""}</div>
          ))}
        </div>
        </div>
        <div
          onTouchStart={(e) => { const t = e.touches[0]; fSw.current = { x: t.clientX, y: t.clientY, on: true }; }}
          onTouchEnd={(e) => {
            const st2 = fSw.current; if (!st2 || !st2.on) return; fSw.current = { on: false };
            const t = e.changedTouches[0]; const dx = t.clientX - st2.x, dy = t.clientY - st2.y;
            if (Math.abs(dx) > 56 && Math.abs(dx) > Math.abs(dy) * 1.3) {
              const order = ["all", "differ", "arch"];
              const i2 = order.indexOf(fTab);
              const n2 = Math.max(0, Math.min(order.length - 1, i2 + (dx < 0 ? 1 : -1)));
              switchFTab(order[n2]);
            }
          }}
          className={fAnim} onAnimationEnd={() => setFAnim("")}
          style={{ flex: 1, overflowY: "auto", paddingBottom: "calc(var(--sab) + 20px)" }}>
        <div className={fAnim} onAnimationEnd={() => setFAnim("")}>
        {(!list || list.length === 0) ? <div style={{ padding: "8px 18px 20px", color: C.sub, fontSize: 14 }}>{(loadingPosts || loadingAttach) ? "Подгружаю файлы из темы, подожди…" : mode === "updates" ? "Более новых версий не найдено." : "Файлы в теме не найдены."}</div> :
          list.map((f, i) => {
            const isApk = /\.(apk|apks|xapk)(\?|#|$)/i.test(f.name || "");
            const m = meta[f.url];
            const abisArr = (m && m.abis) ? parseAbis(m.abis) : fileAbis(f.name);
            // красным — только когда ABI прочитаны из самого apk. По имени файла это догадка
            // («…-x64.apk» у MiXplorer и т.п.), и она красила рабочие файлы
            const agKeyN = "n:" + safeDec(f.name).toLowerCase();
            const ag = agInfo[String(f.aid)] || agInfo[agKeyN] || null;
            const agAbis = ag ? agAbiList(ag.flags) : [];
            // красным — только когда файл собран ПОД ОДИН чужой процессор. Универсальные сборки
            // (несколько наборов внутри) на устройстве работают, красить их нельзя
            const badArch = (!!(m && m.abis) && abisArr.length === 1 && !devSupportsAbi(abisArr[0]))
                         || (!!ag && ag.flags > 0 && agAbis.length === 1 && !devSupportsAbi(agAbis[0]));
            const samePkg = !ag || !ag.pkg || ag.pkg === app.packageName;   // файл может быть другого пакета (beta/silver) — тогда сравнивать не с чем
            const sigState = (mySig && m && m.sig) ? (m.sig === mySig ? "match" : "differ")
                           : (samePkg && mySigMd5 && ag && ag.sig) ? (String(ag.sig).toUpperCase() === mySigMd5 ? "match" : "differ")
                           : "?";   // подпись с сервера App&Game сравнивается без скачивания файла
            let nameColor = C.ink;
            if (sigState === "differ") nameColor = C.info;
            if (badArch) nameColor = C.red;   // чужой процессор важнее отличающейся подписи      // голубой — подпись отличается (как ag4pda)
            else if (sigState === "match") nameColor = C.sub;  // серый — подпись совпадает
            return <div key={i} style={{ padding: "12px 18px", borderTop: i ? `1px solid ${C.border}` : "none", display: "flex", alignItems: "center", gap: 12 }}>
              <div onClick={() => setPicked(f)} style={{ flex: 1, minWidth: 0, cursor: "pointer" }}>
                <div style={{ color: nameColor, fontSize: 15, wordBreak: "break-word" }}>{sigState === "match" ? "✓ " : ""}{(app.label || app.packageName)}{(apkVer(f.name) || f.ver) ? " " + shortVer(apkVer(f.name) || f.ver) : ""}</div>
                <div style={{ color: badArch ? C.red : C.sub, fontSize: 13, wordBreak: "break-all", marginTop: 1 }}>{f.name}</div>
                <div style={{ marginTop: 2, fontSize: 12.5, color: C.sub, display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <span>{[((ag || {}).dl != null ? "Скачиваний: " + ag.dl : (f.downloads ? "Скачиваний: " + f.downloads : "")), f.added ? "Добавлено: " + f.added : ""].filter(Boolean).join(" · ")}</span>
                  <span>{f.size || (agInfo[String(f.aid)] ? Math.round((agInfo[String(f.aid)].size / 1048576) * 100) / 100 + " МБ" : "")}</span>
                </div>
                {(() => { const line = ag ? agReqLine(ag) : (isApk ? archLine(f.url, f.name) : null);   // сервер важнее; своё — только когда сервер молчит
                  return line ? <div style={{ marginTop: 2, fontSize: 12.5, color: C.sub }}>{line}</div> : null; })()}
              </div>
              {f.postUrl ? iBtn(() => setPostPop({ url: f.postUrl, text: f.name })) : null}
            </div>;
          })}
        {listTotal > list.length && <div onClick={() => setFShow((n) => n + 300)} style={{ padding: "13px 18px", color: C.acc, fontSize: 14, fontWeight: 700, textAlign: "center", cursor: "pointer" }}>Показать ещё ({listTotal - list.length})</div>}
        {list && list.length > 0 && (loadingPosts || loadingAttach) && <div style={{ padding: "10px 18px", color: C.sub, fontSize: 13, textAlign: "center" }}>Подгружаю ещё файлы из темы…</div>}
        <div style={{ height: 8 }} />
        </div>
        </div>
      </div>
      {picked && (
        <div className="t4-dim" onClick={(e) => { e.stopPropagation(); setPicked(null); }} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 80, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 8px" }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "calc(100% - 20px)", maxWidth: "none", background: C.card, borderRadius: 18, padding: "16px 16px 6px", marginBottom: "calc(var(--sab, env(safe-area-inset-bottom, 0px)) + 10px)" }}>
            <div style={{ color: C.text, fontSize: 17, fontWeight: 600, marginBottom: 12 }}>Начать закачку?</div>
            <Row k="Название" v={app.label || app.packageName} />
            <div style={{ fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub }}>Имя файла: </span><span style={{ color: C.text, wordBreak: "break-all" }}>{picked.name}</span></div>
            {(() => { const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]); const code = ag && ag.code ? ag.code : buildCodeFromName(picked.name); const base = ag && ag.ver ? ag.ver : apkVer(picked.name); const v = base ? (base + (code ? ` (${code})` : "")) : (code ? `(${code})` : ""); return v ? <Row k="Версия" v={v} /> : null; })()}
            {(() => { const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]); const sz = picked.size || (ag ? Math.round((ag.size / 1048576) * 100) / 100 + " МБ" : ""); return sz ? <Row k="Размер" v={sz} /> : null; })()}
            {(() => { const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]); const pk = (ag && ag.pkg) || pkgFromName(picked.name); return pk ? <Row k="Имя пакета" v={pk} /> : null; })()}
            {(() => { const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]); return ag && ag.crc ? <Row k="CRC32" v={(+ag.crc).toString(16).toUpperCase()} /> : null; })()}
            
            {(() => { const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]);
              const line = ag ? agReqLine(ag) : archLine(picked.url, picked.name);
              return line ? <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>Требования:</span><span style={{ color: C.text }}>{line}</span></div> : null; })()}
            {(() => { const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]);
              if (!ag) return <div style={{ color: C.sub, fontSize: 13, marginTop: 6 }}>{[picked.downloads ? "Скачиваний: " + picked.downloads : "", picked.added ? "Добавлено: " + picked.added : ""].filter(Boolean).join(" · ") || ""}</div>;
              return ag && ag.pkg && ag.pkg !== app.packageName ? <div style={{ color: C.sub, fontSize: 13, marginTop: 6, lineHeight: 1.4 }}>Это отдельное приложение ({ag.pkg}), у вас оно не установлено — подпись сравнивать не с чем.</div> : null; })()}
            
            {(() => {
              const ag2 = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]);
              const m2 = meta[picked.url];
              const abis2 = (m2 && m2.abis) ? parseAbis(m2.abis) : (ag2 && ag2.flags ? agAbiList(ag2.flags) : []);
              return (abis2.length === 1 && !devSupportsAbi(abis2[0]))
                ? <div style={{ color: C.red, fontSize: 13.5, lineHeight: 1.45, margin: "12px 0 2px" }}>Этот файл предназначен для другого типа процессора, на вашем устройстве он не заработает.</div>
                : null;
            })()}
            {(() => { const m = meta[picked.url]; const ag = (agInfo[String(picked.aid)] || agInfo["n:" + safeDec(picked.name).toLowerCase()]); const samePkg2 = !ag || !ag.pkg || ag.pkg === app.packageName;
              const differs = (mySig && m && m.sig && m.sig !== mySig) || (samePkg2 && mySigMd5 && ag && ag.sig && String(ag.sig).toUpperCase() !== mySigMd5); return differs ? <div style={{ color: "#7fd8cf", fontSize: 13.5, lineHeight: 1.45, margin: "12px 0 2px" }}>Подпись у этого файла не совпадает с подписью установленной у вас версии программы. Перед установкой этого файла нужно будет удалить установленную программу.</div> : null; })()}
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 18, marginTop: 16 }}>
              <div onClick={() => setPicked(null)} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 4px" }}>ОТМЕНА</div>
              <div onClick={() => { const ref = picked.postUrl || (topicIdF ? `https://4pda.to/forum/index.php?showtopic=${topicIdF}` : ""); startDownload({ url: picked.url, name: picked.name, referer: ref, aid: picked.aid || 0 }); setPicked(null); setAskDl(true); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 4px" }}>СКАЧАТЬ</div>
            </div>
          </div>
        </div>
      )}
      {askDl && (
        <div className="t4-dim" onClick={(e) => { e.stopPropagation(); setAskDl(false); onClose(); }} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 86, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 340, background: C.card, borderRadius: 14, padding: 20 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 16 }}>Открыть загрузки?</div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 20 }}>
              <div onClick={() => { setAskDl(false); onClose(); }} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 6px" }}>НЕТ</div>
              <div onClick={() => { setAskDl(false); onClose(); if (onDownloads) onDownloads(); else Apps.openDownloads().catch(() => {}); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 6px" }}>ДА</div>
            </div>
          </div>
        </div>
      )}
      {postPop && <PostPopup url={postPop.url} text={postPop.text} app={app} topicId={topicIdF} onClose={() => setPostPop(null)} onDownloads={onDownloads} />}
    </div>
  );
}
function Row({ k, v }) {
  return <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>{k}:</span><span style={{ color: C.text, wordBreak: "break-all" }}>{v}</span></div>;
}

function PostPopup({ url, text, app, topicId: topicIdProp, onClose, onDownloads }) {
  const topicId = String(topicIdProp || (String(url || "").match(/showtopic=(\d+)/) || [])[1]
    || (app && ((readCache()[app.packageName] || {}).topicId || app.topicId)) || "");
  const [st, setSt] = useState({ phase: "loading" });
  const [pick, setPick] = useState(null); // выбранный в посте apk → диалог загрузки
  useEffect(() => { if (pick && !pList.length && topicId) { let ok = true; setPLoading(true); agFiles(topicId).then((l) => { if (ok && l && l.length) setPList(l); }).catch(() => {}).then(() => { if (ok) setPLoading(false); }); return () => { ok = false; }; } }, [pick]);
  const [pAg, setPAg] = useState(null);   // сведения о файле с сервера App&Game
  const [pList, setPList] = useState([]);
  const [pLoading, setPLoading] = useState(false);  // все файлы темы — для покраски ссылок в посте
  useEffect(() => {
    if (pList.length || !topicId) return;
    const c = FILES_CACHE.get(String(topicId));           // готовое из открытой темы — мгновенно
    if (c && c.ag) { const arr = Object.values(c.ag).filter((x) => x && x.aid); if (arr.length) { setPList(arr); return; } }
    let ok = true;
    setPLoading(true);
    const t = setTimeout(() => { agFiles(topicId).then((l) => { if (ok && l && l.length) setPList(l); }).catch(() => {}).then(() => { if (ok) setPLoading(false); }); }, 0);
    return () => { ok = false; clearTimeout(t); };
  }, [topicId]);
  const [pMySig, setPMySig] = useState("");
  useEffect(() => {                       // подпись установленного и сведения о файлах темы
    let alive = true;
    (async () => {
      try { const r = await Apps.appSignature({ pkg: app && app.packageName }); if (alive && r && r.sigMd5) setPMySig(String(r.sigMd5).toUpperCase()); } catch {}
      try {
        if (!topicId) return;
        const list = await agFiles(topicId);
        if (!alive || !list.length) return;
        const aid = +((String(url).match(/\/dl\/post\/(\d+)\//) || [])[1] || 0);
        const nm = safeDec(apkName).toLowerCase();
        const hit = list.find((x) => (aid && x.aid === aid)) || list.find((x) => safeDec(String(x.url || "").split("/").pop() || "").toLowerCase() === nm);
        if (hit) setPAg(hit);
        setPList(list);
      } catch {}
    })();
    return () => { alive = false; };
  }, []);
  const [askDl, setAskDl] = useState(false); // предложить открыть загрузки после старта
  useEffect(() => { window.__closePop = () => { if (askDl) setAskDl(false); else if (pick) setPick(null); else onClose(); }; return () => { if (window.__closePop) window.__closePop = null; }; }, [askDl, pick]);
  const boxRef = useRef(null);
  useEffect(() => {                       // красим ссылки на файлы прямо в тексте поста
    const paint = () => {
      try {
        const el = boxRef.current; if (!el || !pList.length) return;
        const byName = new Map();
        for (const f of pList) byName.set(safeDec(String(f.url || "").split("/").pop() || "").toLowerCase(), f);
        el.querySelectorAll("a").forEach((a) => {
          const href = String(a.getAttribute("href") || a.dataset.href || "");
          const txt = safeDec(a.textContent || "").trim().toLowerCase();
          if (!/\.(apk|apks|xapk)/i.test(href + " " + txt)) return;
          const aid = +((href.match(/\/dl\/post\/(\d+)\//) || [])[1] || 0);
          const x = (aid && pList.find((f) => f.aid === aid)) || byName.get(txt) || byName.get(safeDec(href.split("/").pop() || "").toLowerCase());
          if (!x) {                                  // сведений нет — судим по имени файла
            const okByName = fileForDevice(txt) && fileForDevice(safeDec(href.split("/").pop() || ""));
            a.style.setProperty("color", okByName ? C.text : C.red, "important");
            return;
          }
          const abis = agAbiList(x.flags || 0);
          const bad = (abis.length === 1 && !devSupportsAbi(abis[0])) || !fileForDevice(txt);
          const same = !x.pkg || !app || x.pkg === app.packageName;
          const differ = same && pMySig && x.sig && String(x.sig).toUpperCase() !== pMySig;
          a.style.setProperty("color", bad ? C.red : differ ? C.info : C.text, "important");
        });
      } catch {}
    };
    paint();
    const t1 = setTimeout(paint, 300); const t2 = setTimeout(paint, 1200);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [pList, pMySig, st]);
  const directApk = /\/dl\/post\/\d+\/[^?#]+\.(?:apk|apks|xapk|zip|obb)/i.test(url);
  const apkName = (() => { const m = url.match(/\/dl\/post\/\d+\/([^?#]+)/i); if (m) { try { return decodeURIComponent(m[1]); } catch { return m[1]; } } const t = (text || "").match(/([^\s]+\.(?:apk|apks|xapk|zip|obb))\b/i); return t ? t[1] : (text || "файл"); })();
  useEffect(() => {
    let alive = true;
    (async () => {
      if (directApk) { setSt({ phase: "apk" }); return; }
      const pid = (url.match(/[?&]p=(\d+)/) || url.match(/pid=(\d+)/) || url.match(/entry(\d+)/) || [])[1];
      try {
        const html = await fetchUrl4pdaUser(url);   // попап поста: аноним, при заглушке — сессия
        if (!alive) return;
        const doc = new DOMParser().parseFromString(html, "text/html");
        let bodyEl = null;
        if (pid) {
          const anchor = doc.querySelector('a[name="entry' + pid + '"]') || doc.querySelector("#entry" + pid) || doc.querySelector('[id="p' + pid + '"]') || doc.querySelector('[data-post="' + pid + '"]') || doc.querySelector('[id*="' + pid + '"]');
          if (anchor) {
            let el = anchor;
            for (let i = 0; i < 10 && el && !bodyEl; i++) { if (el.querySelector) bodyEl = el.querySelector(".post_body, .postcolor"); if (!bodyEl) el = el.parentElement; }
            if (!bodyEl) { let n = anchor.nextElementSibling, g = 0; while (n && g < 12 && !bodyEl) { if (n.querySelector) bodyEl = n.querySelector(".post_body, .postcolor"); if (!bodyEl && n.classList && n.classList.contains("post_body")) bodyEl = n; n = n.nextElementSibling; g++; } }
          }
        }
        // конкретный пост не найден — показываем файл, а не всю шапку темы
        if (!bodyEl) { setSt({ phase: "apk" }); return; }
        let h = bodyEl.innerHTML.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/Сообщение отредактировал[\s\S]*?(?=<div|<br|<span|<p|$)/gi, "");
        h = h.replace(/(?:\s*<br\s*\/?>\s*){2,}/gi, "<br>"); // двойные переносы → один (компактнее)
        h = h.replace(/\(\s*([\d.,]+)\s*(МБ|MB|КБ|KB|ГБ|GB)\s*\)/gi, "<span class=\"sz\">(\u00A0$1\u00A0$2\u00A0)</span>"); // размер одним неразрывным куском — скобка не орфанится
        setSt({ phase: "ok", html: h });
      } catch { setSt({ phase: "apk" }); }
    })();
    return () => { alive = false; };
  }, [url]);
  return (
    <div onClick={(e) => { e.stopPropagation(); onClose(); }} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 84, display: "flex", alignItems: "center", justifyContent: "center", paddingLeft: 10, paddingRight: 10, paddingTop: "calc(var(--sat, env(safe-area-inset-top, 0px)) + 12px)", paddingBottom: "calc(var(--sab, env(safe-area-inset-bottom, 0px)) + 12px)", boxSizing: "border-box" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: "none", maxHeight: "100%", background: C.card, borderRadius: 16, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "11px 14px", borderBottom: `1px solid ${C.border}` }}>
          <div style={{ flex: 1, minWidth: 0, color: C.info, fontSize: 15, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || "Пост 4pda"}</div>
          <div onClick={() => Apps.openUrl({ url: /findpost|pid=\d|showtopic/i.test(url) ? url : (topicId ? `https://4pda.to/forum/index.php?showtopic=${topicId}` : url) }).catch(() => {})} title="Открыть на 4pda" style={{ cursor: "pointer", color: C.text, fontSize: 20, padding: "2px 6px" }}>↗</div>
          <div onClick={onClose} style={{ cursor: "pointer", color: C.sub, fontSize: 20, padding: "2px 6px" }}>✕</div>
        </div>
        <div style={{ overflowY: "auto", padding: "12px 14px" }}>
          {st.phase === "loading" && <div style={{ color: C.sub, fontSize: 14, textAlign: "center", padding: "20px 0" }}>Загрузка…</div>}
          {st.phase === "apk" && <>
            {(() => {
              const abis3 = pAg && pAg.flags ? agAbiList(pAg.flags) : [];
              const bad3 = (abis3.length === 1 && !devSupportsAbi(abis3[0])) || !fileForDevice(apkName);
              const same3 = !pAg || !pAg.pkg || !app || pAg.pkg === app.packageName;
              const differ3 = same3 && pMySig && pAg && pAg.sig && String(pAg.sig).toUpperCase() !== pMySig;
              const col3 = bad3 ? C.red : differ3 ? C.info : C.text;
              return <div style={{ color: col3, fontSize: 15, wordBreak: "break-all", marginBottom: 6 }}>{apkName}</div>;
            })()}
            <div style={{ color: fileForDevice(apkName) ? C.sub : C.red, fontSize: 12.5, marginBottom: 6 }}>{fileForDevice(apkName) ? "" : "не для вашего процессора"}</div>
            {pAg ? <div style={{ fontSize: 12.5, color: C.sub, marginBottom: 14, lineHeight: 1.5 }}>
              {pAg.ver ? <div>Версия: <span style={{ color: C.text }}>{pAg.ver}{pAg.code ? ` (${pAg.code})` : ""}</span></div> : null}
              {pAg.pkg ? <div>Имя пакета: <span style={{ color: C.text }}>{pAg.pkg}</span></div> : null}
              <div>{agReqLine(pAg)}{pAg.dl != null ? ` · Скачиваний: ${pAg.dl}` : ""}</div>
              {(() => {
                if (!pAg.sig) return null;
                if (pAg.pkg && app && pAg.pkg !== app.packageName) return <div style={{ color: C.sub }}>Отдельное приложение — подпись сравнивать не с чем.</div>;
                if (!pMySig) return null;
                return String(pAg.sig).toUpperCase() === pMySig
                  ? <div style={{ color: C.green || C.sub }}>Подпись совпадает с установленной версией.</div>
                  : <div style={{ color: C.info }}>Подпись не совпадает с установленной — перед установкой придётся удалить программу.</div>;
              })()}
            </div> : <div style={{ marginBottom: 8 }} />}
            <div onClick={() => { startDownload({ url, name: apkName, referer: topicId ? "https://4pda.to/forum/index.php?showtopic=" + topicId : "", aid: +((String(url).match(/\/dl\/post\/(\d+)\//) || [])[1] || 0) }); onClose(); }} style={{ display: "inline-block", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 14, padding: "10px 18px", borderRadius: 10, cursor: "pointer" }}>Скачать</div>
          </>}
          {st.phase === "ok" && <><div ref={boxRef}><DescView compact html={st.html} onPostLink={(href, txt) => { if (/\/dl\/post\//i.test(href) || /\.(apk|apks|xapk|zip|obb)(\?|#|$)/i.test(href)) { let nm = txt || "файл"; const mm = href.match(/\/dl\/post\/\d+\/([^?#]+)/i); if (mm) { try { nm = decodeURIComponent(mm[1]); } catch { nm = mm[1]; } } setPick({ url: href, name: nm }); } else Apps.openUrl({ url: href }).catch(() => {}); }} /></div><style>{`.topic-desc a{color:${C.blue};text-decoration:none;word-break:break-word}.topic-desc img{max-width:100%;height:auto;border-radius:6px}.topic-desc .sz{white-space:nowrap;color:${C.sub}}.topic-desc .block-title,.topic-desc .spoiler-title{font-weight:700;color:${C.text};padding:6px 9px;background:${C.card};border:1px solid ${C.border};border-radius:6px;margin:4px 0;cursor:pointer}.topic-desc .block-body,.topic-desc .spoiler-body{padding:4px 8px;border-left:2px solid ${C.border};margin:1px 0 5px}`}</style></>}
        </div>
      </div>
      {pick && (
        <div onClick={() => setPick(null)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 90, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "calc(100% - 20px)", maxWidth: "none", background: C.card, borderRadius: 18, padding: "16px 16px 6px", marginBottom: "calc(var(--sab, env(safe-area-inset-bottom, 0px)) + 10px)" }}>
            <div style={{ color: C.text, fontSize: 17, fontWeight: 600, marginBottom: 12 }}>Начать закачку?</div>
            <Row k="Название" v={(app && (app.label || app.packageName)) || pick.name} />
            <div style={{ fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub }}>Имя файла: </span><span style={{ color: C.text, wordBreak: "break-all" }}>{pick.name}</span></div>
            {(() => {                                     // те же сведения, что и в списке файлов
              const aid = +((String(pick.url).match(/\/dl\/post\/(\d+)\//) || [])[1] || 0);
              let x = pList.find((f) => f.aid === aid);
              const soft = (v) => safeDec(String(v || "")).toLowerCase().replace(/[^a-z0-9.]+/g, "");
              if (!x) { const nm2 = soft(pick.name); x = pList.find((f) => soft(String(f.url || "").split("/").pop()) === nm2); }
              if (!x) { const nm3 = soft(pick.name); x = pList.find((f) => soft(String(f.url || "").split("/").pop()).indexOf(nm3) >= 0 || nm3.indexOf(soft(String(f.url || "").split("/").pop())) >= 0); }
              if (!x && aid) { try { const db = JSON.parse(localStorage.getItem("t4_agdb") || "{}"); for (const k in db) { const hit = (db[k].files || []).find((f) => f.aid === aid); if (hit) { x = hit; break; } } } catch {} }
              if (!x) return <>
                {(() => { const line = archLine(pick.url, pick.name); return line ? <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>Требования:</span><span style={{ color: C.text }}>{line}</span></div> : null; })()}
                <div style={{ color: C.sub, fontSize: 13, marginTop: 2 }}>{pLoading ? "Загружаю сведения…" : "Нет сведений на сервере"}</div>
                {!fileForDevice(pick.name) ? <div style={{ color: C.red, fontSize: 13.5, lineHeight: 1.45, margin: "10px 0 2px" }}>Этот файл предназначен для другого типа процессора, на вашем устройстве он не заработает.</div> : null}
              </>;
              const abis = agAbiList(x.flags || 0);
              const bad = (abis.length === 1 && !devSupportsAbi(abis[0])) || !fileForDevice(pick.name);
              const same = !x.pkg || !app || x.pkg === app.packageName;
              const differ = same && pMySig && x.sig && String(x.sig).toUpperCase() !== pMySig;
              return <>
                {x.ver ? <Row k="Версия" v={x.ver + (x.code ? ` (${x.code})` : "")} /> : null}
                {x.size ? <Row k="Размер" v={Math.round((x.size / 1048576) * 100) / 100 + " МБ"} /> : null}
                {x.pkg ? <Row k="Имя пакета" v={x.pkg} /> : null}
                {x.crc ? <Row k="CRC32" v={(+x.crc).toString(16).toUpperCase()} /> : null}
                {(() => { const line = agReqLine(x); return line ? <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>Требования:</span><span style={{ color: C.text }}>{line}</span></div> : null; })()}
                {x.dl != null ? <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>Скачиваний:</span><span style={{ color: C.text }}>{x.dl}</span></div> : null}
                {bad ? <div style={{ color: C.red, fontSize: 13.5, lineHeight: 1.45, margin: "10px 0 2px" }}>Этот файл предназначен для другого типа процессора, на вашем устройстве он не заработает.</div> : null}
                {!same ? <div style={{ color: C.sub, fontSize: 13, marginTop: 6, lineHeight: 1.4 }}>Это отдельное приложение ({x.pkg}), у вас оно не установлено — подпись сравнивать не с чем.</div>
                  : differ ? <div style={{ color: C.info, fontSize: 13.5, lineHeight: 1.45, margin: "10px 0 2px" }}>Подпись у этого файла не совпадает с подписью установленной у вас версии программы. Перед установкой этого файла нужно будет удалить установленную программу.</div> : null}
              </>;
            })()}
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 14 }}>
              <div onClick={() => setPick(null)} style={{ padding: "8px 14px", color: C.sub, fontSize: 14, cursor: "pointer" }}>Отмена</div>
              <div onClick={() => { startDownload({ url: pick.url, name: pick.name, referer: url, aid: +((String(pick.url).match(/\/dl\/post\/(\d+)\//) || [])[1] || 0) }); setPick(null); setAskDl(true); }} style={{ padding: "8px 16px", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 14, borderRadius: 10, cursor: "pointer" }}>Скачать</div>
            </div>
          </div>
        </div>
      )}
      {askDl && (
        <div onClick={() => { setAskDl(false); onClose(); }} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 92, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 360, background: C.card, borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 15, fontWeight: 600, marginBottom: 6 }}>Загрузка началась</div>
            <div style={{ color: C.sub, fontSize: 13.5, marginBottom: 14 }}>Открыть загрузки?</div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
              <div onClick={() => { setAskDl(false); onClose(); }} style={{ padding: "8px 14px", color: C.sub, fontSize: 14, cursor: "pointer" }}>Позже</div>
              <div onClick={() => { setAskDl(false); onClose(); if (onDownloads) onDownloads(); else Apps.openDownloads().catch(() => {}); }} style={{ padding: "8px 16px", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 14, borderRadius: 10, cursor: "pointer" }}>Да</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DescView({ html, onPostLink, compact }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    el.querySelectorAll(".spoiler, .post-block").forEach((sp) => {
      const title = sp.querySelector(".block-title, .spoiler-title, .title");
      const body = sp.querySelector(".block-body, .spoiler-body, .body");
      if (title && body && !title.dataset.w) {
        title.dataset.w = "1";
        body.style.display = "none";
        const mark = document.createElement("span"); mark.textContent = "► "; title.prepend(mark);
        title.addEventListener("click", () => { const open = body.style.display !== "none"; body.style.display = open ? "none" : "block"; mark.textContent = open ? "► " : "▼ "; });
      }
    });
    el.querySelectorAll("a[href]").forEach((a) => {
      if (a.dataset.w) return; a.dataset.w = "1";
      a.addEventListener("click", (e) => {
        e.preventDefault();
        let href = a.getAttribute("href") || ""; if (!href) return;
        if (href.indexOf("//") === 0) href = "https:" + href;
        if (href.indexOf("http") !== 0) href = "https://4pda.to" + (href[0] === "/" ? "" : "/") + href;
        const text = (a.textContent || "").trim();
        // ссылки на скачивание/пост-анонс — во всплывающий укороченный пост; остальные — во внешний браузер
        const isPostLink = /findpost|[?&]pid=\d|#entry\d|\/dl\/post\/|act=attach|attach_id=/i.test(href) || /\.(apk|apks|xapk|zip|obb)\b/i.test(text);
        if (isPostLink && onPostLink) onPostLink(href, text);
        else Apps.openUrl({ url: href }).catch(() => {});
      });
    });
  }, [html]);
    useEffect(() => {                      // между двумя спойлерами подряд убираем пустые строки
    try {
      const el = ref.current; if (!el) return;
      el.querySelectorAll(".post-block, .block-title, .spoiler-title").forEach((t) => {
        let p2 = t.previousSibling, removed = [];
        while (p2 && (p2.nodeName === "BR" || (p2.nodeType === 3 && !p2.textContent.trim()))) { removed.push(p2); p2 = p2.previousSibling; }
        const prevIsSpoiler = p2 && p2.classList && (p2.classList.contains("post-block") || p2.classList.contains("block-body") || p2.classList.contains("spoiler-body"));
        if (prevIsSpoiler) removed.forEach((n) => n.parentNode && n.parentNode.removeChild(n));
      });
      el.querySelectorAll(".block-body, .spoiler-body").forEach((b) => {
        let n = b.nextSibling;
        while (n && ((n.nodeName === "BR") || (n.nodeType === 3 && !n.textContent.trim()))) {
          const nx = n.nextSibling;
          const after = nx && nx.classList && (nx.classList.contains("block-title") || nx.classList.contains("spoiler-title"));
          if (!after && !(nx && nx.nodeName === "BR")) break;
          n.parentNode.removeChild(n); n = nx;
        }
      });
    } catch {}
  }, [html]);
  return <div ref={ref} className="topic-desc" style={{ color: C.text, fontSize: compact ? 13 : 14, lineHeight: compact ? 1.36 : 1.5 }} dangerouslySetInnerHTML={{ __html: html || "—" }} />;
}

function Detail({ app, onClose, onCache, onFiles, onDownloads, onSimilar }) {
  const [td, setTd] = useState({ phase: "loading" });
  useEffect(() => { const tid = (readCache()[app.packageName] || {}).topicId || app.topicId; if (tid) { try { prefetchFiles(tid); } catch {} } }, []);
  const [menuOpen, setMenuOpen] = useState(false);
  const [postPop, setPostPop] = useState(null);
  const [retKey, setRetKey] = useState(0);
  const [shot, setShot] = useState(-1);

  useEffect(() => {
    let alive = true;
    (async () => {
      setTd({ phase: "loading" });
      try {
        const cache = readCache()[app.packageName] || {};
        let topicId = app.topicId || cache.topicId, matched = cache.matched, html = null;
        if (!topicId) {
          const r = await resolveTopic(app);
          if (!alive) return;
          if (r === "captcha") { setTd({ phase: "captcha" }); return; }
          if (!r) { setTd({ phase: "notfound" }); return; }
          topicId = r.topicId; matched = r.matched; html = r.html;
          onCache(app.packageName, { topicId, matched, notfound: false });
        }
        if (!html) {
          html = await fetchTopicHtml(topicId);
          if (!alive) return;
          if (!html) { setTd({ phase: "captcha" }); return; }
        }
        const p = parseTopic(html);
        onCache(app.packageName, { ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short });
        setTd({ phase: "ok", topicId, descHtml: p.descHtml, descMain: p.descMain, files: p.files, dlPosts: p.dlPosts, ver4pda: p.ver4pda, screenshots: p.screenshots, title4pda: p.title, hatIcon: p.hatIcon, hatDate: p.hatDate || p.forumDate || "", verPlay: cache.verPlay || "" });
        // фоновая предзагрузка файлов из анонсов, чтобы «Файлы»/«Обновления» открывались сразу
        if (topicId) { try { delete attachCache[String(topicId)]; delete postFilesCache[String(topicId)]; } catch {} } // сбрасываем кэш файлов темы — иначе при новой версии в шапке списки остаются старыми
        if (topicId) fetchTopicAttachments(topicId).catch(() => {});
        if (topicId && p.dlPosts && p.dlPosts.length) {
          fetchDlPostFiles(topicId, p.dlPosts, app.versionName, "all", null).catch(() => {}); // единый кэш темы: греет и «Файлы», и «Обновления»
        }
        if (!cache.verPlay) {
          fetchPlayVersion(app.packageName).then((v) => { if (v) { onCache(app.packageName, { verPlay: v.name, verPlayCode: v.code }); if (alive) setTd((t) => (t && t.phase === "ok" ? { ...t, verPlay: v.name } : t)); } }).catch(() => {});
        }
      } catch (e) { if (alive) setTd({ phase: "error", msg: (e && e.message) || "ошибка" }); }
    })();
    return () => { alive = false; };
  }, [retKey]);

  const note = (txt, btn) => <div style={{ textAlign: "center", marginTop: 30, padding: "0 10px" }}><div style={{ color: C.sub, fontSize: 14, marginBottom: 14 }}>{txt}</div>{btn}</div>;
  const btn = (label, fn) => <div onClick={fn} style={{ display: "inline-block", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 14, padding: "10px 16px", borderRadius: 10, cursor: "pointer" }}>{label}</div>;

  return (
    <div className="t4-screen" style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 62 }}>
      <style>{`.topic-desc img{max-width:100%;height:auto;border-radius:6px} .topic-desc a{color:${C.blue}} .topic-desc{word-break:break-word}`}</style>
      {(() => {
        const tid = td.topicId || (readCache()[app.packageName] || {}).topicId || app.topicId;
        const linked = !!tid;
        const openForum = () => Apps.openUrl({ url: tid ? `https://4pda.to/forum/index.php?showtopic=${tid}` : searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {});
        const mItem = (label, fn, danger) => <div onClick={() => { setMenuOpen(false); fn(); }} style={{ padding: "12px 16px", color: danger ? C.red : C.text, fontSize: 14.5, cursor: "pointer", whiteSpace: "nowrap" }}>{label}</div>;
        return (
          <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0, borderBottom: `1px solid ${C.border}` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "0 8px 0 12px", minHeight: 62 }}>
              <div onClick={onClose} style={{ cursor: "pointer", color: C.text, fontSize: 25, width: 26, flexShrink: 0 }}>←</div>
              <div style={{ flexShrink: 0 }}><Icon app={app} size={44} /></div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: C.text, fontSize: 16.5, fontWeight: 600, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.22 }}>{(() => { const t = td.title4pda || (readCache()[app.packageName] || {}).title4pda || app.label || app.packageName; const v = app.versionName; return v && !/\[[^\]]*\d[^\]]*\]\s*$/.test(t) ? `${t} [${v}]` : t; })()}</div>
                {(td.hatDate || (readCache()[app.packageName] || {}).hatDate) && <div style={{ color: C.sub, fontSize: 12.5, marginTop: 3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Обновление: {td.hatDate || (readCache()[app.packageName] || {}).hatDate}</div>}
              </div>
              {td.phase === "loading" && <div style={{ width: 18, height: 18, border: "2px solid #555", borderTopColor: C.acc, borderRadius: "50%", animation: "spin .7s linear infinite", flexShrink: 0 }} />}
              <div onClick={() => onDownloads && onDownloads()} title="Загрузки" style={{ cursor: "pointer", padding: "6px 8px 6px 6px", flexShrink: 0, color: C.nav }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>
            </div>
          </div>
        );
      })()}
      <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 14px 14px" }} onClick={() => menuOpen && setMenuOpen(false)}>
        {td.phase === "ok" && td.screenshots && td.screenshots.length > 0 && <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 6 }}>
            {td.screenshots.map((s, i) => <img key={i} src={s.thumb} alt="" onClick={() => setShot(i)} style={{ height: 200, borderRadius: 8, flexShrink: 0, cursor: "pointer" }} />)}
          </div>
        </div>}

        {td.phase === "loading" && <div style={{ color: C.sub, fontSize: 14 }}>Загрузка темы с 4pda…</div>}
        {td.phase === "captcha" && note("4pda просит проверку. Открой 4pda, войди/реши капчу и вернись.", <span>{btn("Открыть 4pda", () => openTopicApp(app))} <span style={{ display: "inline-block", width: 8 }} />{btn("Повторить", () => setRetKey((k) => k + 1))}</span>)}
        {td.phase === "notfound" && note("Тема не загрузилась (4pda мог не ответить).", <span>{btn("Повторить", () => setRetKey((k) => k + 1))} <span style={{ display: "inline-block", width: 8 }} />{btn("Искать на 4pda", () => Apps.openUrl({ url: searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}))}</span>)}
        {td.phase === "error" && note("Не удалось загрузить: " + td.msg, btn("Повторить", () => setRetKey((k) => k + 1)))}
        {td.phase === "ok" && <>
          <DescView html={td.descHtml} onPostLink={(u, txt) => setPostPop({ url: u, text: txt })} />
          <style>{`
            .topic-desc a{color:${C.blue};text-decoration:none;word-break:break-word}
            .topic-desc img{max-width:100%;height:auto;border-radius:6px}
            .topic-desc b,.topic-desc strong{color:${C.text}}
            .topic-desc .block-title,.topic-desc .spoiler-title{font-weight:700;color:${C.text};padding:9px 12px;background:${C.card};border:1px solid ${C.border};border-radius:8px;margin:7px 0;cursor:pointer}
            .topic-desc .block-body,.topic-desc .spoiler-body{padding:6px 10px;border-left:2px solid ${C.border};margin:2px 0 6px}
            .topic-desc br + br{display:none}                       /* двойные переносы — в один */
            .topic-desc p{margin:4px 0}
            .topic-desc p:empty{display:none}
            .topic-desc > div:last-child{margin-bottom:0}
            .topic-desc .block-title,.topic-desc .spoiler-title{margin:6px 0 0}
            .topic-desc .block-body,.topic-desc .spoiler-body{margin:2px 0 6px}
            /* два спойлера подряд — вплотную, без пустой строки между ними */
            .topic-desc .block-body + .block-title,
            .topic-desc .spoiler-body + .spoiler-title,
            .topic-desc .block-body + .spoiler-title,
            .topic-desc .spoiler-body + .block-title{margin-top:2px}
            .topic-desc .block-body + br,
            .topic-desc .spoiler-body + br,
            .topic-desc br + .block-title,
            .topic-desc br + .spoiler-title,
            .topic-desc .block-body + br + br,
            .topic-desc .spoiler-body + br + br,
            .topic-desc br + br + .block-title,
            .topic-desc br + br + .spoiler-title{display:none}
            .topic-desc .block-body + div.block-title,
            .topic-desc .spoiler-body + div.spoiler-title{margin-top:0}
            /* между двумя спойлерами любые переносы схлопываются */
            .topic-desc .block-body ~ br:not(:has(~ :not(br))),
            .topic-desc .spoiler-body ~ br:not(:has(~ :not(br))){display:none}
            /* между любыми соседними спойлерами — без пустых строк */
            .topic-desc .spoiler-body + br, .topic-desc .block-body + br,
            .topic-desc br + .spoiler-title, .topic-desc br + .block-title { display:none }
            .topic-desc .spoiler-body + .spoiler-title,
            .topic-desc .block-body + .block-title,
            .topic-desc .spoiler-body + .block-title,
            .topic-desc .block-body + .spoiler-title { margin-top:2px }
          `}</style>
        </>}
        <div style={{ height: 6 }} />
      </div>

      <div style={{ paddingBottom: "var(--sab)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", height: 46 }}>
          <div onClick={() => { const tid = td.topicId || (readCache()[app.packageName] || {}).topicId || app.topicId; Apps.openUrl({ url: tid ? `https://4pda.to/forum/index.php?showtopic=${tid}` : searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}); }} title="4pda" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><I4 /></div>
          {(() => { const hasUpd = td.phase === "ok" && ((td.ver4pda && app.versionName && verCmp(td.ver4pda, app.versionName) > 0) || (td.files || []).some((f) => { const v = apkVerName(f.name); return v && app.versionName && verCmp(v, app.versionName) > 0; })); return <div onClick={() => td.phase === "ok" && onFiles({ app, files: td.files, dlPosts: td.dlPosts, mode: "updates", onDownloads })} style={{ flex: 1, textAlign: "center", color: td.phase !== "ok" ? C.sub : hasUpd ? C.red : C.acc, fontSize: 14, fontWeight: 700, cursor: td.phase === "ok" ? "pointer" : "default" }}>ОБНОВЛЕНИЯ</div>; })()}
          <div onClick={() => onFiles({ app, files: td.files || [], dlPosts: td.dlPosts || [], mode: "all", onDownloads })} style={{ flex: 1, textAlign: "center", color: C.acc, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>ФАЙЛЫ</div>
          <div onClick={() => openPlay(app)} title="Google Play" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><IPlayStore /></div>
        </div>
      </div>
      {shot >= 0 && td.screenshots && td.screenshots[shot] && (
        <div onClick={() => setShot(-1)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.94)", zIndex: 90, display: "flex", alignItems: "center", justifyContent: "center" }}
          onTouchStart={(e) => { shot >= 0 && (shot._x = e.touches[0].clientX); }}>
          <img src={td.screenshots[shot].full || td.screenshots[shot].thumb} alt="" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
          <div style={{ position: "absolute", top: "var(--sat)", right: 14, color: "#fff", fontSize: 30, padding: 10, cursor: "pointer" }} onClick={() => setShot(-1)}>✕</div>
          {shot > 0 && <div onClick={(e) => { e.stopPropagation(); setShot(shot - 1); }} style={{ position: "absolute", left: 6, top: "50%", transform: "translateY(-50%)", color: "#fff", fontSize: 40, padding: 12, cursor: "pointer", opacity: 0.7 }}>‹</div>}
          {shot < td.screenshots.length - 1 && <div onClick={(e) => { e.stopPropagation(); setShot(shot + 1); }} style={{ position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)", color: "#fff", fontSize: 40, padding: 12, cursor: "pointer", opacity: 0.7 }}>›</div>}
          <div style={{ position: "absolute", bottom: "calc(var(--sab) + 14px)", left: 0, right: 0, textAlign: "center", color: "#bbb", fontSize: 13 }}>{shot + 1} / {td.screenshots.length}</div>
        </div>
      )}
      {postPop && <PostPopup url={postPop.url} text={postPop.text} app={app} topicId={td.topicId || (readCache()[app.packageName] || {}).topicId || app.topicId} onClose={() => setPostPop(null)} onDownloads={onDownloads} />}
    </div>
  );
}

function SubList({ title, initial, loadSystem, topics, onOpen, onMenu, onClose }) {
  const [sysList, setSysList] = useState(null);
  const [srt, setSrt] = useState(localStorage.getItem("t4_sys_sort") || "date");   // сортировка списка: date | name
  const [srtOpen, setSrtOpen] = useState(false);
  const holdT = useRef(0); const holdF = useRef(false);
  useEffect(() => {
    if (loadSystem) Apps.getInstalledApps({ icons: true, system: true }).then((r) => setSysList((r.apps || []).filter((a) => a.system))).catch(() => setSysList([]));
  }, []);
  let list = loadSystem ? sysList : (initial || []); // не снимок: список пересчитывается снаружи (скрыл приложение — сразу исчезло)
  if (list && list.length) list = srt === "name" ? [...list].sort((a, b) => (a.label || a.packageName || "").localeCompare(b.label || b.packageName || "", "ru")) : [...list].sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0));
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 60 }}>
      <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 28 }}>←</div><span onTouchStart={() => { holdF.current = false; clearTimeout(holdT.current); holdT.current = setTimeout(() => { holdF.current = true; setSrtOpen(true); }, 450); }} onTouchEnd={() => clearTimeout(holdT.current)} onTouchMove={() => clearTimeout(holdT.current)} style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>{title}</span></div></div>
      {srtOpen && (
        <div onClick={() => setSrtOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 66 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", top: "calc(var(--sat, 0px) + 64px)", background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, boxShadow: C.shadow, overflow: "hidden", minWidth: 210 }}>
            <div style={{ padding: "10px 16px 4px", color: C.sub, fontSize: 12 }}>Сортировка списка</div>
            {[["date", "По дате обновления"], ["name", "По имени"], ["ver", "По версии"], ["size", "По размеру"], ["inst", "По дате установки"], ["upd", "Сначала с обновлениями"]].map(([k, label]) => <div key={k} onClick={() => { setSrt(k); localStorage.setItem("t4_sys_sort", k); setSrtOpen(false); }} style={{ padding: "13px 16px", color: srt === k ? C.acc : C.text, fontSize: 15, fontWeight: srt === k ? 700 : 400, cursor: "pointer" }}>{label}</div>)}
          </div>
        </div>
      )}
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {list === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : list.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Пусто</div> :
          list.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName] || {}} onOpen={onOpen} onMenu={onMenu} />)}
        <div style={{ height: 12 }} />
      </div>
    </div>
  );
}

function parseTopicTitle(html) {
  const m = html.match(/<title>([^<]*)<\/title>/i);
  if (!m) return "";
  return m[1].replace(/\s*[-–|]\s*4PDA.*$/i, "").replace(/&amp;/g, "&").trim();
}

function SearchScreen({ initialQuery, searchType, instIcons, onClose, onOpenResult }) {
  const type = searchType || "apps";
  const allMode = type === "all";
  const [q, setQ] = useState(initialQuery || "");
  const [res, setRes] = useState(undefined);
  const [tabs, setTabs] = useState({ apps: undefined, games: undefined, emu: undefined });
  const [activeTab, setActiveTab] = useState("apps");
  const [sort, setSort] = useState("match");
  const [sortOpen, setSortOpen] = useState(false);
  const [field, setField] = useState("all");               // область поиска: all | name (только название) | desc (только описание)
  const fieldRef = useRef("all");
  const [fieldOpen, setFieldOpen] = useState(false);
  const FIELDS = [["all", "Искать всё"], ["name", "Только по названию"], ["desc", "Только в описании"]];
  const dbg = useRef({ html: "", captcha: false });
  const bgRef = useRef(0);
  const [searching, setSearching] = useState(false);
  // ИКОНКИ ПОДГРУЖАЮТСЯ ПО МЕРЕ ПРОКРУТКИ: видимые + следующая порция вперёд, пачками
  const ICO_KEY = "t4_ico";
  const icoCache = (() => { try { return JSON.parse(localStorage.getItem(ICO_KEY) || "{}"); } catch { return {}; } })();
  const [icons, setIcons] = useState(icoCache);            // topicId → ссылка на иконку (с запоминанием между запусками)
  const [descs, setDescs] = useState({});
  const [dates, setDates] = useState({});   // тема → дата обновления (для сортировки)                  // topicId → краткое описание темы
  const iconWant = useRef(new Set());                      // что уже запрашивали
  const iconBusy = useRef(false);
  const listRef = useRef(null);
  const iconQueue = useRef([]);
  const loadIcons = async (ids) => {
    if (!protoOn()) return;
    for (const id of ids) if (id && !icons[id] && !iconWant.current.has(id)) { iconWant.current.add(id); iconQueue.current.push(String(id)); }
    if (iconBusy.current) return;                                   // уже качаем — новые просто встали в очередь
    iconBusy.current = true;
    while (iconQueue.current.length) {
    const need = iconQueue.current.splice(0, 12);                   // пачка поменьше — ответы приходят быстрее
    try {
      const rr = await Apps.protoTopics({ host: "app.4pda.to", port: 993, topicIds: need, ver: protoVer(), brief: true, waitMs: 15000 });
      const add = {}; const addDesc = {}; const addDate = {};
      for (const it of ((rr && rr.items) || [])) {          // приходит уже разобранным: иконка, описание, раздел
        let ico = it.icon || "";
        if (!ico && it.raw) { const pr = parseProtoTopic(it.raw); ico = pr.icon || ""; if (pr.desc && !it.desc) addDesc[String(it.topicId)] = pr.desc; }
        if (ico) add[String(it.topicId)] = ico;
        if (it.desc) addDesc[String(it.topicId)] = it.desc;
        if (it.raw) { const pr2 = parseProtoTopic(it.raw); if (pr2.du) addDate[String(it.topicId)] = pr2.du; }
      }
      // вложения форума в <img> напрямую не открываются — забираем сами и подставляем готовую картинку
      if (Object.keys(add).length) {
        setIcons((o) => { const n2 = { ...o, ...add }; try { const keys = Object.keys(n2); const cut = keys.length > 800 ? keys.slice(-800) : keys; const trimmed = {}; cut.forEach((k2) => { trimmed[k2] = n2[k2]; }); localStorage.setItem(ICO_KEY, JSON.stringify(trimmed)); } catch {} return n2; });
      }
      if (Object.keys(addDesc).length) setDescs((o) => ({ ...o, ...addDesc }));
      if (Object.keys(addDate).length) setDates((o) => ({ ...o, ...addDate }));
    } catch {}
    }
    iconBusy.current = false;
  }
  useEffect(() => {                                          // первая порция иконок — как только появились результаты
    const list = (typeof sortedRes !== "undefined" && sortedRes) || [];
    if (list.length) loadIcons(list.slice(0, 20).map((x) => String(x.topicId)));
  }, [res, tabs, activeTab]);;
  const bg = (delta) => { bgRef.current = Math.max(0, bgRef.current + delta); setSearching(bgRef.current > 0); };
  // Только по заголовкам (src=top) — лёгкие запросы, чтобы ВСЕ разделы (вкл. Архив 1109) успевали, а не отваливались в timeout.
  const searchGroups = (t) => t === "games" ? [[213], [1149], [523], [519], [524], [526], [528]] : t === "emu" ? [[529], [539], [537], [540]] : [[212], [1198], [550], [284], [1109], [320], [94]];
  const withTimeout = (p, ms) => Promise.race([p, new Promise((res2) => setTimeout(() => res2({ body: "", captcha: false, __timeout: true }), ms))]);
  const searchOne = async (query, t, setter) => {
    window.__searching = true;
    try { clearTimeout(window.__searchGuard); } catch {}
    window.__searchGuard = setTimeout(() => { window.__searching = false; }, 60000);
    const map = new Map();
    const addAll = (arr) => { for (const it of arr) if (it.topicId && !map.has(it.topicId)) map.set(it.topicId, it); };
    const wq = query.trim();
    // СНАЧАЛА — служебный сервер официального приложения: он отдаёт сразу сотни тем
    // с названиями и описаниями, без страниц выдачи, проверок браузера и ограничений
    try {                                                        // СНАЧАЛА сервер App&Game: ответ с датами и иконками
      bg(1);
      let ags = await agSearch(wq, 0);
      for (let pg = 1; pg < 4 && ags.items.length < (ags.total || 0) && ags.items.length < 400; pg++) {
        const more = await agSearch(wq, pg);
        if (!more.items.length) break;
        ags.items = ags.items.concat(more.items);
      }
      if (ags.items.length) {
        const idx = agDateByTopic();
        const dd2 = {};
        for (const it of ags.items) {
          let hd = "";
          if (it.upd && /^\d{8}$/.test(it.upd)) {                 // 20260809 → 09.08.26 для карточки
            idx.set(String(it.topicId), it.upd);
            hd = `${it.upd.slice(6, 8)}.${it.upd.slice(4, 6)}.${it.upd.slice(2, 4)}`;
            dd2[String(it.topicId)] = hd;
          }
          if (!map.has(it.topicId)) map.set(it.topicId, { topicId: it.topicId, title: it.title, short: it.short, icon: it.icon, hatDate: hd });
          else if (hd) { const cur = map.get(it.topicId); if (!cur.hatDate) cur.hatDate = hd; }
        }
        const ic2 = {};
        for (const it of ags.items) if (it.icon) ic2[String(it.topicId)] = it.icon;   // иконка пришла вместе с результатом
        if (Object.keys(ic2).length) {
          setIcons((o) => { const n2 = { ...o, ...ic2 }; try { localStorage.setItem(ICO_KEY, JSON.stringify(n2)); } catch {} return n2; });
          for (const k2 in ic2) iconWant.current.add(k2);                              // такие темы больше не догружаем
        }
        if (Object.keys(dd2).length) setDates((o) => ({ ...o, ...dd2 }));
        setter([...map.values()]);
        dbg.current.report.push(`App&Game: ${ags.items.length} из ${ags.total}`);
      }
      bg(-1);
    } catch { bg(-1); }
    if (protoOn()) {
      try {
        bg(1);
        let pf = await protoFind(wq, 0, 100);
        for (let off = 100; off < Math.min(pf.total || 0, 300) && pf.items.length < 300; off += 100) {
          const more = await protoFind(wq, off, 100);           // берём выдачу страницами, а не первую сотню
          if (!more.items.length) break;
          pf = { total: pf.total || more.total, items: pf.items.concat(more.items) };
        }
        if (pf.items.length) {
          const cb = catById();
          const NOT_ANDROID = /\b(iphone|ipad|ipod|ios|apple\s*watch|watchos|macos|windows\s*phone|symbian|tizen|blackberry)\b/i;
          const fit = pf.items.filter((it) => {
            if (NOT_ANDROID.test(it.title) || NOT_ANDROID.test(it.short || "")) return false;   // чужие платформы в выдаче не нужны
            const e = cb[it.topicId]; const k = kindOf({ f: (e && e.f) || 0 });
            return t === "all" || (e ? (k === t || k === "drop") : false);   // без раздела в разделы не пускаем
          });
          addAll(fit.map((it) => ({ topicId: it.topicId, title: it.title, short: it.short, icon: "" })));
          setter([...map.values()]);
          try {                                                      // свежие темы: разделы отдают список по последнему сообщению
            const FRESH_F = ["212", "213", "285", "315", "316", "317", "318", "319", "320", "321"];
            const ql = wq.toLowerCase();
            const rr = await Apps.protoForum({ host: "app.4pda.to", port: 993, forumIds: FRESH_F, from: 0, count: 30, ver: protoVer(), waitMs: 12000 });
            for (const it4 of ((rr && rr.items) || [])) {
              const re4 = /\[(\d),(\d{3,9}),"((?:[^"\\]|\\.)*)"/g; let m4;
              while ((m4 = re4.exec(it4.raw || ""))) {
                const ttl = protoClean(m4[3]);
                if (!ttl || ttl.toLowerCase().indexOf(ql) < 0) continue;
                if (!map.has(m4[2])) map.set(m4[2], { topicId: m4[2], title: ttl, short: "", icon: "" });
              }
            }
            setter([...map.values()]);
          } catch {}
          try {                                                      // даты для сортировки — одной пачкой, как у App&Game
            const need = [...map.values()].map((x) => String(x.topicId)).filter((t2) => !agDateByTopic().has(t2)).slice(0, 300);
            if (need.length) {
              const rr2 = await Apps.protoTopics({ host: "app.4pda.to", port: 993, topicIds: need, ver: protoVer(), brief: true, waitMs: 12000 });
              const dd = {};
              for (const it3 of ((rr2 && rr2.items) || [])) {
                const pr3 = it3.raw ? parseProtoTopic(it3.raw) : null;
                const du = (pr3 && pr3.du) || "";
                if (du) dd[String(it3.topicId)] = du;
              }
              if (Object.keys(dd).length) setDates((o) => ({ ...o, ...dd }));
            }
          } catch {}
          dbg.current.report.push(`сервер приложения: ${pf.items.length} из ${pf.total}`);
        }
        bg(-1);
      } catch {}
    }
    const ql = query.toLowerCase().trim();
    const qw = ql.split(/\s+/).filter((w) => w.length > 1);
    const grabPage = async (forums, source, st) => {
      const surl = searchUrl4pda(wq, source, forums, forums.length > 0, st);
      const hr = await withTimeout(t4http(surl, false), 15000);
      let body = hr.body || "", via = "http";
      const cf = body && /Just a moment|cf-browser-verification|challenge-platform|Attention Required|Проверка браузера/i.test(body);
      let webLen = -1, webTo = false, webCap = false;
      if (!hr.__timeout && !hr.__rate && (hr.captcha || !body || body.length < 400 || cf)) { const sr = await withTimeout(t4web(surl, false), 20000); body = sr.body || ""; via = "web"; webLen = body.length; webTo = !!sr.__timeout; webCap = !!sr.captcha; if (sr.captcha) dbg.current.captcha = true; }
      if (!dbg.current.__diag) { dbg.current.__diag = true; dbg.current.report.push(`ДИАГ: http[длина=${(hr.body || "").length} cf=${!!cf}] web[длина=${webLen} таймаут=${webTo}]`); const txt = (body || "").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(); const tt = (body.match(/<title>([^<]*)<\/title>/i) || [])[1] || ""; dbg.current.report.push(`СТРАНИЦА: [${tt}] ${txt.slice(0, 220)}`); }
      if (!dbg.current.html && body) dbg.current.html = body;
      return { body, via };
    };
    const grabGroup = async (forums, source, requireAndroid) => {
      const maxSt = forums.length === 0 ? 100 : 75; // глобальный поиск: больше страниц, чтобы достать и не топовые по релевантности темы
      try {
        for (let st = 0; st <= maxSt; st += 25) {
          const { body, via } = await grabPage(forums, source, st);
          let r = parseSearchResults(body);
          { const cb = catById(); r = r.map((x) => { const c = cb[x.topicId]; return c ? { ...x, short: x.short || c.d || "", icon: x.icon || c.ic || "", forumId: x.forumId || String(c.f || "") } : x; }); } // описание/иконку/раздел берём из каталога, если в сниппете пусто
          const raw = r.length;
          if (source === "all") r = r.filter((x) => { const s = ((x.title || "") + " " + (x.short || "")).toLowerCase(); return s.indexOf(ql) >= 0 || qw.some((w) => s.indexOf(w) >= 0); });
          { const cb = catById(); if (Object.keys(cb).length > 3) r = r.filter((x) => !!cb[x.topicId]); } // ЖЁСТКО: только темы из каталога приложений/игр (как ag4pda — только база); вопросы/темы устройств/клиента отпадают. При пустом каталоге фильтр не применяем
          r = r.filter((x) => !DENY_F.has(String(x.forumId)) && kindOf({ f: x.forumId }) === t); // режем только мусорные разделы (не белый список), чтобы валидные приложения из несобранных разделов проходили
          if (requireAndroid) r = r.filter((x) => /android/i.test((x.title || "") + " " + (x.short || "")));
          const before = map.size; addAll(r);
          const cf = /Just a moment|Attention Required|Проверка браузера|challenge-platform|cf-browser/i.test(body || "");
          const noRes = /ничего не найдено|не дал никаких результатов|По вашему запросу ничего/i.test(body || "");
          const needLogin = /Вход на форум|войдите на форум|введите (?:логин|имя пользователя)|form_login/i.test(body || "");
          let status = raw > 0 ? "ок" : !body || body.length < 400 ? "нет ответа (сеть)" : cf ? "капча Cloudflare" : needLogin ? "нужен вход в 4pda" : noRes ? "нет результатов (пусто по запросу)" : "страница есть, но 0 (проверить вёрстку/вход)";
          dbg.current.report.push(`Раздел ${forums.join(",") || "все"}: +${map.size - before} (нашлось ${raw}) — ${status}`);
          if (raw < 20) break;
        }
      } catch (e) { const msg = (e && e.message) || ""; const ru = /timeout/i.test(msg) ? "не ответил (долго ждали)" : /resolve host|No address|Unable to resolve/i.test(msg) ? "сайт 4pda недоступен (сеть/VPN)" : msg; dbg.current.report.push(`Раздел ${forums.join(",") || "все"}: ${ru}`); }
    };
    // проходы по очереди (без наложения сокетов)
    // обогащение (иконки/описания/даты) — фоном
    const enrich = async (list) => {
      const stat = { n: list.length, ok: 0, nofetch: 0, notandroid: 0, filled: 0, nodesc: 0 };
      const one = async (it) => {
        try {
          let tr = await withTimeout(t4http(`https://4pda.to/forum/index.php?showtopic=${it.topicId}`, true), 15000);
          if ((tr.captcha || !tr.body || !realTopic(tr.body)) && !tr.__rate) { await t4webWarm(); tr = await withTimeout(t4http(`https://4pda.to/forum/index.php?showtopic=${it.topicId}`, true), 15000); }   // без сессии — историю не метим
          if (!tr.body || !realTopic(tr.body)) { stat.nofetch++; return; }
          if (!isAndroidTopic(tr.body)) { stat.notandroid++; return; }
          stat.ok++;
          const p = parseTopic(tr.body || "");
          let sh = p.short;
          if (!sh && p.descMain) sh = p.descMain.replace(/\s+/g, " ").trim().slice(0, 160); // нет метки «Краткое описание» — берём начало блока «Описание»
          if (!sh && it.pkg) { try { sh = await fetchPlayDesc(it.pkg); } catch {} }
          if (sh) stat.filled++; else stat.nodesc++;
          const dl = (p.files || []).reduce((s, f) => s + (parseInt((f.downloads || "").replace(/\D/g, ""), 10) || 0), 0);
          const cur = map.get(it.topicId) || {};
          const patch = { short: sh || cur.short || "", icon: p.hatIcon || cur.icon, ver4pda: p.ver4pda || cur.ver4pda, hatDate: p.hatDate || p.forumDate || cur.hatDate || "", dl };
          map.set(it.topicId, { ...cur, ...patch }); // пишем в map, иначе следующий publish() затрёт описание
          setter((prev) => (prev ? prev.map((x) => (x.topicId === it.topicId ? { ...x, ...patch } : x)) : prev));
        } catch (e) { stat.nofetch++; }
      };
      for (let i = 0; i < list.length; i += 4) { await Promise.all(list.slice(i, i + 4).map(one)); }
      dbg.current.report.push(`Догрузка шапок: ${stat.n} → открыто ${stat.ok}, не Android ${stat.notandroid}, не открылось ${stat.nofetch}, описание ${stat.filled}, пусто ${stat.nodesc}`);
    };
    const relevance = (it) => { const f = fieldRef.current; const s = (f === "name" ? appNameFor(it.title) : f === "desc" ? (it.short || "") : appNameFor(it.title) + " " + (it.short || "")).toLowerCase(); return s.indexOf(ql) >= 0 || qw.some((w) => s.indexOf(w) >= 0); };
    const publish = () => { const list = [...map.values()].filter(relevance).slice(0, 500); setter(list); return list; }; // потолок 500 (был 80 — резал выдачу против ag4pda)

    // 1) МГНОВЕННО из локальной базы (как ag4pda)
    const catKind = t === "games" ? "games" : (t === "emu" ? "emu" : "apps");
    { const cm = catalogMatches(catKind, query, fieldRef.current); for (const it of cm) if (!map.has(it.topicId)) map.set(it.topicId, it); }
    let shown = publish();
    dbg.current.report.push(`Из базы 4pda: ${shown.length} приложений (мгновенно, офлайн)`);
    window.__searching = false;

    // 2) обогащение видимых (иконки) — тихо, без крутилки
    { const ni = shown.filter((x) => !x.icon || !x.short).sort((a, b) => (a.short ? 1 : 0) - (b.short ? 1 : 0)).slice(0, 40); if (ni.length) enrich(ni); } // все видимые (не только 16), сначала без описания

    // 3) живой поиск — ОДИН широкий поиск по всему 4pda (как ProPDA), затем отсев по каталогам/вкладке на клиенте.
    (async () => {
      dbg.current.report.push(`Живой поиск на 4pda: запущен…`);
      try {
        const before = map.size;
        await grabGroup([], fieldRef.current === "name" ? "top" : fieldRef.current === "desc" ? "posts" : "all", false); // [] = весь сайт; область — по фильтру поиска
        dbg.current.report.push(`Живой поиск: добавлено свежих ${map.size - before}`);
        if (map.size > before) { const list = publish(); const ni = list.filter((x) => !x.icon || !x.short).sort((a, b) => (a.short ? 1 : 0) - (b.short ? 1 : 0)).slice(0, 40); if (ni.length) enrich(ni); }
      } catch (e) { dbg.current.report.push(`Живой поиск: ошибка`); }
    })();
  };
  const run = async (q0) => {
    const query = (q0 != null ? q0 : q).trim(); if (!query) return;
    dbg.current = { html: "", captcha: false, report: [] };
    if (allMode) {
      setTabs({ apps: null, games: null, emu: null });
      // типы по очереди (приоритет: Программы → Игры → Эмуляторы), чтобы не плодить лишние WebView
      await searchOne(query, "apps", (v) => setTabs((t) => ({ ...t, apps: typeof v === "function" ? v(t.apps) : v })));
      await searchOne(query, "games", (v) => setTabs((t) => ({ ...t, games: typeof v === "function" ? v(t.games) : v })));
      await searchOne(query, "emu", (v) => setTabs((t) => ({ ...t, emu: typeof v === "function" ? v(t.emu) : v })));
    } else {
      setRes(null);
      await searchOne(query, type, setRes);
    }
  };
  const dbgText = () => "=== ОТЧЁТ ПО РАЗДЕЛАМ ===\n" + ((dbg.current.report || []).join("\n") || "нет") + "\n\n=== ОБРАЗЕЦ HTML (первый непустой ответ) ===\n" + (dbg.current.html || "пусто") + "\n";
  const copyDbg = async () => { const t = (dbg.current.captcha ? "CAPTCHA:true\n" : "") + dbgText(); try { window.__t4toast && window.__t4toast("Отладка скопирована"); } catch {} const done = () => notify("Отладка скопирована"); try { await navigator.clipboard.writeText(t); done(); } catch { try { const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); done(); } catch { notify("Не удалось скопировать"); } } };
  const saveDbg = async () => { try { const rep = dbgText(); const r = await Apps.saveText({ name: "4pda_search_debug.txt", text: (dbg.current.captcha ? "CAPTCHA:true\n" : "") + rep }); notify("Сохранено: " + (r && r.path ? r.path : "Downloads/4pda_search_debug.txt")); } catch (e) { notify("Не удалось сохранить"); } };
  useEffect(() => { if (initialQuery) run(initialQuery); }, []);
  useEffect(() => { if (allMode && (tabs[activeTab] || []).length === 0) { const first = ["apps", "games", "emu"].find((k) => (tabs[k] || []).length > 0); if (first) setActiveTab(first); } }, [tabs]);
  const SORTS = [["match", "По совпадению"], ["name", "По имени"], ["date", "По дате обновления"], ["installs", "По установкам"], ["downloads", "По скачиванию"]];
  const dnum = (s) => { const m = (s || "").match(/(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{2,4})/); if (!m) return 0; let y = +m[3]; if (y < 100) y += 2000; return y * 10000 + (+m[2]) * 100 + (+m[1]); };
  const curRes = allMode ? tabs[activeTab] : res;
  const sortedRes = (() => {
    if (!curRes || sort === "match") return curRes;
    const a = [...curRes];
    if (sort === "name") a.sort((x, y) => (x.title || "").localeCompare(y.title || "", "ru"));
    else if (sort === "date") {
      const idx = agDateByTopic();
      const key = (r) => {
        const u = idx.get(String(r.topicId));                    // «20260809» — готовая дата из базы
        if (u && /^\d{8}$/.test(u)) return +u;
        const d = r.hatDate || dates[String(r.topicId)];
        const n = dnum(d);
        return n ? n : 0;
      };
      a.sort((x, y) => key(y) - key(x));
    }
    else if (sort === "downloads" || sort === "installs") a.sort((x, y) => (y.dl || 0) - (x.dl || 0));
    return a;
  })();
  const TABS = [["apps", "Программы"], ["games", "Игры"], ["emu", "Эмуляторы"]].filter(([k]) => { const h = (() => { try { return JSON.parse(localStorage.getItem("t4_sections") || "{}"); } catch { return {}; } })(); return !(k === "emu" && h.emu) && !(k === "games" && h.games); });
  return (
    <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: "var(--t4-kb, 0px)", background: C.bg, display: "flex", flexDirection: "column", zIndex: 57 }}>
      <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 26 }}>←</div>
          <span style={{ color: C.text, fontSize: 19, fontWeight: 600 }}>Поиск на сайте{curRes && curRes.length ? " : " + curRes.length : ""}</span>
          {searching && <svg width="17" height="17" viewBox="0 0 24 24" style={{ marginLeft: 9 }}><circle cx="12" cy="12" r="9" fill="none" stroke={C.acc} strokeWidth="3" strokeLinecap="round" strokeDasharray="40 18"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.75s" repeatCount="indefinite" /></circle></svg>}
          <span style={{ flex: 1 }} />
          <div style={{ position: "relative" }}>
            <div onClick={() => { setFieldOpen((o) => !o); setSortOpen(false); }} title="Область поиска" style={{ cursor: "pointer", padding: "6px 4px", color: field === "all" ? C.nav : C.acc, fontSize: 12.5, fontWeight: 700 }}>{field === "all" ? "ВСЁ" : field === "name" ? "НАЗВ" : "ОПИС"}</div>
            <div onClick={() => { setSortOpen((o) => !o); setFieldOpen(false); }} title="Сортировка" style={{ cursor: "pointer", padding: "6px 4px", color: C.nav }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 5v14M6 5l-3 3M6 5l3 3M18 19V5M18 19l-3-3M18 19l3-3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
            {fieldOpen && (
              <div style={{ position: "absolute", top: "100%", right: 0, marginTop: 4, background: C.menu, borderRadius: 10, boxShadow: C.shadow, overflow: "hidden", zIndex: 5, minWidth: 210 }}>
                {FIELDS.map(([k, label]) => <div key={k} onClick={() => { setField(k); fieldRef.current = k; setFieldOpen(false); if (q && q.trim()) run(q); }} style={{ padding: "12px 16px", color: field === k ? C.acc : C.text, fontSize: 14.5, fontWeight: field === k ? 700 : 400, cursor: "pointer", whiteSpace: "nowrap" }}>{label}</div>)}
              </div>
            )}
            {sortOpen && (
              <div style={{ position: "absolute", top: "100%", right: 0, marginTop: 4, background: C.menu, borderRadius: 10, boxShadow: C.shadow, overflow: "hidden", zIndex: 5, minWidth: 210 }}>
                {SORTS.map(([k, label]) => <div key={k} onClick={() => { setSort(k); setSortOpen(false); }} style={{ padding: "12px 16px", color: sort === k ? C.acc : C.text, fontSize: 14.5, fontWeight: sort === k ? 700 : 400, cursor: "pointer", whiteSpace: "nowrap" }}>{label}</div>)}
              </div>
            )}
          </div>
        </div>
        {allMode && TABS.some(([k]) => (tabs[k] || []).length > 0) && (
          <div style={{ display: "flex", borderTop: `1px solid ${C.border}` }}>
            {TABS.filter(([k]) => (tabs[k] || []).length > 0).map(([k, label]) => { const n = (tabs[k] || []).length; return <div key={k} onClick={() => setActiveTab(k)} style={{ flex: 1, textAlign: "center", padding: "11px 4px", fontSize: 14, fontWeight: activeTab === k ? 700 : 500, color: activeTab === k ? C.acc : C.sub, borderBottom: activeTab === k ? `2px solid ${C.acc}` : "2px solid transparent", cursor: "pointer" }}>{label} {n}</div>; })}
          </div>
        )}
      </div>
      <div key={allMode ? activeTab : "res"} ref={listRef} className={allMode ? "t4-tab" : ""} style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }} onClick={() => sortOpen && setSortOpen(false)}
        onScroll={(e) => {                                    // иконки грузим по мере пролистывания: видимые + запас вперёд
          const el = e.currentTarget; const list = sortedRes || [];
          if (!list.length) return;
          const rowH = 66;                                    // примерная высота строки
          const first = Math.max(0, Math.floor(el.scrollTop / rowH) - 2);
          const visible = Math.ceil(el.clientHeight / rowH);
          loadIcons(list.slice(first, first + visible * 2 + 6).map((x) => String(x.topicId)));
        }}>
        {(() => { const n = catCount(); return n < 100 ? <div style={{ background: C.hintBg, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 11px", marginBottom: 8, color: C.hintTx, fontSize: 12, lineHeight: 1.35 }}>Каталог 4pda для поиска по части названия ещё не загружен с GitHub. Он подкачается сам — подожди немного, перезапусти приложение или нажми «Обновить каталог» в настройках.</div> : null; })()}
        {curRes === undefined ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 14 }}>Введите запрос и нажмите поиск</div> :
          curRes === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ищу, подожди...</div> :
            curRes.length === 0 ? <div style={{ textAlign: "center", marginTop: 40 }}>
              <div style={{ color: C.sub, fontSize: 15 }}>{dbg.current.captcha ? "4pda просит капчу для поиска" : "Ничего не найдено"}</div>
              <div style={{ color: C.sub, fontSize: 13, marginTop: 10, padding: "0 20px", lineHeight: 1.4 }}>{dbg.current.captcha ? "Войдите в 4pda через меню (гамбургер) — тогда поиск не будет требовать капчу." : "Попробуйте другой запрос."}</div>
              
              {localStorage.getItem("t4_dbg") === "1" && <div style={{ display: "flex", gap: 16, marginTop: 12 }}><div onClick={copyDbg} style={{ color: C.info, fontSize: 12.5, cursor: "pointer" }}>Скопировать отладку</div><div onClick={saveDbg} style={{ color: C.info, fontSize: 12.5, cursor: "pointer" }}>Сохранить всё</div></div>}
            </div> :
              sortedRes.map((r) => <div key={r.topicId} className="t4-press" onClick={() => onOpenResult(r)} style={{ display: "flex", gap: 10, alignItems: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7, padding: "9px 10px", cursor: "pointer" }}>
                {(() => { const ic = r.icon || icons[String(r.topicId)] || (r.pkg && instIcons && instIcons[r.pkg]) || ""; return ic ? <img src={ic} alt="" style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, objectFit: "cover" }} /> : <div style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, background: tileColor(r.title || r.topicId), display: "flex", alignItems: "center", justifyContent: "center", color: "#eaeaea", fontWeight: 800, fontSize: 19 }}>{(r.title || "?").trim().charAt(0).toUpperCase()}</div>; })()}
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}><div style={{ color: C.text, fontSize: 15.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", flex: 1 }}>{r.title}</div>{(() => { const okDate = (v) => { const m = (v || "").match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})$/); if (!m) return ""; let y = +m[3]; if (y < 100) y += 2000; return (+m[1] <= 31 && +m[2] <= 12 && y >= 2005 && y <= new Date().getFullYear()) ? (m[1]+"."+m[2]+"."+m[3]) : ""; }; const d = okDate(r.hatDate) || okDate(r.u); return d ? <div style={{ color: C.sub, fontSize: 12, flexShrink: 0 }}>{d}</div> : null; })()}</div>
                  <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{r.short || descs[String(r.topicId)] || ("4pda · тема " + r.topicId)}</div>
                </div>
              </div>)}
        {curRes && localStorage.getItem("t4_dbg") === "1" && <div style={{ marginTop: 14, padding: "10px 12px", background: C.dbgBg, borderRadius: 8, border: `1px solid ${C.border}` }}>
          <div style={{ color: "#8aa", fontSize: 11, fontWeight: 700, marginBottom: 6 }}>ОТЛАДКА ПОИСКА</div>
          {(dbg.current.report || []).map((l, i) => <div key={i} style={{ color: C.sub, fontSize: 11.5, lineHeight: 1.5, wordBreak: "break-word" }}>{l}</div>)}
          <div onClick={saveDbg} style={{ color: C.info, fontSize: 11, marginTop: 6, cursor: "pointer" }}>Сохранить всё</div>
        </div>}
        <div style={{ height: 12 }} />
      </div>
      <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "var(--sab)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "5px 12px", height: 46, boxSizing: "border-box" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} autoFocus placeholder="Поиск на 4pda" style={{ flex: 1, background: C.input, border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
          <div onClick={() => run()} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
        </div>
      </div>
    </div>
  );
}

function LinkScreen({ app, onClose, onLinked }) {
  const [q, setQ] = useState(app.label || app.packageName);
  const [res, setRes] = useState(undefined);
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const [urlOpen, setUrlOpen] = useState(false);           // окно «связать по ссылке» (кнопка URL в шапке)
  const [urlVal, setUrlVal] = useState("");
  const runGen = useRef(0);                               // поколение поиска: новый запрос гасит публикации старого
  const run = async (q0) => {
    const query = (q0 != null ? q0 : q).trim(); if (!query) return;
    const gen = ++runGen.current;
    const live = () => gen === runGen.current;
    { const um = query.match(/showtopic=(\d+)/) || query.match(/lofiversion\/index\.php\?t(\d+)/) || query.match(/^t?(\d{4,9})$/); // ссылка на тему или голый id — привязка напрямую, без поиска
      if (um) { if (live()) { setRes([]); setConfirm({ topicId: String(um[1]), title: "Тема по ссылке" }); } return; } }
    if (!live()) return;
    setRes(null);
    const map = new Map();
    const ql = query.toLowerCase().trim();
    const qw = ql.split(/\s+/).filter((w) => w.length > 1);
    // мгновенно из локальной базы — как «Искать всё» в поиске по лупе: программы, игры и эмуляторы, по названию и описанию
    { for (const k of ["apps", "games", "emu"]) for (const it of catalogMatches(k, query, "all")) if (it.topicId && !map.has(it.topicId)) map.set(it.topicId, it);
      if (map.size && live()) setRes(Array.from(map.values()).slice(0, 60)); }
    const wt = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r({ body: "", captcha: false, __timeout: true }), ms))]);
    // те же группы форумов, что и в поиске по лупе: приложения + игры + эмуляторы
    const groups = [[212], [1198], [550], [284], [1109], [320], [94], [213], [1149], [523], [519], [524], [526], [528], [529], [539], [537], [540]];
    const grab = async (forums, source) => {
      const maxSt = forums.length === 0 ? 75 : 25;
      for (let st = 0; st <= maxSt; st += 25) {
        if (!live()) return;                              // перебит новым запросом — молча выходим
        const surl = searchUrl4pda(query, source, forums, forums.length > 0, st);
        let hr = await wt(t4http(surl, false), 12000);
        let body = hr.body || "";
        if (!hr.__timeout && !hr.__rate && (hr.captcha || !body || body.length < 400)) { const sr = await wt(t4web(surl, false), 18000); body = sr.body || ""; }
        let r = parseSearchResults(body);
        { const cb = catById(); r = r.map((x) => { const c = cb[x.topicId]; return c ? { ...x, short: x.short || c.d || "", icon: x.icon || c.ic || "", forumId: x.forumId || String(c.f || "") } : x; }); }
        const raw = r.length;
        if (source === "all") r = r.filter((x) => { const s = ((x.title || "") + " " + (x.short || "")).toLowerCase(); return s.indexOf(ql) >= 0 || qw.some((w) => s.indexOf(w) >= 0); });
        r = r.filter((x) => !DENY_F.has(String(x.forumId)));
        for (const it of r) if (it.topicId && !map.has(it.topicId)) map.set(it.topicId, it);
        if (!live()) return;
        setRes(Array.from(map.values()).slice(0, 60));
        if (raw < 20) break;
      }
    };
    try {
      for (const g of groups) { if (!live()) return; await grab(g, "top"); }
      if (!live()) return;
      await grab([], "all"); // глобальный проход — темы из несобранных разделов
      if (!live()) return;
      const list = Array.from(map.values()).slice(0, 60);
      setRes(list);
      // догрузка иконок/описаний для верхних результатов
      list.slice(0, 12).forEach(async (it) => {
        try { const tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }); let b = tr.body; if (tr.captcha || !b || b.length < 800) { const w = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }); b = w.body; } if (!b || !live()) return; const p = parseTopic(b); setRes((prev) => (prev ? prev.map((x) => (x.topicId === it.topicId ? { ...x, short: x.short || p.short, icon: x.icon || p.hatIcon } : x)) : prev)); } catch {}
      });
    } catch { if (live()) setRes(Array.from(map.values())); }
  };
  useEffect(() => { run(app.label || app.packageName); }, []);
  // выдача разложена по видам — как поиск с включённым «Искать всё сразу»
  const [lTab, setLTab] = useState("apps");
  const LTABS = [["apps", "Программы"], ["games", "Игры"], ["emu", "Эмуляторы"]];
  const groups = (() => {
    const g = { apps: [], games: [], emu: [] };
    const cb = catById();
    for (const r of (res || [])) {
      const c = cb[r.topicId];
      let k = kindOf({ f: (c && c.f) || r.forumId });
      if (k === "drop") k = "apps";
      (g[k] || g.apps).push(r);
    }
    return g;
  })();
  useEffect(() => { if (!groups[lTab].length) { const f = ["apps", "games", "emu"].find((k) => groups[k].length); if (f) setLTab(f); } }, [res]);
  const pick = async (r) => {
    if (busy) return; setBusy(true);
    // связываем СРАЗУ — ждать загрузку шапки не нужно, иначе «Связывание…» висит бесконечно
    onLinked(app.packageName, { topicId: r.topicId, matched: true, manual: true, notfound: false, ver4pda: "", du: "", title4pda: r.title || "", desc: r.short || "", stale: true });
    notify("Связано: " + (r.title || ("тема " + r.topicId)));
    onClose();
    try {                                                        // подробности подтянем следом, молча
      const html = await raceTO(fetchTopicHtml(r.topicId), 12000);
      const p = parseTopic(html || "");
      if (p && (p.ver4pda || p.title)) onLinked(app.packageName, { topicId: r.topicId, matched: true, manual: true, notfound: false, ver4pda: p.ver4pda, hatDate: p.hatDate, du: normD(p.hatDate) || "", fdate: p.forumDate, title4pda: p.title, desc: p.short, stale: true });
    } catch {}
  };
  return (
    <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: "var(--t4-kb, 0px)", background: C.bg, display: "flex", flexDirection: "column", zIndex: 70 }}>
      <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 26 }}>←</div>
          <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: C.text, fontSize: 17, fontWeight: 600 }}>Связать тему</div><div style={{ color: C.sub, fontSize: 12.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div></div>
          <div onClick={() => { setUrlVal(""); setUrlOpen(true); }} title="Связать по ссылке" style={{ cursor: "pointer", color: C.acc, fontSize: 14.5, fontWeight: 700, letterSpacing: 0.4, padding: "8px 6px 8px 12px", flexShrink: 0 }}>URL</div>
        </div>
        <div style={{ display: "flex", borderTop: `1px solid ${C.border}` }}>
          {LTABS.map(([k, label]) => { const n = groups[k].length; return <div key={k} onClick={() => setLTab(k)} style={{ flex: 1, textAlign: "center", padding: "11px 4px", fontSize: 14, fontWeight: lTab === k ? 700 : 500, color: lTab === k ? C.acc : C.sub, borderBottom: lTab === k ? `2px solid ${C.acc}` : "2px solid transparent", cursor: "pointer" }}>{label}{n ? " " + n : ""}</div>; })}
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {busy && <div style={{ color: C.acc, textAlign: "center", marginTop: 20 }}>Связывание…</div>}
        {res === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ищу, подожди...</div> :
          res && groups[lTab].length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ничего не найдено</div> :
            groups[lTab].map((r) => <div key={r.topicId} onClick={() => setConfirm(r)} style={{ display: "flex", gap: 10, alignItems: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7, padding: "9px 10px", cursor: "pointer" }}>
              {r.icon ? <img src={r.icon} alt="" style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, objectFit: "cover" }} /> : <div style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, background: tileColor(r.title || r.topicId), display: "flex", alignItems: "center", justifyContent: "center", color: "#eaeaea", fontWeight: 800, fontSize: 18 }}>{(r.title || "?").trim().charAt(0).toUpperCase()}</div>}
              <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: C.text, fontSize: 15, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.title}</div><div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{r.short || ("тема " + r.topicId)}</div></div>
            </div>)}
        <div style={{ height: 12 }} />
      </div>
      {urlOpen && (
        <div onClick={() => setUrlOpen(false)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 79, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: C.card, borderRadius: 14, padding: 20 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Связать по ссылке</div>
            <div style={{ color: C.sub, fontSize: 12.5, marginBottom: 12 }}>Ссылка на тему 4pda или её номер</div>
            <input value={urlVal} autoFocus onChange={(e) => setUrlVal(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { const m = urlVal.match(/showtopic=(\d+)/) || urlVal.match(/lofiversion\/index\.php\?t(\d+)/) || urlVal.trim().match(/^t?(\d{4,9})$/); if (m) { setUrlOpen(false); setConfirm({ topicId: String(m[1]), title: "Тема по ссылке" }); } } }} placeholder="https://4pda.to/forum/index.php?showtopic=…" style={{ width: "100%", boxSizing: "border-box", background: C.input, border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "10px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
            <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", alignItems: "center", marginTop: 16 }}>
              <div onClick={() => setUrlOpen(false)} style={{ cursor: "pointer", color: C.sub, fontSize: 22, padding: "4px 8px" }}>✕</div>
              {(() => { const m = urlVal.match(/showtopic=(\d+)/) || urlVal.match(/lofiversion\/index\.php\?t(\d+)/) || urlVal.trim().match(/^t?(\d{4,9})$/); const ok = !!m;
                return <div onClick={() => { if (!ok) return; setUrlOpen(false); setConfirm({ topicId: String(m[1]), title: "Тема по ссылке" }); }} style={{ cursor: ok ? "pointer" : "default", background: ok ? C.acc : C.off, color: ok ? C.onAcc : C.sub, fontWeight: 700, fontSize: 15, padding: "10px 18px", borderRadius: 10 }}>Связать</div>; })()}
            </div>
          </div>
        </div>
      )}
      {confirm && (
        <div onClick={() => setConfirm(null)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 78, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: "#2a2a2a", borderRadius: 14, padding: 20 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Связать тему?</div>
            <div style={{ color: C.sub, fontSize: 14, marginBottom: 18, wordBreak: "break-word" }}>{confirm.title} · тема {confirm.topicId}</div>
            <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", alignItems: "center" }}>
              <div onClick={() => setConfirm(null)} style={{ cursor: "pointer", color: C.sub, fontSize: 22, padding: "4px 8px" }}>✕</div>
              <div onClick={() => { const r = confirm; setConfirm(null); pick(r); }} style={{ cursor: "pointer", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 15, padding: "10px 18px", borderRadius: 10 }}>Связать</div>
            </div>
          </div>
        </div>
      )}
      <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "var(--sab)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "5px 12px", height: 46, boxSizing: "border-box" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} placeholder="Поиск темы на 4pda" style={{ flex: 1, background: C.input, border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
          <div onClick={() => run()} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState(1);
  const [tabSort, setTabSort] = useState(localStorage.getItem("t4_tab_sort") || "date"); // сортировка списков вкладок: date | name
  const [tabSortOpen, setTabSortOpen] = useState(false);
  const tabHoldT = useRef(0); const tabHoldRef = useRef(false);   // лонг-тап по заголовку вкладки = меню сортировки
  const [secHid, setSecHid] = useState(() => { try { return JSON.parse(localStorage.getItem("t4_sections") || "{}"); } catch { return {}; } }); // скрытые разделы: {games,emu,unlinked}
  const [impOpen, setImpOpen] = useState(false); const [impVal, setImpVal] = useState(""); // импорт связей вставкой
  const VIS = [0, 1, ...(secHid.games ? [] : [2]), ...(secHid.emu ? [] : [3]), ...(secHid.unlinked ? [] : [4])];   // видимые вкладки: позиция ленты p ↔ реальная вкладка VIS[p]
  const visRef = useRef(VIS); visRef.current = VIS;
  const activeRef = useRef(1);                             // актуальная вкладка для слушателей/сторожа
  const pagerFrac = useRef(1);                             // позиция ленты в ДОЛЯХ вкладки (1.0 = вкладка 1)
  const pagerIdx = useRef(1);                              // логическая вкладка ленты (setActive — после доводки)
  const pagerBusy = useRef(false);                         // палец на ленте или идёт доводка
  const pagerGen = useRef(0);                              // поколение анимации: новый жест/доводка перебивает старую
  const pagerFixN = useRef(0);                             // счётчик починок сторожа (диагностика)
  const pendAct = useRef(0);                               // отложенный setActive: рендер не бьёт по летящей анимации
  const stripRef = useRef(null);                           // лента панелей
  const tabTxtRefs = useRef([]); const tabUndRefs = useRef([]); // мгновенная подсветка вкладок прямым DOM
  const tabBarRef = useRef(null);   // сама полоса вкладок — её прокручиваем, чтобы активная была по центру
  const [apps, setApps] = useState(null);
  const [sysScreen, setSysScreen] = useState(false);
  const [hidScreen, setHidScreen] = useState(false);
  const [searchScreen, setSearchScreen] = useState(null); // строка-запрос => экран 4pda-поиска
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTypeMenu, setSearchTypeMenu] = useState(false);
  const [searchType, setSearchType] = useState("apps");
  const [searchQuery, setSearchQuery] = useState("");
  useEffect(() => { if (searchScreen == null) { setSearchOpen(false); setSearchQuery(""); } }, [searchScreen]);
  const [sel, setSel] = useState(null);
  const [menu, setMenu] = useState(null);   // {app, x, y}
  const [infoApp, setInfoApp] = useState(null);
  const [dlScreen, setDlScreen] = useState(false);
  const [filesData, setFilesData] = useState(null);
  const [topics, setTopics] = useState(() => readCache());
  const [selMode, setSelMode] = useState(false);
  const [selected, setSelected] = useState({});
  const [refreshTick, setRefreshTick] = useState(0);
  const [updScreen, setUpdScreen] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [settingsScreen, setSettingsScreen] = useState(false);
  const [idxBusy, setIdxBusy] = useState(false);
  const [idxMsg, setIdxMsg] = useState("");
  const [themeScreen, setThemeScreen] = useState(false);
  const [debugScreen, setDebugScreen] = useState(false);
  const [saveScreen, setSaveScreen] = useState(false);   // экран «Сохранение настроек»
  const [saveSel, setSaveSel] = useState({ fav: true, hupd: true, hidden: true, prefs: true });
  const [expOpen, setExpOpen] = useState(false);          // выбор, что выгружать
  const [impPick, setImpPick] = useState(false);          // выбор, что забирать из файла
  const [impSetOpen, setImpSetOpen] = useState(false);
  const [impSetVal, setImpSetVal] = useState("");
  // сохранение выбранного одним файлом: пометки приложений и настройки
  const exportSettings = async () => {
    try {
      const c = readCache(); const out = { v: 1 };
      if (saveSel.fav) { out.fav = Object.keys(c).filter((p2) => c[p2] && c[p2].flags && c[p2].flags.fav); }
      if (saveSel.hidden) { out.hidden = Object.keys(c).filter((p2) => c[p2] && c[p2].flags && c[p2].flags.hidden); }
      if (saveSel.hupd) { out.hupd = {}; for (const p2 in c) { const f = (c[p2] || {}).flags || {}; if (f.hideAll || f.hideForum || f.hidePlay) out.hupd[p2] = { ...(f.hideAll ? { hideAll: 1 } : {}), ...(f.hideForum ? { hideForum: 1 } : {}), ...(f.hidePlay ? { hidePlay: 1 } : {}) }; } }
      if (saveSel.prefs) {
        out.prefs = {};
        for (const k of ["t4_theme", "t4_sections", "t4_dl_ask", "t4_files_myarch", "t4_big_cards", "t4_tab_sort", "t4_sys_sort", "t4_fast_check", "t4_proto", "t4_search_all"]) {
          const v = localStorage.getItem(k); if (v != null) out.prefs[k] = v;
        }
        try { const dd = await Apps.getDownloadFolder(); if (dd && dd.uri) out.saveDir = dd.uri; } catch {}
      }
      const d = new Date(); const nm = `4pdapps-settings-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}.json`;
      const r = await Apps.saveTextFile({ name: nm, text: JSON.stringify(out, null, 2) });
      notify(`Сохранено: ${(r && r.path) || nm}`);
    } catch (e) { notify("Не удалось сохранить"); }
  };
  const importSettings = (txt) => {
    try {
      const o = JSON.parse(txt); const c = readCache(); let n = 0;
      const setFlag = (pkg, key, val) => { c[pkg] = c[pkg] || {}; c[pkg].flags = { ...(c[pkg].flags || {}), [key]: val }; n++; };
      if (saveSel.fav && Array.isArray(o.fav)) o.fav.forEach((p2) => setFlag(p2, "fav", true));
      if (saveSel.hidden && Array.isArray(o.hidden)) o.hidden.forEach((p2) => setFlag(p2, "hidden", true));
      if (saveSel.hupd && o.hupd && typeof o.hupd === "object") for (const p2 in o.hupd) { const f = o.hupd[p2] || {}; for (const k in f) setFlag(p2, k, true); }
      if (saveSel.prefs && o.prefs && typeof o.prefs === "object") for (const k in o.prefs) { try { localStorage.setItem(k, String(o.prefs[k])); } catch {} }
      try { localStorage.setItem(CKEY, JSON.stringify(c)); } catch {}
      try { applyTheme(); } catch {}
      setRefreshTick((t) => t + 1);
      notify(`Восстановлено: ${n} пометок`);
    } catch { notify("Файл не распознан"); }
  };
  // ---- Пробник протокола официального клиента 4pda (экран «Отладка») ----
  const [pHost, setPHost] = useState("");
  const [pPort, setPPort] = useState("");
  const [pTls, setPTls] = useState(() => localStorage.getItem("t4_p_tls") !== "0");
  const [pData, setPData] = useState("");
  const [pLog, setPLog] = useState("");
  const [pType, setPType] = useState(() => localStorage.getItem("t4_p_type") || "1");
  const [pZip, setPZip] = useState(() => localStorage.getItem("t4_p_zip") !== "0");
  const [pBusy, setPBusy] = useState(false);
  const probeSend = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Подключаюсь…");
    try { localStorage.setItem("t4_p_host", pHost); localStorage.setItem("t4_p_port", pPort); localStorage.setItem("t4_p_tls", pTls ? "1" : "0"); localStorage.setItem("t4_p_data", pData); } catch {}
    const isHex = /^[0-9a-fA-F\s]+$/.test(pData.trim()) && pData.replace(/[^0-9a-fA-F]/g, "").length >= 4;
    try {
      const r = await Apps.rawSocket({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, tls: pTls, ...(isHex ? { hex: pData } : { text: pData }), waitMs: 6000, maxRead: 4096 });
      const lines = [
        `сервер: ${pHost}:${pPort}${pTls ? " (защищённое)" : ""}`,
        r.ok ? `соединение: есть, ${r.ms} мс` : `ошибка: ${r.error || "?"} (${r.ms} мс)`,
        `отправлено байт: ${r.sent || 0}${isHex ? " (как шестнадцатеричные)" : " (как текст)"}`,
        `получено байт: ${r.len || 0}`,
        "", "ТЕКСТ ОТВЕТА:", (r.text || "—"), "", "БАЙТЫ ОТВЕТА:", (r.hex || "—"),
      ];
      setPLog(lines.join("\n"));
    } catch (e) { setPLog("Не удалось: " + ((e && (e.message || e.errorMessage)) || "?")); }
    setPBusy(false);
  };
  // Запрос темы через служебный сервер официального клиента (представиться и попросить тему)
  const probeTopic = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Спрашиваю тему у сервера приложения…");
    const tid = (pData.match(/\d{4,9}/) || [])[0] || "1124379";
    try {
      const r = await Apps.protoTopic({ host: (pHost.trim() || "app.4pda.to"), port: (parseInt(pPort, 10) || 993), topicId: tid, ver: protoVer(), waitMs: 9000 });
      const lines = [
        `тема ${tid} у ${pHost}:${pPort} — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`,
        "", "ОТВЕТ НА ПРЕДСТАВЛЕНИЕ:", (r.hello || "—"),
        "", "ОТВЕТ ПРО ТЕМУ:", (r.topic || "—").slice(0, 4000),
      ];
      setPLog(lines.join("\n"));
    } catch (e) { setPLog("Не удалось: " + ((e && (e.message || e.errorMessage)) || "?")); }
    setPBusy(false);
  };
  // Проверка сервера App&Game 4PDA: спрашиваем сведения о теме (номер темы берётся из поля)
  const probeProfile = async () => {              // почему нет аватарки
    if (pBusy) return;
    setPBusy(true); setPLog("Спрашиваю профиль…");
    const out = [];
    try {
      const rp = await Apps.protoProfile({ host: "app.4pda.to", port: 993, ver: protoVer() });
      const raw = String((rp && rp.raw) || "");
      out.push("ответ сервера, длина " + raw.length + (rp && rp.error ? " · ошибка: " + rp.error : ""));
      out.push(raw.slice(0, 600));
      const m = raw.match(/(https:\/\/4pda\.to\/static\/forum\/uploads\/[^"\\]+)/i);
      out.push("ссылка на аватар: " + (m ? m[1] : "не найдена"));
    } catch (e) { out.push("протокол не ответил: " + ((e && e.message) || "?")); }
    try {
      const pr = await check4pdaLogin();
      out.push("вход: " + (pr && pr.loggedIn ? "да" : "нет") + " · имя: " + ((pr && pr.name) || "—") + " · аватар: " + ((pr && pr.avatar) || "пусто"));
    } catch (e) { out.push("профиль сайта не прочитан: " + ((e && e.message) || "?")); }
    setPLog(out.join("\n"));
    setPBusy(false);
  };
  const probeTopicFiles = async () => {          // почему в посте нет сведений о файле
    if (pBusy) return;
    setPBusy(true); setPLog("Спрашиваю файлы темы…");
    const tid = (pData.match(/\d{4,9}/) || [])[0] || "318294";
    const out = ["тема " + tid];
    try {
      const l = await agFiles(tid);
      out.push("файлов получено: " + l.length);
      out.push(l.slice(0, 3).map((x) => `${x.aid} · ${x.ver} · ${x.pkg} · ${x.sig ? "подпись есть" : "без подписи"}`).join("\n"));
      out.push("накопитель: " + Object.keys(JSON.parse(localStorage.getItem("t4_agdb") || "{}")).length + " тем");
    } catch (e) { out.push("ошибка: " + ((e && e.message) || "?")); }
    setPLog(out.join("\n"));
    setPBusy(false);
  };
  const probeHat = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Читаю шапку темы…");
    const tid = (pData.match(/\d{4,9}/) || [])[0] || "318294";
    try {
      const html = await fetchTopicHtml(tid);
      const p2 = parseTopic(html || "");
      const h = String((p2 && p2.descHtml) || "");
      const i2 = Math.max(0, h.search(/Описание/i));
      setPLog(["разметка шапки темы " + tid + ", длина " + h.length, "", h.slice(Math.max(0, i2 - 200), i2 + 1200)].join("\n"));
    } catch (e) { setPLog("Не удалось: " + ((e && e.message) || "?")); }
    setPBusy(false);
  };
  const probeAgSearch = async () => {             // ищем, каким полем App&Game принимает поиск
    if (pBusy) return;
    setPBusy(true); setPLog("Пробую поиск на сервере App&Game…");
    const q = ((pData || "браузер").trim().split(/\s+/)[0]) || "браузер";
    const U = encodeURIComponent(q);
    const variants = [
      ["search_name (их поле)", `search_name=${U}`],
      ["search_name+method", `search_name=${U}&method=getAppInfo`],
      ["search", `search=${U}`],
      ["query", `query=${U}`],
      ["name", `name=${U}`],
      ["title", `title=${U}`],
      ["q", `q=${U}`],
      ["find", `find=${U}`],
      ["search+sort", `search=${U}&sort=date`],
      ["search+order", `search=${U}&order=date_upd`],
      ["search+limit", `search=${U}&limit=50`],
    ];
    const out = [`запрос: ${q}`];
    for (const [lbl, qq] of variants) {
      try {
        const r = await Apps.agRequest({ srv: 1, method: "getAppInfo.php", params: "", q: qq });
        const b = String((r && r.body) || "").replace(/\s+/g, " ");
        const n = (b.match(/"pack_name"/g) || []).length;
        out.push(`${lbl}: записей ${n} · ${b.slice(0, 160)}`);
      } catch { out.push(`${lbl}: ошибка`); }
    }
    setPLog(out.join("\n"));
    setPBusy(false);
  };
  const probeSort = async () => {                 // подбор порядка выдачи: где сверху свежие темы
    if (pBusy) return;
    setPBusy(true); setPLog("Пробую разные режимы поиска…");
    const q = ((pData || "браузер").trim().split(/\s+/)[0]) || "браузер";
    const variants = [
      ["как сейчас", { flags: 196610 }],
      ["+1", { flags: 196611 }],
      ["+2", { flags: 196612 }],
      ["+8", { flags: 196618 }],
      ["0x40000", { flags: 262146 }],
      ["0x20000", { flags: 131074 }],
      ["набор a=[1]", { flags: 196610, a: "[1]" }],
      ["набор c=[1]", { flags: 196610, c: "[1]" }],
    ];
    const out = [`запрос: ${q}`];
    for (const [lbl, ex] of variants) {
      try {
        const r = await Apps.protoSearch({ host: "app.4pda.to", port: 993, query: q, from: 0, count: 5, ver: protoVer(), waitMs: 9000, ...ex });
        const pr = parseProtoSearch((r && r.raw) || "");
        out.push(`${lbl}: всего ${pr.total} · ${pr.items.slice(0, 3).map((x) => x.title).join(" | ") || "—"}`);
      } catch { out.push(`${lbl}: ошибка`); }
    }
    setPLog(out.join("\n"));
    setPBusy(false);
  };
  const probeAg = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Спрашиваю сервер App&Game…");
    const tid = (pData.match(/\d{4,9}/) || [])[0] || "1124379";
    try {
      const url = encodeURIComponent("https://4pda.to/forum/index.php?showtopic=" + tid);
      const plain = "https://4pda.to/forum/index.php?showtopic=" + tid;
      // проверяем догадку: данные сервер отдаёт только «вошедшим» — подставляем номер и имя пользователя 4pda
      const me = (() => { try { return JSON.parse(localStorage.getItem("t4_profile") || "{}"); } catch { return {}; } })();
      const uid = String(me.uid || me.userId || "4602801");
      const uname = String(me.name || me.username || "Leshugan");
      const md5empty = localStorage.getItem("t4_ag_mail_hash") || "d41d8cd98f00b204e9800998ecf8427e";   // отпечаток почты берётся из настроек, в коде его нет
      const gfs = String(Math.floor(Math.random() * 9e15) + 1e15);           // идентификатор сервисов Google — любое число
      const mail = "user" + gfs.slice(0, 6) + "@gmail.com";
      const U = (x) => encodeURIComponent(x);
      const tries = [
        ["связи: packages в адресе", { method: "getAppInfo.php", params: "", q: "packages=com.mixplorer" }],
        ["связи: pack_name в адресе", { method: "getAppInfo.php", params: "", q: "pack_name=com.mixplorer" }],
        ["связи: pack_names в адресе", { method: "getAppInfo.php", params: "", q: "pack_names=com.mixplorer" }],
        ["связи: два пакета через |", { method: "getAppInfo.php", params: "", q: `packages=${encodeURIComponent("com.mixplorer|com.brave.browser")}` }],
        ["связи: app_url в адресе", { method: "getAppInfo.php", params: "", q: `app_url=${U("https://4pda.to/forum/index.php?showtopic=" + tid)}` }],
        ["связи: topic_id в адресе", { method: "getAppInfo.php", params: "", q: `topic_id=${tid}` }],
        ["файлы (рабочий)", { method: "getFileInfo.php", params: "", q: `topic_id=${tid}` }],
      ];
      for (const [lbl, ex] of tries) {
        const { method: m4, params: p4, ...rest } = ex;
        const r4 = await Apps.agRequest({ srv: 1, method: m4 || "getAppInfo.php", params: p4 != null ? p4 : `app_url=${url}`, ...rest });
        window.__agTry = (window.__agTry || []).concat([`${lbl} → ${(r4.body || "").replace(/\s+/g, " ").slice(0, ((r4.body || "").indexOf("\"data\"") > 0 ? 2500 : 200))}`]);
      }
      const variants = [
        ["getAppInfo.php", `app_url=${url}`],                       // адрес закодирован
        ["getAppInfo.php", `app_url=${plain}`],                     // адрес как есть, без кодирования
        ["getAppInfo.php", `app_url=${encodeURIComponent("4pda.to/forum/index.php?showtopic=" + tid)}`],
        ["getAppInfo.php", `app_url=${url}|`],                      // список из одной темы
        ["getAppInfo.php", `app_url=${url}&app_name=${encodeURIComponent("MiXplorer")}`],
        ["getAppInfo.php", `app_url=${url}&pack_name=com.mixplorer`],
        ["getFileInfo.php", `topic_id=${tid}`],
      ];
      const out = [`сервер App&Game (srv1), тема ${tid} — пробую разные варианты запроса`, ""];
      for (const [m2, pr2] of variants) {
        const r2 = await Apps.agRequest({ srv: 1, method: m2, params: pr2 });
        const body = (r2.body || "").replace(/\s+/g, " ").slice(0, 500);
        out.push(`${m2} ← ${pr2 || "(без параметров)"}`);
        out.push(`   ${r2.ok ? "код " + r2.status : "ошибка " + (r2.error || "?")} · ${r2.ms} мс · ${body || "пусто"}`);
      }
      setPLog(out.concat(["", "С ДАННЫМИ ПОЛЬЗОВАТЕЛЯ:"], window.__agTry || []).join("\n"));
      window.__agTry = [];
    } catch (e) { setPLog("Не удалось: " + ((e && (e.message || e.errorMessage)) || "?")); }
    setPBusy(false);
  };
  // Проверка: даёт ли сервер прямую ссылку на вложение без входа (команда fa)
  const probeLink = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Спрашиваю ссылку на файл…");
    const aid = (pData.match(/\d{5,12}/) || [])[0] || "";
    if (!aid) { setPLog("Впиши в поле номер вложения (число)"); setPBusy(false); return; }
    try {
      const r = await Apps.protoAttach({ host: (pHost.trim() || "app.4pda.to"), port: (parseInt(pPort, 10) || 993), attachIds: [aid], ver: protoVer(), waitMs: 9000 });
      const l = (r && r.links) || [];
      setPLog([`вложение ${aid} — ${r.ok ? "ответ получен" : "ошибка: " + (r.error || "?")} за ${r.ms} мс`, "", "ССЫЛКА:", (l[0] || "— сервер не дал ссылку (возможно, нужен вход)")].join("\n"));
    } catch (e) { setPLog("Не удалось: " + ((e && (e.message || e.errorMessage)) || "?")); }
    setPBusy(false);
  };
  // ПОЛНОЕ подключение как у официального приложения: сначала рукопожатие веб-сокета, потом пакет
  const probeWs = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Здороваюсь с сервером…");
    try { localStorage.setItem("t4_p_type", pType); localStorage.setItem("t4_p_zip", pZip ? "1" : "0"); localStorage.setItem("t4_p_data", pData); } catch {}
    try {
      const r = await Apps.wsProbe({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, path: "/ws/", tls: pTls, type: parseInt(pType, 10) || 1, compress: pZip, mask: false, text: pData, waitMs: 7000 });
      const lines = [
        `${pHost}:${pPort}/ws/ — шифрование ${pTls ? "ВКЛ" : "ВЫКЛ"} — ${r.upgraded ? "рукопожатие принято" : "рукопожатие НЕ принято"}${r.ok ? "" : " · ошибка: " + (r.error || "?")}`,
        `ответ сервера на рукопожатие:`, (r.handshake || "—").trim(),
        "", `отправлено байт: ${r.sent || 0} · получено: ${r.len || 0} · ${r.ms} мс`,
        (r.respLen != null ? `пакет ответа: тип ${r.respType}, ${r.respCompressed ? "сжат" : "не сжат"}, длина ${r.respLen}` : ""),
        "", "СОДЕРЖИМОЕ:", (r.body || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].filter((x) => x !== "");
      setPLog(lines.join("\n"));
    } catch (e) { setPLog("Не удалось: " + ((e && (e.message || e.errorMessage)) || "?")); }
    setPBusy(false);
  };
  // отправка пакета ровно в том виде, в каком его шлёт официальное приложение
  const probeFrame = async () => {
    if (pBusy) return;
    setPBusy(true); setPLog("Отправляю пакет…");
    try { localStorage.setItem("t4_p_type", pType); localStorage.setItem("t4_p_zip", pZip ? "1" : "0"); localStorage.setItem("t4_p_data", pData); } catch {}
    try {
      const r = await Apps.sendFrame({ host: pHost.trim(), port: parseInt(pPort, 10) || 443, tls: pTls, type: parseInt(pType, 10) || 0, compress: pZip, flag80: true, text: pData, waitMs: 6000 });
      const lines = [
        `пакет: тип ${pType}${pZip ? ", сжатый" : ""} → ${pHost}:${pPort} — шифрование ${pTls ? "ВКЛ" : "ВЫКЛ"}`,
        `сервер поздоровался первым: ${r.helloLen || 0} байт${r.helloLen ? " · " + (r.helloText || "") + " · " + (r.helloHex || "") : ""}`,
        r.ok ? `отправлено байт: ${r.sent || 0}, ответ за ${r.ms} мс` : `ошибка: ${r.error || "?"} (${r.ms} мс)`,
        `получено байт: ${r.len || 0}`,
        (r.respLen != null ? `ответ: тип ${r.respType}, ${r.respCompressed ? "сжат" : "не сжат"}, длина ${r.respLen}` : ""),
        "", "РАЗОБРАННОЕ СОДЕРЖИМОЕ:", (r.body || "—"),
        "", "ТЕКСТ:", (r.text || "—"), "", "БАЙТЫ:", (r.hex || "—"),
      ].filter((x) => x !== "");
      setPLog(lines.join("\n"));
    } catch (e) { setPLog("Не удалось: " + ((e && (e.message || e.errorMessage)) || "?")); }
    setPBusy(false);
  };
  const [linkApp, setLinkApp] = useState(null);
  const [profile, setProfile] = useState(() => { try { return JSON.parse(localStorage.getItem("t4_profile") || "null"); } catch { return null; } });
  const [logoutBusy, setLogoutBusy] = useState(false);
  const [loginForm, setLoginForm] = useState(false);
  const [lgNick, setLgNick] = useState(""); const [lgPass, setLgPass] = useState(""); const [lgHidden, setLgHidden] = useState(false);
  const [lgBusy, setLgBusy] = useState(false); const [lgErr, setLgErr] = useState("");
  const [lgCap, setLgCap] = useState(null); const [lgCapInput, setLgCapInput] = useState("");
  const doLogin = async () => {
    if (lgBusy || !lgNick || !lgPass) return;
    if (lgCap && !lgCapInput) { setLgErr("Введите капчу с картинки"); return; }
    setLgBusy(true); setLgErr("");
    try {
      const r = await Apps.login4pda({ nick: lgNick, password: lgPass, hidden: lgHidden, captcha: lgCap ? lgCapInput : "", captchaTime: lgCap ? lgCap.time : "", captchaSig: lgCap ? lgCap.sig : "" });
      if (r && r.ok) { setLoginForm(false); setLgPass(""); setLgCap(null); setLgCapInput(""); const p = await check4pdaLogin(); onLogged(p && p.loggedIn ? p : { loggedIn: false }); }
      else if (r && r.cf) { setLgErr("Cloudflare-проверка — открываю вход 4pda"); setTimeout(() => { Apps.openWeb({ url: "https://4pda.to/forum/index.php?act=auth" }).catch(() => {}); setLoginForm(false); }, 900); }
      else if (r && r.captcha) {
        const f = await Apps.authForm4pda();
        if (f && f.captchaImage) { setLgCap({ image: f.captchaImage, time: f.captchaTime || "", sig: f.captchaSig || "" }); setLgCapInput(""); setLgErr(lgCap ? "Неверная капча — введите новую" : "Введите капчу с картинки"); }
        else if (f && f.cf) { setLgErr("Cloudflare — открываю вход 4pda"); setTimeout(() => { Apps.openWeb({ url: "https://4pda.to/forum/index.php?act=auth" }).catch(() => {}); setLoginForm(false); }, 900); }
        else setLgErr("Проверьте логин, пароль и капчу");
      }
      else setLgErr("Неверный логин или пароль");
    } catch { setLgErr("Ошибка входа"); }
    setLgBusy(false);
  };
  const loggedRef = useRef(false);
  const [dlFolder, setDlFolder] = useState("");
  useEffect(() => { let a = true; if (settingsScreen) { try { Apps.getDownloadFolder().then((r) => { if (a && r) setDlFolder(r.name || ""); }).catch(() => {}); } catch {} } return () => { a = false; }; }, [settingsScreen]);
  // debug: экспорт куки 4pda-сессии для секрета CI FPDA_COOKIE
  const exportAuth = async () => {
    try {
      const r = await Apps.exportAuth();
      const raw = (r && r.cookie) || "";
      const ua = (r && r.ua) || "";
      const map = {};
      raw.split(";").forEach((p) => { const i = p.indexOf("="); if (i > 0) { const k = p.slice(0, i).trim(), v = p.slice(i + 1).trim(); if (k) map[k] = v; } });
      if (!map["member_id"] || !map["pass_hash"]) { notify("Куки авторизации не найдены (нужны member_id и pass_hash).\nВойди в 4pda в приложении и попробуй снова."); return; }
      const hasCf = !!map["cf_clearance"];
      const cookieStr = Object.keys(map).map((k) => k + "=" + map[k]).join("; ");
      const str = ua ? (ua + "|||" + cookieStr) : cookieStr;
      try { await Apps.copyText({ text: str }); } catch {}
      let saved = ""; try { const s = await Apps.saveText({ name: "4pda_FPDA_COOKIE.txt", text: str }); saved = (s && s.path) ? s.path : "Downloads/4pda_FPDA_COOKIE.txt"; } catch {}
      notify("Скопировано в буфер" + (saved ? " (и в " + saved + ")" : "") + ".\n\ncf_clearance: " + (hasCf ? "ЕСТЬ ✓ — можно вставлять в секрет" : "НЕТ ✗ — сначала открой любую тему на 4pda в приложении (чтобы прошла проверка Cloudflare), потом жми экспорт снова") + "\n\nВставь строку в секрет GitHub → FPDA_COOKIE.");
    } catch (e) { notify("Не удалось экспортировать авторизацию"); }
  };
  const onLogged = (p) => { setProfile(p); try { if (p && p.loggedIn) localStorage.setItem('t4_profile', JSON.stringify(p)); else localStorage.removeItem('t4_profile'); } catch {} if (p && p.loggedIn && !loggedRef.current) { loggedRef.current = true; try { refresh(); load(); } catch {} } if (p && !p.loggedIn) loggedRef.current = false; };
  useEffect(() => { check4pdaLogin().then(onLogged).catch(() => setProfile({ loggedIn: false })); }, []);
  useEffect(() => { if (drawer) check4pdaLogin().then(onLogged).catch(() => {}); }, [drawer]);
  const updateApps = (apps || []).filter((a) => needsUpdate(a, topics[a.packageName]));
  const updates = updateApps.length;
  // ===== лента v14: позиция в долях, transform в процентах ширины ленты =====
  const applyFrac = (f) => { pagerFrac.current = f; const st = stripRef.current; if (st) st.style.transform = `translate3d(${-(f * (100 / visRef.current.length))}%,0,0)`; };
  const centerTab = (i) => {                                 // активная вкладка всегда по центру полосы (раньше «НЕ СВЯЗАННЫЕ» уезжали за край)
    try {
      const bar = tabBarRef.current; const tx = tabTxtRefs.current[i];
      if (!bar || !tx) return;
      const cell = tx.parentElement || tx;
      const target = cell.offsetLeft + cell.offsetWidth / 2 - bar.clientWidth / 2;
      const max = Math.max(0, bar.scrollWidth - bar.clientWidth);
      const to = Math.max(0, Math.min(max, target));
      if (Math.abs(bar.scrollLeft - to) > 1) { try { bar.scrollTo({ left: to, behavior: "smooth" }); } catch { bar.scrollLeft = to; } }
    } catch {}
  };
  const paintTabs = (i) => { for (let k = 0; k < visRef.current.length; k++) { const tx = tabTxtRefs.current[k]; if (tx) tx.style.color = k === i ? C.active : C.sub; const un = tabUndRefs.current[k]; if (un) un.style.opacity = k === i ? "1" : "0"; } centerTab(i); };
  const pagerSnapTo = (idx, ms) => {                        // единственная доводка (свайп и тап)
    idx = Math.max(0, Math.min(visRef.current.length - 1, idx));
    const gen = ++pagerGen.current; pagerBusy.current = true;
    clearTimeout(pendAct.current);                          // старый отложенный рендер не должен выстрелить посреди новой доводки
    paintTabs(idx);                                         // подсветка сразу в целевую — не мигает по пути
    const from = pagerFrac.current, dist = idx - from, t0 = performance.now(), dur = ms || 160;
    const step = (now) => {
      if (gen !== pagerGen.current) return;                 // перебили новым жестом/доводкой
      const p = Math.min(1, (now - t0) / dur);
      const e = 1 - (1 - p) * (1 - p);                      // quad ease-out
      applyFrac(from + dist * e);
      if (p < 1) requestAnimationFrame(step);
      else {
        applyFrac(idx); pagerIdx.current = idx; pagerBusy.current = false;
        clearTimeout(pendAct.current);
        pendAct.current = setTimeout(() => { if (!pagerBusy.current && pagerIdx.current === idx) setActive(idx); }, 90); // рендер — после затишья серии
      }
    };
    requestAnimationFrame(step);
  };
  useEffect(() => { activeRef.current = active; });
  useEffect(() => {                                        // раздел скрыли — позиция ленты не должна выйти за число видимых панелей
    const n = VIS.length;
    if (pagerIdx.current > n - 1) { pagerIdx.current = n - 1; }
    if (active > n - 1) setActive(n - 1);
    applyFrac(Math.min(pagerFrac.current, n - 1)); paintTabs(pagerIdx.current);
  }, [secHid]);
  const gotoTab = (i) => { if (i !== pagerIdx.current || Math.abs(pagerFrac.current - i) > 0.01) pagerSnapTo(i, 160); };
  const tabList = (tab, limit) => {
    const inf = (a) => topics[a.packageName] || {};
    const linked = (a) => inf(a).topicId;
    const userHidden = (a) => inf(a).flags && inf(a).flags.hidden;
    // РОВНО как в рабочем APK: категория по kindApp (раздел темы 4pda, иначе флаг), фильтр по kindApp===тип && linked
    let list = null;
    if (tab === 0) list = apps ? apps.filter((a) => inf(a).flags && inf(a).flags.fav) : apps;
    else if (tab === 1) list = apps ? apps.filter((a) => kindApp(a) === "apps" && linked(a)) : apps;
    else if (tab === 2) list = apps ? apps.filter((a) => kindApp(a) === "games" && linked(a)) : apps;
    else if (tab === 3) list = apps ? apps.filter((a) => kindApp(a) === "emu" && linked(a)) : apps;
    else if (tab === 4) list = apps ? apps.filter((a) => !linked(a)) : apps;
    if (tab === 1 && list && list.length && !window.__shotDone) {   // слепок первого кадра вкладки «Приложения» — читается в плашке ПОСЛЕ, когда баг уже пойман
      window.__shotDone = true;
      try {
        const top = list.slice(0, 6).map((a) => { const c = readCache()[a.packageName] || {}; const e = c.topicId ? (catById()[String(c.topicId)] || null) : null; return (a.label || "").slice(0, 12) + "|k:" + kindApp(a) + "|t:" + (c.topicId || "—") + "|f:" + (e ? e.f : "—"); });
        localStorage.setItem("t4_shot", "кат:" + (_catCache ? _catCache.length : 0) + " карта:" + Object.keys(VERMAP).length + " прив:" + Object.values(readCache()).filter((x) => x && x.topicId).length + " lr:" + String(linkedReady) + "\n" + top.join("\n"));
      } catch (err) { try { localStorage.setItem("t4_shot", "err:" + String(err && err.message)); } catch {} }
    }
    if (list && tab !== 0) list = list.filter((a) => !userHidden(a));
    if (list && searchOpen && searchQuery.trim()) {
      const qq = searchQuery.trim().toLowerCase();
      list = list.filter((a) => (a.label || "").toLowerCase().includes(qq) || (a.packageName || "").toLowerCase().includes(qq));
    }
    if (list) {
      if (tabSort === "name") list = [...list].sort((a, b) => (a.label || a.packageName || "").localeCompare(b.label || b.packageName || "", "ru"));
      else if (tabSort === "ver") list = [...list].sort((a, b) => verCmp((readCache()[b.packageName] || {}).ver4pda || b.versionName || "", (readCache()[a.packageName] || {}).ver4pda || a.versionName || ""));
      else if (tabSort === "size") list = [...list].sort((a, b) => (b.size || 0) - (a.size || 0));
      else if (tabSort === "inst") list = [...list].sort((a, b) => (b.firstInstall || b.lastUpdate || 0) - (a.firstInstall || a.lastUpdate || 0));
      else if (tabSort === "upd") list = [...list].sort((a, b) => (upd4(b, topics[b.packageName] || {}) ? 1 : 0) - (upd4(a, topics[a.packageName] || {}) ? 1 : 0));
      else { const key = (a) => { const cd = catDateFor(a); const m = cd && cd.match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (m) { let y = +m[3]; if (y < 100) y += 2000; return Date.UTC(y, +m[2] - 1, +m[1]); } return a.lastUpdate || 0; }; list = [...list].sort((a, b) => key(b) - key(a)); } // свежеобновлённые сверху (дата 4pda, иначе дата на устройстве)
    }
    const msg = (t) => <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>{t}</div>;
    if (list === null) return msg("—");
    if (apps === null || !catReady) return msg("Загрузка…");               // даты и порядок — из каталога: не показываем список до его чтения с диска (иначе секунда с датами устройства и перескок)
    if (tab !== 0 && tab !== 4 && !linkedReady) return msg("Загрузка…");   // проги/игры/эму — только после первичной привязки тем (иначе гонка = игры в прогах)
    if (list.length === 0) return msg(tab === 0 ? "В избранном пусто" : tab === 4 ? "Все приложения связаны с 4pda" : tab === 2 ? "Игры не найдены" : tab === 3 ? "Эмуляторы не найдены" : "Приложения не найдены");
    const shown = limit ? list.slice(0, limit) : list;
    return shown.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName]} onOpen={setSel} onMenu={openMenu} onLong={enterSel} selMode={selMode} selected={!!selected[a.packageName]} onToggleSel={toggleSel} />);
  };

  const onFlag = (app, key, val) => onCache(app.packageName, { flags: { ...((readCache()[app.packageName] || {}).flags || {}), [key]: val } });
  const openMenu = (app, e) => { const t = (e && e.touches && e.touches[0]) || e; setMenu({ app, x: t ? t.clientX : null, y: t ? t.clientY : null }); };
  const enterSel = (app) => {
    if (localStorage.getItem("t4_dbg") === "1") {          // диагностика: вся цепочка категории этого приложения
      try {
        const c = readCache()[app.packageName] || {};
        const e = c.topicId ? (catById()[String(c.topicId)] || null) : null;
        const k = e ? kindOf(e) : "(нет темы в каталоге)";
        notify("КАТЕГОРИЯ: " + app.label + "\npkg: " + app.packageName + "\ntopicId: " + (c.topicId || "—") + "\nкаталог f: " + (e ? e.f : "—") + "  r: " + (e && e.r ? e.r : "—") + "\nkindOf: " + JSON.stringify(k) + "\nкэш kind: " + (c.kind || "—") + "\nсистема isGame: " + String(!!app.isGame) + "  isEmu: " + String(isEmu(app)) + "\nитог kindApp: " + kindApp(app));
        return;
      } catch (err) { try { notify("диагностика: " + String((err && err.message) || err)); } catch {} return; }
    }
    setSelMode(true); setSelected({ [app.packageName]: true });
  };
  const toggleSel = (app) => setSelected((s) => { const n = { ...s }; if (n[app.packageName]) delete n[app.packageName]; else n[app.packageName] = true; if (Object.keys(n).length === 0) setSelMode(false); return n; });
  const exitSel = () => { setSelMode(false); setSelected({}); };
  const bulkHide = () => { Object.keys(selected).forEach((pkg) => onCache(pkg, { flags: { ...((readCache()[pkg] || {}).flags || {}), hidden: true } })); exitSel(); };

  // аппаратная «Назад» — закрыть верхний экран/меню, иначе выйти
  useEffect(() => {
    let handle;
    CapApp.addListener("backButton", () => {
      if (window.__closeFiles && window.__closeFiles()) return;   // открыт вопрос о закачке — закрываем только его
      if (window.__closePop) { window.__closePop(); return; } // открыт попап «!» внутри Файлов/Обновлений — закрываем сначала его
      if (themeScreen) setThemeScreen(false);
      else if (settingsScreen) setSettingsScreen(false);
      else if (impSetOpen) setImpSetOpen(false);
      else if (saveScreen) setSaveScreen(false);
      else if (debugScreen) setDebugScreen(false);
      else if (drawer) setDrawer(false);
      else if (linkApp) setLinkApp(null);
      else if (infoApp) setInfoApp(null);
      else if (menu) setMenu(null);
      else if (filesData) setFilesData(null);
      else if (dlScreen) setDlScreen(false);
      else if (sel) setSel(null);
      else if (searchScreen != null) { setSearchScreen(null); setSearchOpen(false); setSearchQuery(""); }
      else if (updScreen) setUpdScreen(false);
      else if (searchOpen) { setSearchOpen(false); setSearchQuery(""); }
      else if (sysScreen) setSysScreen(false);
      else if (hidScreen) setHidScreen(false);
      else if (selMode) exitSel();
      else CapApp.exitApp();
    }).then((h) => { handle = h; });
    return () => { if (handle) handle.remove(); };
  }, [saveScreen, impSetOpen, filesData, menu, infoApp, selMode, dlScreen, sel, searchScreen, searchOpen, updScreen, drawer, linkApp, sysScreen, hidScreen, settingsScreen, debugScreen]);

  const instIcons = React.useMemo(() => { const m = {}; (apps || []).forEach((a) => { if (a.packageName && a.icon) m[a.packageName] = a.icon; }); return m; }, [apps]);
  const onCache = (pkg, patch) => { const cur = readCache(); const next = { ...cur, [pkg]: { ...(cur[pkg] || {}), ...patch } }; try { localStorage.setItem(CKEY, JSON.stringify(next)); } catch {} setTopics(next); };

  const load = async () => {
    try {
      const r = await Apps.getInstalledApps({ icons: true, system: false, hidden: false });
      const list = (r.apps || []).slice().sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0));
      setApps(list);
    } catch { setApps(Capacitor.getPlatform() === "web" ? DEMO : []); }
  };
  useEffect(() => { load(); Apps.requestPerms && Apps.requestPerms().catch(() => {}); try { if (!localStorage.getItem("t4_allfiles_asked")) { localStorage.setItem("t4_allfiles_asked", "1"); setTimeout(() => { Apps.requestAllFiles && Apps.requestAllFiles().catch(() => {}); }, 1200); } } catch {}
    // перечитываем установленные приложения при возврате в приложение — чтобы увидеть только что обновлённую версию (иначе висит «доступно обновление» на уже установленное)
    let resumeH = null;
    const chkDl = () => { try { Apps.consumeOpenDl && Apps.consumeOpenDl().then((r) => { if (r && r.open) setDlScreen(true); }).catch(() => {}); } catch {} try { Apps.dlHeal && Apps.dlHeal().catch(() => {}); } catch {} };   // при возврате в приложение чиним зависшие «качается»/уведомления
    try { applyTheme(); } catch {} // повторно после готовности мост
    try { Apps.monetPalette && Apps.monetPalette().then((p) => { if (p && p.ok) { localStorage.setItem("t4_monet", JSON.stringify(p)); if (buildMonetThemes(p)) applyTheme(); setRefreshTick((t) => t + 1); } if (p && typeof p.night === "boolean") { window.__t4night = p.night; applyTheme(); } }).catch(() => {}); } catch {}   // палитра Monet и флаг ночи системы; натив-бары под сохранённую тему
    // проверка обновлений выполняется ТОЛЬКО при запуске приложения (таймер и проверка на возврате убраны по требованию);
    // недавно проверенные темы пропускаются по интервалу, поэтому запуск не грузит 4pda лишний раз
    try { const last = parseInt(localStorage.getItem("t4_last_check") || "0", 10) || 0; if (Date.now() - last > checkTtlMs()) setTimeout(() => setRefreshTick((t) => t + 1), 900); } catch {}
    try { CapApp.addListener("appStateChange", (st) => { if (st && st.isActive) { load(); setRefreshTick((t) => t + 1); chkDl(); } }).then((h) => { resumeH = h; }); } catch {}
    setTimeout(chkDl, 600); // холодный старт по тапу на уведомление
    // поднимаем базу из файла в память (для мгновенного поиска), затем сверяем версию на GitHub
    loadCatFromFile().then(() => { setCatReady(true); setRefreshTick((t) => t + 1); setTimeout(() => { fetchGhCatalog(false).then((n) => { if (n) { setRefreshTick((t) => t + 1); } }); }, 2500); }).catch(() => setCatReady(true));
    return () => { try { if (resumeH && resumeH.remove) resumeH.remove(); } catch {} };
  }, []);

  // щадящий фоновый автоподбор тем (стоп на капче). refreshTick — перезапуск по кнопке.
  useEffect(() => {
    if (!apps || apps.length === 0) return;
    if (!_catCache || !_catCache.length) return;    // ждём САМ каталог (даты тем), а не VERMAP: карта восстанавливается из localStorage мгновенно и снимала гейт до загрузки дат — список показывался с датами устройства и через секунду пересортировывался
    relinkCollisions(apps);                          // разово: тёзки с кривой темой (сборники) перепривязываются по имени
    // МГНОВЕННО из базы: связь ТОЛЬКО по пакету (не нашли — не ищем, уйдёт в «Не связанные»)
    const cache = readCache();
    let applied = 0;
    for (const a of apps) {
      const c = cache[a.packageName] || {};
      if (c.topicId) continue;
      const vm = a.packageName && pickTopicForApp(a);   // тёзки: тема выбирается по имени приложения, сборники штрафуются
      if (vm) { const tid = Array.isArray(vm) ? vm[0] : vm; const bver = Array.isArray(vm) ? (vm[1] || "") : ""; onCache(a.packageName, { topicId: String(tid), matched: true, ver4pda: bver }); applied++; }
    }
    if (applied) { const c2 = readCache(); setTopics({ ...c2 }); }
    setLinkedReady(true);   // первичная привязка из каталога завершена — вкладки можно показывать
  }, [apps, refreshTick]);

  // ЖИВАЯ проверка версий у связанных тем без версии — самостоятельный цикл, добирает и тех, кто привязался позже
  const verStarted = useRef(0);
  const appsRef = useRef([]);                     // свежий список для фоновых циклов: обновление apps НЕ должно ронять идущий проход
  const [chkBusy, setChkBusy] = useState(false);
  const [catReady, setCatReady] = useState(false);         // локальный каталог прочитан
  const [linkedReady, setLinkedReady] = useState(false);   // первичная привязка тем прошла — до неё именованные вкладки не показываем (иначе часть приложений мелькает по эвристике = игры в прогах на медленном старте)
  const chkProgRef = useRef(null);                         // «12/40» пишем прямо в DOM — прогресс не дёргает рендер всего приложения
  const busyRef = useRef({ cat: false, ver: false, until: 0 });
  const syncBusy = () => {                                 // кнопка крутится, пока есть работа (и минимум 900мс — чтобы тап был заметен)
    const b = busyRef.current;
    const left = b.until - Date.now();
    const on = b.cat || b.ver || left > 0;
    setChkBusy(on);
    if (!b.cat && !b.ver && left > 0) setTimeout(syncBusy, Math.max(60, left));
    if (!on && chkProgRef.current) chkProgRef.current.textContent = "";
  };
  useEffect(() => { const t = setTimeout(() => centerTab(active), 60); return () => clearTimeout(t); }, [active, secHid]);   // центрируем и при старте, и когда меняется набор вкладок
  appsRef.current = apps || [];                   // пишем при каждом рендере — циклы читают только через ref
  useEffect(() => { verStarted.current++; }, [refreshTick]);   // «Обновить»/старт — только БУДИМ цикл, не пересоздаём его
  useEffect(() => {
    let alive = true;
    (async () => {
      let idle = 0;
      let seen = verStarted.current;
      const checked = new Set(); // проверенные в этом заходе — чтобы не долбить одни и те же по кругу
      while (alive) {
        if (seen !== verStarted.current) { seen = verStarted.current; checked.clear(); idle = 0; }   // пришёл новый запрос — проверяем всех заново, проход не обрывается
        const catReady = Object.keys(VERMAP).length > 0; // база подгружена в память
        const known = appsRef.current.filter((a) => { const c = readCache()[a.packageName]; return c && c.topicId && !checked.has(a.packageName) && (c.stale || !checkFresh(c)); }); // как ag4pda: недавно проверенные пропускаем (date_check), stale — форс
        { const cc = readCache(); const vals = Object.values(cc); window.__verDbg = `кэш:${Object.keys(cc).length} topicId:${vals.filter((x) => x && x.topicId).length} ver:${vals.filter((x) => x && x.ver4pda).length} du:${vals.filter((x) => x && x.du).length} known:${known.length} база:${catReady ? "да" : "нет"}`; }
        if (!known.length) { busyRef.current.ver = false; syncBusy(); idle++; await new Promise((r) => setTimeout(r, idle > 20 ? 8000 : 2000)); continue; }   // никогда не выходим — ждём новых задач // база ещё качается или все проверены — ждём/выходим
        idle = 0; busyRef.current.ver = true; syncBusy();
        const st = { n: known.length, done: 0, notid: 0, http: 0, web: 0, fail: 0, got: 0, tHttp: 0, t0: Date.now() };
        const upd = () => { if (chkProgRef.current) chkProgRef.current.textContent = st.done < st.n ? `${st.done}/${st.n}` : ""; window.__verStat = `версии: ${st.done}/${st.n} · http ${st.http} (${st.http ? Math.round(st.tHttp / st.http) : 0}мс) · lofi ${st.lofiOff ? "выкл" : (st.lofi || 0)} · без изм ${st.n304 || 0} · web ${st.web} · fail ${st.fail} · нашлось ${st.got}${st.dq ? ` · даты ${st.dqGot || 0}/${st.dq}` : ""}${st.nl ? ` · связано ${st.nl}` : ""} · ${Math.round((Date.now() - st.t0) / 1000)}с`; };
        const raceTO = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r({ body: "", captcha: false, __timeout: true }), ms))]);
        let lofiMiss = 0;                                                // сколько раз подряд облегчённая страница пришла пустой
        const lofiOff = () => { try { return localStorage.getItem("t4_lofi_off") === new Date().toDateString(); } catch { return false; } };
        const lofiKill = () => { try { localStorage.setItem("t4_lofi_off", new Date().toDateString()); } catch {} };
        // --- СЕРВЕР App&Game: по списку пакетов сразу приходят тема, версия, дата, описание и иконка
        if (known.length) {
          try { await agGithubLoad(); } catch {}
          const gh = agGithub();
          for (const a of known) {                                  // связи из готовой базы робота — мгновенно и без сети
            const g = gh[a.packageName]; if (!g || !g.topicId) continue;
            const c = readCache()[a.packageName] || {};
            if (!c.topicId) onCache(a.packageName, { topicId: String(g.topicId), matched: true, stale: true, ...(g.name && !c.title4pda ? { title4pda: g.name } : {}) });
          }
          const as = { ok: 0, n: 0, t0: Date.now() };
          const pkgs = known.map((a) => a.packageName);
          as.n = pkgs.length;
          for (let i2 = 0; i2 < pkgs.length; i2 += 40) {
            if (!alive) break;
            let got = {};
            try { got = await agApps(pkgs.slice(i2, i2 + 40)); } catch {}
            for (const pkg in got) {
              const g = got[pkg]; if (!g.ver && !g.topicId) continue;
              const c = readCache()[pkg] || {};
              onCache(pkg, {
                ...(g.topicId ? { topicId: g.topicId, matched: true } : {}),
                ...(g.ver ? { ver4pda: g.ver } : {}),
                ...(g.upd && /^\d{8}$/.test(g.upd) ? { du: `${g.upd.slice(6, 8)}.${g.upd.slice(4, 6)}.${g.upd.slice(2, 4)}` } : {}),
                ...(g.title && !c.title4pda ? { title4pda: g.title } : {}),
                ...(g.desc && !c.desc ? { desc: g.desc } : {}),
                ...(g.icon && !c.icon ? { icon: g.icon } : {}),
                stale: false, chk: Date.now(),
                nochg: (g.ver && c.ver4pda && g.ver !== c.ver4pda) ? 0 : ((c.nochg || 0) + 1),
              });
              if (g.ver) { if (!checked.has(pkg)) { st.done++; st.got++; } checked.add(pkg); as.ok++; }
            }
            upd();
          }
          window.__agStat = `App&Game: ${as.ok}/${as.n} · ${Math.round((Date.now() - as.t0) / 100) / 10}с`;
          upd();
        }
        // --- КАНАЛ ОФИЦИАЛЬНОГО ПРИЛОЖЕНИЯ: одним соединением спрашиваем темы у их служебного сервера
        if (protoOn() && known.length) {
          const ps = { ok: 0, n: 0, t0: Date.now() };
          const byTid = new Map(); const cc0 = readCache();
          for (const a of known) { if (checked.has(a.packageName)) continue; const c = cc0[a.packageName] || {}; if (c.topicId) byTid.set(String(c.topicId), a.packageName); }   // кого закрыл App&Game — повторно не спрашиваем
          const ids = [...byTid.keys()].slice(0, 200);   // запросы уходят одной пачкой — ограничение почти не нужно
          ps.n = ids.length;
          if (ids.length) {
            try {
              const askVer = protoVerStale();                              // раз в сутки заодно спрашиваем тему официального клиента
              const r = await Apps.protoTopics({ host: "app.4pda.to", port: 993, topicIds: askVer ? [PROTO_VER_TOPIC, ...ids] : ids, ver: protoVer(), waitMs: 25000 });
              for (const it of ((r && r.items) || [])) {
                const pr = parseProtoTopic(it.raw || "");
                if (String(it.topicId) === PROTO_VER_TOPIC) {              // это тема самого клиента — обновляем номер версии
                  try { if (pr.ver) localStorage.setItem("t4_proto_ver", pr.ver); localStorage.setItem("t4_proto_ver_chk", String(Date.now())); } catch {}
                  continue;
                }
                const pkg = byTid.get(String(it.topicId)); if (!pkg || !pr.ver) continue;
                const c = readCache()[pkg] || {};
                onCache(pkg, { ver4pda: pr.ver, stale: false, chk: Date.now(), nochg: (pr.ver && c.ver4pda && pr.ver !== c.ver4pda) ? 0 : ((c.nochg || 0) + 1), ...(pr.du ? { du: pr.du } : {}), ...(pr.desc && !c.desc ? { desc: pr.desc } : {}), ...(pr.title && !c.title4pda ? { title4pda: pr.title } : {}), ...(pr.icon && !c.icon ? { icon: pr.icon } : {}), ...(pr.forumId ? { kf: pr.forumId } : {}) });
                checked.add(pkg); st.done++; st.got++; ps.ok++;
              }
            } catch {}
          }
          window.__protoStat = `сервер приложения: ${ps.ok}/${ps.n} · версия клиента ${protoVer()} · ${Math.round((Date.now() - ps.t0) / 100) / 10}с`;
          upd();
        }
        const dq = []; const dqSeen = new Set();                          // темы, которым нужна свежая дата — добираются фоном полной страницей
        // --- БЫСТРЫЙ ПРОХОД: версии из списков тем разделов + дайджесты; в темы идём только за остатком
        const restAfterProto = known.filter((a) => !checked.has(a.packageName));   // кого не закрыл сервер приложения
        if (fastOn() && restAfterProto.length) {
          const fs = { sect: 0, fromSect: 0, digest: 0, pages: 0, t0: Date.now() };
          const byPkg = new Map(); const forums = new Map(); const needIds = new Set();
          const cc0 = readCache(); const cb0 = catById();
          for (const a of restAfterProto) {
            const c = cc0[a.packageName] || {}; const tid = String(c.topicId || "");
            if (!tid) continue;
            byPkg.set(tid, a.packageName); needIds.add(tid);
            const e = cb0[tid]; const fid = e && e.f;
            if (!fid) continue;
            if (!forums.has(String(fid))) forums.set(String(fid), new Set());
            forums.get(String(fid)).add(tid);
          }
          const alv = () => alive && !window.__rate;
          let found = new Map();
          try { found = await fastScanForums(forums, fs, alv); } catch {}
          for (const id of found.keys()) needIds.delete(id);
          if (needIds.size) { try { const d = await fastScanDigest(needIds, fs, alv); for (const [k, v] of d) found.set(k, v); } catch {} }
          for (const [tid, v] of found) {
            const pkg = byPkg.get(tid); if (!pkg) continue;
            const c = readCache()[pkg] || {};
            onCache(pkg, { ver4pda: v, stale: false, chk: Date.now() });
            checked.add(pkg); st.done++; st.got++;
            if (!(c.du && dnQ0(c.du) === tdy0()) && !dqSeen.has(pkg)) { dqSeen.add(pkg); const ap = appsRef.current.find((x) => x.packageName === pkg); if (ap) dq.push(ap); }
          }
          fs.rest = restAfterProto.length - found.size;
          window.__fastStat = `быстро: ${found.size}/${restAfterProto.length} · разделов ${fs.sect} · стр ${fs.pages} · дайджест ${fs.digest} · осталось ${fs.rest} · ${Math.round((Date.now() - fs.t0) / 100) / 10}с`;
          upd();
        }
        const worker = async (a, dateRun) => {
          checked.add(a.packageName);
          const c = readCache()[a.packageName]; const tid = c && c.topicId; if (!tid) { st.notid++; st.done++; return; }
          try {
            const t1 = Date.now();
            const dnQ = (v) => { const m = (v || "").match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!m) return 0; let y = +m[3]; if (y < 100) y += 2000; return y * 10000 + (+m[2]) * 100 + (+m[1]); };
            const tdy = (() => { const d = new Date(); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); })();
            if (!dateRun && !lofiOff()) {                                  // основной проход: версия лёгкой lofi — почти вдвое быстрее полной
              // версия всегда в одной строке под заголовком → хватает первых 40КБ; плюс условный запрос:
              // если страница не менялась, сервер отвечает 304 без тела — это почти мгновенно
              const lfUrl = `https://4pda.to/forum/lofiversion/index.php?t${tid}`;
              const cond = {}; if (c.et) cond.ifNoneMatch = c.et; else if (c.lm) cond.ifModifiedSince = c.lm;
              const lf = await raceTO(t4http(lfUrl, true, cond), 12000);   // lofi и так лёгкая — обрезать нечего
              if (lf && (lf.notModified || lf.status === 304)) {           // страница та же — версия точно не менялась
                st.n304 = (st.n304 || 0) + 1; st.http++; st.done++;
                onCache(a.packageName, { chk: Date.now(), stale: false, nochg: (c.nochg || 0) + 1 });
                return;
              }
              if (lf && (lf.etag || lf.lastMod)) onCache(a.packageName, { et: lf.etag || "", lm: lf.lastMod || "" });
              const lfVer = (lf.body && !lf.captcha) ? quickVer(lf.body) : "";
              if (lf.body && !lf.captcha && (lfVer || lf.body.indexOf("Полная версия") >= 0)) {   // признак удачи — найденная версия, а не маркер в конце страницы
                st.lofi = (st.lofi || 0) + 1; st.tHttp += Date.now() - t1; st.http++;
                const v = lfVer; if (v) st.got++;
                onCache(a.packageName, { ver4pda: v || c.ver4pda, stale: false, chk: Date.now(), nochg: (v && c.ver4pda && v !== c.ver4pda) ? 0 : ((c.nochg || 0) + 1) });
                st.done++;
                if (!(c.du && dnQ(c.du) === tdy) && !dqSeen.has(a.packageName)) { dqSeen.add(a.packageName); dq.push(a); } // дата несвежая — добрать фоном
                return;
              }
              if (!lf.body || lf.captcha) { if (++lofiMiss >= 3) { lofiKill(); st.lofiOff = 1; } }   // 4pda не отдаёт lofi — больше не дёргаем
              else lofiMiss = 0;
            }                                                              // lofi не отдал — падаем на полную ниже
            let tr = await raceTO(t4http(`https://4pda.to/forum/index.php?showtopic=${tid}`, true), 15000);   // без сессии, целиком: обрезка давала огрызки
            let fullVer = (tr.body && !tr.captcha) ? quickVer(tr.body) : "";
            const httpOk = tr.body && !tr.captcha && (fullVer || realTopic(tr.body));   // успех = нашли версию (она в шапке) или признак темы
            if (httpOk) { st.http++; st.tHttp += Date.now() - t1; }
            else if (tr.__rate) { st.fail++; }
            else { window.__verErr = "http пусто: len=" + ((tr.body || "").length) + " cap=" + (!!tr.captcha) + " to=" + (!!tr.__timeout) + " | " + ((tr.body || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 160)); try { await t4webWarm(); tr = await raceTO(t4http(`https://4pda.to/forum/index.php?showtopic=${tid}`, true), 15000); fullVer = (tr.body && !tr.captcha) ? quickVer(tr.body) : ""; } catch {} if (tr.body && (fullVer || realTopic(tr.body))) st.web++; else st.fail++; }
            if (tr.body && (fullVer || realTopic(tr.body))) { const v = fullVer || quickVer(tr.body); if (v) st.got++; const hd = quickHatDate(tr.body); onCache(a.packageName, { ver4pda: v || c.ver4pda, stale: false, chk: Date.now(), ...(hd ? { du: hd } : {}) }); }
          } catch (e) { window.__verErr = "httpGet err: " + ((e && e.message) || String(e)); }
          if (!dateRun) st.done++;                                         // добор дат не раздувает счётчик «версии: N/N»
        };
        {                                                                // ПАРАЛЛЕЛЬНО: очередь сама держит темп и откатывается при отказах сайта
          let idx = 0, done = 0;
          const runner = async () => {
            while (alive) {
              const i = idx++; if (i >= known.length) break;
              if (checked.has(known[i].packageName)) continue;
              await worker(known[i], false);
              if (++done % 4 === 0) upd();
            }
          };
          await Promise.all(Array.from({ length: 8 }, runner));
        }
        // версии показаны — СПИННЕР ГАСИМ ЗДЕСЬ. Дальше идёт фоновая доработка (даты, привязка),
        // из-за которой иконка раньше крутилась ещё минуты после того, как список был готов
        busyRef.current.ver = false; syncBusy(); // последовательно: троттлер держит темп, без шквала
        upd();
        if (dq.length > 25) {                                              // добор дат — порциями: сначала темы вовсе без даты, остальное в следующий проход
          const cc2 = readCache();
          dq.sort((a, b) => ((cc2[a.packageName] || {}).du ? 1 : 0) - ((cc2[b.packageName] || {}).du ? 1 : 0));
          dq.length = 25;
        }
        if (dq.length) {                                                   // добор дат фоном: версии уже показаны, полные страницы качаем после
          st.dq = dq.length; st.dqGot = 0;
          { let di = 0;                                                    // добор дат тоже параллельно — очередь держит темп
            const dr = async () => { while (alive) { const i = di++; if (i >= dq.length) break;
              const before = (readCache()[dq[i].packageName] || {}).du; await worker(dq[i], true);
              const after = (readCache()[dq[i].packageName] || {}).du; if (after && after !== before) st.dqGot++;
              if (i % 4 === 3) upd(); } };
            await Promise.all(Array.from({ length: 4 }, dr)); }
          upd();
        }
        try {                                                              // фоновая привязка «Несвязанных»: их пакет темы каталог не знает — ищем тему по имени
          if (alive && !window.__rate) {
            const tried = (() => { try { return JSON.parse(localStorage.getItem("t4_nl_try") || "{}"); } catch { return {}; } })();
            const now = Date.now(); const cch = readCache();
            const cand = appsRef.current.filter((a) => { const e = cch[a.packageName]; if (e && e.topicId) return false; if (e && e.flags && e.flags.hidden) return false; const t = tried[a.packageName] || 0; return now - t > (protoOn() ? 12 * 3600e3 : 3 * 86400e3); }).slice(0, protoOn() ? 40 : 6); // через служебный сервер можно чаще и больше: раз в 12ч, до 40 за проход
                        try {                                                        // СНАЧАЛА связи по имени пакета с сервера App&Game — одним запросом на всех
              const need = cand.filter((a) => !(cch[a.packageName] || {}).topicId).map((a) => a.packageName);
              if (need.length) {
                const got = await agApps(need);
                for (const pkg in got) {
                  const g = got[pkg];
                  if (!g.topicId) continue;
                  onCache(pkg, { topicId: g.topicId, matched: true, stale: true, ...(g.title ? { title4pda: g.title } : {}), ...(g.desc ? { desc: g.desc } : {}), ...(g.icon ? { icon: g.icon } : {}), ...(g.ver ? { ver4pda: g.ver } : {}), ...(g.upd && /^\d{8}$/.test(g.upd) ? { du: `${g.upd.slice(6, 8)}.${g.upd.slice(4, 6)}.${g.upd.slice(2, 4)}` } : {}) });
                  st.nl = (st.nl || 0) + 1;
                  tried[pkg] = now;
                }
                upd();
              }
            } catch {}
            const nrm = (x) => (x || "").toLowerCase().replace(/[^a-zа-яё0-9]+/gi, "");
            for (const a of cand) {
              if (!alive) break;
              tried[a.packageName] = now;
              try {                                                       // указатель «пакет → тема», накопленный с сервера App&Game
                const idx = JSON.parse(localStorage.getItem("t4_agpkg") || "{}");
                const t2 = idx[a.packageName];
                if (t2) { onCache(a.packageName, { topicId: String(t2), matched: true, stale: true }); st.nl = (st.nl || 0) + 1; continue; }
              } catch {}
              if (protoOn()) {                                            // ищем тему через служебный сервер — быстро и без ограничений
                try {
                  const nm2 = appNameFor(a.label || "");
                  if (nm2 && nm2.length >= 3) {
                    const pf = await protoFind(nm2, 0, 20);
                    const key2 = nrm(nm2);
                    const hits2 = pf.items.filter((r) => nrm(appNameFor(r.title)) === key2);
                    if (hits2.length === 1) { onCache(a.packageName, { topicId: String(hits2[0].topicId), matched: true, stale: true }); st.nl = (st.nl || 0) + 1; continue; }
                    if (hits2.length > 1) continue;
                  }
                } catch {}
              }
              if (window.__rate) break;
              try {
                const nm = appNameFor(a.label || ""); if (!nm || nm.length < 3) continue;
                const sr = await raceTO(t4http(searchUrl4pda(nm, "top", [], false, 0), false), 15000);
                if (!sr.body || sr.captcha) break;                         // капча/пусто — не жжём дальше
                const rs = parseSearchResults(sr.body);
                const key = nrm(nm);
                const hits = rs.filter((r) => nrm(appNameFor(r.title)) === key);
                if (hits.length === 1) { onCache(a.packageName, { topicId: String(hits[0].topicId), matched: true, stale: true }); st.nl = (st.nl || 0) + 1; }
              } catch {}
            }
            localStorage.setItem("t4_nl_try", JSON.stringify(tried));
            if (st.nl) upd();
          }
        } catch {}
        try { localStorage.setItem("t4_last_check", String(Date.now())); } catch {} // конец прохода — для автопроверки по расписанию
        busyRef.current.ver = false; syncBusy();
      }
    })();
    return () => { alive = false; };
  }, []);   // ни apps, ни refreshTick в зависимостях: ничто не пересоздаёт цикл и не обрывает идущий проход

  // версия из Google Play — идёт вместе с проверкой обновлений при запуске, ДЛЯ ВСЕХ приложений
  // (раньше только для связанных с темой — у остальных версия появлялась, лишь когда откроешь карточку)
  const playStarted = useRef(0);
  useEffect(() => { playStarted.current++; }, [refreshTick]);   // будим, а не пересоздаём
  useEffect(() => {
    let alive = true;
    const PTRY = "t4_play_try";
    const readTry = () => { try { return JSON.parse(localStorage.getItem(PTRY) || "{}"); } catch { return {}; } };
    (async () => {
      let idle = 0;
      while (alive) {
        const cc = readCache(); const tried = readTry(); const now = Date.now();
        const pk = appsRef.current.filter((a) => {
          const c = cc[a.packageName] || {};
          const need = !c.verPlay || now - (c.playChk || 0) > 24 * 3600e3;   // нет версии или она старше суток
          if (!need) return false;
          return now - (tried[a.packageName] || 0) > 6 * 3600e3;             // неудачную попытку не повторяем чаще 6ч (нет в Play и т.п.)
        });
        if (!pk.length) { idle++; await new Promise((r) => setTimeout(r, idle > 5 ? 20000 : 4000)); continue; }   // не выходим — ждём новых приложений/истечения суток
        idle = 0;
        // ПАЧКАМИ (как в APKUpdater): один запрос на список пакетов вместо запроса на каждое приложение.
        // Ограничение gplayapi — не больше 20 пакетов за запрос
        for (let i = 0; i < pk.length && alive; i += 20) {
          const part = pk.slice(i, i + 20);
          let got = null;
          try { const r = await Apps.playVersions({ packages: part.map((a) => a.packageName) }); got = (r && r.items) || []; } catch { got = null; }
          if (got && got.length) {
            const ts0 = Date.now();
            for (const it of got) { if (it && it.packageName && it.versionName) onCache(it.packageName, { verPlay: it.versionName, verPlayCode: it.versionCode || "", playChk: ts0 }); }
          } else if (got === null) {
            for (const a of part) { if (!alive) break; try { const pv = await fetchPlayVersion(a.packageName); if (pv) onCache(a.packageName, { verPlay: pv.name, verPlayCode: pv.code, playChk: Date.now() }); } catch {} }   // пачка не прошла — поштучно, как раньше
          }
          const t2 = readTry(); const ts = Date.now(); for (const a of part) t2[a.packageName] = ts;   // отмечаем попытку: не долбим Play по кругу
          try { localStorage.setItem(PTRY, JSON.stringify(t2)); } catch {}
          await new Promise((r) => setTimeout(r, 300));
        }
      }
    })();
    return () => { alive = false; };
  }, []);

  // кнопка «Обновить»: сбросить «не найдено» и перезапустить подбор/проверку
  const refresh = () => {
    const c = readCache();
    Object.keys(c).forEach((pkg) => {
      if (c[pkg] && c[pkg].notfound && !c[pkg].topicId) { delete c[pkg].notfound; }
      if (c[pkg] && c[pkg].topicId) c[pkg].stale = true; // ручное «Обновить» форсит ВСЕХ связанных (TTL — только для фоновой автопроверки)
    });
    try { localStorage.setItem(CKEY, JSON.stringify(c)); } catch {}
    try { localStorage.removeItem("t4_play_try"); } catch {}   // ручное «Обновить» — Play-версии тоже перепроверяем
    setTopics({ ...c });
    const b = busyRef.current; b.cat = true; b.until = Date.now() + 900; syncBusy();   // визуальный отклик с первого кадра
    fetchGhCatalog(true).then(() => { b.cat = false; syncBusy(); setRefreshTick((t) => t + 1); }).catch(() => { b.cat = false; syncBusy(); });
    setRefreshTick((t) => t + 1);
  };

  // Пейджер вкладок: лента едет GPU-transform'ом; палец пишет цель, применяет её rAF-цикл (кадр-в-кадр, субпиксельно).
  const pagerRef = useRef(null);                           // контейнер панелей (жест свайпа)

  useEffect(() => {                                        // жест ленты v14: палец пишет только цель, кадр применяет; ноль React во время жеста
    const p = pagerRef.current; if (!p) return;
    const g = { on: false, axis: 0, x0: 0, y0: 0, start: 1, tgt: 1, raf: 0, lastX: 0, lastT: 0, vx: 0 };
    const W = () => p.clientWidth || 1;
    const loop = () => { if (!g.on || g.axis !== 1) { g.raf = 0; return; } applyFrac(g.tgt); paintTabs(Math.round(g.tgt)); g.raf = requestAnimationFrame(loop); };
    const ts = (e) => { const t = e.touches[0]; g.on = true; g.axis = 0; g.x0 = t.clientX; g.y0 = t.clientY; g.lastX = t.clientX; g.lastT = performance.now(); g.vx = 0; };
    const tm = (e) => {
      if (!g.on) return;
      const t = e.touches[0];
      if (!g.axis) {
        const dx = t.clientX - g.x0, dy = t.clientY - g.y0;
        if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
        g.axis = (Math.abs(dx) > Math.abs(dy) * 1.15) ? 1 : 2;
        if (g.axis === 1) { ++pagerGen.current; pagerBusy.current = true; clearTimeout(pendAct.current); g.start = pagerFrac.current; g.tgt = g.start; if (!g.raf) g.raf = requestAnimationFrame(loop); }
      }
      if (g.axis !== 1) return;
      e.preventDefault();
      const now = performance.now(); const dt = now - g.lastT;
      if (dt > 0) { g.vx = (t.clientX - g.lastX) / dt; g.lastX = t.clientX; g.lastT = now; }
      g.tgt = Math.max(0, Math.min(visRef.current.length - 1, g.start - (t.clientX - g.x0) / W()));
    };
    const te = () => {
      if (!g.on) return; g.on = false;
      if (g.axis !== 1) {                                  // вертикаль/тап: летящую доводку НЕ трогаем (перебивание гнало ленту к старой вкладке); ровняем только реально съехавшую ленту
        if (!pagerBusy.current && Math.abs(pagerFrac.current - pagerIdx.current) > 0.01) pagerSnapTo(pagerIdx.current, 120);
        return;
      }
      if (g.raf) { cancelAnimationFrame(g.raf); g.raf = 0; }
      const f = g.tgt; const base = Math.round(g.start);   // точка захвата (не устаревшая pagerIdx — при перехвате летящей ленты она отстаёт)
      let target = Math.round(f);
      if (target === base) {                               // короткий свайп тоже листает: любой распознанный горизонтальный жест двигает в сторону движения
        const dev = f - g.start; const fling = Math.abs(g.vx) > 0.45;
        if (Math.abs(dev) > 0.02 || fling) target = base + (fling ? (g.vx > 0 ? -1 : 1) : (dev > 0 ? 1 : -1));
      }
      pagerSnapTo(target, 160);
    };
    p.addEventListener("touchstart", ts, { passive: true });
    p.addEventListener("touchmove", tm, { passive: false });
    p.addEventListener("touchend", te, { passive: true });
    p.addEventListener("touchcancel", te, { passive: true });
    return () => { p.removeEventListener("touchstart", ts); p.removeEventListener("touchmove", tm); p.removeEventListener("touchend", te); p.removeEventListener("touchcancel", te); };
  }, []);
  useEffect(() => {                                        // переприменение позиции после каждого рендера (кроме жеста/доводки) — любой слёт закрывается тут же
    if (!pagerBusy.current) { applyFrac(pagerFrac.current); paintTabs(pagerIdx.current); }
  });
  useEffect(() => {                                        // сторож: сверка РЕАЛЬНОГО экрана ЧИСЛОМ (getComputedStyle → matrix tx), не строкой
    const iv = setInterval(() => {
      try {
        if (pagerBusy.current) return;
        const st = stripRef.current, p = pagerRef.current; if (!st || !p) return;
        const w = p.clientWidth || 0; if (!w) return;
        const want = -pagerIdx.current * w;
        let tx = 0; const tr = getComputedStyle(st).transform;
        if (tr && tr !== "none") { const m = tr.match(/matrix\(([^)]+)\)/); if (m) tx = parseFloat(m[1].split(",")[4]) || 0; }
        if (Math.abs(tx - want) > 2) { applyFrac(pagerIdx.current); pagerFixN.current++; }
        if (Math.abs(pagerFrac.current - pagerIdx.current) > 0.005) { applyFrac(pagerIdx.current); pagerFixN.current++; }
        if (pagerIdx.current !== activeRef.current) { setActive(pagerIdx.current); pagerFixN.current++; }
        paintTabs(pagerIdx.current);
      } catch {}
    }, 500);
    return () => clearInterval(iv);
  }, []);

  const panes = useMemo(() => { const m = {}; for (const t of VIS) m[t] = tabList(t); return m; }, [apps, topics, tabSort, catReady, linkedReady, refreshTick, secHid, selMode, selected]);   // ПОСЛЕ объявления tabList (TDZ!); deps: ЛЮБОЙ источник данных списка, включая режим выделения
  return (
    <div className="t4root" style={{ height: "100vh", background: C.bg, display: "flex", flexDirection: "column", fontFamily: "Roboto, system-ui, sans-serif", overflow: "hidden", WebkitUserSelect: "none", userSelect: "none", WebkitTapHighlightColor: "transparent" }}>
      <style>{`.t4root { height: calc(100vh - var(--t4-kb, 0px)) !important; } @supports (height: 100dvh) { .t4root { height: calc(100dvh - var(--t4-kb, 0px)) !important; } }`}</style>
      <style>{`
        @keyframes t4fade { from { opacity: 0 } to { opacity: 1 } }
        @keyframes t4slR { from { transform: translate3d(10%,0,0) } to { transform: translate3d(0,0,0) } }
        @keyframes t4slL { from { transform: translate3d(-10%,0,0) } to { transform: translate3d(0,0,0) } }
        .t4-sl-in-r { animation: t4slR .22s cubic-bezier(.33,1,.68,1) both; will-change: transform; backface-visibility: hidden }
        .t4-sl-in-l { animation: t4slL .22s cubic-bezier(.33,1,.68,1) both; will-change: transform; backface-visibility: hidden }
        @keyframes t4spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
        @keyframes t4up { from { transform: translateY(24px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
        @keyframes t4sheet { from { transform: translateY(100%) } to { transform: translateY(0) } }
        @keyframes t4pop { from { transform: scale(.9); opacity: 0 } to { transform: scale(1); opacity: 1 } }
        @keyframes t4dim { from { opacity: 0 } to { opacity: 1 } }
        .t4-fade { animation: t4fade .22s ease }
        .t4-screen { animation: t4fade .2s ease, t4up .26s cubic-bezier(.22,.61,.36,1) }
        .t4-sheet { animation: t4sheet .28s cubic-bezier(.22,.61,.36,1) }
        .t4-pop { animation: t4pop .2s cubic-bezier(.22,.61,.36,1) }
        .t4-dim { animation: t4dim .2s ease }
        .t4-item { animation: t4up .3s cubic-bezier(.22,.61,.36,1) both }
        @keyframes t4tab { from { transform: translateX(14px); opacity: .3 } to { transform: translateX(0); opacity: 1 } }
        .t4-tab { animation: t4tab .2s cubic-bezier(.22,.61,.36,1) }
        .t4-press { transition: transform .09s ease, opacity .09s ease }
        .t4-press:active { transform: scale(.96); opacity: .8 }
      `}</style>      <div style={{ paddingTop: "var(--sat)", background: selMode ? C.accSoft : C.bar, flexShrink: 0, transition: "background .15s" }}>
        {selMode ? (
          <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "0 16px", height: 56 }}>
            <div onClick={exitSel} style={{ cursor: "pointer", color: C.text, fontSize: 22, width: 26, textAlign: "center" }}>✕</div>
            <span style={{ color: C.text, fontSize: 19, fontWeight: 700, flex: 1 }}>Выбрано: {Object.keys(selected).length}</span>
            <div onClick={bulkHide} style={{ cursor: "pointer", color: C.acc, fontWeight: 700, fontSize: 15 }}>Скрыть</div>
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "0 16px", height: 56 }}>
            <div onClick={() => setDrawer(true)} style={{ width: 26, height: 20, display: "flex", flexDirection: "column", justifyContent: "space-between", cursor: "pointer" }}>{[0, 1, 2].map((i) => <span key={i} style={{ height: 2, borderRadius: 2, background: C.text }} />)}</div>
            <span style={{ color: C.text, fontSize: 22, fontWeight: 600 }}>4PDApps</span>
          </div>
        )}
      </div>
      {localStorage.getItem("t4_dbg") === "1" && (() => { const tv = Object.values(topics || {}); const bound = tv.filter((t) => t && t.topicId).length; const withVer = tv.filter((t) => t && t.ver4pda).length; return <div onClick={(e) => { const t = e.currentTarget.innerText; const done = () => notify("Диагностика скопирована"); try { navigator.clipboard.writeText(t).then(done).catch(() => { const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); done(); }); } catch { try { const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); done(); } catch {} } }} style={{ left: 4, right: 4, background: C.dbgBg, color: C.hintTx, fontSize: 8.5, lineHeight: 1.2, padding: "2px 6px", fontFamily: "monospace", borderBottom: `1px solid ${C.border}`, cursor: "pointer", maxHeight: 92, overflow: "hidden" }}>база:{catCount()} карта:{Object.keys(VERMAP).length} привязано:{bound} версий:{withVer}<br />{window.__verStat || "версии: —"}<br />{window.__agStat || ""}<br />{window.__agFiles || ""}<br />{window.__protoStat || ""}<br />{window.__fastStat || ""}<br />{window.__catLoad || ""}<br />вкладка: {active}<br />СНИМОК 1-го кадра:<br /><span style={{ whiteSpace: "pre-wrap" }}>{localStorage.getItem("t4_shot") || "—"}</span><br />{window.__verDbg || ""}<br />{window.__verErr || ""}</div>; })()}

      {drawer && (
        <div onClick={() => setDrawer(false)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 80, display: "flex" }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: 280, maxWidth: "82%", height: "100%", background: C.bar, paddingTop: "var(--sat)", boxShadow: "2px 0 20px rgba(0,0,0,.5)" }}>
            {profile && profile.loggedIn ? (
              <>
                <div style={{ padding: "22px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 12 }}>
                  {profile.avatar ? <img src={profile.avatar} alt="" style={{ width: 50, height: 50, borderRadius: "50%", objectFit: "cover" }} /> : <div style={{ width: 50, height: 50, borderRadius: "50%", background: tileColor(profile.name || "u"), display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 22 }}>{(profile.name || "?").trim().charAt(0).toUpperCase()}</div>}
                  <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 17, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{String(profile.name || "").replace(/\s*[-–—|]?\s*4pda.*$/i, "").trim()}</div><div style={{ color: C.acc, fontSize: 12 }}>вы авторизованы</div></div>
                </div>
                <div onClick={async () => { if (logoutBusy) return; setLogoutBusy(true); await logout4pda(profile.logoutK); setProfile({ loggedIn: false }); setLogoutBusy(false); }} style={{ padding: "16px 18px", color: C.red, fontSize: 15.5, cursor: "pointer" }}>{logoutBusy ? "Выхожу…" : "Выйти из 4pda"}</div>
              </>
            ) : (
              <>
                <div style={{ padding: "20px 18px", borderBottom: `1px solid ${C.border}`, color: C.text, fontSize: 20, fontWeight: 700 }}>4PDApps<span style={{ color: C.sub, fontSize: 10.5, fontWeight: 400, marginLeft: 8 }}>сборка {BUILD_TAG}</span></div>
                <div onClick={async () => { setLoginForm(true); setLgErr(""); setLgCap(null); setLgCapInput(""); try { let f = await Apps.authForm4pda(); if (!f || !f.captchaImage) { try { await Apps.webGet({ url: "https://4pda.to/forum/index.php?act=auth" }); } catch {} try { f = await Apps.authForm4pda(); } catch {} } if (f && f.captchaImage) setLgCap({ image: f.captchaImage, time: f.captchaTime || "", sig: f.captchaSig || "" }); else setLgErr("Капча не загрузилась (Cloudflare). Закрой и открой вход ещё раз."); } catch {} }} style={{ padding: "16px 18px", color: C.text, fontSize: 15.5, cursor: "pointer" }}>Войти в 4pda</div>
                {loginForm && <div onClick={() => !lgBusy && setLoginForm(false)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 95, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
                  <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 340, background: C.card, borderRadius: 14, padding: 20, border: `1px solid ${C.border}` }}>
                    <div style={{ color: C.text, fontSize: 18, fontWeight: 600, marginBottom: 14 }}>Вход в 4pda</div>
                    <input value={lgNick} onChange={(e) => setLgNick(e.target.value)} placeholder="Логин или e-mail" autoCapitalize="none" style={{ width: "100%", boxSizing: "border-box", padding: "11px 12px", marginBottom: 10, borderRadius: 8, border: `1px solid ${C.border}`, background: C.bg, color: C.text, fontSize: 15 }} />
                    <input value={lgPass} onChange={(e) => setLgPass(e.target.value)} type="password" placeholder="Пароль" style={{ width: "100%", boxSizing: "border-box", padding: "11px 12px", marginBottom: 10, borderRadius: 8, border: `1px solid ${C.border}`, background: C.bg, color: C.text, fontSize: 15 }} />
                    <div onClick={() => setLgHidden((v) => !v)} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, cursor: "pointer" }}><div style={{ width: 18, height: 18, borderRadius: 4, border: `2px solid ${lgHidden ? C.acc : C.sub}`, background: lgHidden ? C.acc : "transparent" }} /><span style={{ color: C.sub, fontSize: 14 }}>Скрытый вход (невидимка)</span></div>
                    {lgCap && <div style={{ marginBottom: 12 }}>
                      <img src={lgCap.image} alt="captcha" style={{ display: "block", width: "100%", height: "auto", maxHeight: 170, objectFit: "contain", borderRadius: 6, marginBottom: 8, background: "#fff" }} onError={(e) => { e.target.style.opacity = 0.3; }} />
                      <input value={lgCapInput} onChange={(e) => setLgCapInput(e.target.value)} placeholder="Введите текст с картинки" autoCapitalize="none" style={{ width: "100%", boxSizing: "border-box", padding: "11px 12px", borderRadius: 8, border: `1px solid ${C.acc}`, background: C.bg, color: C.text, fontSize: 15 }} />
                    </div>}
                    {lgErr && <div style={{ color: C.red, fontSize: 13, marginBottom: 12 }}>{lgErr}</div>}
                    <div style={{ display: "flex", gap: 10 }}>
                      <div onClick={() => !lgBusy && setLoginForm(false)} style={{ flex: 1, textAlign: "center", padding: "11px 0", borderRadius: 8, border: `1px solid ${C.border}`, color: C.sub, fontSize: 15, cursor: "pointer" }}>Отмена</div>
                      <div onClick={doLogin} style={{ flex: 1, textAlign: "center", padding: "11px 0", borderRadius: 8, background: (lgNick && lgPass && !lgBusy) ? C.acc : C.off, color: "#fff", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>{lgBusy ? "Вход…" : "Войти"}</div>
                    </div>
                  </div>
                </div>}
                <div style={{ padding: "14px 18px", color: C.sub, fontSize: 12.5, lineHeight: 1.4 }}>После входа связь и поиск на 4pda работают стабильнее (проходит Cloudflare), а список обновится автоматически.</div>
              </>
            )}
            <div onClick={() => { setDrawer(false); setSettingsScreen(true); }} style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}`, display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer" }}><span style={{ color: C.text, fontSize: 15.5 }}>Настройки</span><span style={{ color: C.sub, fontSize: 22 }}>›</span></div>
            <div onClick={() => { setDrawer(false); setSaveScreen(true); }} style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}`, display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer" }}><span style={{ color: C.text, fontSize: 15.5 }}>Сохранение настроек</span><span style={{ color: C.sub, fontSize: 22 }}>›</span></div>
            <div onClick={() => { setDrawer(false); setDebugScreen(true); }} style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}`, display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer" }}><span style={{ color: C.text, fontSize: 15.5 }}>Отладка</span><span style={{ color: C.sub, fontSize: 22 }}>›</span></div>
          </div>
        </div>
      )}

      <div ref={tabBarRef} style={{ display: "flex", background: C.bar, overflowX: "auto", borderBottom: `1px solid ${C.border}`, flexShrink: 0, scrollbarWidth: "none" }}>
        {VIS.map((t, i) => <div key={t} onClick={() => { if (tabHoldRef.current) { tabHoldRef.current = false; return; } gotoTab(i); }} onTouchStart={() => { tabHoldRef.current = false; clearTimeout(tabHoldT.current); tabHoldT.current = setTimeout(() => { tabHoldRef.current = true; setTabSortOpen(true); }, 450); }} onTouchEnd={() => clearTimeout(tabHoldT.current)} onTouchMove={() => clearTimeout(tabHoldT.current)} style={{ padding: "13px 9px", whiteSpace: "nowrap", position: "relative", cursor: "pointer" }}><span ref={(el) => { tabTxtRefs.current[i] = el; }} style={{ color: i === active ? C.active : C.sub, fontSize: 13.5, fontWeight: 600, letterSpacing: 0.1 }}>{TABS[t]}</span><div ref={(el) => { tabUndRefs.current[i] = el; }} style={{ position: "absolute", left: 8, right: 8, bottom: 0, height: 3, borderRadius: 3, background: C.sub, opacity: i === active ? 1 : 0 }} /></div>)}

      </div>

      <style>{`.t4-pager{scrollbar-width:none}.t4-pager::-webkit-scrollbar{display:none}`}</style>
      <div ref={pagerRef} className="t4-pager" style={{ flex: 1, overflow: "hidden", position: "relative" }}>
        {/* Лента v14: N панелей, палец тянет, доводка 160мс. Позиция ставится синхронно callback-ref'ом; сторож сверяет реальный экран числом */}
        <div ref={(el) => { stripRef.current = el; if (el) { el.style.transform = `translate3d(${-(pagerFrac.current * (100 / visRef.current.length))}%,0,0)`; paintTabs(pagerIdx.current); } }} style={{ display: "flex", width: `${VIS.length * 100}%`, height: "100%", willChange: "transform" }}>
          {VIS.map((t) => (
            <div key={t} style={{ width: `${100 / VIS.length}%`, flexShrink: 0, height: "100%", overflowY: "auto", overflowX: "hidden", touchAction: "pan-y" }}>
              <div style={{ padding: "10px 10px 0" }}>{panes[t]}<div style={{ height: 12 }} /></div>
            </div>
          ))}
        </div>
      </div>

      {searchOpen && (
        <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "var(--sab)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "5px 12px", height: 46, boxSizing: "border-box" }}>
            <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && searchQuery.trim()) setSearchScreen(searchQuery.trim()); }} autoFocus placeholder={`Поиск: ${searchType === "games" ? "Игры" : searchType === "emu" ? "Эмуляторы" : "Программы"} · Enter`} style={{ flex: 1, background: C.input, border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
            <div onClick={() => searchQuery.trim() && setSearchScreen(searchQuery.trim())} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
            <div onClick={() => { setSearchOpen(false); setSearchQuery(""); }} style={{ cursor: "pointer", color: C.sub, fontSize: 20, padding: "0 4px" }}>✕</div>
          </div>
        </div>
      )}

      {!searchOpen && searchTypeMenu && (
        <div onClick={() => setSearchTypeMenu(false)} style={{ position: "fixed", inset: 0, zIndex: 40 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", bottom: "calc(var(--sab) + 62px)", background: C.menu, borderRadius: 12, boxShadow: C.shadow, overflow: "hidden", minWidth: 200 }}>
            {[["emu", "Эмуляторы"], ["games", "Игры"], ["apps", "Программы"]].filter(([k]) => { const h = (() => { try { return JSON.parse(localStorage.getItem("t4_sections") || "{}"); } catch { return {}; } })(); return !(k === "emu" && h.emu) && !(k === "games" && h.games); }).map(([k, label]) => (
              <div key={k} onClick={() => { setSearchType(k); setSearchTypeMenu(false); setSearchOpen(true); }} style={{ padding: "14px 18px", color: C.text, fontSize: 15.5, cursor: "pointer", borderTop: k !== "emu" ? `1px solid ${C.border}` : "none" }}>{label}</div>
            ))}
          </div>
        </div>
      )}
      {!searchOpen && <div style={{ paddingBottom: "var(--sab)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around", height: 46 }}>
          <NavBtn title="Системные" onClick={() => setSysScreen(true)}><IAndroid /></NavBtn>
          <NavBtn title="Скрытые" onClick={() => setHidScreen(true)}><IEyeOff /></NavBtn>
          <NavBtn title="Загрузки" onClick={() => setDlScreen(true)}><IDownload /></NavBtn>
          <NavBtn title="Поиск" onClick={() => { if (localStorage.getItem("t4_search_all") === "1") { setSearchScreen(""); } else { setSearchTypeMenu((v) => !v); } }}><ISearch /></NavBtn>
          <NavBtn title="Обновить" onClick={refresh}><div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
            <div style={{ display: "flex", animation: chkBusy ? "t4spin 900ms linear infinite" : "none", transformOrigin: "50% 50%" }}><IRefresh color={chkBusy ? C.acc : undefined} /></div>
            <span ref={chkProgRef} style={{ position: "absolute", top: 20, fontSize: 8.5, fontWeight: 700, color: C.acc, whiteSpace: "nowrap", lineHeight: 1, display: chkBusy ? "block" : "none" }} />
          </div></NavBtn>
          <NavBtn title="Обновления" onClick={() => updates > 0 && setUpdScreen(true)}><div style={{ width: 34, height: 34, borderRadius: "50%", border: `2px solid ${updates > 0 ? C.red : C.sub}`, background: updates > 0 ? C.red : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: updates > 0 ? "#fff" : C.nav, fontSize: 14, fontWeight: 700 }}>{updates}</span></div></NavBtn>
        </div>
      </div>}

      {sel && <Detail app={sel} onClose={() => setSel(null)} onCache={onCache} onFiles={setFilesData} onDownloads={() => { setFilesData(null); setDlScreen(true); }} onSimilar={() => { const q = sel.label || sel.packageName; setSel(null); setSearchScreen(q); }} />}
      {menu && <ContextMenu app={menu.app} x={menu.x} y={menu.y} info={topics[menu.app.packageName]} onClose={() => setMenu(null)} onInfo={(a) => { setMenu(null); setInfoApp(a); }} onFlag={onFlag} onLink={(a) => { setMenu(null); setLinkApp(a); }} />}
      {linkApp && <LinkScreen app={linkApp} onClose={() => setLinkApp(null)} onLinked={(pkg, patch) => { onCache(pkg, patch); }} />}
      {infoApp && <InfoDialog app={infoApp} info={topics[infoApp.packageName]} onClose={() => setInfoApp(null)} />}
      {themeScreen && (
        <div className="t4-screen" style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 64 }}>
          <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={() => setThemeScreen(false)} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Тема</span></div></div>
          <div style={{ flex: 1, overflowY: "auto", padding: "14px 14px calc(var(--sab) + 20px)" }}>
            <div onClick={() => { localStorage.setItem("t4_theme", "system"); applyTheme("system"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 14px", marginBottom: 12, borderRadius: 12, background: C.card, border: `1px solid ${(localStorage.getItem("t4_theme") || "dark") === "system" ? C.acc : C.border}`, cursor: "pointer" }}>
              <span style={{ color: C.text, fontSize: 15 }}>Системная (как на телефоне)</span>
              {(localStorage.getItem("t4_theme") || "dark") === "system" && <span style={{ color: C.acc, fontSize: 16, fontWeight: 800 }}>✓</span>}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
              {THEMES.map((t) => {
                const on = (localStorage.getItem("t4_theme") || "dark") === t.id;
                return <div key={t.id} onClick={() => { localStorage.setItem("t4_theme", t.id); applyTheme(t.id); setRefreshTick((r) => r + 1); }} style={{ borderRadius: 14, overflow: "hidden", cursor: "pointer", border: on ? `2.5px solid ${t.acc}` : `1px solid ${t.border}`, background: t.card }}>
                  <div style={{ height: 34, background: t.bar, display: "flex", alignItems: "center", padding: "0 10px", gap: 5 }}>
                    <div style={{ width: 16, height: 3, borderRadius: 2, background: t.text, opacity: 0.5 }} />
                    <div style={{ flex: 1 }} />
                    <div style={{ width: 6, height: 6, borderRadius: "50%", background: t.acc }} />
                  </div>
                  <div style={{ background: t.bg, padding: "12px 10px", display: "flex", flexDirection: "column", gap: 7 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{ width: 26, height: 26, borderRadius: 7, background: t.acc, flexShrink: 0 }} />
                      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
                        <div style={{ height: 5, width: "75%", borderRadius: 3, background: t.text, opacity: 0.85 }} />
                        <div style={{ height: 4, width: "45%", borderRadius: 3, background: t.sub }} />
                      </div>
                    </div>
                    <div style={{ height: 22, borderRadius: 7, background: t.card, border: `1px solid ${t.border}`, display: "flex", alignItems: "center", padding: "0 7px" }}><div style={{ height: 4, width: "55%", borderRadius: 3, background: t.sub }} /></div>
                  </div>
                  <div style={{ background: t.bar, padding: "8px 10px", display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: `1px solid ${t.divider}` }}>
                    <span style={{ color: t.text, fontSize: 13, fontWeight: 600 }}>{t.name}</span>
                    {on && <span style={{ color: t.acc, fontSize: 15, fontWeight: 800 }}>✓</span>}
                  </div>
                </div>;
              })}
            </div>
          </div>
        </div>
      )}
      {impOpen && (
        <div onClick={() => setImpOpen(false)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 82, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 420, background: C.card, borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Импорт связей</div>
            <div style={{ color: C.sub, fontSize: 12.5, marginBottom: 10 }}>Вставьте содержимое файла экспорта</div>
            <textarea value={impVal} autoFocus onChange={(e) => setImpVal(e.target.value)} placeholder='{"com.example": {"topicId": "123456"}}' style={{ width: "100%", boxSizing: "border-box", height: 140, background: C.input, border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 13, padding: "10px 12px", outline: "none", resize: "none", WebkitUserSelect: "text", userSelect: "text" }} />
            <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", alignItems: "center", marginTop: 14 }}>
              <div onClick={() => setImpOpen(false)} style={{ cursor: "pointer", color: C.sub, fontSize: 22, padding: "4px 8px" }}>✕</div>
              <div onClick={() => {
                try {
                  const j = JSON.parse(impVal); const cc = readCache(); let n = 0;
                  for (const [pkg, v] of Object.entries(j || {})) {
                    const tid = v && String(v.topicId || "").match(/^\d{4,9}$/) && String(v.topicId);
                    if (!tid) continue;
                    const ex = cc[pkg];
                    if (ex && ex.manual && !(v && v.manual)) continue;            // ручную связь авто-записью не перетираем
                    cc[pkg] = { ...(ex || {}), topicId: tid, matched: true, ...(v && v.manual ? { manual: true } : {}), stale: true };
                    n++;
                  }
                  localStorage.setItem(CKEY, JSON.stringify(cc));
                  setImpOpen(false); setImpVal(""); setRefreshTick((x) => x + 1);
                  notify(`Импортировано связей: ${n}`);
                } catch { notify("Не похоже на файл экспорта"); }
              }} style={{ cursor: "pointer", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 15, padding: "10px 18px", borderRadius: 10 }}>Импортировать</div>
            </div>
          </div>
        </div>
      )}
      {tabSortOpen && (
        <div onClick={() => setTabSortOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 55 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", top: "calc(var(--sat, 0px) + 104px)", background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, boxShadow: C.shadow, overflow: "hidden", minWidth: 210 }}>
            <div style={{ padding: "10px 16px 4px", color: C.sub, fontSize: 12 }}>Сортировка списка</div>
            {[["date", "По дате обновления"], ["name", "По имени"], ["ver", "По версии"], ["size", "По размеру"], ["inst", "По дате установки"], ["upd", "Сначала с обновлениями"]].map(([k, label]) => <div key={k} onClick={() => { setTabSort(k); localStorage.setItem("t4_tab_sort", k); setTabSortOpen(false); }} style={{ padding: "13px 16px", color: tabSort === k ? C.acc : C.text, fontSize: 15, fontWeight: tabSort === k ? 700 : 400, cursor: "pointer" }}>{label}</div>)}
          </div>
        </div>
      )}
      {settingsScreen && (
        <div className="t4-screen" style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 62 }}>
          <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={() => setSettingsScreen(false)} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Настройки</span></div></div>
          <div style={{ flex: 1, overflowY: "auto", paddingBottom: "calc(var(--sab) + 24px)" }}>
            <div onClick={() => setThemeScreen(true)} style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}`, display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer" }}>
              <div><div style={{ color: C.text, fontSize: 15 }}>Тема</div><div style={{ color: C.sub, fontSize: 12.5, marginTop: 2 }}>{(() => { const v = localStorage.getItem("t4_theme") || "dark"; return v === "system" ? "Системная" : (THEME_BY[v] || THEME_BY.dark).name; })()}</div></div>
              <span style={{ color: C.sub, fontSize: 22 }}>›</span>
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Вид</div>
              {(() => { const on = localStorage.getItem("t4_big_cards") === "1"; return (
                <div onClick={() => { localStorage.setItem("t4_big_cards", on ? "0" : "1"); setRefreshTick((x) => x + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                  <span style={{ color: C.sub, fontSize: 13.5 }}>Крупные карточки</span>
                  <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>
                </div>
              ); })()}
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Разделы</div>
              {[["games", "Игры"], ["emu", "Эмуляторы"], ["unlinked", "Не связанные"]].map(([k, label]) => (
                <div key={k} onClick={() => { const h = { ...secHid, [k]: !secHid[k] }; if (!h[k]) delete h[k]; localStorage.setItem("t4_sections", JSON.stringify(h)); setSecHid(h); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12, marginBottom: 12 }}>
                  <span style={{ color: C.sub, fontSize: 13.5 }}>{label}</span>
                  {(() => { const on = !secHid[k]; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
                </div>
              ))}
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Тип поиска</div>
              <div onClick={() => { const v = localStorage.getItem("t4_search_all") === "1"; localStorage.setItem("t4_search_all", v ? "0" : "1"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                <span style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.35 }}>Искать всё сразу (Программы, Игры, Эмуляторы во вкладках)</span>
                {(() => { const on = localStorage.getItem("t4_search_all") === "1"; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
              </div>
            </div>
<div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Загрузки</div>
              <div onClick={async () => { try { const r = await Apps.pickDownloadFolder(); if (r && r.ok) setDlFolder(r.name || "выбранная папка"); } catch {} }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12, marginBottom: 12 }}>
                <div style={{ minWidth: 0 }}><div style={{ color: C.sub, fontSize: 13.5 }}>Папка скачивания</div><div style={{ color: C.text, fontSize: 13, marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{dlFolder || "Папка «Загрузки»"}</div></div>
                <span style={{ color: C.acc, fontSize: 13.5, fontWeight: 700, flexShrink: 0 }}>Изменить</span>
              </div>
              {dlFolder && dlFolder !== "Папка «Загрузки»" && <div onClick={async () => { try { await Apps.clearDownloadFolder(); setDlFolder("Папка «Загрузки»"); } catch {} }} style={{ color: C.red, fontSize: 12.5, cursor: "pointer", marginBottom: 12, marginTop: -6 }}>Сбросить на «Загрузки»</div>}
              <div onClick={() => { const v = localStorage.getItem("t4_dl_ask") === "1"; localStorage.setItem("t4_dl_ask", v ? "0" : "1"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                <span style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.35 }}>Всегда спрашивать, куда сохранить</span>
                {(() => { const on = localStorage.getItem("t4_dl_ask") === "1"; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
              </div>
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Файлы</div>
              <div onClick={() => { const v = localStorage.getItem("t4_files_myarch") !== "0"; localStorage.setItem("t4_files_myarch", v ? "0" : "1"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                <span style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.35 }}>Отображать файлы только под мой процессор</span>
                {(() => { const on = localStorage.getItem("t4_files_myarch") !== "0"; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
              </div>
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>Каталог приложений 4pda (подстрочный поиск)</div>
              <div style={{ color: C.sub, fontSize: 12.5, lineHeight: 1.35, marginBottom: 10 }}>База названий 4pda собирается на GitHub, хранится локально; при запуске приложение лишь сверяет версию и догружает изменения. Кнопка — синхронизировать/перекачать сейчас.</div>
              <div onClick={async () => { if (idxBusy) return; setIdxBusy(true); setIdxMsg("Качаю каталог с GitHub…"); try { const n = await fetchGhCatalog(true); setIdxMsg(n ? `Готово: ${n} тем в каталоге` : "Не удалось скачать (проверь, что catalog.json собрался в репозитории)"); setRefreshTick((t) => t + 1); } catch { setIdxMsg("Ошибка"); } setIdxBusy(false); }} style={{ display: "inline-block", background: idxBusy ? C.off : C.acc, color: idxBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: idxBusy ? "default" : "pointer" }}>{idxBusy ? "Качаю…" : "Обновить каталог"}</div>
              {idxMsg && <div style={{ color: C.sub, fontSize: 12.5, marginTop: 8 }}>{idxMsg}</div>}
              {(() => { const n = catCount(); return n ? <div style={{ color: C.green, fontSize: 12, marginTop: 4 }}>В каталоге: {n} тем</div> : null; })()}
            </div>
                </div>
        </div>
      )}
      {impSetOpen && (
        <div onClick={() => setImpSetOpen(false)} style={{ position: "fixed", inset: 0, background: C.dim, zIndex: 84, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 460, background: C.card, borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 8 }}>Восстановить настройки</div>
            <div style={{ color: C.sub, fontSize: 12.5, marginBottom: 10 }}>Вставьте содержимое сохранённого файла.</div>
            <textarea value={impSetVal} autoFocus onChange={(e) => setImpSetVal(e.target.value)} style={{ width: "100%", boxSizing: "border-box", height: 140, background: C.input, border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 12.5, padding: "10px 12px", fontFamily: "monospace" }} />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 14, marginTop: 12 }}>
              <div onClick={() => setImpSetOpen(false)} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 4px" }}>ОТМЕНА</div>
              <div onClick={() => { importSettings(impSetVal); setImpSetOpen(false); setImpSetVal(""); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 4px" }}>ВОССТАНОВИТЬ</div>
            </div>
          </div>
        </div>
      )}
            {saveScreen && (
        <div className="t4-screen" style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 62 }}>
          <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={() => setSaveScreen(false)} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Сохранение настроек</span></div></div>
          <div style={{ flex: 1, overflowY: "auto", paddingBottom: "calc(var(--sab) + 24px)" }}>
            <div style={{ padding: "16px 18px" }}>
              <div style={{ color: C.sub, fontSize: 12.5, lineHeight: 1.45, marginBottom: 14 }}>Файл со всеми пометками и настройками: избранное, скрытые приложения и обновления, тема, разделы, папка загрузки, вид списка.</div>
              <div style={{ display: "flex", gap: 10 }}>
                <div onClick={() => { setExpOpen(true); setImpPick(false); }} style={{ flex: 1, textAlign: "center", background: expOpen ? C.acc : C.off, color: expOpen ? C.onAcc : C.text, fontWeight: 700, fontSize: 14.5, padding: "12px 8px", borderRadius: 12, cursor: "pointer" }}>Сохранить</div>
                <div onClick={() => { setImpPick(true); setExpOpen(false); }} style={{ flex: 1, textAlign: "center", background: impPick ? C.acc : C.off, color: impPick ? C.onAcc : C.text, fontWeight: 700, fontSize: 14.5, padding: "12px 8px", borderRadius: 12, cursor: "pointer" }}>Восстановить</div>
              </div>
              {(expOpen || impPick) && (
                <div style={{ marginTop: 14 }}>
                  <div style={{ color: C.sub, fontSize: 12.5, marginBottom: 6 }}>{expOpen ? "Что сохранить" : "Что восстановить"}</div>
                  {[["fav", "Избранное"], ["hupd", "Скрытые обновления"], ["hidden", "Скрытые приложения"], ["prefs", "Настройки приложения"]].map(([kk, label]) => (
                    <div key={kk} onClick={() => setSaveSel((o) => ({ ...o, [kk]: !o[kk] }))} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12, padding: "9px 0", borderBottom: `1px solid ${C.divider}` }}>
                      <span style={{ color: C.text, fontSize: 14 }}>{label}</span>
                      <div style={{ width: 42, height: 24, borderRadius: 12, background: saveSel[kk] ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: saveSel[kk] ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>
                    </div>
                  ))}
                  <div onClick={() => { if (expOpen) { exportSettings(); setExpOpen(false); } else { setImpSetOpen(true); setImpPick(false); } }} style={{ marginTop: 14, textAlign: "center", background: C.acc, color: C.onAcc, fontWeight: 700, fontSize: 14.5, padding: "12px 8px", borderRadius: 12, cursor: "pointer" }}>{expOpen ? "Сохранить в файл" : "Вставить файл"}</div>
                  <div style={{ color: C.sub, fontSize: 11.5, marginTop: 8, lineHeight: 1.35 }}>{expOpen ? "Файл появится в папке «Загрузки»." : "Откройте сохранённый файл и вставьте его содержимое."}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      {debugScreen && (
        <div className="t4-screen" style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 62 }}>
          <div style={{ paddingTop: "var(--sat)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={() => setDebugScreen(false)} style={{ cursor: "pointer", color: C.text, fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Отладка</span></div></div>
          <div style={{ flex: 1, overflowY: "auto", paddingBottom: "calc(var(--sab) + 24px)" }}>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div style={{ color: C.sub, fontSize: 12, marginBottom: 10 }}>сборка {BUILD_TAG}</div>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>Пробник протокола 4pda</div>
              
              <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
                <input value={pHost} onChange={(e) => setPHost(e.target.value)} placeholder="сервер" autoCapitalize="none" style={{ flex: 2, minWidth: 0, background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13.5, padding: "9px 10px" }} />
                <input value={pPort} onChange={(e) => setPPort(e.target.value)} placeholder="порт" inputMode="numeric" style={{ flex: 1, minWidth: 0, background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13.5, padding: "9px 10px" }} />
              </div>
              <div onClick={() => setPTls((v) => !v)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12, marginBottom: 8 }}>
                <span style={{ color: C.sub, fontSize: 13.5 }}>Защищённое соединение</span>
                <div style={{ width: 42, height: 24, borderRadius: 12, background: pTls ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: pTls ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                <span style={{ color: C.sub, fontSize: 13.5 }}>Тип пакета</span>
                <input value={pType} onChange={(e) => setPType(e.target.value)} inputMode="numeric" style={{ width: 60, background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13.5, padding: "7px 10px" }} />
                <span onClick={() => setPZip((v) => !v)} style={{ color: pZip ? C.acc : C.sub, fontSize: 13.5, cursor: "pointer", marginLeft: 6 }}>{pZip ? "со сжатием" : "без сжатия"}</span>
              </div>
              <textarea value={pData} onChange={(e) => setPData(e.target.value)} placeholder="что отправить: текст или байты вида 5b 74 71 5d" style={{ width: "100%", boxSizing: "border-box", height: 90, background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13, padding: "9px 10px", fontFamily: "monospace" }} />
              <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                <div onClick={probeProfile} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Профиль"}</div>
                <div onClick={probeTopicFiles} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Файлы темы"}</div>
                <div onClick={probeHat} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Разметка шапки"}</div>
                <div onClick={probeAgSearch} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Поиск App&Game"}</div>
                <div onClick={probeSort} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Режимы поиска"}</div>
                <div onClick={probeAg} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Спросить App&Game"}</div>
                <div onClick={probeLink} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Ссылка на файл"}</div>
                <div onClick={probeTopic} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Спросить тему"}</div>
                <div onClick={probeWs} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Подключиться и отправить"}</div>
                <div onClick={probeFrame} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду…" : "Отправить как клиент"}</div>
                <div onClick={probeSend} style={{ background: pBusy ? C.off : C.acc, color: pBusy ? C.sub : C.onAcc, fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: pBusy ? "default" : "pointer" }}>{pBusy ? "Жду ответ…" : "Отправить"}</div>
                <div onClick={() => { setPData(""); setPLog(""); }} style={{ border: `1px solid ${C.border}`, color: C.sub, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: "pointer" }}>Очистить</div>
                {pLog ? <div onClick={() => { const done = () => notify("Скопировано"); try { navigator.clipboard.writeText(pLog).then(done).catch(() => {}); } catch {} }} style={{ border: `1px solid ${C.border}`, color: C.acc, fontSize: 13.5, padding: "9px 14px", borderRadius: 9, cursor: "pointer" }}>Скопировать ответ</div> : null}
              </div>
              {pLog ? <div style={{ marginTop: 10, background: C.dbgBg, color: C.text, fontSize: 11.5, fontFamily: "monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", padding: "10px 12px", borderRadius: 8, border: `1px solid ${C.border}` }}>{pLog}</div> : null}
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid ${C.divider}` }}>
              <div onClick={() => { const v = localStorage.getItem("t4_dbg") === "1"; localStorage.setItem("t4_dbg", v ? "0" : "1"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                <span style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.35 }}>Диагностика (плашка со служебной информацией)</span>
                {(() => { const on = localStorage.getItem("t4_dbg") === "1"; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : C.off, flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
              </div>
              <div style={{ height: 14 }} />
              
              
            </div>
          </div>
        </div>
      )}
      <NotifyBox />
      {filesData && <DlgGuard onClose={() => setFilesData(null)}><FilesDialog app={filesData.app} files={filesData.files} dlPosts={filesData.dlPosts} mode={filesData.mode} onDownloads={filesData.onDownloads} onClose={() => setFilesData(null)} /></DlgGuard>}
      {sysScreen && <SubList title="Системные" loadSystem topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setSysScreen(false)} />}
      {hidScreen && <SubList title="Скрытые" initial={(apps || []).filter((a) => topics[a.packageName] && topics[a.packageName].flags && topics[a.packageName].flags.hidden)} topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setHidScreen(false)} />}
      {searchScreen != null && <SearchScreen initialQuery={searchScreen} searchType={localStorage.getItem("t4_search_all") === "1" ? "all" : searchType} instIcons={instIcons} onClose={() => { setSearchScreen(null); setSearchOpen(false); setSearchQuery(""); }} onOpenResult={(r) => { setSel({ label: r.title, packageName: "topic:" + r.topicId, topicId: r.topicId }); }} />}
      {dlScreen && <Downloads onClose={() => setDlScreen(false)} />}
      {updScreen && <SubList title="Доступные обновления" initial={updateApps} topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setUpdScreen(false)} />}

    </div>
  );
}
