import { useState, useEffect, useRef } from "react";
import { registerPlugin, Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";

const Apps = registerPlugin("Apps");

const C = {
  bg: "#161009", bar: "#20180f", card: "#241a11", border: "#342617",
  text: "#e9e6e2", sub: "#9a8f82", date: "#887d70", active: "#ffffff",
  nav: "#cbc3ba", acc: "#34C759", blue: "#1e88e5", green: "#43a047", divider: "#342617",
};
const TABS = ["ИЗБРАННОЕ", "ПРИЛОЖЕНИЯ", "ИГРЫ", "ЭМУЛЯТОРЫ", "НЕ СВЯЗАННЫЕ"];
const DEMO = [
  { packageName: "com.android.chrome", label: "Chrome", versionName: "126.0", lastUpdate: Date.now() },
  { packageName: "org.telegram.messenger", label: "Telegram", versionName: "11.1.0", lastUpdate: Date.now() - 864e5 },
];

const pad = (n) => String(n).padStart(2, "0");
const fmtDate = (ms) => { if (!ms) return ""; const d = new Date(ms); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; };
// сокращение длинных версий (2026.07.06.943847899.1-release → 2026.07.06), обычные не трогаем
const shortVer = (v) => {
  if (!v) return v;
  let s = String(v).replace(/[\s_-]*(release|stable|final|full|beta|rc)\b.*$/i, "").trim();
  const parts = s.split(".");
  if (s.length > 14 || parts.some((p) => p.replace(/\D/g, "").length >= 6)) return parts.slice(0, 3).join(".");
  return s;
};
const tileColor = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return `hsl(${h % 360} 42% 30%)`; };

// сравнение версий: 1 если a>b, -1 если a<b, 0 равны
function verCmp(a, b) {
  if (!a || !b) return 0;
  const pa = String(a).split(/[.\-_ ]/).map((x) => parseInt(x, 10));
  const pb = String(b).split(/[.\-_ ]/).map((x) => parseInt(x, 10));
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = isNaN(pa[i]) ? 0 : pa[i], y = isNaN(pb[i]) ? 0 : pb[i];
    if (x > y) return 1; if (x < y) return -1;
  }
  return 0;
}
const hideForum = (f) => !!(f && (f.hideAll || f.hideForum));
const hidePlay = (f) => !!(f && (f.hideAll || f.hidePlay));
const EMU_RE = /(emulator|emulador|эмулятор|retroarch|ppsspp|dolphin|epsxe|drastic|citra|yuzu|ryujinx|pcsx|redream|duckstation|mupen|melonds|dosbox|scummvm|winlator|exagear|\bmame\b|fpse|nostalgia|reicast|flycast|aethersx|eka2l1|vita3k|snes9|nesoid|gameboy|\bgba\b|vgba|gbanext|john\s?(nes|gba|snes)|matsu|myboy|my\s?boy|\bnds\b|\bn64\b|\bpsx\b|\bpsp\b|\bnes\b|\bsnes\b|\bgbc\b|\bsega\b|megadrive|genesis|dolphin|pizza\s?boy|lemuroid|classicboy|md\.emu|nds4droid|citrondb|skyline|xbsx2|damon|octopus|happychick|gamesir)/i;
const isEmu = (a) => !!a && (EMU_RE.test(a.packageName || "") || EMU_RE.test(a.label || ""));
const upd4 = (app, info) => !!(info && info.ver4pda && verCmp(info.ver4pda, app.versionName) > 0);
const updP = (app, info) => !!(info && info.verPlay && verCmp(info.verPlay, app.versionName) > 0);
// нужно ли обновление (новее установленной и не скрыто пользователем)
const needsUpdate = (app, info) => {
  if (!info || !app) return false;
  const f = info.flags || {};
  return (upd4(app, info) && !hideForum(f)) || (updP(app, info) && !hidePlay(f));
};

// архитектуры устройства (для выбора нужного apk)
let DEVICE_ABIS = [];
Apps.deviceAbis().then((r) => { DEVICE_ABIS = r.abis || []; }).catch(() => {});
const ABI_TOKENS = { "arm64-v8a": ["arm64", "arm8a", "aarch64", "v8a"], "armeabi-v7a": ["arm7a", "armeabi", "armv7", "v7a"], "x86_64": ["x86_64", "x86-64", "x64"], "x86": ["x86"] };
function fileForDevice(name) {
  const n = (name || "").toLowerCase();
  if (!/(arm64|arm7a|armeabi|armv7|x86|aarch64|v8a|v7a)/.test(n)) return true;
  for (const abi of DEVICE_ABIS) for (const t of (ABI_TOKENS[abi] || [])) if (n.includes(t)) return true;
  return false;
}

// ссылки 4pda / play
const q4 = (app) => encodeURIComponent(app.label || app.packageName);
const topicUrl = (app) => app.topicId ? `https://4pda.to/forum/index.php?showtopic=${app.topicId}` : `https://4pda.to/forum/index.php?act=search&query=${q4(app)}`;
const openTopicApp = (app) => Apps.openWeb({ url: topicUrl(app) }).catch(() => {});
const openPlay = (app) => Apps.openUrl({ url: `market://details?id=${app.packageName}` }).catch(() => Apps.openUrl({ url: `https://play.google.com/store/apps/details?id=${app.packageName}` }));

// --- парсинг темы 4pda ---
// извлечь apk-ссылки из любого DOM-узла (шапка или пост-анонс)
function apksFromScope(scope, postUrl) {
  const out = [], seen = new Set();
  if (!scope) return out;
  scope.querySelectorAll("a[href]").forEach((a) => {
    let url = a.getAttribute("href") || "";
    if (!url) return;
    const text = (a.textContent || "").replace(/\s+/g, " ").trim();
    const isDl = /\/dl\/post\/|\/dl\/|act=attach|attach_id=|getattach|code=attach/i.test(url);
    const apkInUrl = /\.(apk|apks|xapk|zip|obb)(\?|#|$)/i.test(url);
    const apkInText = /\.(apk|apks|xapk|zip|obb)\b/i.test(text);
    if (!isDl && !apkInUrl && !apkInText) return;
    if (url.indexOf("//") === 0) url = "https:" + url;
    if (url.indexOf("http") !== 0) url = "https://4pda.to" + (url[0] === "/" ? "" : "/") + url;
    let name = "";
    const um = url.match(/\/dl\/post\/\d+\/([^?#]+)/i) || url.match(/\/([^\/?#]+\.(?:apk|apks|xapk|zip|obb))(?:\?|#|$)/i);
    if (um) { try { name = decodeURIComponent(um[1]); } catch { name = um[1].replace(/%[0-9a-f]{0,2}/gi, ""); } }
    if (!/\.(apk|apks|xapk|zip|obb)$/i.test(name)) { const tm = text.match(/([^\s][^\n]*?\.(?:apk|apks|xapk|zip|obb))\b/i); if (tm) name = tm[1].trim(); }
    if (!/\.(apk|apks|xapk|zip|obb)$/i.test(name)) return;
    name = name.replace(/\+/g, " ").trim();
    const key = url.replace(/&amp;/g, "&");
    if (seen.has(key)) return; seen.add(key);
    let size = "";
    let sib = a.nextSibling, guard = 0;
    while (sib && guard < 5 && !size) { if (sib.nodeType === 3) { const tt = sib.textContent || ""; const s = tt.match(/\(([^)]*(?:МБ|MB|КБ|KB)[^)]*)\)/i) || tt.match(/\(([\d.,]+\s*[A-Za-zА-Яа-я]+)\)/); if (s) size = s[1].trim(); } sib = sib.nextSibling; guard++; }
    out.push({ name, url: key, size, downloads: "", postUrl: postUrl || "" });
  });
  return out;
}
// извлечь apk из конкретного поста-анонса (страница findpost)
function parseApkLinks(html, postUrl) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const pid = postUrl && ((postUrl.match(/pid=(\d+)/) || postUrl.match(/entry(\d+)/) || [])[1]);
  let out = [];
  if (pid) {
    const post = doc.querySelector("#entry" + pid) || doc.querySelector("#p" + pid) || doc.querySelector('[data-post="' + pid + '"]') || doc.querySelector('[id*="' + pid + '"]');
    const scope = post && (post.querySelector ? (post.querySelector(".post_body, .postcolor") || post) : null);
    if (scope) out = apksFromScope(scope, postUrl);
  }
  // запасной вариант: собрать apk со всех сообщений страницы (в т.ч. нужный анонс)
  if (!out.length) {
    doc.querySelectorAll(".post_body, .postcolor").forEach((b) => { out = out.concat(apksFromScope(b, postUrl)); });
    const seen = new Set(); out = out.filter((f) => { if (seen.has(f.url)) return false; seen.add(f.url); return true; });
  }
  return out;
}

function parseTopic(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const firstBody = doc.querySelector(".post_body") || doc.querySelector(".postcolor");
  let hatIcon = "";
  if (firstBody) { const im0 = firstBody.querySelector("img"); if (im0) { const s0 = im0.getAttribute("data-src") || im0.getAttribute("src") || ""; if (s0.indexOf("http") === 0) hatIcon = s0; } }
  let forumDate = "";
  try { const pd = doc.querySelector(".post_date"); if (pd) forumDate = (pd.textContent || "").replace(/\s+/g, " ").trim(); } catch {}
  // скриншоты (прикреплённые картинки) — отдельной лентой
  const screenshots = [];
  if (firstBody) {
    firstBody.querySelectorAll("img.linked-image, a.ipb-attach img, .post-block img").forEach((im) => {
      const src = im.getAttribute("data-src") || im.getAttribute("src") || "";
      const full = im.getAttribute("data-preview") || src;
      if (src && src.indexOf("http") === 0) screenshots.push({ thumb: src, full });
      im.remove();
    });
  }
  let descHtml = firstBody ? firstBody.innerHTML : "";
  descHtml = descHtml.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "");
  descHtml = descHtml.replace(/<span[^>]*class="[^"]*edit[^"]*"[\s\S]*?<\/span>/gi, "");
  descHtml = descHtml.replace(/Сообщение отредактировал[\s\S]*?(?:Причина редактирования:[^<]*)?(?=<div|<br|<span|<p|$)/gi, "");
  descHtml = descHtml.replace(/<div[^>]*class="[^"]*signature[^"]*"[\s\S]*?<\/div>/gi, "");
  const tmp = document.createElement("div"); tmp.innerHTML = descHtml;
  const descText = (tmp.textContent || "").replace(/\s+/g, " ").trim();
  let ver4pda = "";
  const vm = descText.match(/верси[яию]\s*:?\s*([0-9][0-9.]*)/i);
  if (vm) ver4pda = vm[1];

  const scope = firstBody || doc;
  const files = apksFromScope(scope, "");
  // ссылки на посты-анонсы версий (там лежат apk у тем вроде Instagram) + версия из текста рядом
  const dlPosts = []; const dseen = new Set();
  scope.querySelectorAll("a[href]").forEach((a) => {
    let href = a.getAttribute("href") || "";
    if (!/findpost|[?&]pid=\d|#entry\d|act=findpost/i.test(href)) return;
    if (href.indexOf("//") === 0) href = "https:" + href;
    if (href.indexOf("http") !== 0) href = "https://4pda.to" + (href[0] === "/" ? "" : "/") + href;
    const key = href.replace(/&amp;/g, "&");
    if (dseen.has(key)) return; dseen.add(key);
    let ver = "";
    let prev = a.previousSibling, guard = 0;
    while (prev && guard < 4 && !ver) { const t = (prev.textContent != null ? prev.textContent : (prev.nodeValue || "")); const m = t.match(/верси[яию]\s*:?\s*([0-9][0-9.]+)/i); if (m) ver = m[1]; prev = prev.previousSibling; guard++; }
    if (!ver && a.parentElement) { const m = (a.parentElement.textContent || "").match(/верси[яию]\s*:?\s*([0-9][0-9.]+)/i); if (m) ver = m[1]; }
    dlPosts.push({ url: key, ver });
  });
  if (!ver4pda && files[0]) { const fm = files[0].name.match(/([0-9]+(?:\.[0-9]+)+)/); if (fm) ver4pda = fm[1]; }
  // краткое описание как у ag4pda: блок «Краткое описание …» до следующего раздела; иначе пусто (без версии/дат)
  let short = "";
  const sm = descText.match(/краткое описание\s*:?\s*(.+?)(?:\s*(?:полное\s+описание|^описание\b|описание\s*:|системные требования|требовани|что нового|русский интерфейс|разработчик|версия\s*:|официальн|скриншот)|$)/i);
  if (sm) short = sm[1];
  else { const dm = descText.match(/описание\s*:?\s*(.{8,}?)(?:\s*(?:системные требовани|требовани|что нового|версия\s*:|скриншот)|$)/i); if (dm) short = dm[1]; }
  short = short.replace(/^[\s:–\-—]+/, "").replace(/\s+/g, " ").trim().slice(0, 140);
  // дата обновления шапки/темы (как post_update у ag4pda) — пробуем несколько формулировок, берём самую свежую
  let hatDate = "";
  try {
    const dnumLocal = (v) => { const m = (v || "").match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/); if (!m) return 0; let y = +m[3]; if (y < 100) y += 2000; return y * 10000 + (+m[2]) * 100 + (+m[1]); };
    const dates = [];
    const reList = [/шапк[еи]\s*:?\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/ig, /обновл[а-я]*\s*:?\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/ig, /обновление\s+шапки\s*:?\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/ig, /(\d{1,2}\.\d{1,2}\.\d{2,4})\s*(?:г\.?)?\s*(?:—|-)?\s*обновл/ig];
    for (const re of reList) { let m; while ((m = re.exec(descText)) !== null) { const v = m[1]; const d = dnumLocal(v); if (d) dates.push([d, v]); } }
    if (dates.length) { dates.sort((a, b) => b[0] - a[0]); hatDate = dates[0][1]; }
  } catch {}
  let title = "";
  try { const t = doc.querySelector("title"); if (t) title = (t.textContent || "").replace(/\s*[-–|]\s*4PDA.*$/i, "").replace(/&amp;/g, "&").trim(); } catch {}
  // основное описание (как у ag4pda): блок «Описание …» до следующего раздела; чистим от версии/требований/чейнджлога
  const SECT = "(?:что нового|нововведени|системные требовани|требовани|особенности|поддерживаем|скриншот|снимк|разработчик|версия\\s*:|последнее обновление|перевод|автор перевода|сборк|скачать|download)";
  let descMain = "";
  const dmm = descText.match(new RegExp("(?:краткое описание[\\s\\S]*?)?(?:^|[\\s.:])описание\\s*:?\\s*([\\s\\S]+?)(?=" + SECT + "|$)", "i"));
  if (dmm && dmm[1].trim().length > 20) descMain = dmm[1].trim();
  else { descMain = descText.split(new RegExp(SECT, "i"))[0].replace(/^краткое описание\s*:?/i, "").trim(); }
  descMain = descMain.replace(/^[\s:–\-—]+/, "").slice(0, 2500);
  return { descHtml, descMain, descText, short, ver4pda, hatDate, forumDate, title, hatIcon, files, dlPosts, screenshots };
}
// windows-1251 URL-кодирование (форумный поиск 4pda требует cp1251)
function cp1251(str) {
  let out = "";
  for (const ch of str) {
    const c = ch.charCodeAt(0);
    let byte = -1;
    if (c < 128) { out += encodeURIComponent(ch); continue; }
    else if (c >= 0x0410 && c <= 0x044F) byte = c - 0x0410 + 0xC0;
    else if (c === 0x0401) byte = 0xA8;
    else if (c === 0x0451) byte = 0xB8;
    if (byte < 0) { out += encodeURIComponent(ch); continue; }
    out += "%" + byte.toString(16).toUpperCase().padStart(2, "0");
  }
  return out;
}
// правильный URL форумного поиска 4pda (noform=1 => сразу результаты, а не форма)
const searchUrl4pda = (query, source = "all", forums = [212], subforums = true, st = 0) =>
  `https://4pda.to/forum/index.php?act=search&result=topics&sort=dd&source=${source}&query=${cp1251(query)}${(forums || []).map((f) => `&forums=${f}`).join("")}${subforums ? "&subforums=1" : ""}&noform=1&st=${st}&exclude_trash=0`;

// разбор страницы результатов поиска: [{topicId, title}] за один запрос
function parseSearchResults(html) {
  if (!html) return [];
  if (/не дал никаких результатов|Вы искали:/i.test(html)) return [];
  const doc = new DOMParser().parseFromString(html, "text/html");
  const out = [], seen = new Set();
  const nonAndroid = /\[(ios|iphone|ipad|ipados|desktop|windows|win(?:32|64)?|wp7|wp8|wp10|wp7-10|wp|mac(?:os)?|symbian|linux|web(?:os)?|java|bada|blackberry|bb10?|tizen|kaios)\]/i;
  // 1) старый десктопный формат с data-topic
  doc.querySelectorAll("[data-topic]").forEach((div) => {
    const topicId = div.getAttribute("data-topic");
    if (!topicId || !/^\d{3,}$/.test(topicId) || seen.has(topicId)) return;
    const a = div.querySelector('a[href*="showtopic="]') || div.querySelector("a");
    const title = ((a && a.textContent) || "").replace(/\s+/g, " ").trim();
    if (title.length < 2 || nonAndroid.test(title)) return;
    const dsc = div.querySelector(".topic_desc");
    const forumId = dsc ? ((dsc.innerHTML.match(/showforum=(\d+)/) || [])[1] || "") : "";
    let short = "";
    if (dsc) { const t = (dsc.textContent || "").replace(/\s+/g, " "); const fm = t.split(/форум\s*:/i)[0].trim(); if (fm && fm.length > 2) short = fm.slice(0, 140); }
    seen.add(topicId);
    out.push({ topicId, title, forumId, short });
  });
  if (out.length) return out;
  // 2) текущий десктопный формат: берём ВСЕ ссылки тем на странице (узкий блок «Результаты поиска» терял часть строк); лишнее отсечёт фильтр релевантности и форума
  const marker = /^(новые|новый|последн|перейти|ответить|цитата|»+|«+|→|\d+|\.+)$/i;
  let scope = null;
  const heads = doc.querySelectorAll(".maintitle, .cat_name, .category");
  for (const h of heads) { if (/Результаты поиска/i.test(h.textContent || "")) { scope = h.closest(".borderwrap") || (h.parentElement ? h.parentElement : null); break; } }
  const root = doc;
  root.querySelectorAll('a[href*="showtopic="], a[href*="/forum/topic/"]').forEach((a) => {
    const href = a.getAttribute("href") || "";
    if (/view=getnewpost|view=getlastpost|view=findpost|&pid=|#entry|act=|&p=\d/i.test(href)) return;
    const m = href.match(/(?:showtopic=|\/forum\/topic\/)(\d{3,})/);
    if (!m || seen.has(m[1])) return;
    const title = (a.textContent || "").replace(/\s+/g, " ").trim();
    if (title.length < 3 || marker.test(title) || nonAndroid.test(title)) return;
    // короткое описание + форум результата (для отсева не-Android без загрузки темы)
    let short = "", forumTxt = "";
    const row = a.closest("tr, .topic, li, div");
    if (row) {
      const rt = (row.textContent || "").replace(/\s+/g, " ").replace(title, "").trim();
      const fa = row.querySelector('a[href*="showforum="]');
      const fname = fa && fa.textContent ? fa.textContent.trim() : "";
      let rtShort = rt;
      // отрезаем всё, начиная с названия форума и/или даты-статистики (чтобы не липло "Архив программАвтор...")
      if (fname && fname.length > 2 && rtShort.indexOf(fname) > 3) rtShort = rtShort.slice(0, rtShort.indexOf(fname));
      rtShort = rtShort.split(/\d{2}\.\d{2}\.\d{2,4}/)[0].replace(/\s+/g, " ").trim();
      if (rtShort.length > 4) short = rtShort.slice(0, 140);
      forumTxt = (fname || rt).toLowerCase();
    }
    // если форум явно не Android — пропускаем
    if (/iphone|ipad|ipod|ios|apple|mac\s?os|windows|symbian|bada|blackberry|tizen|java\b|wp\d/.test(forumTxt) && !/android/.test(forumTxt)) return;
    seen.add(m[1]);
    out.push({ topicId: m[1], title, short });
  });
  return out;
}

const playPkg = (html) => {
  if (!html) return null;
  const PKG = "([a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+){1,})";
  // 1) пакет прямо в шапке текстом: «Имя пакета: com.x.y» / «packageName: com.x.y»
  let m = html.match(new RegExp("Имя\\s*пакета[\\s\\S]{0,30}?" + PKG, "i"))
       || html.match(new RegExp("package\\s*name[\\s\\S]{0,30}?" + PKG, "i"))
       || html.match(new RegExp("packageName['\":\\s]{0,8}" + PKG, "i"));
  if (m) return m[1];
  // 2) ссылка Google Play / market
  m = html.match(/play\.google\.com\/store\/apps\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  if (m) return m[1];
  m = html.match(/market:\/\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  return m ? m[1] : null;
};
function topicIds(html) {
  const ids = [], seen = new Set();
  // showtopic=<id> (в т.ч. относительные ссылки) И новый формат /forum/topic/<id>
  const re = /(?:showtopic=|\/forum\/topic\/)(\d{3,})/gi;
  let m; while ((m = re.exec(html)) !== null) if (!seen.has(m[1])) { seen.add(m[1]); ids.push(m[1]); }
  return ids;
}

// поиск темы: собираем кандидатов из поиска 4pda (пакет+название) и Google (site:4pda.to),
// берём ТОЛЬКО тему, где в шапке ссылка Play с этим пакетом. "captcha" | {topicId,html} | null
const isAppPage = (html) => !!(playPkg(html) || /dw_button|onclick="dw\(|nav_download|attach_id=|Загрузить с сервера|"attachment"|post-attach/i.test(html));
// тема именно про Android (а не iOS/Windows/Symbian)
const isAndroidTopic = (html) => {
  if (!html) return true;
  const android = /Требуется\s*Android|Android\s*[\d.]+\s*(?:и выше|\+)|play\.google\.com|market:\/\/|\.apk\b|\.apks\b|\.xapk\b|Имя\s*пакета/i.test(html);
  const otherOs = /Требуется\s*iOS|Требуется\s*iPhone|Совместимо с iOS|App Store|itunes\.apple|Windows\s*Phone|Требуется\s*Windows|\.ipa\b|Cydia|jailbreak|Symbian/i.test(html);
  if (android) return true;
  if (otherOs) return false;
  return true;
};

const realTopic = (b) => !!b && (b.indexOf("post_body") >= 0 || b.indexOf("postcolor") >= 0);

// Индекс приложений из каталогов-дайджестов 4pda (127361 программы / 381335 игры).
// 4pda-поиск ищет пословно и не находит подстроки (Habitica по habit) — а по индексу ищем подстрокой, как ag4pda.
const DIGEST_TOPICS = { apps: 127361, games: 381335 };
async function buildAppIndex(kind, pages, onProgress) {
  const topicId = DIGEST_TOPICS[kind];
  const seen = {};
  for (let p = 0; p < pages; p++) {
    const st = p * 20;
    const url = `https://4pda.to/forum/index.php?showtopic=${topicId}&st=${st}`;
    let body = "";
    try {
      const hr = await Apps.httpGet({ url });
      body = hr.body || "";
      if (!body || body.length < 500 || /Just a moment|challenge-platform|cf-browser/i.test(body)) { const sr = await Apps.webGet({ url }); body = sr.body || ""; }
    } catch {}
    if (!body) continue;
    let m, found = 0;
    const re = /showtopic=(\d+)[^>]*>\s*([^<]{2,90}?)\s*<\/a>/g;
    while ((m = re.exec(body)) !== null) {
      const tid = m[1]; let name = m[2].replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/\s+/g, " ").trim();
      name = name.replace(/\s*\[[^\]]*\]\s*$/, "").trim(); // убрать [версию] в конце
      if (name.length < 2 || /^\d+$/.test(name) || /сообщени|показать|скрыт|цитата|profile|member|каталог|дайджест|поиск|правила|набор|подписаться/i.test(name)) continue;
      if (!seen[tid]) { seen[tid] = name; found++; }
    }
    if (onProgress) onProgress(p + 1, Object.keys(seen).length);
    if (found === 0 && p > 3) break;
    await new Promise((r) => setTimeout(r, 120));
  }
  const arr = Object.keys(seen).map((t) => ({ t, n: seen[t] }));
  try { localStorage.setItem("t4_idx_" + kind, JSON.stringify(arr)); localStorage.setItem("t4_idx_" + kind + "_ts", String(Date.now())); } catch {}
  return arr.length;
}
function catalogMatches(kind, query) {
  try {
    const arr = JSON.parse(localStorage.getItem("t4_idx_" + kind) || "[]");
    const ql = query.toLowerCase().trim();
    const qw = ql.split(/\s+/).filter((w) => w.length > 1);
    return arr.filter((e) => { const n = (e.n || "").toLowerCase(); return n.indexOf(ql) >= 0 || qw.some((w) => n.indexOf(w) >= 0); }).map((e) => ({ topicId: String(e.t), title: e.n, short: "" }));
  } catch { return []; }
}
async function fetchUrl4pda(url) {
  let tr = await Apps.httpGet({ url });
  if (tr.captcha || !realTopic(tr.body)) { try { tr = await Apps.webGet({ url }); } catch {} }
  return tr && tr.body ? tr.body : "";
}
// открыть пост в нативном WebView-попапе (как dlg_post_view у ag4pda), но чистым: только тело поста, тёмная тема
async function openPostClean(url, topicId) {
  try {
    const html = await fetchUrl4pda(url);
    const doc = new DOMParser().parseFromString(html, "text/html");
    const pid = (url.match(/pid=(\d+)/) || url.match(/entry(\d+)/) || [])[1];
    let bodyEl = null;
    if (pid) {
      const anchor = doc.querySelector('a[name="entry' + pid + '"]') || doc.querySelector("#entry" + pid) || doc.querySelector('[id="p' + pid + '"]') || doc.querySelector('[data-post="' + pid + '"]') || doc.querySelector('[id*="' + pid + '"]');
      if (anchor) { let el = anchor; for (let i = 0; i < 10 && el && !bodyEl; i++) { if (el.querySelector) bodyEl = el.querySelector(".post_body, .postcolor"); if (!bodyEl) el = el.parentElement; } if (!bodyEl) { let n = anchor.nextElementSibling, g = 0; while (n && g < 12 && !bodyEl) { if (n.querySelector) bodyEl = n.querySelector(".post_body, .postcolor"); n = n.nextElementSibling; g++; } } }
    }
    if (!bodyEl) bodyEl = doc.querySelector(".post_body, .postcolor");
    let inner = bodyEl ? bodyEl.innerHTML : "";
    inner = inner.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/Сообщение отредактировал[\s\S]*$/i, "");
    if (!inner.trim()) { Apps.openPostView({ url }).catch(() => Apps.openUrl({ url }).catch(() => {})); return; }
    const clean = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><style>body{margin:0;padding:14px;background:#1e1e1e;color:#d2d2d2;font:15px/1.55 -apple-system,Roboto,Arial,sans-serif;word-wrap:break-word;overflow-wrap:break-word}a{color:#5ab0d8;text-decoration:none}img{max-width:100%;height:auto;border-radius:6px}b,strong{color:#ededed}.post-block,.spoiler{border:1px solid #333;border-radius:8px;margin:8px 0;padding:8px 10px;background:#242424}.block-title,.spoiler-title,.title{font-weight:700;color:#e0e0e0}hr{border:none;border-top:1px solid #333}</style></head><body>" + inner + "</body></html>";
    await Apps.openPostView({ html: clean });
  } catch { Apps.openPostView({ url }).catch(() => Apps.openUrl({ url }).catch(() => {})); }
}
async function fetchTopicHtml(id) {
  let tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${id}` });
  if (tr.captcha || !realTopic(tr.body)) { try { tr = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${id}` }); } catch {} }
  return tr && tr.body ? tr.body : "";
}
async function check4pdaLogin() {
  let html = "";
  try {
    const r = await Apps.httpGet({ url: "https://4pda.to/forum/index.php" });
    html = r.body || "";
    if (r.captcha || !/logout/i.test(html) || html.length < 2000) { try { const w = await Apps.webGet({ url: "https://4pda.to/forum/index.php" }); if ((w.body || "").length > html.length) html = w.body; } catch {} }
  } catch {}
  const kk = html.match(/(?:act|action)=logout[^"'<>]*?k=([a-f0-9]{32})/i) || html.match(/logout[^"'<>]{0,40}?[?&]k=([a-f0-9]{32})/i);
  if (!kk) return { loggedIn: false };
  const uid = (html.match(/showuser=(\d+)/) || [])[1] || "";
  let name = "", avatar = "";
  if (uid) {
    try {
      const pr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` });
      let pb = pr.body || "";
      if (pr.captcha || pb.length < 1500) { try { const w = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` }); if ((w.body || "").length > pb.length) pb = w.body; } catch {} }
      name = (pb.match(/<title>\s*([^<]+?)\s*(?:[-–—]\s*Просмотр профиля|<\/title>)/i) || [])[1] || "";
      name = name.replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
      avatar = (pb.match(/<img[^>]+src="([^"]+)"[^>]*class="[^"]*avatar/i)
        || pb.match(/class="[^"]*avatar[^"]*"[^>]*>\s*<img[^>]+src="([^"]+)"/i)
        || pb.match(/src="(https?:\/\/[^"']*\/(?:uploads|avatar)[^"']+\.(?:jpg|jpeg|png|gif|webp))"/i)
        || [])[1] || "";
    } catch {}
  }
  if (!avatar) avatar = (html.match(/<img[^>]+class="[^"]*avatar[^"]*"[^>]+src="([^"]+)"/i) || [])[1] || "";
  if (avatar && avatar.indexOf("//") === 0) avatar = "https:" + avatar;
  return { loggedIn: true, userId: uid, name: name || ("Профиль" + (uid ? " id" + uid : "")), avatar, logoutK: kk[1] };
}
async function logout4pda(k) {
  try { await Apps.webGet({ url: `https://4pda.to/forum/index.php?act=logout&CODE=03&k=${k}` }); } catch {}
  try { await Apps.httpGet({ url: `https://4pda.to/forum/index.php?act=logout&CODE=03&k=${k}` }); } catch {}
}
function titleScore(title, label) {
  const t = (title || "").toLowerCase().trim(), l = (label || "").toLowerCase().trim();
  if (!t || !l) return 0;
  if (/(клуб|club|чат|\bчата\b|обсужд|fanclub|фан-?клуб|курилк|флудил|вопрос|faq по)/i.test(t)) return 5; // не тема приложения
  if (t === l) return 100;
  if (t === l + " [android]" || t === l + " [андроид]") return 98;
  if (/\[android\]|\[андроид\]/i.test(t) && t.replace(/\s*\[[^\]]*\]\s*/g, "") === l) return 95;
  if (t.replace(/\s*\[[^\]]*\]\s*/g, "").trim() === l) return 90; // «Имя [что-то]» == имя
  if (t.indexOf(l + " ") === 0 || t.indexOf(l + " [") === 0) return 60;
  if (t.indexOf(l) >= 0) return 40;
  return 8;
}
async function resolveTopic(app, maxCand = 8, useGoogle = true) {
  // 1) внешний каталог пакет→тема (как у freeman42, но база твоя) — мгновенно и точно
  if (CATALOG[app.packageName]) {
    const id = CATALOG[app.packageName];
    try { const html = await fetchTopicHtml(id); if (html) return { topicId: id, matched: true, html }; } catch {}
    return { topicId: id, matched: true, html: "" };
  }
  const cands = [];
  const add = (arr) => { for (const r of arr) if (!cands.find((c) => c.topicId === r.topicId)) cands.push(r); };
  const nameQ = app.label && app.label !== app.packageName ? app.label : app.packageName;
  // поиск по названию: сначала в разделах Программы/Игры, затем (если пусто) без ограничения
  try { const sr = await Apps.webGet({ url: searchUrl4pda(nameQ, "top", 0, true) }); if (sr.captcha) return "captcha"; add(parseSearchResults(sr.body || "")); } catch {}
  if (!cands.length) { try { const sr = await Apps.webGet({ url: searchUrl4pda(nameQ, "top", 0, false) }); add(parseSearchResults(sr.body || "")); } catch {} }
  if (!cands.length) { try { const sr2 = await Apps.webGet({ url: searchUrl4pda(app.packageName, "all", 0, false) }); add(parseSearchResults(sr2.body || "")); } catch {} }
  if (!cands.length) return null;
  cands.sort((a, b) => titleScore(b.title, nameQ) - titleScore(a.title, nameQ));
  let best = null;
  for (let i = 0; i < Math.min(cands.length, maxCand); i++) {
    try {
      const html = await fetchTopicHtml(cands[i].topicId);
      if (!html) continue;
      if (playPkg(html) === app.packageName) return { topicId: cands[i].topicId, matched: true, html };
      // запасной вариант — только для тем с сильным совпадением названия (не «Club»/обсуждение)
      if (!best && titleScore(cands[i].title, nameQ) >= 90 && isAppPage(html)) best = { topicId: cands[i].topicId, matched: false, html };
    } catch {}
  }
  return best;
}
async function fetchPlayVersion(pkg) {
  // 1) через gplayapi (анонимно, без входа) — точная версия + код
  try { const r = await Apps.playVersion({ packageName: pkg }); if (r && r.versionName) return { name: r.versionName, code: r.versionCode || "" }; } catch {}
  // 2) откат: парсинг HTML Play (ненадёжно)
  for (const hl of ["ru", "en"]) {
    try {
      const r = await Apps.httpGet({ url: `https://play.google.com/store/apps/details?id=${pkg}&hl=${hl}&gl=US` });
      const b = r.body || "";
      let m = b.match(/\[\[\["([0-9][0-9A-Za-z.\-_]*)"\]\],\s*\[/);
      if (m) return { name: m[1], code: "" };
      m = b.match(/"softwareVersion"\s*:\s*"([^"]+)"/i); if (m) return { name: m[1].trim(), code: "" };
      m = b.match(/Current Version[\s\S]{0,120}?([0-9]+\.[0-9][0-9A-Za-z.\-_]*)/i); if (m) return { name: m[1], code: "" };
    } catch {}
  }
  return null;
}

// --- кэш пакет→тема (localStorage) ---
const CKEY = "t4_cache_v1";
// Внешний каталог связей: JSON вида { "com.instagram.android": 236581, ... }.
// URL задаётся в настройках (гамбургер) и хранится локально — базу хостишь где хочешь (raw github и т.п.).
let CATALOG = {};
const catalogUrl = () => { try { return localStorage.getItem("t4_catalog_url") || ""; } catch { return ""; } };
// кэш файлов из постов-анонсов по теме (для предзагрузки в фоне)
const postFilesCache = {};
async function fetchDlPostFiles(topicId, dlPosts, installedVer, mode, onAdd) {
  const key = topicId + ":" + (mode || "all");
  if (!postFilesCache[key]) postFilesCache[key] = { files: [], done: false, running: false };
  const c = postFilesCache[key];
  if (c.done || c.running) { if (onAdd && c.files.length) onAdd(c.files.slice()); return c; }
  c.running = true;
  const posts = (dlPosts || []).filter((p) => mode !== "updates" || (p.ver && installedVer && verCmp(p.ver, installedVer) > 0)).slice(0, mode === "updates" ? 4 : 8);
  for (const p of posts) {
    try {
      const html = await fetchUrl4pda(p.url);
      const apks = parseApkLinks(html, p.url);
      if (apks.length) { const seen = new Set(c.files.map((x) => x.url)); const add = apks.filter((x) => !seen.has(x.url)); c.files.push(...add); if (onAdd && add.length) onAdd(c.files.slice()); }
    } catch {}
  }
  c.running = false; c.done = true;
  return c;
}
async function loadCatalog() {
  const url = catalogUrl(); if (!url) return 0;
  try {
    const r = await Apps.httpGet({ url });
    const j = JSON.parse(r.body || "{}");
    const map = {};
    // поддержка { pkg: id } и { pkg: {topicId} } и [{package, topicId}]
    if (Array.isArray(j)) { for (const it of j) { const p = it.package || it.pkg || it.packageName; const id = it.topicId || it.topic_id || it.id; if (p && id) map[p] = String(id).replace(/\D/g, ""); } }
    else for (const p in j) { const v = j[p]; const id = (typeof v === "object") ? (v.topicId || v.topic_id || v.id) : v; if (id) map[p] = String(id).replace(/\D/g, ""); }
    CATALOG = map; return Object.keys(map).length;
  } catch { return 0; }
}
function readCache() { try { return JSON.parse(localStorage.getItem(CKEY) || "{}"); } catch { return {}; } }

function Icon({ app, size = 56 }) {
  const box = { width: size, height: size, borderRadius: size * 0.25, flexShrink: 0, overflow: "hidden" };
  const src = app.iconFile ? Capacitor.convertFileSrc(app.iconFile) : (app.icon || null);
  if (src) return <img src={src} alt="" style={{ ...box, objectFit: "cover" }} loading="lazy" />;
  const letter = (app.label || app.packageName || "?").trim().charAt(0).toUpperCase();
  return <div style={{ ...box, background: tileColor(app.packageName || app.label || "?"), display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#eaeaea", fontWeight: 800, fontSize: size * 0.43 }}>{letter}</span></div>;
}

const Mini = ({ kind }) => {
  if (kind === "inst") return <svg width="15" height="15" viewBox="0 0 24 24"><path d="M7 6 L5.8 4.4" stroke={C.green} strokeWidth="1.3" strokeLinecap="round" fill="none" /><path d="M17 6 L18.2 4.4" stroke={C.green} strokeWidth="1.3" strokeLinecap="round" fill="none" /><path d="M6 9a6 6 0 0 1 12 0z" fill={C.green} /><rect x="6.2" y="9.2" width="11.6" height="7.2" rx="1.4" fill={C.green} /><rect x="3" y="9.6" width="2.2" height="5.8" rx="1.1" fill={C.green} /><rect x="18.8" y="9.6" width="2.2" height="5.8" rx="1.1" fill={C.green} /><circle cx="9.6" cy="6.4" r="0.8" fill="#0d0d0d" /><circle cx="14.4" cy="6.4" r="0.8" fill="#0d0d0d" /></svg>;
  if (kind === "4pda") return <span style={{ width: 14, height: 14, borderRadius: 3, background: C.blue, color: "#fff", fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>4</span>;
  return <svg width="13" height="13" viewBox="0 0 24 24"><path d="M3.9 1.5c-.3.2-.5.5-.5 1v19c0 .5.2.8.5 1l10.5-10.5z" fill="#00C3FF" /><path d="M18 8.4 14.4 12l3.6 3.6 4-2.3c1.1-.6 1.1-1.7 0-2.3z" fill="#FFCE00" /><path d="m17.9 15.7-3.5-3.7L3.9 22.5c.4.4 1 .4 1.7.1z" fill="#FF3A44" /><path d="M3.9 1.5 14.4 12 18 8.4 5.6 1.4c-.7-.4-1.3-.3-1.7.1z" fill="#00D97D" /></svg>;
};

function VerBar({ app, info }) {
  const inst = app.versionName;
  const f = (info && info.flags) || {};
  const v4 = info && info.ver4pda, vp = info && info.verPlay;
  // как у ag4pda: установленная — обычная; версия столбца КРАСНАЯ если активное обновление
  // (новее И не скрыто), иначе ЗАЧЁРКНУТА серым (не новее ИЛИ скрыто)
  const cell = (kind, val, i, hidden) => {
    let color = "#cfcfcf", strike = false;
    if (kind === "inst") { color = "#cfcfcf"; }
    else if (!val) { color = "#6a6a6a"; }
    else {
      const newer = verCmp(val, inst) > 0;
      if (newer && hidden) { color = "#7a7a7a"; strike = true; }   // скрытое обновление — зачёркнуто
      else if (newer) { color = "#e5675e"; }                        // активное обновление — красным
      else { color = "#8a8a8a"; }                                   // не новее — просто серым, без зачёркивания
    }
    return (
      <div key={i} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "6px 4px", borderRight: i < 2 ? `1px solid ${C.divider}` : "none" }}>
        <Mini kind={kind} /><span style={{ fontSize: 12.5, color, textDecoration: strike ? "line-through" : "none", whiteSpace: "nowrap" }}>{val ? shortVer(val) : "—"}</span>
      </div>
    );
  };
  return <div style={{ display: "flex", borderTop: `1px solid #2c2c2c` }}>{cell("inst", inst, 0, false)}{cell("4pda", v4, 1, hideForum(f))}{cell("play", vp, 2, hidePlay(f))}</div>;
}

function AppCard({ app, info, onOpen, onMenu, onLong, selMode, selected, onToggleSel }) {
  const sub = (info && info.desc) ? info.desc : app.packageName;
  const nu = needsUpdate(app, info);
  const lp = useRef(false), tm = useRef(null);
  const down = () => { lp.current = false; if (!onLong) return; tm.current = setTimeout(() => { lp.current = true; onLong(app); }, 450); };
  const up = () => { if (tm.current) clearTimeout(tm.current); };
  const click = () => { if (lp.current) { lp.current = false; return; } selMode ? onToggleSel(app) : onOpen(app); };
  return (
    <div style={{ background: selected ? "#26301f" : C.card, border: `1px solid ${selected ? C.acc : C.border}`, borderLeft: nu ? "3px solid #e5675e" : `1px solid ${selected ? C.acc : C.border}`, borderRadius: 10, marginBottom: 7, WebkitTapHighlightColor: "transparent", contentVisibility: "auto", containIntrinsicSize: "0 74px" }}>
      <div style={{ display: "flex", padding: "9px 10px", gap: 10, alignItems: "center", cursor: "pointer" }} onClick={click} onTouchStart={down} onTouchEnd={up} onTouchMove={up} onContextMenu={(e) => e.preventDefault()}>
        <Icon app={app} size={44} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: C.text, fontSize: 16, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
          <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{sub}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", flexShrink: 0, alignSelf: "stretch", justifyContent: "space-between", paddingTop: 2 }}>
          <span style={{ color: C.date, fontSize: 12 }}>{fmtDate(app.lastUpdate)}</span>
          {!selMode && <div onClick={(e) => { e.stopPropagation(); onMenu(app, e); }} style={{ width: 30, height: 26, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3, WebkitTapHighlightColor: "transparent" }}>
            {[0, 1, 2].map((i) => <span key={i} style={{ width: 3.5, height: 3.5, borderRadius: 4, background: "#9a9a9a" }} />)}
          </div>}
        </div>
      </div>
      <div style={{ padding: "0 10px 8px" }}><VerBar app={app} info={info} /></div>
    </div>
  );
}

function NavBtn({ title, onClick, children }) {
  const [p, setP] = useState(false);
  return <div title={title} onClick={onClick} onPointerDown={() => setP(true)} onPointerUp={() => setP(false)} onPointerLeave={() => setP(false)} style={{ padding: "10px 9px", cursor: "pointer", opacity: p ? 0.5 : 1, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</div>;
}
const sw = (color) => ({ fill: "none", stroke: color, strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" });
const IBot = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="11" width="18" height="10" rx="2.5" /><path d="M12 7v4" /><circle cx="12" cy="5" r="2" /><circle cx="8.5" cy="16" r="1.1" fill={color} stroke="none" /><circle cx="15.5" cy="16" r="1.1" fill={color} stroke="none" /></svg>);
const IEyeOff = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19" /><path d="M6.61 6.61A18.6 18.6 0 0 0 2 12s3 8 10 8a9.1 9.1 0 0 0 5.39-1.61" /><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" /><path d="M2 2l20 20" /></svg>);
const IEye = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M2 12s3-8 10-8 10 8 10 8-3 8-10 8-10-8-10-8Z" /><circle cx="12" cy="12" r="3" /></svg>);
const ICatalog = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>);
const IDownload = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M7 10l5 5 5-5" /><path d="M12 15V3" /></svg>);
const ISearch = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>);
const IRefresh = ({ color = C.nav }) => (<svg width="23" height="23" viewBox="0 0 24 24" {...sw(color)}><path d="M21 12a9 9 0 1 1-2.64-6.36" /><path d="M21 3v6h-6" /></svg>);
const I4 = () => (<div style={{ width: 26, height: 26, borderRadius: 6, background: C.blue, color: "#fff", fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>4</div>);
const IPlayStore = () => (<svg width="22" height="22" viewBox="0 0 24 24"><path d="M3.9 1.5c-.3.2-.5.5-.5 1v19c0 .5.2.8.5 1l10.5-10.5z" fill="#00C3FF" /><path d="M18 8.4 14.4 12l3.6 3.6 4-2.3c1.1-.6 1.1-1.7 0-2.3z" fill="#FFCE00" /><path d="m17.9 15.7-3.5-3.7L3.9 22.5c.4.4 1 .4 1.7.1z" fill="#FF3A44" /><path d="M3.9 1.5 14.4 12 18 8.4 5.6 1.4c-.7-.4-1.3-.3-1.7.1z" fill="#00D97D" /></svg>);
const IStar = ({ filled }) => (<svg width="22" height="22" viewBox="0 0 24 24" fill={filled ? "#4d9fff" : "none"} stroke={filled ? "#4d9fff" : C.nav} strokeWidth="2" strokeLinejoin="round"><polygon points="12 2 15.1 8.3 22 9.3 17 14.1 18.2 21 12 17.8 5.8 21 7 14.1 2 9.3 8.9 8.3 12 2" /></svg>);
const IExternal = () => (<svg width="22" height="22" viewBox="0 0 24 24" {...sw(C.nav)}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><path d="M15 3h6v6" /><path d="M10 14L21 3" /></svg>);
const ITrash = () => (<svg width="22" height="22" viewBox="0 0 24 24" {...sw("#e5675e")}><path d="M3 6h18" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>);
const IOpenApp = () => (<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke={C.nav} strokeWidth="2" /><path d="M10 8.4l6 3.6-6 3.6z" fill={C.nav} /></svg>);
const IGear = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09A1.65 1.65 0 0 0 10 4.6V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>);
const IAndroid = ({ color = C.nav }) => (
  <svg width="24" height="24" viewBox="0 0 24 24">
    <path d="M7 6 L5.6 4.2" stroke={color} strokeWidth="1.6" strokeLinecap="round" fill="none" />
    <path d="M17 6 L18.4 4.2" stroke={color} strokeWidth="1.6" strokeLinecap="round" fill="none" />
    <path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill={color} />
    <rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill={color} />
    <rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill={color} />
    <rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill={color} />
    <circle cx="9.6" cy="8.8" r="0.85" fill="#0d0d0d" />
    <circle cx="14.4" cy="8.8" r="0.85" fill="#0d0d0d" />
  </svg>
);

function VerChip({ label, value, accent }) {
  return <div style={{ flex: 1, background: "#141414", border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
    <div style={{ color: C.sub, fontSize: 11, letterSpacing: 0.3 }}>{label}</div>
    <div style={{ color: accent || C.text, fontSize: 14, fontWeight: 600, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{value}</div>
  </div>;
}

function ContextMenu({ app, x, y, info, onClose, onInfo, onFlag, onLink }) {
  const flags = (info && info.flags) || {};
  const vw = window.innerWidth, vh = window.innerHeight, W = 290;
  const left = Math.max(8, Math.min((x || vw / 2) - W / 2, vw - W - 8));
  const top = Math.max(8, Math.min((y || 80), vh - 400));
  const iconBtn = (child, fn) => <div onClick={() => { fn(); }} style={{ flex: 1, display: "flex", justifyContent: "center", padding: "13px 0", cursor: "pointer" }}>{child}</div>;
  const check = (label, key) => (
    <div onClick={() => { onFlag(app, key, !flags[key]); onClose(); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", cursor: "pointer", gap: 10 }}>
      <span style={{ color: C.text, fontSize: 14.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      <div style={{ width: 20, height: 20, flexShrink: 0, borderRadius: 4, border: `2px solid ${flags[key] ? C.acc : "#666"}`, background: flags[key] ? C.acc : "transparent", display: "flex", alignItems: "center", justifyContent: "center", color: "#04210f", fontWeight: 800, fontSize: 13 }}>{flags[key] ? "✓" : ""}</div>
    </div>
  );
  const item = (label, fn) => <div onClick={() => { fn(); onClose(); }} style={{ padding: "12px 16px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>{label}</div>;
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 60 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left, top, width: W, background: "#242424", borderRadius: 12, overflow: "hidden", boxShadow: "0 10px 34px rgba(0,0,0,.55)", maxHeight: 400, overflowY: "auto" }}>
        <div style={{ display: "flex", borderBottom: `1px solid ${C.border}` }}>
          {iconBtn(<I4 />, () => { openTopicApp(app); onClose(); })}
          {iconBtn(<IPlayStore />, () => { openPlay(app); onClose(); })}
          {iconBtn(<IStar filled={flags.fav} />, () => { onFlag(app, "fav", !flags.fav); onClose(); })}
          {iconBtn(<ITrash />, () => { Apps.uninstallApp({ packageName: app.packageName }).catch(() => {}); onClose(); })}
        </div>
        {item(flags.fav ? "Убрать из избранного" : "Добавить в избранное", () => onFlag(app, "fav", !flags.fav))}
        {item("Открыть приложение", () => Apps.launchApp({ packageName: app.packageName }).catch(() => {}))}
        {item("Доступные связи (связать тему)", () => onLink(app))}
        {flags.hidden ? item("Сделать видимым", () => onFlag(app, "hidden", false)) : item("Скрыть приложение", () => onFlag(app, "hidden", true))}
        {check("Скрыть все обновления", "hideAll")}
        {check("Скрыть обновления с форума", "hideForum")}
        {check("Скрыть обновления с Google Play", "hidePlay")}
        {item("Информация", () => onInfo(app))}
      </div>
    </div>
  );
}

function InfoDialog({ app, info, onClose }) {
  const [d, setD] = useState(null);
  useEffect(() => { Apps.appDetails({ packageName: app.packageName }).then(setD).catch(() => setD({})); }, []);
  const dt = (ms) => { if (!ms) return ""; const x = new Date(ms); const p = (n) => String(n).padStart(2, "0"); return `${p(x.getDate())}.${p(x.getMonth() + 1)}.${x.getFullYear()} ${p(x.getHours())}:${p(x.getMinutes())}`; };
  const sz = (b) => (!b ? "" : b >= 1048576 ? (b / 1048576).toFixed(1) + " МБ" : Math.round(b / 1024) + " КБ");
  const nf = (info || {});
  const g = (k) => (d && d[k] != null && d[k] !== "" ? d[k] : null);
  const row = (label, value, onClick) => (value || value === 0) ? (
    <div style={{ fontSize: 14.5, marginBottom: 7, lineHeight: 1.35 }}>
      <span style={{ color: C.text, fontWeight: 700 }}>{label}</span>
      <span style={{ color: C.sub }}> : </span>
      <span onClick={onClick} style={{ color: onClick ? "#4db6c4" : C.text, textDecoration: onClick ? "underline" : "none", wordBreak: "break-all", cursor: onClick ? "pointer" : "default" }}>{value}</span>
    </div>
  ) : null;
  const vName = app.versionName || g("versionName");
  const vCode = g("versionCode");
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 75, display: "flex", alignItems: "center", justifyContent: "center", padding: 18 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 460, background: "#3a3a3a", borderRadius: 6, padding: 22, maxHeight: "85%", overflowY: "auto" }}>
        <div style={{ color: "#e9e9e9", fontSize: 24, fontWeight: 400, marginBottom: 18 }}>Информация</div>
        {row("Имя пакета", app.packageName, () => openPlay(app))}
        {row("Имя приложения", app.label || g("label"))}
        {row("Имя на форуме", nf.title4pda)}
        {row("Версия (код)", vName ? `${vName}${vCode != null ? ` (${vCode})` : ""}` : null)}
        {row("Версия на форуме", nf.ver4pda)}
        {row("Версия в Google Play", nf.verPlay ? `${nf.verPlay}${nf.verPlayCode ? ` (${nf.verPlayCode})` : ""}` : null)}
        {row("Дата на форуме", nf.fdate)}
        {row("Обновление шапки", nf.hatDate)}
        {row("Дата обновления", dt(app.lastUpdate || g("lastUpdate")))}
        {row("Дата установки", dt(app.firstInstall || g("firstInstall")))}
        {row("Размер APK", sz(g("apkSize")))}
        {row("Target / Min SDK", g("targetSdk") ? `${g("targetSdk")}${g("minSdk") ? " / " + g("minSdk") : ""}` : null)}
        {row("Установщик", g("installer"))}
        {row("Связь", nf.topicId, nf.topicId ? () => Apps.openWeb({ url: `https://4pda.to/forum/index.php?showtopic=${nf.topicId}` }).catch(() => {}) : null)}
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 16 }}>
          <div onClick={onClose} style={{ color: "#4db6c4", fontWeight: 700, fontSize: 15, cursor: "pointer", padding: "6px 8px" }}>ЗАКРЫТЬ</div>
        </div>
      </div>
    </div>
  );
}

function Downloads({ onClose }) {
  const [items, setItems] = useState(null);
  const [del, setDel] = useState(null);
  const [sigs, setSigs] = useState({});
  const prev = useRef({});
  const sigChecked = useRef({});
  const hidden = () => { try { return JSON.parse(localStorage.getItem("t4_dl_hidden") || "[]"); } catch { return []; } };
  const hide = (id) => { try { const h = hidden(); if (!h.includes(id)) { h.push(id); localStorage.setItem("t4_dl_hidden", JSON.stringify(h)); } } catch {} };
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await Apps.dlStatus();
        if (!alive) return;
        const now = Date.now();
        const list = (r.items || []).map((it) => {
          const p = prev.current[it.id];
          let speed = 0;
          if (p && it.status === 2 && now > p.t) speed = Math.max(0, (it.done - p.done) / ((now - p.t) / 1000));
          prev.current[it.id] = { done: it.done, t: now };
          return { ...it, speed };
        }).sort((a, b) => (b.date || 0) - (a.date || 0));
        const hid = hidden();
        setItems(list.filter((it) => !hid.includes(it.id)));
      } catch { if (alive) setItems([]); }
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => { alive = false; clearInterval(iv); };
  }, []);
  const sz = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + " МБ" : Math.max(1, Math.round(b / 1024)) + " КБ");
  const spd = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + " МБ/с" : Math.round(b / 1024) + " КБ/с");
  const [sigDlg, setSigDlg] = useState(null);
  const doInstall = (path) => { Apps.requestInstall && Apps.requestInstall().catch(() => {}); Apps.installApk({ path }).catch(() => {}); };
  const install = (it) => {
    const u = it.uri || ""; if (u.indexOf("file://") !== 0) return;
    let p = u.slice(7); try { p = decodeURIComponent(p); } catch {}
    if (/\.apk$/i.test(p)) {
      // как у ag4pda: перед установкой считаем подпись и сверяем с установленной
      Apps.checkSignature({ path: p }).then((r) => {
        if (r && r.installed && !r.match) setSigDlg({ path: p, pkg: r.package || "" });
        else doInstall(p);
      }).catch(() => doInstall(p));
    } else doInstall(p);
  };
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 55 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Загрузки</span></div></div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 0" }}>
        {items === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : items.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Нет загрузок</div> :
          items.map((it) => {
            const running = it.status === 2 || it.status === 1;
            const pct = it.total > 0 ? Math.min(100, Math.round((it.done / it.total) * 100)) : 0;
            const eta = running && it.speed > 0 && it.total > 0 ? Math.round((it.total - it.done) / it.speed) : 0;
            return (
              <div key={it.id} onClick={() => it.status === 8 && install(it)} style={{ background: C.card, border: `1px solid ${it.status === 16 ? "#7a3a34" : running ? C.acc : C.border}`, borderRadius: 12, marginBottom: 10, padding: 12, cursor: it.status === 8 ? "pointer" : "default" }}>
                <div style={{ display: "flex", gap: 11, alignItems: "flex-start" }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, flexShrink: 0, background: "#2c2016", display: "flex", alignItems: "center", justifyContent: "center", color: it.status === 8 ? C.acc : it.status === 16 ? "#e5675e" : C.nav }}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 3v11m0 0 4-4m-4 4-4-4M5 20h14" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ color: C.text, fontSize: 15, fontWeight: 500, wordBreak: "break-all", lineHeight: 1.25 }}>{it.title}</div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10, marginTop: 3, fontSize: 12.5, color: C.sub }}>
                      <span>{(() => { const m = (it.title || "").match(/(\d+(?:\.\d+){1,})/); return m ? "v" + m[1] : ""; })()}</span>
                      <span>{it.total > 0 ? sz(it.total) : ""}</span>
                    </div>
                  </div>
                </div>
                {running ? (
                  <div style={{ marginTop: 9 }}>
                    <div style={{ height: 6, borderRadius: 4, background: "#332619", overflow: "hidden" }}><div style={{ height: "100%", width: pct + "%", background: C.acc, borderRadius: 4 }} /></div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 5, fontSize: 12.5, color: C.sub }}>
                      <span>{it.status === 1 ? "Ожидание…" : `Осталось ${eta} сек · ${spd(it.speed)}`}</span>
                      <span>{pct}%</span>
                    </div>
                  </div>
                ) : it.status === 16 ? (
                  <div style={{ color: "#e5675e", fontSize: 12.5, marginTop: 7, wordBreak: "break-word" }}>Ошибка{it.error ? ": " + it.error : ""}</div>
                ) : (
                  <div style={{ color: it.status === 8 ? C.acc : C.sub, fontSize: 13, marginTop: 7 }}>{it.status === 8 ? "Готово — нажми, чтобы установить" : "Пауза"}</div>
                )}
                <div style={{ display: "flex", gap: 20, marginTop: 10, justifyContent: "flex-end" }} onClick={(e) => e.stopPropagation()}>
                  {(it.status === 2 || it.status === 1) && <div onClick={() => Apps.dlPause({ id: it.id }).catch(() => {})} style={{ color: "#d0b06a", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>Пауза</div>}
                  {(it.status === 16 || it.status === 4) && <div onClick={() => Apps.dlResume({ id: it.id }).catch(() => {})} style={{ color: C.acc, fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>Возобновить</div>}
                  <div onClick={() => setDel(it)} style={{ color: "#e5675e", fontSize: 13.5, fontWeight: 700, cursor: "pointer" }}>Удалить</div>
                </div>
              </div>
            );
          })}
        <div style={{ height: 12 }} />
      </div>
      {del && (
        <div onClick={() => setDel(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 60, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 360, background: "#1e160e", borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Удалить загрузку</div>
            <div style={{ color: C.sub, fontSize: 13.5, marginBottom: 16, wordBreak: "break-all" }}>{del.title}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <div onClick={() => { Apps.dlCancel({ id: del.id, deleteFile: true }).catch(() => {}); setItems((prev) => (prev ? prev.filter((x) => x.id !== del.id) : prev)); setDel(null); }} style={{ padding: "12px 10px", color: "#e5675e", fontSize: 14.5, fontWeight: 600, cursor: "pointer" }}>Удалить файл и задачу</div>
              <div onClick={() => { Apps.dlCancel({ id: del.id, deleteFile: false }).catch(() => {}); hide(del.id); setItems((prev) => (prev ? prev.filter((x) => x.id !== del.id) : prev)); setDel(null); }} style={{ padding: "12px 10px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>Убрать из списка (файл оставить)</div>
              <div onClick={() => setDel(null)} style={{ padding: "12px 10px", color: C.sub, fontSize: 14.5, cursor: "pointer", textAlign: "right" }}>Отмена</div>
            </div>
          </div>
        </div>
      )}
      {sigDlg && (
        <div onClick={() => setSigDlg(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 61, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 370, background: "#1e160e", borderRadius: 14, padding: 18 }}>
            <div style={{ color: "#e0a848", fontSize: 16, fontWeight: 600, marginBottom: 8 }}>Подпись не совпадает</div>
            <div style={{ color: C.sub, fontSize: 13.5, marginBottom: 16, lineHeight: 1.4 }}>Подпись у этого файла не совпадает с подписью установленной у вас версии. Перед установкой нужно удалить установленную программу.</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <div onClick={() => { if (sigDlg.pkg) Apps.uninstallApp({ packageName: sigDlg.pkg }).catch(() => {}); setSigDlg(null); }} style={{ padding: "12px 10px", color: "#e5675e", fontSize: 14.5, fontWeight: 600, cursor: "pointer" }}>Удалить установленную</div>
              <div onClick={() => { const p = sigDlg.path; setSigDlg(null); doInstall(p); }} style={{ padding: "12px 10px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>Всё равно установить</div>
              <div onClick={() => setSigDlg(null)} style={{ padding: "12px 10px", color: C.sub, fontSize: 14.5, cursor: "pointer", textAlign: "right" }}>Отмена</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ArchLine() {
  const abis = (DEVICE_ABIS || []).map((a) => (a || "").toLowerCase());
  const arm = abis.some((a) => a.indexOf("armeabi") >= 0 || a.indexOf("armv7") >= 0 || a.indexOf("v7a") >= 0);
  const arm64 = abis.some((a) => a.indexOf("arm64") >= 0 || a.indexOf("v8a") >= 0);
  const x86 = abis.some((a) => a === "x86");
  const x64 = abis.some((a) => a.indexOf("x86_64") >= 0 || a === "x64");
  const mips = abis.some((a) => a.indexOf("mips") >= 0);
  const t = (on, txt) => <span style={{ color: on ? "#e8e8e8" : "#5a5a5a", fontWeight: on ? 700 : 400 }}>{txt}</span>;
  return <span style={{ fontSize: 12.5, color: "#cfcfcf" }}>({t(arm, "ARM")}/{t(arm64, "64")} {t(x86, "X86")}/{t(x64, "64")} {t(mips, "MIPS")})</span>;
}
// экран «ФАЙЛЫ» — список apk; тап по строке — закачка, кнопка «i» — инфо
function FilesDialog({ app, files, dlPosts, mode, onDownloads, onClose }) {
  const [picked, setPicked] = useState(null);
  const [askDl, setAskDl] = useState(false);
  const topicIdF = (readCache()[app.packageName] || {}).topicId || app.topicId;
  const [postFiles, setPostFiles] = useState(() => { const k = topicIdF + ":" + (mode || "all"); return (postFilesCache[k] && postFilesCache[k].files.slice()) || []; });
  const [loadingPosts, setLoadingPosts] = useState(false);
  const apkVer = (name) => { const m = (name || "").match(/(\d+(?:\.\d+){1,})/); return m ? m[1] : ""; };
  useEffect(() => {
    let alive = true;
    if (!dlPosts || !dlPosts.length || !topicIdF) return;
    const k = topicIdF + ":" + (mode || "all");
    if (postFilesCache[k] && postFilesCache[k].done) { setPostFiles(postFilesCache[k].files.slice()); return; }
    setLoadingPosts(true);
    fetchDlPostFiles(topicIdF, dlPosts, app.versionName, mode, (files) => { if (alive) setPostFiles(files); }).then(() => { if (alive) setLoadingPosts(false); });
    return () => { alive = false; };
  }, []);
  const merged = (() => { const seen = new Set(); return [...(files || []), ...postFiles].filter((f) => { if (seen.has(f.url)) return false; seen.add(f.url); return true; }); })();
  let list = merged;
  if (mode === "updates") list = list.filter((f) => { const v = apkVer(f.name); return v && app.versionName && verCmp(v, app.versionName) > 0; });
  // опция: показывать только файлы под процессор пользователя (по умолчанию вкл.)
  const onlyMyArch = localStorage.getItem("t4_files_myarch") !== "0";
  if (onlyMyArch) list = list.filter((f) => fileForDevice(f.name));
  // сортировка
  const dev64 = (DEVICE_ABIS || []).some((a) => /arm64|v8a|x86_64|\bx64\b/i.test(a || ""));
  const file64 = (n) => /arm64|v8a|x86_64|\bx64\b/i.test(n || "");
  if (mode === "updates") {
    // приоритет: новее+64 (если устройство поддерживает 64) → новее+любой поддерживаемый → новее+не мой процессор
    const rank = (f) => { if (dev64 && file64(f.name) && fileForDevice(f.name)) return 0; if (fileForDevice(f.name)) return 1; return 2; };
    list = [...list].sort((a, b) => { const r = rank(a) - rank(b); if (r) return r; const va = apkVer(a.name), vb = apkVer(b.name); return (va && vb) ? verCmp(vb, va) : 0; });
  } else {
    list = [...list].sort((a, b) => { const va = apkVer(a.name), vb = apkVer(b.name); if (va && vb) { const c = verCmp(vb, va); if (c) return c; } return 0; });
  }
  const iBtn = (fn) => <div onClick={(e) => { e.stopPropagation(); fn(); }} style={{ width: 34, height: 34, borderRadius: "50%", border: `2px solid ${C.sub}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, cursor: "pointer" }}><span style={{ color: C.sub, fontSize: 18, fontWeight: 700, transform: "rotate(180deg)" }}>!</span></div>;
  const topicId = (readCache()[app.packageName] || {}).topicId || app.topicId;
  const openFile4pda = (f) => { let url = f.postUrl; if (!url && topicId) url = `https://4pda.to/forum/index.php?showtopic=${topicId}`; if (!url) url = f.url; Apps.openUrl({ url }).catch(() => {}); };
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 70, display: "flex", alignItems: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxHeight: "80%", overflowY: "auto", background: "#1c1c1c", borderTopLeftRadius: 16, borderTopRightRadius: 16, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ padding: "16px 18px 8px", color: C.text, fontSize: 18, fontWeight: 600 }}>{mode === "updates" ? "Обновления" : "Скачать"}</div>
        {(!list || list.length === 0) ? <div style={{ padding: "8px 18px 20px", color: C.sub, fontSize: 14 }}>{loadingPosts ? "Загрузка файлов из темы…" : mode === "updates" ? "Более новых версий не найдено." : "Файлы в теме не найдены."}</div> :
          list.map((f, i) => {
            const badArch = !fileForDevice(f.name);
            const lbl = (app.label || "").toLowerCase().replace(/[^a-zа-я0-9]/gi, "");
            const fn = (f.name || "").toLowerCase().replace(/[^a-zа-я0-9]/gi, "");
            const nameMatch = !lbl || lbl.length < 3 || fn.indexOf(lbl.slice(0, Math.min(lbl.length, 7))) >= 0;
            const nameColor = badArch ? "#e5675e" : (nameMatch ? "#dcdcdc" : "#5aa9e0");
            return <div key={i} style={{ padding: "12px 18px", borderTop: i ? `1px solid ${C.border}` : "none", display: "flex", alignItems: "center", gap: 12 }}>
              <div onClick={() => setPicked(f)} style={{ flex: 1, minWidth: 0, cursor: "pointer" }}>
                <div style={{ color: nameColor, fontSize: 15, wordBreak: "break-word" }}>{(app.label || app.packageName)}{apkVer(f.name) ? " " + shortVer(apkVer(f.name)) : ""}</div>
                <div style={{ color: badArch ? "#e5675e" : "#9a9a9a", fontSize: 13, wordBreak: "break-all", marginTop: 1 }}>{f.name}</div>
                <div style={{ marginTop: 2, fontSize: 12.5, color: "#8a8a8a", display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <span>{f.downloads ? "Скачиваний: " + f.downloads : ""}</span>
                  <span>{f.size}</span>
                </div>
                <div style={{ marginTop: 1 }}><ArchLine name={f.name} /></div>
              </div>
              {iBtn(() => { const u = f.postUrl || (topicId ? `https://4pda.to/forum/index.php?showtopic=${topicId}` : f.url); Apps.openPostView({ url: u }).catch(() => Apps.openUrl({ url: u }).catch(() => {})); })}
            </div>;
          })}
        {list && list.length > 0 && loadingPosts && <div style={{ padding: "10px 18px", color: C.sub, fontSize: 13, textAlign: "center" }}>Подгружаю ещё файлы из темы…</div>}
        <div style={{ height: 8 }} />
      </div>


      {picked && (
        <div onClick={(e) => { e.stopPropagation(); setPicked(null); }} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 80, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: "#1e1e1e", borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 17, fontWeight: 600, marginBottom: 12 }}>Начать закачку?</div>
            <Row k="Название" v={app.label || app.packageName} />
            <Row k="Имя файла" v={picked.name} />
            {picked.size && <Row k="Размер" v={picked.size} />}
            <Row k="Имя пакета" v={app.packageName} />
            <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>Требования:</span><ArchLine name={picked.name} /></div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 18, marginTop: 16 }}>
              <div onClick={() => setPicked(null)} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 4px" }}>ОТМЕНА</div>
              <div onClick={() => { const ref = picked.postUrl || (topicIdF ? `https://4pda.to/forum/index.php?showtopic=${topicIdF}` : ""); Apps.dlStart({ url: picked.url, name: picked.name, referer: ref }).catch(() => {}); setPicked(null); setAskDl(true); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 4px" }}>СКАЧАТЬ</div>
            </div>
          </div>
        </div>
      )}
      {askDl && (
        <div onClick={(e) => { e.stopPropagation(); setAskDl(false); onClose(); }} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 86, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 340, background: "#1e160e", borderRadius: 14, padding: 20 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 16 }}>Открыть загрузки?</div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 20 }}>
              <div onClick={() => { setAskDl(false); onClose(); }} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 6px" }}>НЕТ</div>
              <div onClick={() => { setAskDl(false); onClose(); if (onDownloads) onDownloads(); else Apps.openDownloads().catch(() => {}); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 6px" }}>ДА</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
function Row({ k, v }) {
  return <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>{k}:</span><span style={{ color: C.text, wordBreak: "break-all" }}>{v}</span></div>;
}

function PostPopup({ url, text, app, topicId, onClose }) {
  const [st, setSt] = useState({ phase: "loading" });
  const directApk = /\/dl\/post\/\d+\/[^?#]+\.(?:apk|apks|xapk|zip|obb)/i.test(url);
  const apkName = (() => { const m = url.match(/\/dl\/post\/\d+\/([^?#]+)/i); if (m) { try { return decodeURIComponent(m[1]); } catch { return m[1]; } } const t = (text || "").match(/([^\s]+\.(?:apk|apks|xapk|zip|obb))\b/i); return t ? t[1] : (text || "файл"); })();
  useEffect(() => {
    let alive = true;
    (async () => {
      if (directApk) { setSt({ phase: "apk" }); return; }
      const pid = (url.match(/pid=(\d+)/) || url.match(/entry(\d+)/) || [])[1];
      try {
        const html = await fetchUrl4pda(url);
        if (!alive) return;
        const doc = new DOMParser().parseFromString(html, "text/html");
        let bodyEl = null;
        if (pid) {
          const anchor = doc.querySelector('a[name="entry' + pid + '"]') || doc.querySelector("#entry" + pid) || doc.querySelector('[id="p' + pid + '"]') || doc.querySelector('[data-post="' + pid + '"]') || doc.querySelector('[id*="' + pid + '"]');
          if (anchor) {
            let el = anchor;
            for (let i = 0; i < 10 && el && !bodyEl; i++) { if (el.querySelector) bodyEl = el.querySelector(".post_body, .postcolor"); if (!bodyEl) el = el.parentElement; }
            if (!bodyEl) { let n = anchor.nextElementSibling, g = 0; while (n && g < 12 && !bodyEl) { if (n.querySelector) bodyEl = n.querySelector(".post_body, .postcolor"); if (!bodyEl && n.classList && n.classList.contains("post_body")) bodyEl = n; n = n.nextElementSibling; g++; } }
          }
        }
        // конкретный пост не найден — показываем файл, а не главную шапку
        if (!bodyEl) { setSt({ phase: "apk" }); return; }
        let h = bodyEl.innerHTML.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/Сообщение отредактировал[\s\S]*?(?=<div|<br|<span|<p|$)/gi, "");
        setSt({ phase: "ok", html: h });
      } catch { setSt({ phase: "apk" }); }
    })();
    return () => { alive = false; };
  }, [url]);
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 84, display: "flex", alignItems: "center", justifyContent: "center", padding: 18 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 440, maxHeight: "82%", background: "#242424", borderRadius: 14, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "14px 16px", borderBottom: `1px solid ${C.border}` }}>
          <div style={{ flex: 1, minWidth: 0, color: "#5ab0d8", fontSize: 15, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || "Пост 4pda"}</div>
          <div onClick={() => Apps.openUrl({ url: /findpost|pid=\d|showtopic/i.test(url) ? url : (topicId ? `https://4pda.to/forum/index.php?showtopic=${topicId}` : url) }).catch(() => {})} title="Открыть на 4pda" style={{ cursor: "pointer", color: "#cfcfcf", fontSize: 20, padding: "2px 6px" }}>↗</div>
          <div onClick={onClose} style={{ cursor: "pointer", color: C.sub, fontSize: 20, padding: "2px 6px" }}>✕</div>
        </div>
        <div style={{ overflowY: "auto", padding: 16 }}>
          {st.phase === "loading" && <div style={{ color: C.sub, fontSize: 14, textAlign: "center", padding: "20px 0" }}>Загрузка…</div>}
          {st.phase === "apk" && <>
            <div style={{ color: C.text, fontSize: 15, wordBreak: "break-all", marginBottom: 6 }}>{apkName}</div>
            <div style={{ color: fileForDevice(apkName) ? C.sub : "#e5675e", fontSize: 12.5, marginBottom: 14 }}>{fileForDevice(apkName) ? "" : "не для вашего процессора"}</div>
            <div onClick={() => { Apps.dlStart({ url, name: apkName }).catch(() => {}); onClose(); }} style={{ display: "inline-block", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 14, padding: "10px 18px", borderRadius: 10, cursor: "pointer" }}>Скачать</div>
          </>}
          {st.phase === "ok" && <><DescView html={st.html} /><style>{`.topic-desc a{color:#5ab0d8;text-decoration:none;word-break:break-word}.topic-desc img{max-width:100%;height:auto;border-radius:6px}.topic-desc .block-title,.topic-desc .spoiler-title{font-weight:700;color:#e0e0e0;padding:8px 10px;background:#2c2c2c;border-radius:6px;margin:6px 0;cursor:pointer}.topic-desc .block-body,.topic-desc .spoiler-body{padding:5px 8px;border-left:2px solid #333;margin:2px 0 8px}`}</style></>}
        </div>
      </div>
    </div>
  );
}

function DescView({ html, onPostLink }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    el.querySelectorAll(".spoiler, .post-block").forEach((sp) => {
      const title = sp.querySelector(".block-title, .spoiler-title, .title");
      const body = sp.querySelector(".block-body, .spoiler-body, .body");
      if (title && body && !title.dataset.w) {
        title.dataset.w = "1";
        body.style.display = "none";
        const mark = document.createElement("span"); mark.textContent = "► "; title.prepend(mark);
        title.addEventListener("click", () => { const open = body.style.display !== "none"; body.style.display = open ? "none" : "block"; mark.textContent = open ? "► " : "▼ "; });
      }
    });
    el.querySelectorAll("a[href]").forEach((a) => {
      if (a.dataset.w) return; a.dataset.w = "1";
      a.addEventListener("click", (e) => {
        e.preventDefault();
        let href = a.getAttribute("href") || ""; if (!href) return;
        if (href.indexOf("//") === 0) href = "https:" + href;
        if (href.indexOf("http") !== 0) href = "https://4pda.to" + (href[0] === "/" ? "" : "/") + href;
        const text = (a.textContent || "").trim();
        // ссылки на скачивание/пост-анонс — во всплывающий укороченный пост; остальные — во внешний браузер
        const isPostLink = /findpost|[?&]pid=\d|#entry\d|\/dl\/post\/|act=attach|attach_id=/i.test(href) || /\.(apk|apks|xapk|zip|obb)\b/i.test(text);
        if (isPostLink && onPostLink) onPostLink(href, text);
        else Apps.openUrl({ url: href }).catch(() => {});
      });
    });
  }, [html]);
  return <div ref={ref} className="topic-desc" style={{ color: "#cfcfcf", fontSize: 14, lineHeight: 1.5 }} dangerouslySetInnerHTML={{ __html: html || "—" }} />;
}

function Detail({ app, onClose, onCache, onFiles, onDownloads, onSimilar }) {
  const [td, setTd] = useState({ phase: "loading" });
  const [menuOpen, setMenuOpen] = useState(false);
  const [retKey, setRetKey] = useState(0);
  const [shot, setShot] = useState(-1);

  useEffect(() => {
    let alive = true;
    (async () => {
      setTd({ phase: "loading" });
      try {
        const cache = readCache()[app.packageName] || {};
        let topicId = app.topicId || cache.topicId, matched = cache.matched, html = null;
        if (!topicId) {
          const r = await resolveTopic(app);
          if (!alive) return;
          if (r === "captcha") { setTd({ phase: "captcha" }); return; }
          if (!r) { setTd({ phase: "notfound" }); return; }
          topicId = r.topicId; matched = r.matched; html = r.html;
          onCache(app.packageName, { topicId, matched, notfound: false });
        }
        if (!html) {
          html = await fetchTopicHtml(topicId);
          if (!alive) return;
          if (!html) { setTd({ phase: "captcha" }); return; }
        }
        const p = parseTopic(html);
        onCache(app.packageName, { ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short });
        setTd({ phase: "ok", topicId, descHtml: p.descHtml, descMain: p.descMain, files: p.files, dlPosts: p.dlPosts, ver4pda: p.ver4pda, screenshots: p.screenshots, verPlay: cache.verPlay || "" });
        // фоновая предзагрузка файлов из анонсов, чтобы «Файлы»/«Обновления» открывались сразу
        if (topicId && p.dlPosts && p.dlPosts.length) {
          fetchDlPostFiles(topicId, p.dlPosts, app.versionName, "all", null).catch(() => {});
          fetchDlPostFiles(topicId, p.dlPosts, app.versionName, "updates", null).catch(() => {});
        }
        if (!cache.verPlay) {
          fetchPlayVersion(app.packageName).then((v) => { if (v) { onCache(app.packageName, { verPlay: v.name, verPlayCode: v.code }); if (alive) setTd((t) => (t && t.phase === "ok" ? { ...t, verPlay: v.name } : t)); } }).catch(() => {});
        }
      } catch (e) { if (alive) setTd({ phase: "error", msg: (e && e.message) || "ошибка" }); }
    })();
    return () => { alive = false; };
  }, [retKey]);

  const note = (txt, btn) => <div style={{ textAlign: "center", marginTop: 30, padding: "0 10px" }}><div style={{ color: C.sub, fontSize: 14, marginBottom: 14 }}>{txt}</div>{btn}</div>;
  const btn = (label, fn) => <div onClick={fn} style={{ display: "inline-block", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 14, padding: "10px 16px", borderRadius: 10, cursor: "pointer" }}>{label}</div>;

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 62 }}>
      <style>{".topic-desc img{max-width:100%;height:auto;border-radius:6px} .topic-desc a{color:#4da3ff} .topic-desc{word-break:break-word}"}</style>
      {(() => {
        const tid = td.topicId || (readCache()[app.packageName] || {}).topicId || app.topicId;
        const linked = !!tid;
        const openForum = () => Apps.openUrl({ url: tid ? `https://4pda.to/forum/index.php?showtopic=${tid}` : searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {});
        const mItem = (label, fn, danger) => <div onClick={() => { setMenuOpen(false); fn(); }} style={{ padding: "12px 16px", color: danger ? "#e5675e" : C.text, fontSize: 14.5, cursor: "pointer", whiteSpace: "nowrap" }}>{label}</div>;
        return (
          <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0, borderBottom: `1px solid ${C.border}` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "0 8px 0 12px", height: 54 }}>
              <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 25, width: 30, flexShrink: 0 }}>←</div>
              <div style={{ flex: 1, minWidth: 0, color: C.text, fontSize: 17, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
              {td.phase === "loading" && <div style={{ width: 18, height: 18, border: "2px solid #555", borderTopColor: C.acc, borderRadius: "50%", animation: "spin .7s linear infinite", flexShrink: 0 }} />}
              <div onClick={() => onDownloads && onDownloads()} title="Загрузки" style={{ cursor: "pointer", padding: "6px 8px 6px 6px", flexShrink: 0, color: "#d0d0d0" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>
            </div>
          </div>
        );
      })()}
      <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 14px 14px" }} onClick={() => menuOpen && setMenuOpen(false)}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14 }}>
          <Icon app={app} />
          <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 18, fontWeight: 600 }}>{app.label || app.packageName}</div><div style={{ color: C.sub, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{(app.packageName || "").indexOf("topic:") === 0 ? "тема 4pda" : app.packageName}</div></div>
        </div>

        {td.phase === "ok" && td.screenshots && td.screenshots.length > 0 && <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 6 }}>
            {td.screenshots.map((s, i) => <img key={i} src={s.thumb} alt="" onClick={() => setShot(i)} style={{ height: 200, borderRadius: 8, flexShrink: 0, cursor: "pointer" }} />)}
          </div>
        </div>}
        <div style={{ color: C.text, fontSize: 13, fontWeight: 700, letterSpacing: 0.4, marginBottom: 8 }}>ОПИСАНИЕ</div>
        {td.phase === "loading" && <div style={{ color: C.sub, fontSize: 14 }}>Загрузка темы с 4pda…</div>}
        {td.phase === "captcha" && note("4pda просит проверку. Открой 4pda, войди/реши капчу и вернись.", <span>{btn("Открыть 4pda", () => openTopicApp(app))} <span style={{ display: "inline-block", width: 8 }} />{btn("Повторить", () => setRetKey((k) => k + 1))}</span>)}
        {td.phase === "notfound" && note("Тема не загрузилась (4pda мог не ответить).", <span>{btn("Повторить", () => setRetKey((k) => k + 1))} <span style={{ display: "inline-block", width: 8 }} />{btn("Искать на 4pda", () => Apps.openUrl({ url: searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}))}</span>)}
        {td.phase === "error" && note("Не удалось загрузить: " + td.msg, btn("Повторить", () => setRetKey((k) => k + 1)))}
        {td.phase === "ok" && <>
          <DescView html={td.descHtml} onPostLink={(u) => Apps.openPostView({ url: u }).catch(() => Apps.openUrl({ url: u }).catch(() => {}))} />
          <style>{`
            .topic-desc a{color:#5ab0d8;text-decoration:none;word-break:break-word}
            .topic-desc img{max-width:100%;height:auto;border-radius:6px}
            .topic-desc b,.topic-desc strong{color:#e9e9e9}
            .topic-desc .block-title,.topic-desc .spoiler-title{font-weight:700;color:#e0e0e0;padding:9px 12px;background:#242424;border:1px solid #333;border-radius:8px;margin:7px 0;cursor:pointer}
            .topic-desc .block-body,.topic-desc .spoiler-body{padding:6px 10px;border-left:2px solid #333;margin:2px 0 10px}
          `}</style>
        </>}
        <div style={{ height: 20 }} />
      </div>

      <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", height: 58 }}>
          <div onClick={() => { const tid = td.topicId || (readCache()[app.packageName] || {}).topicId || app.topicId; Apps.openUrl({ url: tid ? `https://4pda.to/forum/index.php?showtopic=${tid}` : searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}); }} title="4pda" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><I4 /></div>
          {(() => { const hasUpd = td.phase === "ok" && ((td.ver4pda && app.versionName && verCmp(td.ver4pda, app.versionName) > 0) || (td.files || []).some((f) => { const m = (f.name || "").match(/(\d+(?:\.\d+){1,})/); return m && app.versionName && verCmp(m[1], app.versionName) > 0; })); return <div onClick={() => hasUpd && onFiles({ app, files: td.files, dlPosts: td.dlPosts, mode: "updates", onDownloads })} style={{ flex: 1, textAlign: "center", color: hasUpd ? "#e5675e" : "#5a5a5a", fontSize: 14, fontWeight: 700, cursor: hasUpd ? "pointer" : "default" }}>ОБНОВЛЕНИЯ</div>; })()}
          <div onClick={() => td.phase === "ok" && onFiles({ app, files: td.files, dlPosts: td.dlPosts, mode: "all", onDownloads })} style={{ flex: 1, textAlign: "center", color: td.phase === "ok" ? C.acc : "#5a5a5a", fontSize: 14, fontWeight: 700, cursor: td.phase === "ok" ? "pointer" : "default" }}>ФАЙЛЫ</div>
          <div onClick={() => openPlay(app)} title="Google Play" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><IPlayStore /></div>
        </div>
      </div>
      {shot >= 0 && td.screenshots && td.screenshots[shot] && (
        <div onClick={() => setShot(-1)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.94)", zIndex: 90, display: "flex", alignItems: "center", justifyContent: "center" }}
          onTouchStart={(e) => { shot >= 0 && (shot._x = e.touches[0].clientX); }}>
          <img src={td.screenshots[shot].full || td.screenshots[shot].thumb} alt="" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
          <div style={{ position: "absolute", top: "env(safe-area-inset-top)", right: 14, color: "#fff", fontSize: 30, padding: 10, cursor: "pointer" }} onClick={() => setShot(-1)}>✕</div>
          {shot > 0 && <div onClick={(e) => { e.stopPropagation(); setShot(shot - 1); }} style={{ position: "absolute", left: 6, top: "50%", transform: "translateY(-50%)", color: "#fff", fontSize: 40, padding: 12, cursor: "pointer", opacity: 0.7 }}>‹</div>}
          {shot < td.screenshots.length - 1 && <div onClick={(e) => { e.stopPropagation(); setShot(shot + 1); }} style={{ position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)", color: "#fff", fontSize: 40, padding: 12, cursor: "pointer", opacity: 0.7 }}>›</div>}
          <div style={{ position: "absolute", bottom: "calc(env(safe-area-inset-bottom) + 14px)", left: 0, right: 0, textAlign: "center", color: "#bbb", fontSize: 13 }}>{shot + 1} / {td.screenshots.length}</div>
        </div>
      )}
    </div>
  );
}

function SubList({ title, initial, loadSystem, topics, onOpen, onMenu, onClose }) {
  const [list, setList] = useState(loadSystem ? null : (initial || []));
  useEffect(() => {
    if (loadSystem) Apps.getInstalledApps({ icons: true, system: true }).then((r) => setList((r.apps || []).filter((a) => a.system).sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0)))).catch(() => setList([]));
  }, []);
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 60 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>{title}</span></div></div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {list === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : list.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Пусто</div> :
          list.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName] || {}} onOpen={onOpen} onMenu={onMenu} />)}
        <div style={{ height: 12 }} />
      </div>
    </div>
  );
}

function parseTopicTitle(html) {
  const m = html.match(/<title>([^<]*)<\/title>/i);
  if (!m) return "";
  return m[1].replace(/\s*[-–|]\s*4PDA.*$/i, "").replace(/&amp;/g, "&").trim();
}

function SearchScreen({ initialQuery, searchType, onClose, onOpenResult }) {
  const type = searchType || "apps";
  const allMode = type === "all";
  const [q, setQ] = useState(initialQuery || "");
  const [res, setRes] = useState(undefined);
  const [tabs, setTabs] = useState({ apps: undefined, games: undefined, emu: undefined });
  const [activeTab, setActiveTab] = useState("apps");
  const [sort, setSort] = useState("match");
  const [sortOpen, setSortOpen] = useState(false);
  const dbg = useRef({ html: "", captcha: false });
  // Живой поиск — по целевым разделам (быстро, пословно). Подстроку и кросс-раздельные приложения добирает каталог (ниже).
  const searchGroups = (t) => t === "games" ? [{ forums: [213], srcs: ["top", "all"] }] : t === "emu" ? [{ forums: [529], srcs: ["top", "all"] }] : [{ forums: [212], srcs: ["top", "all"] }, { forums: [1198], srcs: ["top"] }, { forums: [550], srcs: ["top"] }, { forums: [284], srcs: ["top"] }, { forums: [1109], srcs: ["top"] }, { forums: [94], srcs: ["top"], android: true }];
  const withTimeout = (p, ms) => Promise.race([p, new Promise((res2) => setTimeout(() => res2({ body: "", captcha: false, __timeout: true }), ms))]);
  const searchOne = async (query, t, setter) => {
    const map = new Map();
    const addAll = (arr) => { for (const it of arr) if (it.topicId && !map.has(it.topicId)) map.set(it.topicId, it); };
    const wq = query.trim();
    const ql = query.toLowerCase().trim();
    const qw = ql.split(/\s+/).filter((w) => w.length > 1);
    const grabPage = async (forums, source, st) => {
      const surl = searchUrl4pda(wq, source, forums, forums.length > 0, st);
      const hr = await withTimeout(Apps.httpGet({ url: surl }), 15000);
      let body = hr.body || "", via = "http";
      const cf = body && /Just a moment|cf-browser-verification|challenge-platform|Attention Required|Проверка браузера/i.test(body);
      if (!hr.__timeout && (hr.captcha || !body || body.length < 400 || cf)) { const sr = await withTimeout(Apps.webGet({ url: surl }), 22000); body = sr.body || ""; via = "web"; if (sr.captcha) dbg.current.captcha = true; }
      if (!dbg.current.html && body) dbg.current.html = body;
      return { body, via };
    };
    const grabGroup = async (forums, source, requireAndroid) => {
      const maxSt = forums.length === 0 ? 150 : 75; // глобальный поиск — глубже листаем
      try {
        for (let st = 0; st <= maxSt; st += 25) {
          const { body, via } = await grabPage(forums, source, st);
          let r = parseSearchResults(body);
          const raw = r.length;
          if (source === "all") r = r.filter((x) => { const s = ((x.title || "") + " " + (x.short || "")).toLowerCase(); return s.indexOf(ql) >= 0 || qw.some((w) => s.indexOf(w) >= 0); });
          if (requireAndroid) r = r.filter((x) => /android/i.test((x.title || "") + " " + (x.short || "")));
          const before = map.size; addAll(r);
          dbg.current.report.push(`forums=${forums.join(",") || "ВСЕ"} src=${source} st=${st} via=${via} raw=${raw} +${map.size - before}`);
          if (raw < 20) break;
        }
      } catch (e) { dbg.current.report.push(`forums=${forums.join(",") || "ВСЕ"} src=${source} ERROR ${e && e.message}`); }
    };
    // проходы по очереди (без наложения сокетов)
    for (const g of searchGroups(t)) for (const src of g.srcs) await grabGroup(g.forums, src, g.android);
    // подстрочные совпадения из каталога (то, что пословный поиск 4pda не находит: Habitica по habit)
    const catKind = t === "games" ? "games" : (t === "emu" ? null : "apps");
    if (catKind) {
      const cm = catalogMatches(catKind, query); let cadd = 0; for (const it of cm) if (!map.has(it.topicId)) { map.set(it.topicId, it); cadd++; } dbg.current.report.push(`catalog ${catKind}: matches=${cm.length} +${cadd}`);
      // если индекс пуст — строим в фоне, чтобы следующий поиск уже находил по части слова
      try { if (!JSON.parse(localStorage.getItem("t4_idx_" + catKind) || "[]").length && !window.__idxBuilding) { window.__idxBuilding = true; buildAppIndex(catKind, 30).finally(() => { window.__idxBuilding = false; }); } } catch {}
    }
    let items = [...map.values()];
    // релевантность: запрос в заголовке ИЛИ в описании
    items = items.filter((it) => { const s = ((it.title || "") + " " + (it.short || "")).toLowerCase(); return s.indexOf(ql) >= 0 || qw.some((w) => s.indexOf(w) >= 0); });
    const list = items.slice(0, 60);
    setter(list);
    // обогащение в фоне, батчами по 3 (иначе десятки запросов разом захлёбываются)
    (async () => {
      const batch = list.slice(0, 22);
      const one = async (it) => {
        try {
          let tr = await withTimeout(Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }), 12000);
          if (tr.captcha || !tr.body || !realTopic(tr.body)) tr = await withTimeout(Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }), 20000);
          if (!tr.body || !realTopic(tr.body)) return;
          if (!isAppPage(tr.body) || !isAndroidTopic(tr.body)) { setter((prev) => (prev ? prev.filter((x) => x.topicId !== it.topicId) : prev)); return; }
          const p = parseTopic(tr.body || "");
          const dl = (p.files || []).reduce((s, f) => s + (parseInt((f.downloads || "").replace(/\D/g, ""), 10) || 0), 0);
          setter((prev) => (prev ? prev.map((x) => (x.topicId === it.topicId ? { ...x, short: p.short || x.short, icon: p.hatIcon, ver4pda: p.ver4pda, hatDate: p.hatDate || p.forumDate || "", dl } : x)) : prev));
        } catch {}
      };
      for (let i = 0; i < batch.length; i += 3) { await Promise.all(batch.slice(i, i + 3).map(one)); }
    })();
  };
  const run = async (q0) => {
    const query = (q0 != null ? q0 : q).trim(); if (!query) return;
    dbg.current = { html: "", captcha: false, report: [] };
    if (allMode) {
      setTabs({ apps: null, games: null, emu: null });
      // типы по очереди (приоритет: Программы → Игры → Эмуляторы), чтобы не плодить лишние WebView
      await searchOne(query, "apps", (v) => setTabs((t) => ({ ...t, apps: typeof v === "function" ? v(t.apps) : v })));
      await searchOne(query, "games", (v) => setTabs((t) => ({ ...t, games: typeof v === "function" ? v(t.games) : v })));
      await searchOne(query, "emu", (v) => setTabs((t) => ({ ...t, emu: typeof v === "function" ? v(t.emu) : v })));
    } else {
      setRes(null);
      await searchOne(query, type, setRes);
    }
  };
  const saveDbg = async () => { try { const rep = "=== ОТЧЁТ ПО РАЗДЕЛАМ ===\n" + ((dbg.current.report || []).join("\n") || "нет") + "\n\n=== ОБРАЗЕЦ HTML (первый непустой ответ) ===\n" + (dbg.current.html || "пусто") + "\n"; const r = await Apps.saveText({ name: "4pda_search_debug.txt", text: (dbg.current.captcha ? "CAPTCHA:true\n" : "") + rep }); alert("Сохранено: " + (r && r.path ? r.path : "Downloads/4pda_search_debug.txt")); } catch (e) { alert("Не удалось сохранить"); } };
  useEffect(() => { if (initialQuery) run(initialQuery); }, []);
  useEffect(() => { if (allMode && (tabs[activeTab] || []).length === 0) { const first = ["apps", "games", "emu"].find((k) => (tabs[k] || []).length > 0); if (first) setActiveTab(first); } }, [tabs]);
  const SORTS = [["match", "По совпадению"], ["name", "По имени"], ["date", "По дате обновления"], ["installs", "По установкам"], ["downloads", "По скачиванию"]];
  const dnum = (s) => { const m = (s || "").match(/(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})/); if (!m) return 0; let y = +m[3]; if (y < 100) y += 2000; return y * 10000 + (+m[2]) * 100 + (+m[1]); };
  const curRes = allMode ? tabs[activeTab] : res;
  const sortedRes = (() => {
    if (!curRes || sort === "match") return curRes;
    const a = [...curRes];
    if (sort === "name") a.sort((x, y) => (x.title || "").localeCompare(y.title || "", "ru"));
    else if (sort === "date") a.sort((x, y) => dnum(y.hatDate) - dnum(x.hatDate));
    else if (sort === "downloads" || sort === "installs") a.sort((x, y) => (y.dl || 0) - (x.dl || 0));
    return a;
  })();
  const TABS = [["apps", "Программы"], ["games", "Игры"], ["emu", "Эмуляторы"]];
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 57 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 26 }}>←</div>
          <span style={{ flex: 1, color: C.text, fontSize: 19, fontWeight: 600 }}>Поиск на сайте{curRes && curRes.length ? " : " + curRes.length : ""}</span>
          <div style={{ position: "relative" }}>
            <div onClick={() => setSortOpen((o) => !o)} title="Сортировка" style={{ cursor: "pointer", padding: "6px 4px", color: "#d0d0d0" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 5v14M6 5l-3 3M6 5l3 3M18 19V5M18 19l-3-3M18 19l3-3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
            {sortOpen && (
              <div style={{ position: "absolute", top: "100%", right: 0, marginTop: 4, background: "#241a11", borderRadius: 10, boxShadow: "0 8px 28px rgba(0,0,0,.55)", overflow: "hidden", zIndex: 5, minWidth: 210 }}>
                {SORTS.map(([k, label]) => <div key={k} onClick={() => { setSort(k); setSortOpen(false); }} style={{ padding: "12px 16px", color: sort === k ? C.acc : C.text, fontSize: 14.5, fontWeight: sort === k ? 700 : 400, cursor: "pointer", whiteSpace: "nowrap" }}>{label}</div>)}
              </div>
            )}
          </div>
        </div>
        {allMode && TABS.some(([k]) => (tabs[k] || []).length > 0) && (
          <div style={{ display: "flex", borderTop: `1px solid ${C.border}` }}>
            {TABS.filter(([k]) => (tabs[k] || []).length > 0).map(([k, label]) => { const n = (tabs[k] || []).length; return <div key={k} onClick={() => setActiveTab(k)} style={{ flex: 1, textAlign: "center", padding: "11px 4px", fontSize: 14, fontWeight: activeTab === k ? 700 : 500, color: activeTab === k ? C.acc : C.sub, borderBottom: activeTab === k ? `2px solid ${C.acc}` : "2px solid transparent", cursor: "pointer" }}>{label} {n}</div>; })}
          </div>
        )}
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }} onClick={() => sortOpen && setSortOpen(false)}>
        {curRes === undefined ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 14 }}>Введите запрос и нажмите поиск</div> :
          curRes === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ищу, подожди...</div> :
            curRes.length === 0 ? <div style={{ textAlign: "center", marginTop: 40 }}>
              <div style={{ color: C.sub, fontSize: 15 }}>{dbg.current.captcha ? "4pda просит капчу для поиска" : "Ничего не найдено"}</div>
              <div style={{ color: C.sub, fontSize: 13, marginTop: 10, padding: "0 20px", lineHeight: 1.4 }}>{dbg.current.captcha ? "Войдите в 4pda через меню (гамбургер) — тогда поиск не будет требовать капчу." : "Попробуйте другой запрос."}</div>
              <div onClick={saveDbg} style={{ color: "#5ab0d8", fontSize: 12.5, marginTop: 18, cursor: "pointer" }}>Сохранить отладку выдачи</div>
            </div> :
              sortedRes.map((r) => <div key={r.topicId} onClick={() => onOpenResult(r)} style={{ display: "flex", gap: 10, alignItems: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7, padding: "9px 10px", cursor: "pointer" }}>
                {r.icon ? <img src={r.icon} alt="" style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, objectFit: "cover" }} /> : <div style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, background: tileColor(r.title || r.topicId), display: "flex", alignItems: "center", justifyContent: "center", color: "#eaeaea", fontWeight: 800, fontSize: 19 }}>{(r.title || "?").trim().charAt(0).toUpperCase()}</div>}
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ color: C.text, fontSize: 15.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.title}</div>
                  <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{r.short || ("4pda · тема " + r.topicId)}</div>
                </div>
              </div>)}
        {curRes && curRes.length > 0 && <div onClick={saveDbg} style={{ color: "#5ab0d8", fontSize: 12, textAlign: "center", marginTop: 6, cursor: "pointer" }}>Сохранить отладку по разделам</div>}
        <div style={{ height: 12 }} />
      </div>
      <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", height: 58, boxSizing: "border-box" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} autoFocus placeholder="Поиск на 4pda" style={{ flex: 1, background: "#222", border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
          <div onClick={() => run()} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
        </div>
      </div>
    </div>
  );
}

function LinkScreen({ app, onClose, onLinked }) {
  const [q, setQ] = useState(app.label || app.packageName);
  const [res, setRes] = useState(undefined);
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const run = async (q0) => {
    const query = (q0 != null ? q0 : q).trim(); if (!query) return;
    setRes(null);
    try {
      let items = [];
      try { const sr = await Apps.webGet({ url: searchUrl4pda(query, "top") }); if (!sr.captcha) items = parseSearchResults(sr.body || ""); } catch {}
      if (!items.length) { try { const sr2 = await Apps.webGet({ url: searchUrl4pda(query, "all") }); if (!sr2.captcha) items = parseSearchResults(sr2.body || ""); } catch {} }
      setRes(items.slice(0, 40));
      items.slice(0, 8).forEach(async (it) => {
        try { const tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }); let b = tr.body; if (tr.captcha || !b || b.length < 800) { const w = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }); b = w.body; } if (!b) return; const p = parseTopic(b); setRes((prev) => (prev ? prev.map((x) => (x.topicId === it.topicId ? { ...x, short: p.short, icon: p.hatIcon } : x)) : prev)); } catch {}
      });
    } catch { setRes([]); }
  };
  useEffect(() => { run(app.label || app.packageName); }, []);
  const pick = async (r) => {
    if (busy) return; setBusy(true);
    try { const html = await fetchTopicHtml(r.topicId); const p = parseTopic(html); onLinked(app.packageName, { topicId: r.topicId, matched: true, notfound: false, ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short }); } catch { onLinked(app.packageName, { topicId: r.topicId, matched: true, notfound: false }); }
    onClose();
  };
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 70 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 26 }}>←</div>
          <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 17, fontWeight: 600 }}>Связать тему</div><div style={{ color: C.sub, fontSize: 12.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div></div>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {busy && <div style={{ color: C.acc, textAlign: "center", marginTop: 20 }}>Связывание…</div>}
        {res === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ищу, подожди...</div> :
          res && res.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ничего не найдено</div> :
            (res || []).map((r) => <div key={r.topicId} onClick={() => setConfirm(r)} style={{ display: "flex", gap: 10, alignItems: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7, padding: "9px 10px", cursor: "pointer" }}>
              {r.icon ? <img src={r.icon} alt="" style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, objectFit: "cover" }} /> : <div style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, background: tileColor(r.title || r.topicId), display: "flex", alignItems: "center", justifyContent: "center", color: "#eaeaea", fontWeight: 800, fontSize: 18 }}>{(r.title || "?").trim().charAt(0).toUpperCase()}</div>}
              <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: C.text, fontSize: 15, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.title}</div><div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{r.short || ("тема " + r.topicId)}</div></div>
            </div>)}
        <div style={{ height: 12 }} />
      </div>
      {confirm && (
        <div onClick={() => setConfirm(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 78, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: "#2a2a2a", borderRadius: 14, padding: 20 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Связать тему?</div>
            <div style={{ color: C.sub, fontSize: 14, marginBottom: 18, wordBreak: "break-word" }}>{confirm.title} · тема {confirm.topicId}</div>
            <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", alignItems: "center" }}>
              <div onClick={() => setConfirm(null)} style={{ cursor: "pointer", color: C.sub, fontSize: 22, padding: "4px 8px" }}>✕</div>
              <div onClick={() => { const r = confirm; setConfirm(null); pick(r); }} style={{ cursor: "pointer", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 15, padding: "10px 18px", borderRadius: 10 }}>Связаться</div>
            </div>
          </div>
        </div>
      )}
      <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", height: 58, boxSizing: "border-box" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} placeholder="Поиск темы на 4pda" style={{ flex: 1, background: "#222", border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
          <div onClick={() => run()} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState(1);
  const [apps, setApps] = useState(null);
  const [sysScreen, setSysScreen] = useState(false);
  const [hidScreen, setHidScreen] = useState(false);
  const [searchScreen, setSearchScreen] = useState(null); // строка-запрос => экран 4pda-поиска
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTypeMenu, setSearchTypeMenu] = useState(false);
  const [searchType, setSearchType] = useState("apps");
  const [searchQuery, setSearchQuery] = useState("");
  const [sel, setSel] = useState(null);
  const [menu, setMenu] = useState(null);   // {app, x, y}
  const [infoApp, setInfoApp] = useState(null);
  const [dlScreen, setDlScreen] = useState(false);
  const [filesData, setFilesData] = useState(null);
  const [topics, setTopics] = useState(() => readCache());
  const [dir, setDir] = useState(1);
  const [anim, setAnim] = useState(null);
  const [selMode, setSelMode] = useState(false);
  const [selected, setSelected] = useState({});
  const [refreshTick, setRefreshTick] = useState(0);
  const [updScreen, setUpdScreen] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [linkApp, setLinkApp] = useState(null);
  const [profile, setProfile] = useState(null);
  const [logoutBusy, setLogoutBusy] = useState(false);
  const loggedRef = useRef(false);
  const [catUrl, setCatUrl] = useState(() => catalogUrl());
  const [catMsg, setCatMsg] = useState("");
  const [idxBusy, setIdxBusy] = useState(false);
  const [idxMsg, setIdxMsg] = useState("");
  useEffect(() => { loadCatalog().then((n) => { if (n) { setCatMsg(n + " связей в каталоге"); setRefreshTick((t) => t + 1); } }); }, []);
  const onLogged = (p) => { setProfile(p); if (p && p.loggedIn && !loggedRef.current) { loggedRef.current = true; try { refresh(); load(); } catch {} } if (p && !p.loggedIn) loggedRef.current = false; };
  useEffect(() => { check4pdaLogin().then(onLogged).catch(() => setProfile({ loggedIn: false })); }, []);
  useEffect(() => { if (drawer) check4pdaLogin().then(onLogged).catch(() => {}); }, [drawer]);
  const updateApps = (apps || []).filter((a) => needsUpdate(a, topics[a.packageName]));
  const updates = updateApps.length;
  const gotoTab = (i) => {
    if (i === active || anim) return;
    const d = i >= active ? 1 : -1;
    setDir(d); setAnim({ from: active, dir: d }); setActive(i);
    setTimeout(() => setAnim(null), 175);
  };
  const tabList = (tab, limit) => {
    const inf = (a) => topics[a.packageName] || {};
    const linked = (a) => inf(a).topicId;
    const userHidden = (a) => inf(a).flags && inf(a).flags.hidden;
    let list = null;
    if (tab === 0) list = apps ? apps.filter((a) => inf(a).flags && inf(a).flags.fav) : apps;
    else if (tab === 1) list = apps ? apps.filter((a) => !a.isGame && !isEmu(a)) : apps;
    else if (tab === 2) list = apps ? apps.filter((a) => a.isGame && !isEmu(a)) : apps;
    else if (tab === 3) list = apps ? apps.filter((a) => isEmu(a)) : apps;
    else if (tab === 4) list = apps ? apps.filter((a) => !linked(a)) : apps;
    if (list && tab !== 0) list = list.filter((a) => !userHidden(a));
    if (list && searchOpen && searchQuery.trim()) {
      const qq = searchQuery.trim().toLowerCase();
      list = list.filter((a) => (a.label || "").toLowerCase().includes(qq) || (a.packageName || "").toLowerCase().includes(qq));
    }
    const msg = (t) => <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>{t}</div>;
    if (list === null) return msg("—");
    if (apps === null) return msg("Загрузка…");
    if (list.length === 0) return msg(tab === 0 ? "В избранном пусто" : tab === 4 ? "Все приложения связаны с 4pda" : tab === 2 ? "Игры не найдены" : tab === 3 ? "Эмуляторы не найдены" : "Приложения не найдены");
    const shown = limit ? list.slice(0, limit) : list;
    return shown.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName]} onOpen={setSel} onMenu={openMenu} onLong={enterSel} selMode={selMode} selected={!!selected[a.packageName]} onToggleSel={toggleSel} />);
  };

  const onFlag = (app, key, val) => onCache(app.packageName, { flags: { ...((readCache()[app.packageName] || {}).flags || {}), [key]: val } });
  const openMenu = (app, e) => { const t = (e && e.touches && e.touches[0]) || e; setMenu({ app, x: t ? t.clientX : null, y: t ? t.clientY : null }); };
  const enterSel = (app) => { setSelMode(true); setSelected({ [app.packageName]: true }); };
  const toggleSel = (app) => setSelected((s) => { const n = { ...s }; if (n[app.packageName]) delete n[app.packageName]; else n[app.packageName] = true; return n; });
  const exitSel = () => { setSelMode(false); setSelected({}); };
  const bulkHide = () => { Object.keys(selected).forEach((pkg) => onCache(pkg, { flags: { ...((readCache()[pkg] || {}).flags || {}), hidden: true } })); exitSel(); };

  // аппаратная «Назад» — закрыть верхний экран/меню, иначе выйти
  useEffect(() => {
    let handle;
    CapApp.addListener("backButton", () => {
      if (drawer) setDrawer(false);
      else if (linkApp) setLinkApp(null);
      else if (infoApp) setInfoApp(null);
      else if (menu) setMenu(null);
      else if (filesData) setFilesData(null);
      else if (sel) setSel(null);
      else if (searchScreen != null) setSearchScreen(null);
      else if (updScreen) setUpdScreen(false);
      else if (searchOpen) { setSearchOpen(false); setSearchQuery(""); }
      else if (sysScreen) setSysScreen(false);
      else if (hidScreen) setHidScreen(false);
      else if (selMode) exitSel();
      else if (dlScreen) setDlScreen(false);
      else CapApp.exitApp();
    }).then((h) => { handle = h; });
    return () => { if (handle) handle.remove(); };
  }, [filesData, menu, infoApp, selMode, dlScreen, sel, searchScreen, searchOpen, updScreen, drawer, linkApp, sysScreen, hidScreen]);

  const onCache = (pkg, patch) => setTopics((prev) => { const next = { ...prev, [pkg]: { ...(prev[pkg] || {}), ...patch } }; try { localStorage.setItem(CKEY, JSON.stringify(next)); } catch {} return next; });

  const load = async () => {
    try {
      const r = await Apps.getInstalledApps({ icons: true, system: false, hidden: false });
      const list = (r.apps || []).slice().sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0));
      setApps(list);
    } catch { setApps(Capacitor.getPlatform() === "web" ? DEMO : []); }
  };
  useEffect(() => { load(); Apps.requestPerms && Apps.requestPerms().catch(() => {}); try { if (!localStorage.getItem("t4_allfiles_asked")) { localStorage.setItem("t4_allfiles_asked", "1"); setTimeout(() => { Apps.requestAllFiles && Apps.requestAllFiles().catch(() => {}); }, 1200); } } catch {}
    // фоново строим индекс каталога 4pda для подстрочного поиска (как ag4pda), если пусто/старее 7 дней
    try {
      const ts = +(localStorage.getItem("t4_idx_apps_ts") || 0);
      if (Date.now() - ts > 7 * 864e5) setTimeout(async () => { try { await buildAppIndex("apps", 40); await buildAppIndex("games", 25); } catch {} }, 4000);
    } catch {}
  }, []);

  // щадящий фоновый автоподбор тем (стоп на капче). refreshTick — перезапуск по кнопке.
  useEffect(() => {
    if (!apps || apps.length === 0) return;
    let stop = false;
    (async () => {
      const cache = readCache();
      const todo = apps.filter((a) => a.packageName && !cache[a.packageName]?.topicId && !cache[a.packageName]?.notfound).slice(0, 12);
      for (const a of todo) {
        if (stop) break;
        try {
          const r = await resolveTopic(a, 3, true);
          if (r === "captcha") break;
          if (r) { const p = parseTopic(r.html); onCache(a.packageName, { topicId: r.topicId, matched: r.matched, ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short }); }
        } catch {}
        try { const pv = await fetchPlayVersion(a.packageName); if (pv) onCache(a.packageName, { verPlay: pv.name, verPlayCode: pv.code }); } catch {}
        await new Promise((res) => setTimeout(res, 800));
      }
    })();
    return () => { stop = true; };
  }, [apps, refreshTick]);

  // кнопка «Обновить»: сбросить «не найдено» и перезапустить подбор/проверку
  const refresh = () => {
    const c = readCache();
    Object.keys(c).forEach((pkg) => { if (c[pkg] && c[pkg].notfound && !c[pkg].topicId) { delete c[pkg].notfound; } });
    try { localStorage.setItem(CKEY, JSON.stringify(c)); } catch {}
    setTopics({ ...c });
    setRefreshTick((t) => t + 1);
  };

  const touch = useRef({ x: 0, y: 0 });
  const onTouchStart = (e) => { const t = e.touches[0]; touch.current = { x: t.clientX, y: t.clientY }; };
  const onTouchEnd = (e) => { const t = e.changedTouches[0]; const dx = t.clientX - touch.current.x, dy = t.clientY - touch.current.y; if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) { if (dx < 0) gotoTab(Math.min(active + 1, TABS.length - 1)); else gotoTab(Math.max(active - 1, 0)); } };

  return (
    <div style={{ height: "100vh", background: C.bg, display: "flex", flexDirection: "column", fontFamily: "Roboto, system-ui, sans-serif", overflow: "hidden", WebkitUserSelect: "none", userSelect: "none", WebkitTapHighlightColor: "transparent" }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "0 16px", height: 56 }}>
          <div onClick={() => setDrawer(true)} style={{ width: 26, height: 20, display: "flex", flexDirection: "column", justifyContent: "space-between", cursor: "pointer" }}>{[0, 1, 2].map((i) => <span key={i} style={{ height: 2, borderRadius: 2, background: "#e0e0e0" }} />)}</div>
          <span style={{ color: C.text, fontSize: 22, fontWeight: 600 }}>4PDApps</span>
        </div>
      </div>

      {drawer && (
        <div onClick={() => setDrawer(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 80, display: "flex" }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: 280, maxWidth: "82%", height: "100%", background: "#1c1c1c", paddingTop: "env(safe-area-inset-top)", boxShadow: "2px 0 20px rgba(0,0,0,.5)" }}>
            {profile && profile.loggedIn ? (
              <>
                <div style={{ padding: "22px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 12 }}>
                  {profile.avatar ? <img src={profile.avatar} alt="" style={{ width: 50, height: 50, borderRadius: "50%", objectFit: "cover" }} /> : <div style={{ width: 50, height: 50, borderRadius: "50%", background: tileColor(profile.name || "u"), display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 22 }}>{(profile.name || "?").trim().charAt(0).toUpperCase()}</div>}
                  <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 17, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{profile.name}</div><div style={{ color: C.acc, fontSize: 12 }}>вы вошли на 4pda</div></div>
                </div>
                <div onClick={async () => { if (logoutBusy) return; setLogoutBusy(true); await logout4pda(profile.logoutK); const p = await check4pdaLogin(); setProfile(p && p.loggedIn ? p : { loggedIn: false }); setLogoutBusy(false); }} style={{ padding: "16px 18px", color: "#e5675e", fontSize: 15.5, cursor: "pointer" }}>{logoutBusy ? "Выхожу…" : "Выйти из 4pda"}</div>
              </>
            ) : (
              <>
                <div style={{ padding: "20px 18px", borderBottom: `1px solid ${C.border}`, color: C.text, fontSize: 20, fontWeight: 700 }}>4PDApps</div>
                <div onClick={() => { Apps.openWeb({ url: "https://4pda.to/forum/index.php?act=auth" }).catch(() => {}); setDrawer(false); }} style={{ padding: "16px 18px", color: C.text, fontSize: 15.5, cursor: "pointer" }}>Войти в 4pda</div>
                <div style={{ padding: "14px 18px", color: C.sub, fontSize: 12.5, lineHeight: 1.4 }}>После входа связь и поиск на 4pda работают стабильнее (проходит Cloudflare), а список обновится автоматически.</div>
              </>
            )}
            <div style={{ padding: "16px 18px", borderTop: `1px solid #262626` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Файлы</div>
              <div onClick={() => { const v = localStorage.getItem("t4_files_myarch") !== "0"; localStorage.setItem("t4_files_myarch", v ? "0" : "1"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                <span style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.35 }}>Отображать файлы только под мой процессор</span>
                {(() => { const on = localStorage.getItem("t4_files_myarch") !== "0"; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : "#444", flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
              </div>
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid #262626` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>Тип поиска</div>
              <div onClick={() => { const v = localStorage.getItem("t4_search_all") === "1"; localStorage.setItem("t4_search_all", v ? "0" : "1"); setRefreshTick((t) => t + 1); }} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer", gap: 12 }}>
                <span style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.35 }}>Искать всё сразу (Программы, Игры, Эмуляторы во вкладках)</span>
                {(() => { const on = localStorage.getItem("t4_search_all") === "1"; return <div style={{ width: 42, height: 24, borderRadius: 12, background: on ? C.acc : "#444", flexShrink: 0, position: "relative", transition: "background .15s" }}><div style={{ position: "absolute", top: 2, left: on ? 20 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left .15s" }} /></div>; })()}
              </div>
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid #262626` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>Каталог приложений 4pda (подстрочный поиск)</div>
              <div style={{ color: C.sub, fontSize: 12.5, lineHeight: 1.35, marginBottom: 10 }}>Индекс из дайджестов 4pda — находит по части названия (habit → Habitica), как ag4pda. Строится сам в фоне, но можно обновить вручную.</div>
              <div onClick={async () => { if (idxBusy) return; setIdxBusy(true); setIdxMsg("Строю индекс…"); try { const a = await buildAppIndex("apps", 60, (p, n) => setIdxMsg(`Программы: стр. ${p}, найдено ${n}`)); setIdxMsg(`Игры…`); const g = await buildAppIndex("games", 40, (p, n) => setIdxMsg(`Игры: стр. ${p}, найдено ${n}`)); setIdxMsg(`Готово: ${a} программ, ${g} игр`); } catch { setIdxMsg("Ошибка построения"); } setIdxBusy(false); }} style={{ display: "inline-block", background: idxBusy ? "#333" : C.acc, color: idxBusy ? C.sub : "#04210f", fontWeight: 700, fontSize: 13.5, padding: "9px 16px", borderRadius: 9, cursor: idxBusy ? "default" : "pointer" }}>{idxBusy ? "Строю…" : "Обновить каталог"}</div>
              {idxMsg && <div style={{ color: C.sub, fontSize: 12.5, marginTop: 8 }}>{idxMsg}</div>}
              {(() => { try { const n = JSON.parse(localStorage.getItem("t4_idx_apps") || "[]").length; return n ? <div style={{ color: "#7a9a6a", fontSize: 12, marginTop: 4 }}>В индексе: {n} программ</div> : null; } catch { return null; } })()}
            </div>
            <div style={{ padding: "16px 18px", borderTop: `1px solid #262626` }}>
              <div style={{ color: C.text, fontSize: 13.5, fontWeight: 600, marginBottom: 8 }}>Каталог связей (URL JSON)</div>
              <input value={catUrl} onChange={(e) => setCatUrl(e.target.value)} placeholder="https://…/catalog.json" style={{ width: "100%", boxSizing: "border-box", background: "#222", border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 13, padding: "8px 10px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
              <div onClick={async () => { try { localStorage.setItem("t4_catalog_url", catUrl.trim()); } catch {} setCatMsg("Загрузка…"); const n = await loadCatalog(); setCatMsg(n ? n + " связей загружено" : "Не удалось загрузить"); if (n) setRefreshTick((t) => t + 1); }} style={{ marginTop: 8, display: "inline-block", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 13.5, padding: "8px 14px", borderRadius: 8, cursor: "pointer" }}>Загрузить каталог</div>
              {catMsg && <div style={{ color: C.sub, fontSize: 12, marginTop: 8 }}>{catMsg}</div>}
              <div style={{ color: C.sub, fontSize: 11.5, marginTop: 8, lineHeight: 1.4 }}>Формат: {"{ \"пакет\": id_темы }"}. Базу строишь вне телефона (Cloudflare мешает парсить на устройстве) и хостишь по URL.</div>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: "flex", background: C.bar, overflowX: "auto", borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
        {TABS.map((t, i) => <div key={i} onClick={() => gotoTab(i)} style={{ padding: "13px 9px", whiteSpace: "nowrap", position: "relative", cursor: "pointer" }}><span style={{ color: i === active ? C.active : "#7f7f7f", fontSize: 13.5, fontWeight: 600, letterSpacing: 0.1 }}>{t}</span>{i === active && <div style={{ position: "absolute", left: 8, right: 8, bottom: 0, height: 3, borderRadius: 3, background: "#8a8a8a" }} />}</div>)}
      </div>

      <style>{"@keyframes pgF{from{transform:translateX(0)}to{transform:translateX(-50%)}}@keyframes pgB{from{transform:translateX(-50%)}to{transform:translateX(0)}}"}</style>
      <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", position: "relative" }} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
        {anim ? (
          <div style={{ display: "flex", width: "200%", animation: (anim.dir > 0 ? "pgF" : "pgB") + " .17s linear", willChange: "transform" }}>
            {anim.dir > 0 ? <>
              <div style={{ width: "50%", padding: "10px 10px 0", boxSizing: "border-box" }}>{tabList(anim.from, 12)}</div>
              <div style={{ width: "50%", padding: "10px 10px 0", boxSizing: "border-box" }}>{tabList(active, 12)}</div>
            </> : <>
              <div style={{ width: "50%", padding: "10px 10px 0", boxSizing: "border-box" }}>{tabList(active, 12)}</div>
              <div style={{ width: "50%", padding: "10px 10px 0", boxSizing: "border-box" }}>{tabList(anim.from, 12)}</div>
            </>}
          </div>
        ) : (
          <div style={{ padding: "10px 10px 0" }}>{tabList(active)}<div style={{ height: 12 }} /></div>
        )}
      </div>

      {searchOpen && (
        <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "env(safe-area-inset-bottom)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", height: 58, boxSizing: "border-box" }}>
            <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && searchQuery.trim()) setSearchScreen(searchQuery.trim()); }} autoFocus placeholder={`Поиск: ${searchType === "games" ? "Игры" : searchType === "emu" ? "Эмуляторы" : "Программы"} · Enter`} style={{ flex: 1, background: "#222", border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
            <div onClick={() => searchQuery.trim() && setSearchScreen(searchQuery.trim())} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
            <div onClick={() => { setSearchOpen(false); setSearchQuery(""); }} style={{ cursor: "pointer", color: C.sub, fontSize: 20, padding: "0 4px" }}>✕</div>
          </div>
        </div>
      )}

      {!searchOpen && searchTypeMenu && (
        <div onClick={() => setSearchTypeMenu(false)} style={{ position: "fixed", inset: 0, zIndex: 40 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", bottom: "calc(env(safe-area-inset-bottom) + 62px)", background: "#241a11", borderRadius: 12, boxShadow: "0 8px 28px rgba(0,0,0,.55)", overflow: "hidden", minWidth: 200 }}>
            {[["emu", "Эмуляторы"], ["games", "Игры"], ["apps", "Программы"]].map(([k, label]) => (
              <div key={k} onClick={() => { setSearchType(k); setSearchTypeMenu(false); setSearchOpen(true); }} style={{ padding: "14px 18px", color: C.text, fontSize: 15.5, cursor: "pointer", borderTop: k !== "emu" ? `1px solid ${C.border}` : "none" }}>{label}</div>
            ))}
          </div>
        </div>
      )}
      {!searchOpen && <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around", height: 58 }}>
          <NavBtn title="Системные" onClick={() => setSysScreen(true)}><IAndroid /></NavBtn>
          <NavBtn title="Скрытые" onClick={() => setHidScreen(true)}><IEyeOff /></NavBtn>
          <NavBtn title="Каталог" onClick={() => Apps.openWeb({ url: "https://4pda.to/forum/index.php?showforum=213" }).catch(() => {})}><ICatalog /></NavBtn>
          <NavBtn title="Загрузки" onClick={() => setDlScreen(true)}><IDownload /></NavBtn>
          <NavBtn title="Поиск" onClick={() => { if (localStorage.getItem("t4_search_all") === "1") { setSearchScreen(""); } else { setSearchTypeMenu((v) => !v); } }}><ISearch /></NavBtn>
          <NavBtn title="Обновить" onClick={refresh}><IRefresh /></NavBtn>
          <NavBtn title="Обновления" onClick={() => updates > 0 && setUpdScreen(true)}><div style={{ width: 34, height: 34, borderRadius: "50%", border: `2px solid ${updates > 0 ? "#e5675e" : "#5a5a5a"}`, background: updates > 0 ? "#e5675e" : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: updates > 0 ? "#fff" : "#d0d0d0", fontSize: 14, fontWeight: 700 }}>{updates}</span></div></NavBtn>
        </div>
      </div>}

      {sel && <Detail app={sel} onClose={() => setSel(null)} onCache={onCache} onFiles={setFilesData} onDownloads={() => { setSel(null); setDlScreen(true); }} onSimilar={() => { const q = sel.label || sel.packageName; setSel(null); setSearchScreen(q); }} />}
      {menu && <ContextMenu app={menu.app} x={menu.x} y={menu.y} info={topics[menu.app.packageName]} onClose={() => setMenu(null)} onInfo={(a) => { setMenu(null); setInfoApp(a); }} onFlag={onFlag} onLink={(a) => { setMenu(null); setLinkApp(a); }} />}
      {linkApp && <LinkScreen app={linkApp} onClose={() => setLinkApp(null)} onLinked={(pkg, patch) => { onCache(pkg, patch); }} />}
      {infoApp && <InfoDialog app={infoApp} info={topics[infoApp.packageName]} onClose={() => setInfoApp(null)} />}
      {dlScreen && <Downloads onClose={() => setDlScreen(false)} />}
      {filesData && <FilesDialog app={filesData.app} files={filesData.files} dlPosts={filesData.dlPosts} mode={filesData.mode} onDownloads={filesData.onDownloads} onClose={() => setFilesData(null)} />}
      {sysScreen && <SubList title="Системные" loadSystem topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setSysScreen(false)} />}
      {hidScreen && <SubList title="Скрытые" initial={(apps || []).filter((a) => topics[a.packageName] && topics[a.packageName].flags && topics[a.packageName].flags.hidden)} topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setHidScreen(false)} />}
      {searchScreen != null && <SearchScreen initialQuery={searchScreen} searchType={localStorage.getItem("t4_search_all") === "1" ? "all" : searchType} onClose={() => setSearchScreen(null)} onOpenResult={(r) => { setSel({ label: r.title, packageName: "topic:" + r.topicId, topicId: r.topicId }); }} />}
      {updScreen && <SubList title="Доступные обновления" initial={updateApps} topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setUpdScreen(false)} />}

      {selMode && (
        <div style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 58, paddingTop: "env(safe-area-inset-top)", background: C.acc }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}>
            <div onClick={exitSel} style={{ cursor: "pointer", color: "#04210f", fontSize: 22, width: 26 }}>✕</div>
            <span style={{ color: "#04210f", fontSize: 18, fontWeight: 700, flex: 1 }}>Выбрано: {Object.keys(selected).length}</span>
            <div onClick={bulkHide} style={{ cursor: "pointer", color: "#04210f", fontWeight: 700, fontSize: 15 }}>Скрыть</div>
          </div>
        </div>
      )}
    </div>
  );
}
