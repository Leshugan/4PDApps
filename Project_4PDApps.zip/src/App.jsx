import { useState, useEffect, useRef } from "react";
import { registerPlugin, Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";

const Apps = registerPlugin("Apps");

const C = {
  bg: "#0d0d0d", bar: "#161616", card: "#1c1c1c", border: "#2a2a2a",
  text: "#e9e9e9", sub: "#8c8c8c", date: "#7c7c7c", active: "#ffffff",
  nav: "#c9c9c9", acc: "#34C759", blue: "#1e88e5", green: "#43a047", divider: "#2c2c2c",
};
const TABS = ["ИЗБРАННОЕ", "ПРИЛОЖЕНИЯ", "ИГРЫ", "ЭМУЛЯТОРЫ", "НЕ СВЯЗАННЫЕ"];
const DEMO = [
  { packageName: "com.android.chrome", label: "Chrome", versionName: "126.0", lastUpdate: Date.now() },
  { packageName: "org.telegram.messenger", label: "Telegram", versionName: "11.1.0", lastUpdate: Date.now() - 864e5 },
];

const pad = (n) => String(n).padStart(2, "0");
const fmtDate = (ms) => { if (!ms) return ""; const d = new Date(ms); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; };
const tileColor = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return `hsl(${h % 360} 42% 30%)`; };

// сравнение версий: 1 если a>b, -1 если a<b, 0 равны
function verCmp(a, b) {
  if (!a || !b) return 0;
  const pa = String(a).split(/[.\-_ ]/).map((x) => parseInt(x, 10));
  const pb = String(b).split(/[.\-_ ]/).map((x) => parseInt(x, 10));
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = isNaN(pa[i]) ? 0 : pa[i], y = isNaN(pb[i]) ? 0 : pb[i];
    if (x > y) return 1; if (x < y) return -1;
  }
  return 0;
}
const hideForum = (f) => !!(f && (f.hideAll || f.hideForum));
const hidePlay = (f) => !!(f && (f.hideAll || f.hidePlay));
const EMU_RE = /(emulator|emulador|эмулятор|retroarch|ppsspp|dolphin|epsxe|drastic|citra|yuzu|ryujinx|pcsx|redream|duckstation|mupen|melonds|dosbox|scummvm|winlator|exagear|\bmame\b|fpse|nostalgia|reicast|flycast|aethersx|eka2l1|vita3k|snes9|nesoid|gameboy|\bgba\b|vgba|gbanext|john\s?(nes|gba|snes)|matsu|myboy|my\s?boy|\bnds\b|\bn64\b|\bpsx\b|\bpsp\b|\bnes\b|\bsnes\b|\bgbc\b|\bsega\b|megadrive|genesis|dolphin|pizza\s?boy|lemuroid|classicboy|md\.emu|nds4droid|citrondb|skyline|xbsx2|damon|octopus|happychick|gamesir)/i;
const isEmu = (a) => !!a && (EMU_RE.test(a.packageName || "") || EMU_RE.test(a.label || ""));
const upd4 = (app, info) => !!(info && info.ver4pda && verCmp(info.ver4pda, app.versionName) > 0);
const updP = (app, info) => !!(info && info.verPlay && verCmp(info.verPlay, app.versionName) > 0);
// нужно ли обновление (новее установленной и не скрыто пользователем)
const needsUpdate = (app, info) => {
  if (!info || !app) return false;
  const f = info.flags || {};
  return (upd4(app, info) && !hideForum(f)) || (updP(app, info) && !hidePlay(f));
};

// архитектуры устройства (для выбора нужного apk)
let DEVICE_ABIS = [];
Apps.deviceAbis().then((r) => { DEVICE_ABIS = r.abis || []; }).catch(() => {});
const ABI_TOKENS = { "arm64-v8a": ["arm64", "arm8a", "aarch64", "v8a"], "armeabi-v7a": ["arm7a", "armeabi", "armv7", "v7a"], "x86_64": ["x86_64", "x86-64", "x64"], "x86": ["x86"] };
function fileForDevice(name) {
  const n = (name || "").toLowerCase();
  if (!/(arm64|arm7a|armeabi|armv7|x86|aarch64|v8a|v7a)/.test(n)) return true;
  for (const abi of DEVICE_ABIS) for (const t of (ABI_TOKENS[abi] || [])) if (n.includes(t)) return true;
  return false;
}

// ссылки 4pda / play
const q4 = (app) => encodeURIComponent(app.label || app.packageName);
const topicUrl = (app) => app.topicId ? `https://4pda.to/forum/index.php?showtopic=${app.topicId}` : `https://4pda.to/forum/index.php?act=search&query=${q4(app)}`;
const openTopicApp = (app) => Apps.openWeb({ url: topicUrl(app) }).catch(() => {});
const openPlay = (app) => Apps.openUrl({ url: `market://details?id=${app.packageName}` }).catch(() => Apps.openUrl({ url: `https://play.google.com/store/apps/details?id=${app.packageName}` }));

// --- парсинг темы 4pda ---
function parseTopic(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const firstBody = doc.querySelector(".post_body") || doc.querySelector(".postcolor");
  let hatIcon = "";
  if (firstBody) { const im0 = firstBody.querySelector("img"); if (im0) { const s0 = im0.getAttribute("data-src") || im0.getAttribute("src") || ""; if (s0.indexOf("http") === 0) hatIcon = s0; } }
  let forumDate = "";
  try { const pd = doc.querySelector(".post_date"); if (pd) forumDate = (pd.textContent || "").replace(/\s+/g, " ").trim(); } catch {}
  // скриншоты (прикреплённые картинки) — отдельной лентой
  const screenshots = [];
  if (firstBody) {
    firstBody.querySelectorAll("img.linked-image, a.ipb-attach img, .post-block img").forEach((im) => {
      const src = im.getAttribute("data-src") || im.getAttribute("src") || "";
      const full = im.getAttribute("data-preview") || src;
      if (src && src.indexOf("http") === 0) screenshots.push({ thumb: src, full });
      im.remove();
    });
  }
  let descHtml = firstBody ? firstBody.innerHTML : "";
  descHtml = descHtml.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "");
  descHtml = descHtml.replace(/<span[^>]*class="[^"]*edit[^"]*"[\s\S]*?<\/span>/gi, "");
  descHtml = descHtml.replace(/Сообщение отредактировал[\s\S]*?(?:Причина редактирования:[^<]*)?(?=<div|<br|<span|<p|$)/gi, "");
  descHtml = descHtml.replace(/<div[^>]*class="[^"]*signature[^"]*"[\s\S]*?<\/div>/gi, "");
  const tmp = document.createElement("div"); tmp.innerHTML = descHtml;
  const descText = (tmp.textContent || "").replace(/\s+/g, " ").trim();
  let ver4pda = "";
  const vm = descText.match(/верси[яию]\s*:?\s*([0-9][0-9.]*)/i);
  if (vm) ver4pda = vm[1];

  const scope = firstBody || doc;
  const seen = new Set();
  const files = [];
  scope.querySelectorAll("a.attach-file").forEach((a) => {
    let url = a.getAttribute("href") || "";
    if (!url) return;
    if (url.indexOf("//") === 0) url = "https:" + url;
    if (url.indexOf("http") !== 0) url = "https://4pda.to" + (url[0] === "/" ? "" : "/") + url;
    const m = url.match(/\/dl\/post\/(\d+)\/([^?#]+)/i);
    if (!m || seen.has(m[1])) return;
    seen.add(m[1]);
    let name = m[2]; try { name = decodeURIComponent(m[2]); } catch { name = m[2].replace(/%[0-9a-f]{0,2}/gi, ""); }
    name = name.replace(/\+/g, " ").trim();
    if (!/\.(apk|apks|xapk|zip|obb|rar|7z)$/i.test(name)) return;
    let size = "";
    let sib = a.nextSibling, guard = 0;
    while (sib && guard < 4 && !size) { if (sib.nodeType === 3) { const s = (sib.textContent || "").match(/\(([^)]+)\)/); if (s) size = s[1].trim(); } sib = sib.nextSibling; guard++; }
    let dl = "";
    const el = a.nextElementSibling;
    if (el && (el.className || "").indexOf("desc") >= 0) dl = (el.textContent || "").replace(/\D/g, "");
    files.push({ id: m[1], name, url: url.replace(/&amp;/g, "&"), size, downloads: dl });
  });
  if (!ver4pda && files[0]) { const fm = files[0].name.match(/([0-9]+(?:\.[0-9]+)+)/); if (fm) ver4pda = fm[1]; }
  // краткое описание как у ag4pda: блок «Краткое описание …» до следующего раздела; иначе пусто (без версии/дат)
  let short = "";
  const sm = descText.match(/краткое описание\s*:?\s*(.+?)(?:\s*(?:полное\s+описание|^описание\b|описание\s*:|системные требования|требовани|что нового|русский интерфейс|разработчик|версия\s*:|официальн|скриншот)|$)/i);
  if (sm) short = sm[1];
  else { const dm = descText.match(/описание\s*:?\s*(.{8,}?)(?:\s*(?:системные требовани|требовани|что нового|версия\s*:|скриншот)|$)/i); if (dm) short = dm[1]; }
  short = short.replace(/^[\s:–\-—]+/, "").replace(/\s+/g, " ").trim().slice(0, 140);
  const hm = descText.match(/шапке\s*:?\s*(\d{1,2}\.\d{1,2}\.\d{2,4})/i);
  const hatDate = hm ? hm[1] : "";
  let title = "";
  try { const t = doc.querySelector("title"); if (t) title = (t.textContent || "").replace(/\s*[-–|]\s*4PDA.*$/i, "").replace(/&amp;/g, "&").trim(); } catch {}
  // основное описание (как у ag4pda): блок «Описание …» до следующего раздела; чистим от версии/требований/чейнджлога
  const SECT = "(?:что нового|нововведени|системные требовани|требовани|особенности|поддерживаем|скриншот|снимк|разработчик|версия\\s*:|последнее обновление|перевод|автор перевода|сборк|скачать|download)";
  let descMain = "";
  const dmm = descText.match(new RegExp("(?:краткое описание[\\s\\S]*?)?(?:^|[\\s.:])описание\\s*:?\\s*([\\s\\S]+?)(?=" + SECT + "|$)", "i"));
  if (dmm && dmm[1].trim().length > 20) descMain = dmm[1].trim();
  else { descMain = descText.split(new RegExp(SECT, "i"))[0].replace(/^краткое описание\s*:?/i, "").trim(); }
  descMain = descMain.replace(/^[\s:–\-—]+/, "").slice(0, 2500);
  return { descHtml, descMain, descText, short, ver4pda, hatDate, forumDate, title, hatIcon, files, screenshots };
}
// windows-1251 URL-кодирование (форумный поиск 4pda требует cp1251)
function cp1251(str) {
  let out = "";
  for (const ch of str) {
    const c = ch.charCodeAt(0);
    let byte = -1;
    if (c < 128) { out += encodeURIComponent(ch); continue; }
    else if (c >= 0x0410 && c <= 0x044F) byte = c - 0x0410 + 0xC0;
    else if (c === 0x0401) byte = 0xA8;
    else if (c === 0x0451) byte = 0xB8;
    if (byte < 0) { out += encodeURIComponent(ch); continue; }
    out += "%" + byte.toString(16).toUpperCase().padStart(2, "0");
  }
  return out;
}
// правильный URL форумного поиска 4pda (noform=1 => сразу результаты, а не форма)
const searchUrl4pda = (query, source = "top", st = 0) =>
  `https://4pda.to/forum/index.php?act=search&result=topics&sort=dd&source=${source}&query=${cp1251(query)}&forums=212&forums=213&subforums=1&noform=1&st=${st}&exclude_trash=0`;

// разбор страницы результатов поиска: [{topicId, title}] за один запрос
function parseSearchResults(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const out = [], seen = new Set();
  const nonAndroid = /\[(ios|iphone|ipad|ipados|desktop|windows|win(?:32|64)?|wp7|wp8|wp10|wp7-10|wp|mac(?:os)?|symbian|linux|web(?:os)?|java|bada|blackberry|bb10?|tizen|kaios)\]/i;
  const discuss = /\?|ошибк|не работает|не запуска|не устанавлива|помогите|\bкак \b|при установке|клон\s|глюк|вылета|зависа|тормоз|прошивк/i;
  const marker = /^(новые|новый|последн|перейти|ответить|цитата|»+|«+|→|\d+|\.+)$/i;
  doc.querySelectorAll('a[href*="showtopic="], a[href*="/forum/topic/"]').forEach((a) => {
    const href = a.getAttribute("href") || "";
    // служебные ссылки (переход к новым/последним постам, поиск поста, пагинация) — не заголовки тем
    if (/view=getnewpost|view=getlastpost|view=findpost|[?&]st=\d|#entry|&pid=/i.test(href)) return;
    const m = href.match(/(?:showtopic=|\/forum\/topic\/)(\d{3,})/);
    if (!m || seen.has(m[1])) return;
    const title = (a.textContent || "").replace(/\s+/g, " ").trim();
    if (title.length < 3 || marker.test(title)) return;
    if (nonAndroid.test(title) || discuss.test(title)) return;
    seen.add(m[1]);
    out.push({ topicId: m[1], title });
  });
  return out;
}

const playPkg = (html) => {  let m = html.match(/play\.google\.com\/store\/apps\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  if (m) return m[1];
  m = html.match(/market:\/\/details\?[^"'<>\s]*id=([a-zA-Z0-9._]+)/i);
  return m ? m[1] : null;
};
function topicIds(html) {
  const ids = [], seen = new Set();
  // showtopic=<id> (в т.ч. относительные ссылки) И новый формат /forum/topic/<id>
  const re = /(?:showtopic=|\/forum\/topic\/)(\d{3,})/gi;
  let m; while ((m = re.exec(html)) !== null) if (!seen.has(m[1])) { seen.add(m[1]); ids.push(m[1]); }
  return ids;
}

// поиск темы: собираем кандидатов из поиска 4pda (пакет+название) и Google (site:4pda.to),
// берём ТОЛЬКО тему, где в шапке ссылка Play с этим пакетом. "captcha" | {topicId,html} | null
const isAppPage = (html) => !!(playPkg(html) || /dw_button|onclick="dw\(|nav_download|attach_id=|Загрузить с сервера|"attachment"|post-attach/i.test(html));

const realTopic = (b) => !!b && (b.indexOf("post_body") >= 0 || b.indexOf("postcolor") >= 0);
async function fetchTopicHtml(id) {
  let tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${id}` });
  if (tr.captcha || !realTopic(tr.body)) { try { tr = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${id}` }); } catch {} }
  return tr && tr.body ? tr.body : "";
}
async function check4pdaLogin() {
  let html = "";
  try {
    const r = await Apps.httpGet({ url: "https://4pda.to/forum/index.php" });
    html = r.body || "";
    if (r.captcha || !/logout/i.test(html) || html.length < 2000) { try { const w = await Apps.webGet({ url: "https://4pda.to/forum/index.php" }); if ((w.body || "").length > html.length) html = w.body; } catch {} }
  } catch {}
  const kk = html.match(/(?:act|action)=logout[^"'<>]*?k=([a-f0-9]{32})/i) || html.match(/logout[^"'<>]{0,40}?[?&]k=([a-f0-9]{32})/i);
  if (!kk) return { loggedIn: false };
  const uid = (html.match(/showuser=(\d+)/) || [])[1] || "";
  let name = "", avatar = "";
  if (uid) {
    try {
      const pr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` });
      let pb = pr.body || "";
      if (pr.captcha || pb.length < 1500) { try { const w = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showuser=${uid}` }); if ((w.body || "").length > pb.length) pb = w.body; } catch {} }
      name = (pb.match(/<title>\s*([^<]+?)\s*(?:[-–—]\s*Просмотр профиля|<\/title>)/i) || [])[1] || "";
      name = name.replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
      avatar = (pb.match(/<img[^>]+src="([^"]+)"[^>]*class="[^"]*avatar/i)
        || pb.match(/class="[^"]*avatar[^"]*"[^>]*>\s*<img[^>]+src="([^"]+)"/i)
        || pb.match(/src="(https?:\/\/[^"']*\/(?:uploads|avatar)[^"']+\.(?:jpg|jpeg|png|gif|webp))"/i)
        || [])[1] || "";
    } catch {}
  }
  if (!avatar) avatar = (html.match(/<img[^>]+class="[^"]*avatar[^"]*"[^>]+src="([^"]+)"/i) || [])[1] || "";
  if (avatar && avatar.indexOf("//") === 0) avatar = "https:" + avatar;
  return { loggedIn: true, userId: uid, name: name || ("Профиль" + (uid ? " id" + uid : "")), avatar, logoutK: kk[1] };
}
async function logout4pda(k) {
  try { await Apps.webGet({ url: `https://4pda.to/forum/index.php?act=logout&CODE=03&k=${k}` }); } catch {}
  try { await Apps.httpGet({ url: `https://4pda.to/forum/index.php?act=logout&CODE=03&k=${k}` }); } catch {}
}
function titleScore(title, label) {
  const t = (title || "").toLowerCase().trim(), l = (label || "").toLowerCase().trim();
  if (!t || !l) return 0;
  if (/(клуб|club|чат|\bчата\b|обсужд|fanclub|фан-?клуб|курилк|флудил|вопрос|faq по)/i.test(t)) return 5; // не тема приложения
  if (t === l) return 100;
  if (t === l + " [android]" || t === l + " [андроид]") return 98;
  if (/\[android\]|\[андроид\]/i.test(t) && t.replace(/\s*\[[^\]]*\]\s*/g, "") === l) return 95;
  if (t.replace(/\s*\[[^\]]*\]\s*/g, "").trim() === l) return 90; // «Имя [что-то]» == имя
  if (t.indexOf(l + " ") === 0 || t.indexOf(l + " [") === 0) return 60;
  if (t.indexOf(l) >= 0) return 40;
  return 8;
}
async function resolveTopic(app, maxCand = 8, useGoogle = true) {
  const cands = [];
  const add = (arr) => { for (const r of arr) if (!cands.find((c) => c.topicId === r.topicId)) cands.push(r); };
  const nameQ = app.label && app.label !== app.packageName ? app.label : app.packageName;
  try { const sr = await Apps.webGet({ url: searchUrl4pda(nameQ, "top") }); if (sr.captcha) return "captcha"; add(parseSearchResults(sr.body || "")); } catch {}
  if (!cands.length) { try { const sr2 = await Apps.webGet({ url: searchUrl4pda(app.packageName, "all") }); add(parseSearchResults(sr2.body || "")); } catch {} }
  if (!cands.length) return null;
  cands.sort((a, b) => titleScore(b.title, nameQ) - titleScore(a.title, nameQ));
  let best = null;
  for (let i = 0; i < Math.min(cands.length, maxCand); i++) {
    try {
      const html = await fetchTopicHtml(cands[i].topicId);
      if (!html) continue;
      if (playPkg(html) === app.packageName) return { topicId: cands[i].topicId, matched: true, html };
      // запасной вариант — только для тем с сильным совпадением названия (не «Club»/обсуждение)
      if (!best && titleScore(cands[i].title, nameQ) >= 90 && isAppPage(html)) best = { topicId: cands[i].topicId, matched: false, html };
    } catch {}
  }
  return best;
}
async function fetchPlayVersion(pkg) {
  // 1) через gplayapi (анонимно, без входа) — точная версия + код
  try { const r = await Apps.playVersion({ packageName: pkg }); if (r && r.versionName) return { name: r.versionName, code: r.versionCode || "" }; } catch {}
  // 2) откат: парсинг HTML Play (ненадёжно)
  for (const hl of ["ru", "en"]) {
    try {
      const r = await Apps.httpGet({ url: `https://play.google.com/store/apps/details?id=${pkg}&hl=${hl}&gl=US` });
      const b = r.body || "";
      let m = b.match(/\[\[\["([0-9][0-9A-Za-z.\-_]*)"\]\],\s*\[/);
      if (m) return { name: m[1], code: "" };
      m = b.match(/"softwareVersion"\s*:\s*"([^"]+)"/i); if (m) return { name: m[1].trim(), code: "" };
      m = b.match(/Current Version[\s\S]{0,120}?([0-9]+\.[0-9][0-9A-Za-z.\-_]*)/i); if (m) return { name: m[1], code: "" };
    } catch {}
  }
  return null;
}

// --- кэш пакет→тема (localStorage) ---
const CKEY = "t4_cache_v1";
function readCache() { try { return JSON.parse(localStorage.getItem(CKEY) || "{}"); } catch { return {}; } }

function Icon({ app, size = 56 }) {
  const box = { width: size, height: size, borderRadius: size * 0.25, flexShrink: 0, overflow: "hidden" };
  const src = app.iconFile ? Capacitor.convertFileSrc(app.iconFile) : (app.icon || null);
  if (src) return <img src={src} alt="" style={{ ...box, objectFit: "cover" }} loading="lazy" />;
  const letter = (app.label || app.packageName || "?").trim().charAt(0).toUpperCase();
  return <div style={{ ...box, background: tileColor(app.packageName || app.label || "?"), display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#eaeaea", fontWeight: 800, fontSize: size * 0.43 }}>{letter}</span></div>;
}

const Mini = ({ kind }) => {
  if (kind === "inst") return <svg width="14" height="14" viewBox="0 0 24 24"><path fill={C.green} d="M18 2H8.83c-.53 0-1.04.21-1.41.59L2.59 7.41C2.21 7.79 2 8.3 2 8.83V20c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8 6H8V4h2v4zm3 0h-2V4h2v4zm3 0h-2V4h2v4z" /></svg>;
  if (kind === "4pda") return <span style={{ width: 14, height: 14, borderRadius: 3, background: C.blue, color: "#fff", fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>4</span>;
  return <svg width="13" height="13" viewBox="0 0 24 24"><path d="M3.9 1.5c-.3.2-.5.5-.5 1v19c0 .5.2.8.5 1l10.5-10.5z" fill="#00C3FF" /><path d="M18 8.4 14.4 12l3.6 3.6 4-2.3c1.1-.6 1.1-1.7 0-2.3z" fill="#FFCE00" /><path d="m17.9 15.7-3.5-3.7L3.9 22.5c.4.4 1 .4 1.7.1z" fill="#FF3A44" /><path d="M3.9 1.5 14.4 12 18 8.4 5.6 1.4c-.7-.4-1.3-.3-1.7.1z" fill="#00D97D" /></svg>;
};

function VerBar({ app, info }) {
  const inst = app.versionName;
  const f = (info && info.flags) || {};
  const v4 = info && info.ver4pda, vp = info && info.verPlay;
  const cell = (kind, val, i, newer, hidden) => {
    let color = "#cfcfcf", strike = false;
    if (!val) color = "#6a6a6a";
    else if (newer && hidden) { color = "#7a7a7a"; strike = true; }
    else if (newer) color = "#e5675e";
    return (
      <div key={i} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "6px 4px", borderRight: i < 2 ? `1px solid ${C.divider}` : "none" }}>
        <Mini kind={kind} /><span style={{ fontSize: 12.5, color, textDecoration: strike ? "line-through" : "none", whiteSpace: "nowrap" }}>{val || "—"}</span>
      </div>
    );
  };
  return <div style={{ display: "flex", borderTop: `1px solid #2c2c2c` }}>{cell("inst", inst, 0, false, false)}{cell("4pda", v4, 1, verCmp(v4, inst) > 0, hideForum(f))}{cell("play", vp, 2, verCmp(vp, inst) > 0, hidePlay(f))}</div>;
}

function AppCard({ app, info, onOpen, onMenu, onLong, selMode, selected, onToggleSel }) {
  const sub = (info && info.desc) ? info.desc : app.packageName;
  const nu = needsUpdate(app, info);
  const lp = useRef(false), tm = useRef(null);
  const down = () => { lp.current = false; if (!onLong) return; tm.current = setTimeout(() => { lp.current = true; onLong(app); }, 450); };
  const up = () => { if (tm.current) clearTimeout(tm.current); };
  const click = () => { if (lp.current) { lp.current = false; return; } selMode ? onToggleSel(app) : onOpen(app); };
  return (
    <div style={{ background: selected ? "#26301f" : C.card, border: `1px solid ${selected ? C.acc : C.border}`, borderLeft: nu ? "3px solid #e5675e" : `1px solid ${selected ? C.acc : C.border}`, borderRadius: 10, marginBottom: 7, WebkitTapHighlightColor: "transparent", contentVisibility: "auto", containIntrinsicSize: "0 74px" }}>
      <div style={{ display: "flex", padding: "9px 10px", gap: 10, alignItems: "center", cursor: "pointer" }} onClick={click} onTouchStart={down} onTouchEnd={up} onTouchMove={up} onContextMenu={(e) => e.preventDefault()}>
        <Icon app={app} size={44} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: C.text, fontSize: 16, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div>
          <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{sub}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", flexShrink: 0, alignSelf: "stretch", justifyContent: "space-between", paddingTop: 2 }}>
          <span style={{ color: C.date, fontSize: 12 }}>{fmtDate(app.lastUpdate)}</span>
          {!selMode && <div onClick={(e) => { e.stopPropagation(); onMenu(app, e); }} style={{ width: 30, height: 26, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3, WebkitTapHighlightColor: "transparent" }}>
            {[0, 1, 2].map((i) => <span key={i} style={{ width: 3.5, height: 3.5, borderRadius: 4, background: "#9a9a9a" }} />)}
          </div>}
        </div>
      </div>
      <div style={{ padding: "0 10px 8px" }}><VerBar app={app} info={info} /></div>
    </div>
  );
}

function NavBtn({ title, onClick, children }) {
  const [p, setP] = useState(false);
  return <div title={title} onClick={onClick} onPointerDown={() => setP(true)} onPointerUp={() => setP(false)} onPointerLeave={() => setP(false)} style={{ padding: "10px 9px", cursor: "pointer", opacity: p ? 0.5 : 1, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</div>;
}
const sw = (color) => ({ fill: "none", stroke: color, strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" });
const IBot = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="11" width="18" height="10" rx="2.5" /><path d="M12 7v4" /><circle cx="12" cy="5" r="2" /><circle cx="8.5" cy="16" r="1.1" fill={color} stroke="none" /><circle cx="15.5" cy="16" r="1.1" fill={color} stroke="none" /></svg>);
const IEyeOff = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19" /><path d="M6.61 6.61A18.6 18.6 0 0 0 2 12s3 8 10 8a9.1 9.1 0 0 0 5.39-1.61" /><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" /><path d="M2 2l20 20" /></svg>);
const IEye = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M2 12s3-8 10-8 10 8 10 8-3 8-10 8-10-8-10-8Z" /><circle cx="12" cy="12" r="3" /></svg>);
const ICatalog = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>);
const IDownload = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M7 10l5 5 5-5" /><path d="M12 15V3" /></svg>);
const ISearch = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>);
const IRefresh = ({ color = C.nav }) => (<svg width="23" height="23" viewBox="0 0 24 24" {...sw(color)}><path d="M21 12a9 9 0 1 1-2.64-6.36" /><path d="M21 3v6h-6" /></svg>);
const I4 = () => (<div style={{ width: 26, height: 26, borderRadius: 6, background: C.blue, color: "#fff", fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1 }}>4</div>);
const IPlayStore = () => (<svg width="22" height="22" viewBox="0 0 24 24"><path d="M3.9 1.5c-.3.2-.5.5-.5 1v19c0 .5.2.8.5 1l10.5-10.5z" fill="#00C3FF" /><path d="M18 8.4 14.4 12l3.6 3.6 4-2.3c1.1-.6 1.1-1.7 0-2.3z" fill="#FFCE00" /><path d="m17.9 15.7-3.5-3.7L3.9 22.5c.4.4 1 .4 1.7.1z" fill="#FF3A44" /><path d="M3.9 1.5 14.4 12 18 8.4 5.6 1.4c-.7-.4-1.3-.3-1.7.1z" fill="#00D97D" /></svg>);
const IStar = ({ filled }) => (<svg width="22" height="22" viewBox="0 0 24 24" fill={filled ? "#4d9fff" : "none"} stroke={filled ? "#4d9fff" : C.nav} strokeWidth="2" strokeLinejoin="round"><polygon points="12 2 15.1 8.3 22 9.3 17 14.1 18.2 21 12 17.8 5.8 21 7 14.1 2 9.3 8.9 8.3 12 2" /></svg>);
const IExternal = () => (<svg width="22" height="22" viewBox="0 0 24 24" {...sw(C.nav)}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><path d="M15 3h6v6" /><path d="M10 14L21 3" /></svg>);
const ITrash = () => (<svg width="22" height="22" viewBox="0 0 24 24" {...sw("#e5675e")}><path d="M3 6h18" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>);
const IOpenApp = () => (<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke={C.nav} strokeWidth="2" /><path d="M10 8.4l6 3.6-6 3.6z" fill={C.nav} /></svg>);
const IGear = ({ color = C.nav }) => (<svg width="24" height="24" viewBox="0 0 24 24" {...sw(color)}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09A1.65 1.65 0 0 0 10 4.6V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>);
const IAndroid = ({ color = C.nav }) => (
  <svg width="24" height="24" viewBox="0 0 24 24">
    <path d="M7 6 L5.6 4.2" stroke={color} strokeWidth="1.6" strokeLinecap="round" fill="none" />
    <path d="M17 6 L18.4 4.2" stroke={color} strokeWidth="1.6" strokeLinecap="round" fill="none" />
    <path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill={color} />
    <rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill={color} />
    <rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill={color} />
    <rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill={color} />
    <circle cx="9.6" cy="8.8" r="0.85" fill="#0d0d0d" />
    <circle cx="14.4" cy="8.8" r="0.85" fill="#0d0d0d" />
  </svg>
);

function VerChip({ label, value, accent }) {
  return <div style={{ flex: 1, background: "#141414", border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
    <div style={{ color: C.sub, fontSize: 11, letterSpacing: 0.3 }}>{label}</div>
    <div style={{ color: accent || C.text, fontSize: 14, fontWeight: 600, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{value}</div>
  </div>;
}

function ContextMenu({ app, x, y, info, onClose, onInfo, onFlag, onLink }) {
  const flags = (info && info.flags) || {};
  const vw = window.innerWidth, vh = window.innerHeight, W = 290;
  const left = Math.max(8, Math.min((x || vw / 2) - W / 2, vw - W - 8));
  const top = Math.max(8, Math.min((y || 80), vh - 400));
  const iconBtn = (child, fn) => <div onClick={() => { fn(); }} style={{ flex: 1, display: "flex", justifyContent: "center", padding: "13px 0", cursor: "pointer" }}>{child}</div>;
  const check = (label, key) => (
    <div onClick={() => onFlag(app, key, !flags[key])} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", cursor: "pointer", gap: 10 }}>
      <span style={{ color: C.text, fontSize: 14.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      <div style={{ width: 20, height: 20, flexShrink: 0, borderRadius: 4, border: `2px solid ${flags[key] ? C.acc : "#666"}`, background: flags[key] ? C.acc : "transparent", display: "flex", alignItems: "center", justifyContent: "center", color: "#04210f", fontWeight: 800, fontSize: 13 }}>{flags[key] ? "✓" : ""}</div>
    </div>
  );
  const item = (label, fn) => <div onClick={() => { fn(); onClose(); }} style={{ padding: "12px 16px", color: C.text, fontSize: 14.5, cursor: "pointer" }}>{label}</div>;
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 60 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ position: "absolute", left, top, width: W, background: "#242424", borderRadius: 12, overflow: "hidden", boxShadow: "0 10px 34px rgba(0,0,0,.55)", maxHeight: 400, overflowY: "auto" }}>
        <div style={{ display: "flex", borderBottom: `1px solid ${C.border}` }}>
          {iconBtn(<I4 />, () => { openTopicApp(app); onClose(); })}
          {iconBtn(<IPlayStore />, () => { openPlay(app); onClose(); })}
          {iconBtn(<IStar filled={flags.fav} />, () => onFlag(app, "fav", !flags.fav))}
          {iconBtn(<IOpenApp />, () => { Apps.launchApp({ packageName: app.packageName }).catch(() => {}); onClose(); })}
          {iconBtn(<ITrash />, () => { Apps.uninstallApp({ packageName: app.packageName }).catch(() => {}); onClose(); })}
        </div>
        {check("Скрытое", "hidden")}
        {item("Доступные связи (связать тему)", () => onLink(app))}
        {check("Проверять обновления только мои", "onlyMine")}
        {check("Скрыть все обновления", "hideAll")}
        {check("Скрыть обновления с форума", "hideForum")}
        {check("Скрыть обновления с Google Play", "hidePlay")}
        {item("Информация", () => onInfo(app))}
      </div>
    </div>
  );
}

function InfoDialog({ app, info, onClose }) {
  const [d, setD] = useState(null);
  useEffect(() => { Apps.appDetails({ packageName: app.packageName }).then(setD).catch(() => setD({})); }, []);
  const dt = (ms) => { if (!ms) return ""; const x = new Date(ms); const p = (n) => String(n).padStart(2, "0"); return `${p(x.getDate())}.${p(x.getMonth() + 1)}.${x.getFullYear()} ${p(x.getHours())}:${p(x.getMinutes())}`; };
  const sz = (b) => (!b ? "" : b >= 1048576 ? (b / 1048576).toFixed(1) + " МБ" : Math.round(b / 1024) + " КБ");
  const nf = (info || {});
  const g = (k) => (d && d[k] != null && d[k] !== "" ? d[k] : null);
  const row = (label, value, onClick) => (value || value === 0) ? (
    <div style={{ fontSize: 14.5, marginBottom: 7, lineHeight: 1.35 }}>
      <span style={{ color: C.text, fontWeight: 700 }}>{label}</span>
      <span style={{ color: C.sub }}> : </span>
      <span onClick={onClick} style={{ color: onClick ? "#4db6c4" : C.text, textDecoration: onClick ? "underline" : "none", wordBreak: "break-all", cursor: onClick ? "pointer" : "default" }}>{value}</span>
    </div>
  ) : null;
  const vName = app.versionName || g("versionName");
  const vCode = g("versionCode");
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 75, display: "flex", alignItems: "center", justifyContent: "center", padding: 18 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 460, background: "#3a3a3a", borderRadius: 6, padding: 22, maxHeight: "85%", overflowY: "auto" }}>
        <div style={{ color: "#e9e9e9", fontSize: 24, fontWeight: 400, marginBottom: 18 }}>Информация</div>
        {row("Имя пакета", app.packageName, () => openPlay(app))}
        {row("Имя приложения", app.label || g("label"))}
        {row("Имя на форуме", nf.title4pda)}
        {row("Версия (код)", vName ? `${vName}${vCode != null ? ` (${vCode})` : ""}` : null)}
        {row("Версия на форуме", nf.ver4pda)}
        {row("Версия в Google Play", nf.verPlay ? `${nf.verPlay}${nf.verPlayCode ? ` (${nf.verPlayCode})` : ""}` : null)}
        {row("Дата на форуме", nf.fdate)}
        {row("Обновление шапки", nf.hatDate)}
        {row("Дата обновления", dt(app.lastUpdate || g("lastUpdate")))}
        {row("Дата установки", dt(app.firstInstall || g("firstInstall")))}
        {row("Размер APK", sz(g("apkSize")))}
        {row("Target / Min SDK", g("targetSdk") ? `${g("targetSdk")}${g("minSdk") ? " / " + g("minSdk") : ""}` : null)}
        {row("Установщик", g("installer"))}
        {row("Связь", nf.topicId, nf.topicId ? () => Apps.openWeb({ url: `https://4pda.to/forum/index.php?showtopic=${nf.topicId}` }).catch(() => {}) : null)}
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 16 }}>
          <div onClick={onClose} style={{ color: "#4db6c4", fontWeight: 700, fontSize: 15, cursor: "pointer", padding: "6px 8px" }}>ЗАКРЫТЬ</div>
        </div>
      </div>
    </div>
  );
}

function Downloads({ onClose }) {
  const [items, setItems] = useState(null);
  const prev = useRef({});
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await Apps.downloadStatus();
        if (!alive) return;
        const now = Date.now();
        const list = (r.items || []).map((it) => {
          const p = prev.current[it.id];
          let speed = 0;
          if (p && it.status === 2 && now > p.t) speed = Math.max(0, (it.done - p.done) / ((now - p.t) / 1000));
          prev.current[it.id] = { done: it.done, t: now };
          return { ...it, speed };
        }).sort((a, b) => (b.date || 0) - (a.date || 0));
        setItems(list);
      } catch { if (alive) setItems([]); }
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => { alive = false; clearInterval(iv); };
  }, []);
  const sz = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + " МБ" : Math.max(1, Math.round(b / 1024)) + " КБ");
  const spd = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + " МБ/с" : Math.round(b / 1024) + " КБ/с");
  const install = (it) => { const u = it.uri || ""; if (u.indexOf("file://") === 0) { let p = u.slice(7); try { p = decodeURIComponent(p); } catch {} Apps.installApk({ path: p }).catch(() => {}); } };
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 55 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>Загрузки</span></div></div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 0" }}>
        {items === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : items.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Нет загрузок</div> :
          items.map((it) => {
            const running = it.status === 2 || it.status === 1;
            const pct = it.total > 0 ? Math.min(100, Math.round((it.done / it.total) * 100)) : 0;
            const eta = running && it.speed > 0 && it.total > 0 ? Math.round((it.total - it.done) / it.speed) : 0;
            return (
              <div key={it.id} onClick={() => it.status === 8 && install(it)} style={{ background: C.card, border: `1px solid ${running ? C.acc : C.border}`, borderRadius: 12, marginBottom: 10, padding: 12, cursor: it.status === 8 ? "pointer" : "default" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <span style={{ color: C.text, fontSize: 15, fontWeight: 500, wordBreak: "break-all" }}>{it.title}</span>
                  <span style={{ color: C.sub, fontSize: 13, flexShrink: 0 }}>{it.total > 0 ? sz(it.total) : ""}</span>
                </div>
                {running ? (
                  <div style={{ marginTop: 8 }}>
                    <div style={{ height: 6, borderRadius: 4, background: "#333", overflow: "hidden" }}><div style={{ height: "100%", width: pct + "%", background: C.acc, borderRadius: 4 }} /></div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 5, fontSize: 12.5, color: C.sub }}>
                      <span>{it.status === 1 ? "Ожидание…" : `Осталось ${eta} сек · ${spd(it.speed)}`}</span>
                      <span>{pct}%</span>
                    </div>
                  </div>
                ) : (
                  <div style={{ color: C.sub, fontSize: 13, marginTop: 4 }}>{it.status === 8 ? "Готово — нажми, чтобы установить" : it.status === 16 ? "Ошибка" : "Пауза"} · {fmtDate(it.date)}</div>
                )}
              </div>
            );
          })}
        <div style={{ height: 12 }} />
      </div>
    </div>
  );
}

// экран «ФАЙЛЫ» — список apk; тап по строке — закачка, кнопка «i» — инфо
function FilesDialog({ app, files, mode, onClose }) {
  const [picked, setPicked] = useState(null);
  const [info, setInfo] = useState(null);
  const apkVer = (name) => { const m = (name || "").match(/(\d+(?:\.\d+){1,})/); return m ? m[1] : ""; };
  let list = files || [];
  if (mode === "updates") list = list.filter((f) => { const v = apkVer(f.name); return v && app.versionName && verCmp(v, app.versionName) > 0; });
  const iBtn = (fn) => <div onClick={(e) => { e.stopPropagation(); fn(); }} style={{ width: 34, height: 34, borderRadius: "50%", border: `2px solid ${C.sub}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, cursor: "pointer" }}><span style={{ color: C.sub, fontSize: 18, fontWeight: 700, transform: "rotate(180deg)" }}>!</span></div>;
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 70, display: "flex", alignItems: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxHeight: "80%", overflowY: "auto", background: "#1c1c1c", borderTopLeftRadius: 16, borderTopRightRadius: 16, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ padding: "16px 18px 8px", color: C.text, fontSize: 18, fontWeight: 600 }}>{mode === "updates" ? "Обновления" : "Скачать"}</div>
        {(!list || list.length === 0) ? <div style={{ padding: "8px 18px 20px", color: C.sub, fontSize: 14 }}>{mode === "updates" ? "Более новых версий не найдено." : "Файлы в теме не найдены."}</div> :
          list.map((f, i) => {
            const badArch = !fileForDevice(f.name);
            return <div key={i} style={{ padding: "12px 18px", borderTop: i ? `1px solid ${C.border}` : "none", display: "flex", alignItems: "center", gap: 12 }}>
              <div onClick={() => setPicked(f)} style={{ flex: 1, minWidth: 0, cursor: "pointer" }}>
                <div style={{ color: badArch ? "#e5675e" : C.text, fontSize: 15, wordBreak: "break-all" }}>{f.name}</div>
                <div style={{ marginTop: 3, fontSize: 13, color: C.sub, display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <span>{[f.size, f.downloads ? "скачиваний: " + f.downloads : ""].filter(Boolean).join(" · ")}</span>
                  {badArch && <span style={{ color: "#e5675e" }}>не для вашего процессора</span>}
                  {!badArch && fileForDevice(f.name) && /(arm64|armeabi|x86|v8a|v7a)/i.test(f.name) && <span style={{ color: C.acc }}>✓ ваш процессор</span>}
                </div>
              </div>
              {iBtn(() => setInfo(f))}
            </div>;
          })}
        <div style={{ height: 8 }} />
      </div>

      {info && (
        <div onClick={(e) => { e.stopPropagation(); setInfo(null); }} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 82, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 420, background: "#2a2a2a", borderRadius: 12, padding: 18, maxHeight: "80%", overflowY: "auto" }}>
            <div style={{ color: "#5ab0d8", fontSize: 17, fontWeight: 700, marginBottom: 4, wordBreak: "break-word" }}>{app.label || app.packageName}{apkVer(info.name) ? " " + apkVer(info.name) : ""}</div>
            <div style={{ color: C.sub, fontSize: 13, marginBottom: 12, wordBreak: "break-all" }}>{info.name}</div>
            {apkVer(info.name) && <Row k="Версия" v={apkVer(info.name)} />}
            {info.size && <Row k="Размер" v={info.size} />}
            {info.downloads && <Row k="Скачиваний" v={info.downloads} />}
            <Row k="Пакет" v={app.packageName} />
            <Row k="Процессор" v={fileForDevice(info.name) ? "подходит" : "не для вашего процессора"} />
            <div style={{ color: C.sub, fontSize: 12.5, marginTop: 10, lineHeight: 1.4 }}>Полный список изменений — в шапке темы (кнопка «4»).</div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 16, marginTop: 14 }}>
              <div onClick={() => setInfo(null)} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 4px" }}>ЗАКРЫТЬ</div>
              <div onClick={() => { const f = info; setInfo(null); setPicked(f); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 4px" }}>СКАЧАТЬ</div>
            </div>
          </div>
        </div>
      )}

      {picked && (
        <div onClick={(e) => { e.stopPropagation(); setPicked(null); }} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 80, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: "#1e1e1e", borderRadius: 14, padding: 18 }}>
            <div style={{ color: C.text, fontSize: 17, fontWeight: 600, marginBottom: 12 }}>Начать закачку?</div>
            <Row k="Название" v={app.label || app.packageName} />
            <Row k="Имя файла" v={picked.name} />
            {picked.size && <Row k="Размер" v={picked.size} />}
            {picked.downloads && <Row k="Скачиваний" v={picked.downloads} />}
            <Row k="Пакет" v={app.packageName} />
            <Row k="Для устройства" v={fileForDevice(picked.name) ? "да" : "возможно, не подходит"} />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 18, marginTop: 16 }}>
              <div onClick={() => setPicked(null)} style={{ color: C.sub, fontWeight: 600, cursor: "pointer", padding: "6px 4px" }}>ОТМЕНА</div>
              <div onClick={() => { Apps.download({ url: picked.url, name: picked.name }).catch(() => {}); setPicked(null); onClose(); }} style={{ color: C.acc, fontWeight: 700, cursor: "pointer", padding: "6px 4px" }}>СКАЧАТЬ</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
function Row({ k, v }) {
  return <div style={{ display: "flex", gap: 8, fontSize: 13.5, marginBottom: 5 }}><span style={{ color: C.sub, flexShrink: 0 }}>{k}:</span><span style={{ color: C.text, wordBreak: "break-all" }}>{v}</span></div>;
}

function DescView({ html }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    el.querySelectorAll(".spoiler, .post-block").forEach((sp) => {
      const title = sp.querySelector(".block-title, .spoiler-title, .title");
      const body = sp.querySelector(".block-body, .spoiler-body, .body");
      if (title && body && !title.dataset.w) {
        title.dataset.w = "1";
        body.style.display = "none";
        const mark = document.createElement("span"); mark.textContent = "► "; title.prepend(mark);
        title.addEventListener("click", () => { const open = body.style.display !== "none"; body.style.display = open ? "none" : "block"; mark.textContent = open ? "► " : "▼ "; });
      }
    });
    el.querySelectorAll("a[href]").forEach((a) => {
      if (a.dataset.w) return; a.dataset.w = "1";
      a.addEventListener("click", (e) => { e.preventDefault(); let href = a.getAttribute("href") || ""; if (!href) return; if (href.indexOf("//") === 0) href = "https:" + href; if (href.indexOf("http") !== 0) href = "https://4pda.to" + (href[0] === "/" ? "" : "/") + href; Apps.openUrl({ url: href }).catch(() => {}); });
    });
  }, [html]);
  return <div ref={ref} className="topic-desc" style={{ color: "#cfcfcf", fontSize: 14, lineHeight: 1.5 }} dangerouslySetInnerHTML={{ __html: html || "—" }} />;
}

function Detail({ app, onClose, onCache, onFiles }) {
  const [td, setTd] = useState({ phase: "loading" });
  const [retKey, setRetKey] = useState(0);

  useEffect(() => {
    let alive = true;
    (async () => {
      setTd({ phase: "loading" });
      try {
        const cache = readCache()[app.packageName] || {};
        let topicId = app.topicId || cache.topicId, matched = cache.matched, html = null;
        if (!topicId) {
          const r = await resolveTopic(app);
          if (!alive) return;
          if (r === "captcha") { setTd({ phase: "captcha" }); return; }
          if (!r) { setTd({ phase: "notfound" }); return; }
          topicId = r.topicId; matched = r.matched; html = r.html;
          onCache(app.packageName, { topicId, matched, notfound: false });
        }
        if (!html) {
          html = await fetchTopicHtml(topicId);
          if (!alive) return;
          if (!html) { setTd({ phase: "captcha" }); return; }
        }
        const p = parseTopic(html);
        onCache(app.packageName, { ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short });
        setTd({ phase: "ok", topicId, descHtml: p.descHtml, descMain: p.descMain, files: p.files, ver4pda: p.ver4pda, screenshots: p.screenshots, verPlay: cache.verPlay || "" });
        if (!cache.verPlay) {
          fetchPlayVersion(app.packageName).then((v) => { if (v) { onCache(app.packageName, { verPlay: v.name, verPlayCode: v.code }); if (alive) setTd((t) => (t && t.phase === "ok" ? { ...t, verPlay: v.name } : t)); } }).catch(() => {});
        }
      } catch (e) { if (alive) setTd({ phase: "error", msg: (e && e.message) || "ошибка" }); }
    })();
    return () => { alive = false; };
  }, [retKey]);

  const note = (txt, btn) => <div style={{ textAlign: "center", marginTop: 30, padding: "0 10px" }}><div style={{ color: C.sub, fontSize: 14, marginBottom: 14 }}>{txt}</div>{btn}</div>;
  const btn = (label, fn) => <div onClick={fn} style={{ display: "inline-block", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 14, padding: "10px 16px", borderRadius: 10, cursor: "pointer" }}>{label}</div>;

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 50 }}>
      <style>{".topic-desc img{max-width:100%;height:auto;border-radius:6px} .topic-desc a{color:#4da3ff} .topic-desc{word-break:break-word}"}</style>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div>
          <div style={{ color: C.text, fontSize: 18, fontWeight: 600 }}>Информация</div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14 }}>
          <Icon app={app} />
          <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 18, fontWeight: 600 }}>{app.label || app.packageName}</div><div style={{ color: C.sub, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{(app.packageName || "").indexOf("topic:") === 0 ? "тема 4pda" : app.packageName}</div></div>
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <VerChip label="УСТАНОВЛЕНО" value={app.versionName || "—"} accent={C.acc} />
          <VerChip label="4PDA" value={td.phase === "ok" ? (td.ver4pda || "—") : "…"} />
          <VerChip label="GOOGLE PLAY" value={td.verPlay || "—"} />
        </div>

        {td.phase === "ok" && td.screenshots && td.screenshots.length > 0 && <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 6 }}>
            {td.screenshots.map((s, i) => <img key={i} src={s.thumb} alt="" onClick={() => Apps.openUrl({ url: s.full }).catch(() => {})} style={{ height: 200, borderRadius: 8, flexShrink: 0, cursor: "pointer" }} />)}
          </div>
        </div>}
        <div style={{ color: C.text, fontSize: 13, fontWeight: 700, letterSpacing: 0.4, marginBottom: 8 }}>ОПИСАНИЕ</div>
        {td.phase === "loading" && <div style={{ color: C.sub, fontSize: 14 }}>Загрузка темы с 4pda…</div>}
        {td.phase === "captcha" && note("4pda просит проверку. Открой 4pda, войди/реши капчу и вернись.", <span>{btn("Открыть 4pda", () => openTopicApp(app))} <span style={{ display: "inline-block", width: 8 }} />{btn("Повторить", () => setRetKey((k) => k + 1))}</span>)}
        {td.phase === "notfound" && note("Тема не загрузилась (4pda мог не ответить).", <span>{btn("Повторить", () => setRetKey((k) => k + 1))} <span style={{ display: "inline-block", width: 8 }} />{btn("Искать на 4pda", () => Apps.openUrl({ url: searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}))}</span>)}
        {td.phase === "error" && note("Не удалось загрузить: " + td.msg, btn("Повторить", () => setRetKey((k) => k + 1)))}
        {td.phase === "ok" && <>
          <DescView html={td.descHtml} />
          <style>{`
            .topic-desc a{color:#5ab0d8;text-decoration:none;word-break:break-word}
            .topic-desc img{max-width:100%;height:auto;border-radius:6px}
            .topic-desc b,.topic-desc strong{color:#e9e9e9}
            .topic-desc .block-title,.topic-desc .spoiler-title{font-weight:700;color:#e0e0e0;padding:9px 12px;background:#242424;border:1px solid #333;border-radius:8px;margin:7px 0;cursor:pointer}
            .topic-desc .block-body,.topic-desc .spoiler-body{padding:6px 10px;border-left:2px solid #333;margin:2px 0 10px}
          `}</style>
        </>}
        <div style={{ height: 20 }} />
      </div>

      <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", height: 58 }}>
          <div onClick={() => { const tid = td.topicId || (readCache()[app.packageName] || {}).topicId || app.topicId; Apps.openUrl({ url: tid ? `https://4pda.to/forum/index.php?showtopic=${tid}` : searchUrl4pda(app.label || app.packageName, "top") }).catch(() => {}); }} title="4pda" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><I4 /></div>
          <div onClick={() => td.phase === "ok" && onFiles({ app, files: td.files, mode: "all" })} style={{ flex: 1, textAlign: "center", color: td.phase === "ok" ? C.acc : "#5a5a5a", fontSize: 14, fontWeight: 700, cursor: td.phase === "ok" ? "pointer" : "default" }}>ФАЙЛЫ</div>
          {td.phase === "ok" && td.ver4pda && app.versionName && verCmp(td.ver4pda, app.versionName) > 0 && <div onClick={() => onFiles({ app, files: td.files, mode: "updates" })} style={{ flex: 1, textAlign: "center", color: "#e5675e", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>ОБНОВИТЬ</div>}
          <div onClick={() => openPlay(app)} title="Google Play" style={{ flex: 1, display: "flex", justifyContent: "center", cursor: "pointer" }}><IPlayStore /></div>
        </div>
      </div>
    </div>
  );
}

function SubList({ title, initial, loadSystem, topics, onOpen, onMenu, onClose }) {
  const [list, setList] = useState(loadSystem ? null : (initial || []));
  useEffect(() => {
    if (loadSystem) Apps.getInstalledApps({ icons: true, system: true }).then((r) => setList((r.apps || []).filter((a) => a.system).sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0)))).catch(() => setList([]));
  }, []);
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 56 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}><div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}><div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 28 }}>←</div><span style={{ color: C.text, fontSize: 20, fontWeight: 600 }}>{title}</span></div></div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {list === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Загрузка…</div> : list.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Пусто</div> :
          list.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName] || {}} onOpen={onOpen} onMenu={onMenu} />)}
        <div style={{ height: 12 }} />
      </div>
    </div>
  );
}

function parseTopicTitle(html) {
  const m = html.match(/<title>([^<]*)<\/title>/i);
  if (!m) return "";
  return m[1].replace(/\s*[-–|]\s*4PDA.*$/i, "").replace(/&amp;/g, "&").trim();
}

function SearchScreen({ initialQuery, onClose, onOpenResult }) {
  const [q, setQ] = useState(initialQuery || "");
  const [res, setRes] = useState(undefined);
  const run = async (q0) => {
    const query = (q0 != null ? q0 : q).trim(); if (!query) return;
    setRes(null);
    try {
      let items = [];
      try { const sr = await Apps.webGet({ url: searchUrl4pda(query, "top") }); if (!sr.captcha) items = parseSearchResults(sr.body || ""); } catch {}
      if (!items.length) { try { const sr2 = await Apps.webGet({ url: searchUrl4pda(query, "all") }); if (!sr2.captcha) items = parseSearchResults(sr2.body || ""); } catch {} }
      if (!items.length) { try { const gr = await Apps.webGet({ url: `https://www.google.com/search?q=${encodeURIComponent(query + " site:4pda.to")}` }); items = topicIds(gr.body || "").map((id) => ({ topicId: id, title: "Тема " + id })); } catch {} }
      const list = items.slice(0, 40);
      setRes(list);
      list.slice(0, 8).forEach(async (it) => {
        try {
          let tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` });
          if (tr.captcha || !tr.body || tr.body.length < 800) tr = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` });
          if (!tr.body) return;
          if (!isAppPage(tr.body)) { setRes((prev) => (prev ? prev.filter((x) => x.topicId !== it.topicId) : prev)); return; }
          const p = parseTopic(tr.body || "");
          setRes((prev) => (prev ? prev.map((x) => (x.topicId === it.topicId ? { ...x, short: p.short, icon: p.hatIcon, ver4pda: p.ver4pda } : x)) : prev));
        } catch {}
      });
    } catch { setRes([]); }
  };
  useEffect(() => { if (initialQuery) run(initialQuery); }, []);
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 57 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 26 }}>←</div>
          <span style={{ color: C.text, fontSize: 19, fontWeight: 600 }}>Поиск на 4pda{res && res.length ? " : " + res.length : ""}</span>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {res === undefined ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 14 }}>Введите запрос и нажмите поиск</div> :
          res === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Поиск…</div> :
            res.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ничего не найдено</div> :
              res.map((r) => <div key={r.topicId} onClick={() => onOpenResult(r)} style={{ display: "flex", gap: 10, alignItems: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7, padding: "9px 10px", cursor: "pointer" }}>
                {r.icon ? <img src={r.icon} alt="" style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, objectFit: "cover" }} /> : <div style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, background: tileColor(r.title || r.topicId), display: "flex", alignItems: "center", justifyContent: "center", color: "#eaeaea", fontWeight: 800, fontSize: 19 }}>{(r.title || "?").trim().charAt(0).toUpperCase()}</div>}
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ color: C.text, fontSize: 15.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.title}</div>
                  <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.25 }}>{r.short || ("4pda · тема " + r.topicId)}</div>
                </div>
              </div>)}
        <div style={{ height: 12 }} />
      </div>
      <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", height: 58, boxSizing: "border-box" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} autoFocus placeholder="Поиск на 4pda" style={{ flex: 1, background: "#222", border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
          <div onClick={() => run()} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
        </div>
      </div>
    </div>
  );
}

function LinkScreen({ app, onClose, onLinked }) {
  const [q, setQ] = useState(app.label || app.packageName);
  const [res, setRes] = useState(undefined);
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const run = async (q0) => {
    const query = (q0 != null ? q0 : q).trim(); if (!query) return;
    setRes(null);
    try {
      let items = [];
      try { const sr = await Apps.webGet({ url: searchUrl4pda(query, "top") }); if (!sr.captcha) items = parseSearchResults(sr.body || ""); } catch {}
      if (!items.length) { try { const sr2 = await Apps.webGet({ url: searchUrl4pda(query, "all") }); if (!sr2.captcha) items = parseSearchResults(sr2.body || ""); } catch {} }
      setRes(items.slice(0, 40));
      items.slice(0, 8).forEach(async (it) => {
        try { const tr = await Apps.httpGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }); let b = tr.body; if (tr.captcha || !b || b.length < 800) { const w = await Apps.webGet({ url: `https://4pda.to/forum/index.php?showtopic=${it.topicId}` }); b = w.body; } if (!b) return; const p = parseTopic(b); setRes((prev) => (prev ? prev.map((x) => (x.topicId === it.topicId ? { ...x, short: p.short, icon: p.hatIcon } : x)) : prev)); } catch {}
      });
    } catch { setRes([]); }
  };
  useEffect(() => { run(app.label || app.packageName); }, []);
  const pick = async (r) => {
    if (busy) return; setBusy(true);
    try { const html = await fetchTopicHtml(r.topicId); const p = parseTopic(html); onLinked(app.packageName, { topicId: r.topicId, matched: true, notfound: false, ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short }); } catch { onLinked(app.packageName, { topicId: r.topicId, matched: true, notfound: false }); }
    onClose();
  };
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, display: "flex", flexDirection: "column", zIndex: 70 }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 14px", height: 56 }}>
          <div onClick={onClose} style={{ cursor: "pointer", color: "#e0e0e0", fontSize: 24, width: 26 }}>←</div>
          <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 17, fontWeight: 600 }}>Связать тему</div><div style={{ color: C.sub, fontSize: 12.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{app.label || app.packageName}</div></div>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "10px 10px 0" }}>
        {busy && <div style={{ color: C.acc, textAlign: "center", marginTop: 20 }}>Связывание…</div>}
        {res === null ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Поиск…</div> :
          res && res.length === 0 ? <div style={{ color: C.sub, textAlign: "center", marginTop: 40 }}>Ничего не найдено</div> :
            (res || []).map((r) => <div key={r.topicId} onClick={() => setConfirm(r)} style={{ display: "flex", gap: 10, alignItems: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 7, padding: "9px 10px", cursor: "pointer" }}>
              {r.icon ? <img src={r.icon} alt="" style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, objectFit: "cover" }} /> : <div style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, background: tileColor(r.title || r.topicId), display: "flex", alignItems: "center", justifyContent: "center", color: "#eaeaea", fontWeight: 800, fontSize: 18 }}>{(r.title || "?").trim().charAt(0).toUpperCase()}</div>}
              <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: C.text, fontSize: 15, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.title}</div><div style={{ color: C.sub, fontSize: 12.5, marginTop: 2, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{r.short || ("тема " + r.topicId)}</div></div>
            </div>)}
        <div style={{ height: 12 }} />
      </div>
      {confirm && (
        <div onClick={() => setConfirm(null)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 78, display: "flex", alignItems: "center", justifyContent: "center", padding: 22 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 400, background: "#2a2a2a", borderRadius: 14, padding: 20 }}>
            <div style={{ color: C.text, fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Связать тему?</div>
            <div style={{ color: C.sub, fontSize: 14, marginBottom: 18, wordBreak: "break-word" }}>{confirm.title} · тема {confirm.topicId}</div>
            <div style={{ display: "flex", gap: 12, justifyContent: "flex-end", alignItems: "center" }}>
              <div onClick={() => setConfirm(null)} style={{ cursor: "pointer", color: C.sub, fontSize: 22, padding: "4px 8px" }}>✕</div>
              <div onClick={() => { const r = confirm; setConfirm(null); pick(r); }} style={{ cursor: "pointer", background: C.acc, color: "#04210f", fontWeight: 700, fontSize: 15, padding: "10px 18px", borderRadius: 10 }}>Связаться</div>
            </div>
          </div>
        </div>
      )}
      <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", height: 58, boxSizing: "border-box" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} placeholder="Поиск темы на 4pda" style={{ flex: 1, background: "#222", border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
          <div onClick={() => run()} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState(1);
  const [apps, setApps] = useState(null);
  const [sysScreen, setSysScreen] = useState(false);
  const [hidScreen, setHidScreen] = useState(false);
  const [searchScreen, setSearchScreen] = useState(null); // строка-запрос => экран 4pda-поиска
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sel, setSel] = useState(null);
  const [menu, setMenu] = useState(null);   // {app, x, y}
  const [infoApp, setInfoApp] = useState(null);
  const [dlScreen, setDlScreen] = useState(false);
  const [filesData, setFilesData] = useState(null);
  const [topics, setTopics] = useState(() => readCache());
  const [dir, setDir] = useState(1);
  const [selMode, setSelMode] = useState(false);
  const [selected, setSelected] = useState({});
  const [refreshTick, setRefreshTick] = useState(0);
  const [updScreen, setUpdScreen] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [linkApp, setLinkApp] = useState(null);
  const [profile, setProfile] = useState(null);
  const [logoutBusy, setLogoutBusy] = useState(false);
  const loggedRef = useRef(false);
  const onLogged = (p) => { setProfile(p); if (p && p.loggedIn && !loggedRef.current) { loggedRef.current = true; try { refresh(); load(); } catch {} } if (p && !p.loggedIn) loggedRef.current = false; };
  useEffect(() => { check4pdaLogin().then(onLogged).catch(() => setProfile({ loggedIn: false })); }, []);
  useEffect(() => { if (drawer) check4pdaLogin().then(onLogged).catch(() => {}); }, [drawer]);
  const updateApps = (apps || []).filter((a) => needsUpdate(a, topics[a.packageName]));
  const updates = updateApps.length;
  const gotoTab = (i) => { setDir(i >= active ? 1 : -1); setActive(i); };

  const onFlag = (app, key, val) => onCache(app.packageName, { flags: { ...((readCache()[app.packageName] || {}).flags || {}), [key]: val } });
  const openMenu = (app, e) => { const t = (e && e.touches && e.touches[0]) || e; setMenu({ app, x: t ? t.clientX : null, y: t ? t.clientY : null }); };
  const enterSel = (app) => { setSelMode(true); setSelected({ [app.packageName]: true }); };
  const toggleSel = (app) => setSelected((s) => { const n = { ...s }; if (n[app.packageName]) delete n[app.packageName]; else n[app.packageName] = true; return n; });
  const exitSel = () => { setSelMode(false); setSelected({}); };
  const bulkHide = () => { Object.keys(selected).forEach((pkg) => onCache(pkg, { flags: { ...((readCache()[pkg] || {}).flags || {}), hidden: true } })); exitSel(); };

  // аппаратная «Назад» — закрыть верхний экран/меню, иначе выйти
  useEffect(() => {
    let handle;
    CapApp.addListener("backButton", () => {
      if (drawer) setDrawer(false);
      else if (linkApp) setLinkApp(null);
      else if (infoApp) setInfoApp(null);
      else if (menu) setMenu(null);
      else if (filesData) setFilesData(null);
      else if (searchScreen) setSearchScreen(null);
      else if (updScreen) setUpdScreen(false);
      else if (searchOpen) { setSearchOpen(false); setSearchQuery(""); }
      else if (sysScreen) setSysScreen(false);
      else if (hidScreen) setHidScreen(false);
      else if (selMode) exitSel();
      else if (dlScreen) setDlScreen(false);
      else if (sel) setSel(null);
      else CapApp.exitApp();
    }).then((h) => { handle = h; });
    return () => { if (handle) handle.remove(); };
  }, [filesData, menu, infoApp, selMode, dlScreen, sel, searchScreen, searchOpen, updScreen, drawer, linkApp, sysScreen, hidScreen]);

  const onCache = (pkg, patch) => setTopics((prev) => { const next = { ...prev, [pkg]: { ...(prev[pkg] || {}), ...patch } }; try { localStorage.setItem(CKEY, JSON.stringify(next)); } catch {} return next; });

  const load = async () => {
    try {
      const r = await Apps.getInstalledApps({ icons: true, system: false, hidden: false });
      const list = (r.apps || []).slice().sort((a, b) => (b.lastUpdate || 0) - (a.lastUpdate || 0));
      setApps(list);
    } catch { setApps(Capacitor.getPlatform() === "web" ? DEMO : []); }
  };
  useEffect(() => { load(); }, []);

  // щадящий фоновый автоподбор тем (стоп на капче). refreshTick — перезапуск по кнопке.
  useEffect(() => {
    if (!apps || apps.length === 0) return;
    let stop = false;
    (async () => {
      const cache = readCache();
      const todo = apps.filter((a) => a.packageName && !cache[a.packageName]?.topicId && !cache[a.packageName]?.notfound).slice(0, 12);
      for (const a of todo) {
        if (stop) break;
        try {
          const r = await resolveTopic(a, 3, true);
          if (r === "captcha") break;
          if (r) { const p = parseTopic(r.html); onCache(a.packageName, { topicId: r.topicId, matched: r.matched, ver4pda: p.ver4pda, hatDate: p.hatDate, fdate: p.forumDate, title4pda: p.title, desc: p.short }); }
        } catch {}
        try { const pv = await fetchPlayVersion(a.packageName); if (pv) onCache(a.packageName, { verPlay: pv.name, verPlayCode: pv.code }); } catch {}
        await new Promise((res) => setTimeout(res, 800));
      }
    })();
    return () => { stop = true; };
  }, [apps, refreshTick]);

  // кнопка «Обновить»: сбросить «не найдено» и перезапустить подбор/проверку
  const refresh = () => {
    const c = readCache();
    Object.keys(c).forEach((pkg) => { if (c[pkg] && c[pkg].notfound && !c[pkg].topicId) { delete c[pkg].notfound; } });
    try { localStorage.setItem(CKEY, JSON.stringify(c)); } catch {}
    setTopics({ ...c });
    setRefreshTick((t) => t + 1);
  };

  const touch = useRef({ x: 0, y: 0 });
  const onTouchStart = (e) => { const t = e.touches[0]; touch.current = { x: t.clientX, y: t.clientY }; };
  const onTouchEnd = (e) => { const t = e.changedTouches[0]; const dx = t.clientX - touch.current.x, dy = t.clientY - touch.current.y; if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) { if (dx < 0) setActive((a) => Math.min(a + 1, TABS.length - 1)); else setActive((a) => Math.max(a - 1, 0)); } };

  return (
    <div style={{ height: "100vh", background: C.bg, display: "flex", flexDirection: "column", fontFamily: "Roboto, system-ui, sans-serif", overflow: "hidden", WebkitUserSelect: "none", userSelect: "none", WebkitTapHighlightColor: "transparent" }}>
      <div style={{ paddingTop: "env(safe-area-inset-top)", background: C.bar, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "0 16px", height: 56 }}>
          <div onClick={() => setDrawer(true)} style={{ width: 26, height: 20, display: "flex", flexDirection: "column", justifyContent: "space-between", cursor: "pointer" }}>{[0, 1, 2].map((i) => <span key={i} style={{ height: 2, borderRadius: 2, background: "#e0e0e0" }} />)}</div>
          <span style={{ color: C.text, fontSize: 22, fontWeight: 600 }}>4PDApps</span>
        </div>
      </div>

      {drawer && (
        <div onClick={() => setDrawer(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 80, display: "flex" }}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: 280, maxWidth: "82%", height: "100%", background: "#1c1c1c", paddingTop: "env(safe-area-inset-top)", boxShadow: "2px 0 20px rgba(0,0,0,.5)" }}>
            {profile && profile.loggedIn ? (
              <>
                <div style={{ padding: "22px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 12 }}>
                  {profile.avatar ? <img src={profile.avatar} alt="" style={{ width: 50, height: 50, borderRadius: "50%", objectFit: "cover" }} /> : <div style={{ width: 50, height: 50, borderRadius: "50%", background: tileColor(profile.name || "u"), display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 22 }}>{(profile.name || "?").trim().charAt(0).toUpperCase()}</div>}
                  <div style={{ minWidth: 0 }}><div style={{ color: C.text, fontSize: 17, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{profile.name}</div><div style={{ color: C.acc, fontSize: 12 }}>вы вошли на 4pda</div></div>
                </div>
                <div onClick={async () => { if (logoutBusy) return; setLogoutBusy(true); await logout4pda(profile.logoutK); const p = await check4pdaLogin(); setProfile(p && p.loggedIn ? p : { loggedIn: false }); setLogoutBusy(false); }} style={{ padding: "16px 18px", color: "#e5675e", fontSize: 15.5, cursor: "pointer" }}>{logoutBusy ? "Выхожу…" : "Выйти из 4pda"}</div>
              </>
            ) : (
              <>
                <div style={{ padding: "20px 18px", borderBottom: `1px solid ${C.border}`, color: C.text, fontSize: 20, fontWeight: 700 }}>4PDApps</div>
                <div onClick={() => { Apps.openWeb({ url: "https://4pda.to/forum/index.php?act=auth" }).catch(() => {}); setDrawer(false); }} style={{ padding: "16px 18px", color: C.text, fontSize: 15.5, cursor: "pointer" }}>Войти в 4pda</div>
                <div style={{ padding: "14px 18px", color: C.sub, fontSize: 12.5, lineHeight: 1.4 }}>После входа связь и поиск на 4pda работают стабильнее (проходит Cloudflare), а список обновится автоматически.</div>
              </>
            )}
          </div>
        </div>
      )}

      <div style={{ display: "flex", background: C.bar, overflowX: "auto", borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
        {TABS.map((t, i) => <div key={i} onClick={() => gotoTab(i)} style={{ padding: "13px 9px", whiteSpace: "nowrap", position: "relative", cursor: "pointer" }}><span style={{ color: i === active ? C.active : "#7f7f7f", fontSize: 13.5, fontWeight: 600, letterSpacing: 0.1 }}>{t}</span>{i === active && <div style={{ position: "absolute", left: 8, right: 8, bottom: 0, height: 3, borderRadius: 3, background: "#8a8a8a" }} />}</div>)}
      </div>

      <style>{"@keyframes slR{from{transform:translateX(100%)}to{transform:translateX(0)}}@keyframes slL{from{transform:translateX(-100%)}to{transform:translateX(0)}}"}</style>
      <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", padding: "10px 10px 0", position: "relative" }} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
        <div key={active} style={{ animation: (dir > 0 ? "slR" : "slL") + " .26s cubic-bezier(.25,.8,.25,1)", willChange: "transform" }}>
          {(() => {
            const inf = (a) => topics[a.packageName] || {};
            const linked = (a) => inf(a).topicId;
            const userHidden = (a) => inf(a).flags && inf(a).flags.hidden;
            let list = null;
            if (active === 1) list = apps ? apps.filter((a) => !a.isGame && !isEmu(a)) : apps;
            else if (active === 2) list = apps ? apps.filter((a) => a.isGame && !isEmu(a)) : apps;
            else if (active === 3) list = apps ? apps.filter((a) => isEmu(a)) : apps;
            else if (active === 4) list = apps ? apps.filter((a) => !linked(a)) : apps;
            if (list) list = list.filter((a) => !userHidden(a));
            if (list && searchOpen && searchQuery.trim()) {
              const qq = searchQuery.trim().toLowerCase();
              list = list.filter((a) => (a.label || "").toLowerCase().includes(qq) || (a.packageName || "").toLowerCase().includes(qq));
            }
            const msg = (t) => <div style={{ color: C.sub, textAlign: "center", marginTop: 40, fontSize: 15 }}>{t}</div>;
            if (list === null) return msg("—");
            if (apps === null) return msg("Загрузка…");
            if (list.length === 0) return msg(active === 4 ? "Все приложения связаны с 4pda" : active === 2 ? "Игры не найдены" : "Приложения не найдены");
            return list.map((a) => <AppCard key={a.packageName} app={a} info={topics[a.packageName]} onOpen={setSel} onMenu={openMenu} onLong={enterSel} selMode={selMode} selected={!!selected[a.packageName]} onToggleSel={toggleSel} />);
          })()}
        </div>
        <div style={{ height: 12 }} />
      </div>

      {searchOpen && (
        <div style={{ background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0, paddingBottom: "env(safe-area-inset-bottom)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", height: 58, boxSizing: "border-box" }}>
            <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && searchQuery.trim()) setSearchScreen(searchQuery.trim()); }} autoFocus placeholder="Фильтр списка · Enter — поиск на 4pda" style={{ flex: 1, background: "#222", border: `1px solid ${C.border}`, borderRadius: 10, color: C.text, fontSize: 15, padding: "9px 12px", outline: "none", WebkitUserSelect: "text", userSelect: "text" }} />
            <div onClick={() => searchQuery.trim() && setSearchScreen(searchQuery.trim())} style={{ cursor: "pointer", padding: "4px 4px" }}><ISearch color={C.acc} /></div>
            <div onClick={() => { setSearchOpen(false); setSearchQuery(""); }} style={{ cursor: "pointer", color: C.sub, fontSize: 20, padding: "0 4px" }}>✕</div>
          </div>
        </div>
      )}

      {!searchOpen && <div style={{ paddingBottom: "env(safe-area-inset-bottom)", background: C.bar, borderTop: `1px solid ${C.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around", height: 58 }}>
          <NavBtn title="Системные" onClick={() => setSysScreen(true)}><IAndroid /></NavBtn>
          <NavBtn title="Скрытые" onClick={() => setHidScreen(true)}><IEyeOff /></NavBtn>
          <NavBtn title="Каталог" onClick={() => Apps.openWeb({ url: "https://4pda.to/forum/index.php?showforum=213" }).catch(() => {})}><ICatalog /></NavBtn>
          <NavBtn title="Загрузки" onClick={() => setDlScreen(true)}><IDownload /></NavBtn>
          <NavBtn title="Поиск" onClick={() => setSearchOpen((v) => !v)}><ISearch /></NavBtn>
          <NavBtn title="Обновить" onClick={refresh}><IRefresh /></NavBtn>
          <NavBtn title="Обновления" onClick={() => updates > 0 && setUpdScreen(true)}><div style={{ width: 34, height: 34, borderRadius: "50%", border: `2px solid ${updates > 0 ? "#e5675e" : "#5a5a5a"}`, background: updates > 0 ? "#e5675e" : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: updates > 0 ? "#fff" : "#d0d0d0", fontSize: 14, fontWeight: 700 }}>{updates}</span></div></NavBtn>
        </div>
      </div>}

      {sel && <Detail app={sel} onClose={() => setSel(null)} onCache={onCache} onFiles={setFilesData} />}
      {menu && <ContextMenu app={menu.app} x={menu.x} y={menu.y} info={topics[menu.app.packageName]} onClose={() => setMenu(null)} onInfo={(a) => { setMenu(null); setInfoApp(a); }} onFlag={onFlag} onLink={(a) => { setMenu(null); setLinkApp(a); }} />}
      {linkApp && <LinkScreen app={linkApp} onClose={() => setLinkApp(null)} onLinked={(pkg, patch) => { onCache(pkg, patch); }} />}
      {infoApp && <InfoDialog app={infoApp} info={topics[infoApp.packageName]} onClose={() => setInfoApp(null)} />}
      {dlScreen && <Downloads onClose={() => setDlScreen(false)} />}
      {filesData && <FilesDialog app={filesData.app} files={filesData.files} mode={filesData.mode} onClose={() => setFilesData(null)} />}
      {sysScreen && <SubList title="Системные" loadSystem topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setSysScreen(false)} />}
      {hidScreen && <SubList title="Скрытые" initial={(apps || []).filter((a) => topics[a.packageName] && topics[a.packageName].flags && topics[a.packageName].flags.hidden)} topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setHidScreen(false)} />}
      {searchScreen && <SearchScreen initialQuery={searchScreen} onClose={() => setSearchScreen(null)} onOpenResult={(r) => { setSearchScreen(null); setSel({ label: r.title, packageName: "topic:" + r.topicId, topicId: r.topicId }); }} />}
      {updScreen && <SubList title="Доступные обновления" initial={updateApps} topics={topics} onOpen={setSel} onMenu={openMenu} onClose={() => setUpdScreen(false)} />}

      {selMode && (
        <div style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 58, paddingTop: "env(safe-area-inset-top)", background: C.acc }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 14px", height: 56 }}>
            <div onClick={exitSel} style={{ cursor: "pointer", color: "#04210f", fontSize: 22, width: 26 }}>✕</div>
            <span style={{ color: "#04210f", fontSize: 18, fontWeight: 700, flex: 1 }}>Выбрано: {Object.keys(selected).length}</span>
            <div onClick={bulkHide} style={{ cursor: "pointer", color: "#04210f", fontWeight: 700, fontSize: 15 }}>Скрыть</div>
          </div>
        </div>
      )}
    </div>
  );
}
