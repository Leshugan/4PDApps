package leshugan.a4pda;

import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private void checkOpenDl(android.content.Intent i) {
        try { if (i != null && i.getBooleanExtra("open_dl", false)) { AppsPlugin.PENDING_OPEN_DL = true; i.removeExtra("open_dl"); } } catch (Exception ignored) {}
    }
    @Override
    public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        checkOpenDl(intent);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AppsPlugin.class);
        super.onCreate(savedInstanceState);
        checkOpenDl(getIntent());
        applyHighRefresh();
        applySystemBars();
    }

    @Override
    public void onResume() {
        super.onResume();
        applyHighRefresh();
        applySystemBars();
    }

    // Статус-бар и навбар в цвет темы приложения (светлые иконки на тёмном фоне)
    private void applySystemBars() {
        try {
            final int BAR = 0xFF20180F;   // C.bar (фон окна под шапкой)
            final int BG  = 0xFF161009;   // C.bg
            android.view.Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            // edge-to-edge: контент (и его фон) уходит под системные панели — тема продолжается в статус-баре и навбаре.
            // отступы в вёрстке уже сделаны через env(safe-area-inset-*), поэтому ничего не перекрывается
            if (Build.VERSION.SDK_INT >= 30) { try { w.setDecorFitsSystemWindows(false); } catch (Exception ignored) {} }
            else {
                android.view.View d0 = w.getDecorView();
                d0.setSystemUiVisibility(d0.getSystemUiVisibility()
                        | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }
            w.setStatusBarColor(android.graphics.Color.TRANSPARENT);
            w.setNavigationBarColor(android.graphics.Color.TRANSPARENT);
            try { w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(BG)); } catch (Exception ignored) {} // фон окна = фон приложения, он и виден в панелях
            android.view.View dv = w.getDecorView();
            int vis = dv.getSystemUiVisibility();
            vis &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;      // иконки статус-бара светлые
            if (Build.VERSION.SDK_INT >= 26) vis &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; // и в навбаре
            dv.setSystemUiVisibility(vis);
            if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);
            try { if (getBridge() != null && getBridge().getWebView() != null) getBridge().getWebView().setBackgroundColor(BG); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    // Запросить максимальную частоту обновления экрана (120/144 Гц вместо 60)
    private void applyHighRefresh() {
        try {
            if (Build.VERSION.SDK_INT < 23) return;
            Display display = (Build.VERSION.SDK_INT >= 30) ? getDisplay() : getWindowManager().getDefaultDisplay();
            if (display == null) return;
            Display.Mode cur = display.getMode();
            Display.Mode best = cur;
            for (Display.Mode m : display.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > best.getRefreshRate()) best = m;
            }
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best.getModeId();
            if (Build.VERSION.SDK_INT >= 31) lp.preferredRefreshRate = best.getRefreshRate();
            getWindow().setAttributes(lp);
        } catch (Exception ignored) {}
    }
}
