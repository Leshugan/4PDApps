package leshugan.a4pda;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Служба закачки: пока она жива, система не душит загрузку при свёрнутом приложении. */
public class DownloadService extends Service {
    public static final String CH = "t4dl_service";

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH, "Загрузки", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
            b.setContentTitle("Загрузка файлов");
            b.setContentText("Идёт скачивание");
            b.setSmallIcon(android.R.drawable.stat_sys_download);
            b.setOngoing(true);
            startForeground(9911, b.build());
            if (!AppsPlugin.anyActive()) { stopForeground(true); stopSelf(); }   // службу подняли, а качать нечего (система воскресила пустую) — сразу гасимся
        } catch (Throwable ignored) {}
        return START_NOT_STICKY;   // пустую службу система воскрешала с вечным «Идёт скачивание»; живые закачки поднимают её сами
    }

    @Override public void onDestroy() {
        try { stopForeground(true); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
