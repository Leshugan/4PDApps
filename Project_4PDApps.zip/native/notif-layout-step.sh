# Замена для шага «Разметка уведомления загрузки (кнопки справа)» в build.yml.
# Отличие от прежнего: цвета текста НЕ захардкожены (#DDDDDD/#9A9A9A/#C8892E),
# а берутся из системных атрибутов шторки — на светлой и тёмной шторке текст всегда читаем.
cat > android/app/src/main/res/layout/t4_notif_dl.xml << 'XML'
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent" android:layout_height="wrap_content"
    android:orientation="vertical"
    android:paddingStart="2dp" android:paddingEnd="2dp" android:paddingTop="4dp" android:paddingBottom="2dp">
  <TextView android:id="@+id/t4_title" android:layout_width="match_parent" android:layout_height="wrap_content"
      android:textSize="13sp" android:maxLines="1" android:ellipsize="end"
      android:textColor="?android:attr/textColorPrimary"/>
  <ProgressBar android:id="@+id/t4_prog" style="?android:attr/progressBarStyleHorizontal"
      android:layout_width="match_parent" android:layout_height="4dp" android:layout_marginTop="6dp" android:max="100"/>
  <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content"
      android:orientation="horizontal" android:gravity="center_vertical" android:layout_marginTop="2dp">
    <TextView android:id="@+id/t4_sub" android:layout_width="0dp" android:layout_height="wrap_content"
        android:layout_weight="1" android:textSize="11sp" android:maxLines="1"
        android:textColor="?android:attr/textColorSecondary"/>
    <TextView android:id="@+id/t4_b1" android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:minHeight="44dp" android:minWidth="64dp" android:gravity="center"
        android:textSize="14sp" android:textStyle="bold" android:textAllCaps="true"
        android:textColor="?android:attr/colorAccent"
        android:paddingStart="12dp" android:paddingEnd="12dp"/>
    <TextView android:id="@+id/t4_b2" android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:minHeight="44dp" android:minWidth="64dp" android:gravity="center"
        android:textSize="14sp" android:textStyle="bold" android:textAllCaps="true"
        android:textColor="?android:attr/colorAccent"
        android:paddingStart="12dp" android:paddingEnd="12dp"/>
  </LinearLayout>
</LinearLayout>
XML
echo "layout создан"
