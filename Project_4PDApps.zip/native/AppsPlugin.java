package leshugan.a4pda;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.URLUtil;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.ActivityCallback;
import androidx.activity.result.ActivityResult;
import android.provider.DocumentsContract;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

import androidx.core.content.FileProvider;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    // Список установленных на устройстве приложений.
    // Параметры: icons (грузить ли base64-иконки, по умолчанию true),
    //            system (включать ли системные, по умолчанию false — только запускаемые пользовательские).
    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        boolean withIcons = Boolean.TRUE.equals(call.getBoolean("icons", true));
        boolean incSystem = Boolean.TRUE.equals(call.getBoolean("system", false));
        boolean incHidden = Boolean.TRUE.equals(call.getBoolean("hidden", false));
        PackageManager pm = getContext().getPackageManager();

        JSArray apps = new JSArray();
        List<PackageInfo> pkgs;
        try {
            pkgs = pm.getInstalledPackages(0);
        } catch (Exception e) {
            call.reject("getInstalledPackages: " + e.getMessage());
            return;
        }

        String self = getContext().getPackageName();
        java.io.File iconDir = new java.io.File(getContext().getCacheDir(), "appicons");
        if (withIcons) iconDir.mkdirs();
        java.util.HashSet<String> valid = new java.util.HashSet<>();

        for (PackageInfo pi : pkgs) {
            try {
                ApplicationInfo ai = pi.applicationInfo;
                if (ai == null) continue;
                if (pi.packageName.equals(self)) continue;

                boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean launchable = pm.getLaunchIntentForPackage(pi.packageName) != null;
                long vc = (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : (long) pi.versionCode;
                String iconName = pi.packageName + "_" + vc + ".png";
                if (withIcons) valid.add(iconName);

                boolean show;
                if (isSystem) show = incSystem;
                else if (!launchable) show = incHidden;
                else show = true;
                if (!show) continue;

                JSObject o = new JSObject();
                o.put("packageName", pi.packageName);
                o.put("label", String.valueOf(ai.loadLabel(pm)));
                o.put("versionName", pi.versionName == null ? "" : pi.versionName);
                o.put("versionCode", vc);
                o.put("system", isSystem);
                o.put("launchable", launchable);
                boolean isGame = false;
                try {
                    if (Build.VERSION.SDK_INT >= 26) isGame = (ai.category == ApplicationInfo.CATEGORY_GAME);
                    if (!isGame) isGame = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                } catch (Exception ignored) {}
                o.put("isGame", isGame);
                o.put("enabled", ai.enabled);
                o.put("firstInstall", pi.firstInstallTime);
                o.put("lastUpdate", pi.lastUpdateTime);
                if (withIcons) {
                    try {
                        java.io.File f = new java.io.File(iconDir, iconName);
                        if (!f.exists()) {
                            Bitmap b = drawableToBitmap(pm.getApplicationIcon(ai));
                            if (b != null) {
                                int mx = Math.max(b.getWidth(), b.getHeight());
                                if (mx > 96) { float sc = 96f / mx; b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true); }
                                java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
                                b.compress(Bitmap.CompressFormat.PNG, 100, fos);
                                fos.flush(); fos.close();
                            }
                        }
                        if (f.exists()) o.put("iconFile", f.getAbsolutePath());
                    } catch (Exception ignored) {}
                }
                apps.put(o);
            } catch (Exception ignored) {}
        }

        // очистить кэш от иконок удалённых/обновлённых приложений
        if (withIcons) {
            try {
                java.io.File[] cached = iconDir.listFiles();
                if (cached != null) for (java.io.File cf : cached) { if (!valid.contains(cf.getName())) cf.delete(); }
            } catch (Exception ignored) {}
        }

        JSObject ret = new JSObject();
        ret.put("apps", apps);
        ret.put("count", apps.length());
        call.resolve(ret);
    }

    // Открыть ссылку во внешнем браузере (тема 4pda и т.п.)
    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // Открыть 4pda внутри приложения (поиск/тема, с сохранением логина, скачивание по тапу)
    @PluginMethod
    public void openWeb(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            Intent i = new Intent(getContext(), WebViewActivity.class);
            i.putExtra("url", url);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // Подробная информация о приложении (для диалога «Информация»)
    @PluginMethod
    public void appDetails(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            PackageManager pm = getContext().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            ApplicationInfo ai = pi.applicationInfo;
            JSObject o = new JSObject();
            o.put("packageName", pkg);
            o.put("label", String.valueOf(ai.loadLabel(pm)));
            o.put("versionName", pi.versionName == null ? "" : pi.versionName);
            long vc = (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : (long) pi.versionCode;
            o.put("versionCode", vc);
            o.put("targetSdk", ai.targetSdkVersion);
            if (Build.VERSION.SDK_INT >= 24) o.put("minSdk", ai.minSdkVersion);
            o.put("enabled", ai.enabled);
            o.put("system", (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
            o.put("firstInstall", pi.firstInstallTime);
            o.put("lastUpdate", pi.lastUpdateTime);
            try { o.put("apkSize", new java.io.File(ai.sourceDir).length()); } catch (Exception ignored) {}
            String installer = "";
            try {
                if (Build.VERSION.SDK_INT >= 30) { android.content.pm.InstallSourceInfo isi = pm.getInstallSourceInfo(pkg); installer = isi.getInstallingPackageName(); }
                else installer = pm.getInstallerPackageName(pkg);
            } catch (Exception ignored) {}
            o.put("installer", installer == null ? "" : installer);
            call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Запустить установленное приложение
    @PluginMethod
    public void launchApp(PluginCall call) {        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { call.reject("нет интента запуска"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Системный экран «О приложении»
    @PluginMethod
    public void openAppInfo(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Удалить приложение (системный диалог)
    @PluginMethod
    public void uninstallApp(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Список скачанных apk в папке «Загрузки»
    @PluginMethod
    public void listDownloads(PluginCall call) {        JSArray files = new JSArray();
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File[] arr = dir != null ? dir.listFiles() : null;
            if (arr != null) {
                for (File f : arr) {
                    if (f.isFile() && f.getName().toLowerCase().endsWith(".apk")) {
                        JSObject o = new JSObject();
                        o.put("name", f.getName());
                        o.put("path", f.getAbsolutePath());
                        o.put("size", f.length());
                        o.put("date", f.lastModified());
                        files.put(o);
                    }
                }
            }
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("files", files);
        call.resolve(ret);
    }

    // Статус загрузок DownloadManager (для экрана «Загрузки» с прогрессом)
    @PluginMethod
    public void downloadStatus(PluginCall call) {
        JSArray arr = new JSArray();
        try {
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            android.database.Cursor c = dm.query(new DownloadManager.Query());
            if (c != null) {
                while (c.moveToNext()) {
                    JSObject o = new JSObject();
                    o.put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                    o.put("title", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)));
                    o.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                    o.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                    o.put("done", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                    o.put("uri", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)));
                    try { String lf = c.getString(c.getColumnIndex("local_filename")); if (lf != null && !lf.isEmpty()) o.put("path", lf); } catch (Exception ignored) {} // реальный путь: COLUMN_LOCAL_URI на новых Android приходит как content://
                    try { o.put("src", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_URI))); } catch (Exception ignored) {}
                    o.put("date", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)));
                    arr.put(o);
                }
                c.close();
            }
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("items", arr);
        call.resolve(ret);
    }

    // Установить apk (сессия PackageInstaller — как в YevFiles)
    private static final java.util.concurrent.ConcurrentHashMap<Long, long[]> DL_SPEED = new java.util.concurrent.ConcurrentHashMap<>();
    public static volatile boolean PENDING_OPEN_DL = false;   // тап по уведомлению закачки — открыть «Загрузки»

    @PluginMethod
    public void consumeOpenDl(PluginCall call) {
        boolean v = PENDING_OPEN_DL; PENDING_OPEN_DL = false;
        JSObject r = new JSObject(); r.put("open", v); call.resolve(r);
    }

    private volatile JSObject lastInstall = null;   // итог установки, если когда-то заполнится (сейчас ставим системным установщиком)

    @PluginMethod
    public void lastInstallResult(PluginCall call) {
        JSObject r = lastInstall; lastInstall = null;
        call.resolve(r != null ? r : new JSObject());
    }

    @PluginMethod
    public void apkMeta(PluginCall call) {
        String path = call.getString("path");
        JSObject o = new JSObject();
        try {
            if (path == null || path.isEmpty()) { call.resolve(o); return; }
            File f = new File(path);
            if (!f.exists()) { try { File alt = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), f.getName()); if (alt.exists()) f = alt; } catch (Exception ignored) {} }
            if (!f.exists()) { call.resolve(o); return; }
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (pi != null && pi.applicationInfo != null) {
                ApplicationInfo ai = pi.applicationInfo;
                ai.sourceDir = f.getAbsolutePath(); ai.publicSourceDir = f.getAbsolutePath();
                try { o.put("label", String.valueOf(ai.loadLabel(pm))); } catch (Exception ignored) {}
                try { o.put("version", pi.versionName); } catch (Exception ignored) {}
                try { o.put("pkg", pi.packageName); } catch (Exception ignored) {}
                try { String b64 = drawableToBase64(ai.loadIcon(pm)); if (b64 != null) o.put("icon", b64); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        call.resolve(o);
    }

    @PluginMethod
    public void installApk(PluginCall call) {
        String path = call.getString("path");
        String uriStr = call.getString("uri");
        try {
            if ((path == null || path.isEmpty()) && uriStr != null && uriStr.startsWith("file://")) {
                String u = uriStr.substring(7);
                if (u.indexOf('%') >= 0) { try { u = java.net.URLDecoder.decode(u, "UTF-8"); } catch (Exception ignored) {} }
                path = u;
            }
            Uri data = null;
            if (path != null && !path.isEmpty()) {
                File f = new File(path);
                if (!f.exists()) { try { File alt = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), f.getName()); if (alt.exists()) f = alt; } catch (Exception ignored) {} }
                if (!f.exists() || !f.canRead()) {
                    if (uriStr != null && uriStr.startsWith("content://")) data = Uri.parse(uriStr);          // файл в выбранной SAF-папке
                    else {
                        android.net.Uri md = findInDownloads(f.getName());                                     // файл в общих «Загрузках», доступ только через MediaStore
                        if (md != null) data = md;
                        else { call.reject("файл не найден: " + f.getAbsolutePath()); return; }
                    }
                }
                else data = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            } else if (uriStr != null && uriStr.startsWith("content://")) {
                data = Uri.parse(uriStr);
            }
            if (data == null) { String nm2 = call.getString("name"); android.net.Uri md = findInDownloads(nm2); if (md != null) data = md; }
            if (data == null) { call.reject("нет пути к файлу"); return; }
            // именно установка, а не «открыть файл» — иначе система показывает пикер «Открыть с помощью»
            Intent i = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            i.setData(data);
            i.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            try { getContext().startActivity(i); }
            catch (Exception ex) {
                Intent v2 = new Intent(Intent.ACTION_VIEW);
                v2.setDataAndType(data, "application/vnd.android.package-archive");
                v2.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                v2.setPackage("com.google.android.packageinstaller");   // системный установщик напрямую, без пикера
                try { getContext().startActivity(v2); }
                catch (Exception ex2) { v2.setPackage("com.android.packageinstaller"); getContext().startActivity(v2); }
            }
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void deviceAbis(PluginCall call) {        JSArray arr = new JSArray();
        try {
            String[] abis = (Build.VERSION.SDK_INT >= 21) ? Build.SUPPORTED_ABIS : new String[]{ Build.CPU_ABI };
            if (abis != null) for (String a : abis) arr.put(a);
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("abis", arr);
        call.resolve(ret);
    }

    // Версия приложения из Google Play БЕЗ входа в аккаунт:
    // анонимный токен с раздатчика auroraoss + gplayapi (AppDetailsHelper).
    @PluginMethod
    public void playVersion(final PluginCall call) {
        final String pkg = call.getString("packageName");
        if (pkg == null || pkg.isEmpty()) { call.reject("no package"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String v = PlayApi.version(getContext(), pkg);
                    if (v == null || v.isEmpty()) { call.reject("no version"); return; }
                    String[] parts = v.split("\u0001", 2);
                    JSObject ret = new JSObject();
                    ret.put("versionName", parts[0]);
                    if (parts.length > 1) ret.put("versionCode", parts[1]);
                    call.resolve(ret);
                } catch (Throwable e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }


    // Прямая ссылка на вложение по его номеру (команда fa) — сервер отдаёт готовый адрес с ключом,
    // качать можно без входа на сайт. И список постов темы (fr со смещением) — из них берём вложения.
    @PluginMethod
    public void protoAttach(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String ver = call.getString("ver", "1.9.43");
        final JSArray idsArr = call.getArray("attachIds");
        final String topicId = call.getString("topicId", "");
        final int from = call.getInt("from", 0);
        final int count = call.getInt("count", 20);
        final int waitMs = call.getInt("waitMs", 12000);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            JSArray links = new JSArray();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(6000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                protoRead(is, 2000);
                if (topicId != null && !topicId.isEmpty()) {
                    boolean last = Boolean.TRUE.equals(call.getBoolean("last", Boolean.FALSE));
                    int off = from;
                    if (last) {   // файлы лежат в ПОСЛЕДНИХ постах: сперва узнаём, сколько их всего
                        os.write(protoFrame("[" + (num++) + ",\"fr\"," + topicId + ",0,1,0]")); os.flush();
                        String head = protoRead(is, 6000);
                        try {
                            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[\\],(\\d{1,7}),\\[\\[").matcher(head);
                            if (m.find()) { int total = Integer.parseInt(m.group(1)); off = Math.max(0, total - count); }
                        } catch (Exception ignored) {}
                        o.put("total", off);
                    }
                    os.write(protoFrame("[" + (num++) + ",\"fr\"," + topicId + "," + off + "," + count + ",0]")); os.flush();
                    o.put("posts", protoRead(is, waitMs));
                }
                java.util.List<String> ids = new java.util.ArrayList<>();
                try { java.util.List<Object> l = idsArr != null ? idsArr.toList() : null; if (l != null) for (Object x : l) { String v = String.valueOf(x); if (v.matches("\\d{3,12}")) ids.add(v); } } catch (Exception ignored) {}
                for (String id : ids) {
                    os.write(protoFrame("[" + (num++) + ",\"fa\"," + id + "]"));
                }
                if (!ids.isEmpty()) {
                    os.flush();
                    String r = protoRead(is, waitMs);
                    for (String line : r.split("\n")) {
                        int q = line.indexOf("\"http");
                        if (q > 0) {
                            int e = line.indexOf('"', q + 1);
                            if (e > q) { links.put(line.substring(q + 1, e)); }
                        }
                    }
                }
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("links", links); o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ---- Сервер App&Game 4PDA (freeman42) как ДОПОЛНИТЕЛЬНЫЙ источник ----
    // Обычный POST на srv<N>.freeman42.ru/app4pda.v3/<метод>. Ключ — идентификатор устройства
    // (свой, генерируем один раз), «хеш» — его отпечаток MD5, как в их приложении.
    @PluginMethod
    public void agRequest(final PluginCall call) {
        final int srv = call.getInt("srv", 1);
        final String method = call.getString("method", "getAppInfo.php");
        final String extra = call.getString("params", "");     // готовая строка вида app_url=…&topic_id=…
        final String appVer = call.getString("appVer", "5.3 beta 9 (539)");   // ВАЖНО: без кода сборки в скобках сервер падает
        new Thread(new Runnable() { public void run() {
            JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            java.net.HttpURLConnection c = null;
            try {
                android.content.SharedPreferences sp = getContext().getSharedPreferences("t4ag", Context.MODE_PRIVATE);
                String raw = sp.getString("raw", "");
                if (raw.isEmpty()) {   // исходный идентификатор устройства — как в их приложении
                    try { raw = android.provider.Settings.Secure.getString(getContext().getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); } catch (Throwable ignored) {}
                    if (raw == null || raw.isEmpty()) raw = Long.toHexString(System.currentTimeMillis()) + (int) (Math.random() * 1000000);
                    sp.edit().putString("raw", raw).apply();
                }
                // ключ = перевёрнутый base64 исходного идентификатора, отпечаток = MD5 ИСХОДНОГО (а не ключа)
                String key = new StringBuffer(Base64.encodeToString(raw.getBytes("UTF-8"), Base64.NO_WRAP)).reverse().toString();
                String hash = md5hex(raw);
                // как в их приложении: ключ/отпечаток/версия — В АДРЕСЕ, длинные значения (список тем) — в теле
                StringBuilder q = new StringBuilder();
                q.append("?key=").append(java.net.URLEncoder.encode(key, "UTF-8"));
                q.append("&hash=").append(java.net.URLEncoder.encode(hash, "UTF-8"));
                q.append("&app_ver=").append(java.net.URLEncoder.encode(appVer, "UTF-8"));
                // поля пользователя 4pda — их клиент шлёт их только когда человек вошёл; шлём, если заданы
                String uid = call.getString("userId", "");
                String uname = call.getString("userName", "");
                String emailHash = call.getString("emailHash", "");
                if (!uid.isEmpty()) q.append("&user_id=").append(java.net.URLEncoder.encode(uid, "UTF-8"));
                if (!uname.isEmpty()) q.append("&username=").append(java.net.URLEncoder.encode(uname, "UTF-8"));
                if (!emailHash.isEmpty()) q.append("&email_hash=").append(java.net.URLEncoder.encode(emailHash, "UTF-8"));
                String extraQ = call.getString("q", "");            // произвольные дополнительные поля адреса (для подбора)
                if (extraQ.equals("device_key=")) extraQ = "device_key=" + java.net.URLEncoder.encode(key, "UTF-8");   // их «ключ устройства» = наш key
                if (!extraQ.isEmpty()) q.append("&").append(extraQ);
                // ПУСТЫЕ username/email_hash НЕ шлём: сервер подставляет их в запрос к базе как есть и падает
                // сведения об устройстве сервер записывает у себя — без них падает на вставке в базу
                // ВАЖНО: сведения об устройстве у них — 13 полей через «|», сервер разбирает их по частям.
                // Пустые части ломают его запрос к базе, поэтому заполняем все.
                String aid = "";
                try { aid = android.provider.Settings.Secure.getString(getContext().getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); } catch (Throwable ignored) {}
                if (aid == null || aid.isEmpty()) aid = "0000000000000000";
                int dens = 320, w = 1080, h = 1920;
                try { android.util.DisplayMetrics dm = getContext().getResources().getDisplayMetrics();
                      dens = dm.densityDpi; w = dm.widthPixels; h = dm.heightPixels; } catch (Throwable ignored) {}
                String[] parts = new String[] {
                    aid,                                   // идентификатор устройства
                    android.os.Build.MANUFACTURER,
                    android.os.Build.MODEL,
                    android.os.Build.DEVICE,
                    android.os.Build.PRODUCT,
                    android.os.Build.BRAND,
                    android.os.Build.HARDWARE,
                    android.os.Build.BOARD,
                    android.os.Build.VERSION.RELEASE,
                    java.util.Locale.getDefault().toString(),
                    String.valueOf(android.os.Build.VERSION.SDK_INT),
                    String.valueOf(dens),
                    w + "x" + h
                };
                StringBuilder db = new StringBuilder();
                for (int i = 0; i < parts.length; i++) {
                    String v = parts[i] == null || parts[i].isEmpty() ? "unknown" : parts[i];
                    if (i > 0) db.append("|");
                    db.append(v);
                }
                String dev = db.toString();
                StringBuilder body = new StringBuilder();
                body.append("device_info=").append(java.net.URLEncoder.encode(dev, "UTF-8"));
                if (extra != null && !extra.isEmpty()) body.append("&").append(extra);
                java.net.URL u = new java.net.URL("https://srv" + srv + ".freeman42.ru/app4pda.v3/" + method + q);
                c = (java.net.HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000); c.setReadTimeout(12000);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                c.setRequestProperty("User-Agent", UA);
                c.setDoOutput(true);
                byte[] bb = body.toString().getBytes("UTF-8");
                c.getOutputStream().write(bb); c.getOutputStream().flush();
                int code = c.getResponseCode();
                java.io.InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = is.read(buf)) > 0 && bos.size() < 1024 * 512) bos.write(buf, 0, n);
                o.put("status", code);
                o.put("sent", u.toString() + "  |  тело: " + body.toString());
                o.put("body", new String(bos.toByteArray(), "UTF-8"));
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (c != null) c.disconnect(); } catch (Exception ignored) {} }
            o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }
    private String md5hex(String in) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] d = md.digest(in.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }

    // Список тем раздела (команда fs) — замена обхода страниц сайта
    @PluginMethod
    public void protoForum(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final JSArray fidsArr = call.getArray("forumIds");
        final int from = call.getInt("from", 0);
        final int count = call.getInt("count", 30);
        final String ver = call.getString("ver", "1.9.43");
        final int waitMs = call.getInt("waitMs", 20000);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            JSArray out = new JSArray();
            try {
                java.util.List<String> fids = new java.util.ArrayList<>();
                try { java.util.List<Object> l = fidsArr != null ? fidsArr.toList() : null; if (l != null) for (Object x : l) { String v = String.valueOf(x); if (v.matches("\\d{1,7}")) fids.add(v); } } catch (Exception ignored) {}
                if (fids.isEmpty()) { o.put("ok", true); o.put("items", out); call.resolve(o); return; }
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(5000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                protoRead(is, 2000);
                java.util.HashMap<String, String> byNum = new java.util.HashMap<>();
                for (String f : fids) { int n = num++; byNum.put(String.valueOf(n), f);
                    os.write(protoFrame("[" + n + ",\"fs\"," + f + "," + from + "," + count + "]")); }
                os.flush();
                String all = protoRead(is, waitMs);
                for (String line : all.split("\n")) {
                    int c = line.indexOf(',');
                    if (!line.startsWith("[") || c < 2) continue;
                    String fid = byNum.get(line.substring(1, c).trim());
                    if (fid == null) continue;
                    JSObject it = new JSObject();
                    it.put("forumId", fid);
                    it.put("raw", line.length() > 60000 ? line.substring(0, 60000) : line);
                    out.put(it);
                }
                o.put("ok", true);
            } catch (Throwable e) { o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); }
            finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("items", out); o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ПОИСК через служебный сервер официального клиента (команда rc) — вместо обхода страниц сайта
    @PluginMethod
    public void protoSearch(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String q = call.getString("query", "");
        final int from = call.getInt("from", 0);
        final int count = call.getInt("count", 60);
        final String ver = call.getString("ver", "1.9.43");
        final int waitMs = call.getInt("waitMs", 12000);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(6000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                protoRead(is, 2000);
                String esc = q.replace("\\", "").replace("\"", "");
                os.write(protoFrame("[" + num + ",\"rc\",196610,[0],[0],[0],\"" + esc + "\"," + from + "," + count + "]")); os.flush();
                o.put("raw", protoRead(is, waitMs));
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // ПАЧКОЙ: одно соединение — представляемся и отправляем запросы ВСЕХ тем подряд,
    // не дожидаясь ответа на каждый. Ответы приходят вперемешку, сопоставляем их по номеру запроса.
    @PluginMethod
    public void protoTopics(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final JSArray idsArr = call.getArray("topicIds");
        final int waitMs = call.getInt("waitMs", 20000);
        final String ver = call.getString("ver", "1.9.43");   // версия официального клиента — приходит из настроек, не зашита
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            JSArray out = new JSArray();
            try {
                java.util.List<String> ids = new java.util.ArrayList<>();
                try { java.util.List<Object> l = idsArr != null ? idsArr.toList() : null; if (l != null) for (Object x : l) { String v = String.valueOf(x); if (v.matches("\\d{3,9}")) ids.add(v); } } catch (Exception ignored) {}
                if (ids.isEmpty()) { o.put("ok", true); o.put("items", out); call.resolve(o); return; }
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(4000);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + (num++) + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                o.put("hello", protoRead(is, 2500));
                java.util.HashMap<String, String> byNum = new java.util.HashMap<>();
                for (String id : ids) {
                    int n = num++;
                    byNum.put(String.valueOf(n), id);
                    os.write(protoFrame("[" + n + ",\"fr\"," + id + ",0,1,0]"));
                }
                os.flush();
                java.util.HashMap<String, String> got = new java.util.HashMap<>();
                java.io.ByteArrayOutputStream acc = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                while (got.size() < ids.size() && System.currentTimeMillis() - t0 < waitMs) {
                    int n;
                    try { n = is.read(buf); } catch (java.net.SocketTimeoutException te) { break; }
                    if (n <= 0) break;
                    acc.write(buf, 0, n);
                    byte[] b = acc.toByteArray();
                    int i = 0;
                    while (i + 2 <= b.length) {
                        int b0 = b[i] & 0xff, ln = b[i + 1] & 0x7f, p = i + 2;
                        if (ln == 126) { if (p + 2 > b.length) break; ln = ((b[p] & 0xff) << 8) | (b[p + 1] & 0xff); p += 2; }
                        else if (ln == 127) { if (p + 8 > b.length) break; ln = ((b[p + 4] & 0xff) << 24) | ((b[p + 5] & 0xff) << 16) | ((b[p + 6] & 0xff) << 8) | (b[p + 7] & 0xff); p += 8; }
                        if (p + ln > b.length) break;
                        String txt;
                        if ((b0 & 0x40) != 0 && ln > 4) {
                            try { java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                                  inf.setInput(b, p + 4, ln - 4);
                                  byte[] ob = new byte[262144]; int m = inf.inflate(ob); inf.end();
                                  txt = new String(ob, 0, m, "windows-1251"); }
                            catch (Throwable e) { txt = ""; }
                        } else txt = new String(b, p, ln, "windows-1251");
                        i = p + ln;
                        int c = txt.indexOf(',');
                        if (txt.startsWith("[") && c > 1) {
                            String key = txt.substring(1, c).trim();
                            String id = byNum.get(key);
                            if (id != null && !got.containsKey(id)) got.put(id, txt);
                        }
                    }
                    if (i > 0) { byte[] rest = new byte[b.length - i]; System.arraycopy(b, i, rest, 0, rest.length); acc.reset(); acc.write(rest); }
                }
                boolean brief = Boolean.TRUE.equals(call.getBoolean("brief", Boolean.FALSE));
                for (java.util.Map.Entry<String, String> e : got.entrySet()) {
                    JSObject it = new JSObject();
                    it.put("topicId", e.getKey());
                    String r = e.getValue();
                    if (brief) {   // разбираем здесь и отдаём только нужное — не гоняем шапку целиком в интерфейс
                        try {
                            java.util.regex.Matcher m1 = java.util.regex.Pattern.compile("attachment=\\\\?\"(\\d{4,12}):([^\"\\\\]+)").matcher(r);
                            while (m1.find()) {
                                String nm = m1.group(2);
                                if (nm.matches("(?i).+\\.(png|jpg|jpeg|gif|webp)")) { it.put("icon", "https://4pda.to/forum/dl/post/" + m1.group(1) + "/" + nm); break; }
                            }
                        } catch (Throwable ignored) {}
                        try {
                            java.util.regex.Matcher m2 = java.util.regex.Pattern.compile(",\\d{3,9},\"[^\"]{2,120}\",\"([^\"]{2,300})\"").matcher(r);
                            if (m2.find()) it.put("desc", m2.group(1).replaceAll("\\s+", " ").trim());
                        } catch (Throwable ignored) {}
                        try {
                            java.util.regex.Matcher m3 = java.util.regex.Pattern.compile("\\[\\[1,(\\d{2,6}),\"").matcher(r);
                            if (m3.find()) it.put("forumId", Integer.parseInt(m3.group(1)));
                        } catch (Throwable ignored) {}
                        if (!it.has("icon")) it.put("raw", r.length() > 6000 ? r.substring(0, 6000) : r);   // не нашли — отдаём кусок шапки, разберёт интерфейс
                    } else it.put("raw", r.length() > 20000 ? r.substring(0, 20000) : r);
                    out.put(it);
                }
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            o.put("items", out); o.put("ms", System.currentTimeMillis() - t0);
            call.resolve(o);
        } }).start();
    }

    // Запрос темы через служебный сервер официального клиента: представляемся («ah»),
    // затем просим тему («fr», номер темы) и возвращаем распакованный ответ (строки в windows-1251).
    @PluginMethod
    public void protoTopic(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.to");
        final int port = call.getInt("port", 993);
        final String topicId = call.getString("topicId", "");
        final int waitMs = call.getInt("waitMs", 8000);
        final String ver = call.getString("ver", "1.9.43");
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                sock = new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(waitMs);
                java.io.OutputStream os = sock.getOutputStream();
                java.io.InputStream is = sock.getInputStream();
                int num = 1000 + (int) (Math.random() * 100000);
                os.write(protoFrame("[" + num + ",\"ah\",\"" + ver + "\",\"\",\"\",0,0]")); os.flush();
                String r1 = protoRead(is, 2500);
                o.put("hello", r1);
                os.write(protoFrame("[" + (num + 1) + ",\"fr\"," + topicId + ",0,20,0]")); os.flush();
                String r2 = protoRead(is, waitMs);
                o.put("topic", r2);
                o.put("ok", true); o.put("ms", System.currentTimeMillis() - t0);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }
    private byte[] protoFrame(String text) throws Exception {
        byte[] raw = text.getBytes("windows-1251");
        java.util.zip.Deflater df = new java.util.zip.Deflater(6, true);
        df.setInput(raw); df.finish();
        byte[] tmp = new byte[raw.length + 100]; int n = df.deflate(tmp); df.end();
        int lenField = n + 4;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        out.write(0xc1);
        if (lenField <= 0x7d) out.write(lenField);
        else if (lenField <= 0xffff) { out.write(0x7e); out.write((lenField >> 8) & 0xff); out.write(lenField & 0xff); }
        else { out.write(0x7f); for (int i = 0; i < 4; i++) out.write(0);
               out.write((lenField >> 24) & 0xff); out.write((lenField >> 16) & 0xff); out.write((lenField >> 8) & 0xff); out.write(lenField & 0xff); }
        out.write(raw.length & 0xff); out.write((raw.length >> 8) & 0xff); out.write((raw.length >> 16) & 0xff); out.write((raw.length >> 24) & 0xff);
        out.write(tmp, 0, n);
        return out.toByteArray();
    }
    private String protoRead(java.io.InputStream is, int waitMs) {
        try {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; long t0 = System.currentTimeMillis();
            while (bos.size() < 262144) {
                int n;
                try { n = is.read(buf); } catch (java.net.SocketTimeoutException te) { break; }
                if (n <= 0) break;
                bos.write(buf, 0, n);
                if (System.currentTimeMillis() - t0 > waitMs) break;
                if (is.available() == 0) { try { Thread.sleep(250); } catch (InterruptedException ignored) {} if (is.available() == 0) break; }
            }
            byte[] b = bos.toByteArray();
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i + 2 <= b.length) {
                int b0 = b[i] & 0xff, ln = b[i + 1] & 0x7f, p = i + 2;
                if (ln == 126) { ln = ((b[p] & 0xff) << 8) | (b[p + 1] & 0xff); p += 2; }
                else if (ln == 127) { ln = ((b[p + 4] & 0xff) << 24) | ((b[p + 5] & 0xff) << 16) | ((b[p + 6] & 0xff) << 8) | (b[p + 7] & 0xff); p += 8; }
                if (p + ln > b.length) break;
                byte[] pay = new byte[ln]; System.arraycopy(b, p, pay, 0, ln); i = p + ln;
                if ((b0 & 0x40) != 0 && ln > 4) {
                    try {
                        java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                        inf.setInput(pay, 4, ln - 4);
                        byte[] out = new byte[262144]; int m = inf.inflate(out); inf.end();
                        sb.append(new String(out, 0, m, "windows-1251"));
                    } catch (Throwable e) { sb.append("<не распаковалось>"); }
                } else sb.append(new String(pay, "windows-1251"));
                sb.append("\n");
            }
            return sb.toString();
        } catch (Throwable e) { return "<ошибка чтения: " + e.getMessage() + ">"; }
    }

    // Полное подключение как у официального клиента: сначала веб-сокет-рукопожатие
    // (GET /ws/ + Upgrade + Sec-WebSocket-Protocol: app + версия 13), затем кадр с данными.
    @PluginMethod
    public void wsProbe(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.ru");
        final int port = call.getInt("port", 443);
        final String path = call.getString("path", "/ws/");
        final int type = call.getInt("type", 1) & 0xf;
        final boolean compress = !Boolean.FALSE.equals(call.getBoolean("compress", true));
        final boolean mask = !Boolean.FALSE.equals(call.getBoolean("mask", false));
        final String text = call.getString("text", "");
        final int waitMs = call.getInt("waitMs", 6000);
        final boolean tls = !Boolean.FALSE.equals(call.getBoolean("tls", true));   // на нестандартных портах бывает без шифрования
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                if (tls) { sock = javax.net.ssl.SSLSocketFactory.getDefault().createSocket(host, port); }   // с именем хоста (SNI)
                else { sock = new java.net.Socket(); sock.connect(new java.net.InetSocketAddress(host, port), 8000); }
                sock.setSoTimeout(waitMs);
                if (tls) ((javax.net.ssl.SSLSocket) sock).startHandshake();
                byte[] keyb = new byte[16]; new java.util.Random().nextBytes(keyb);
                String key = Base64.encodeToString(keyb, Base64.NO_WRAP);
                String hs = "GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        + "Sec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Protocol: app\r\nSec-WebSocket-Version: 13\r\n\r\n";
                java.io.OutputStream os = sock.getOutputStream();
                os.write(hs.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1)); os.flush();
                java.io.InputStream is = sock.getInputStream();
                java.io.ByteArrayOutputStream head = new java.io.ByteArrayOutputStream();
                int c; boolean upgraded = false;
                while ((c = is.read()) >= 0) {
                    head.write(c);
                    String h = head.toString("ISO-8859-1");
                    if (h.endsWith("\r\n\r\n")) { upgraded = h.contains(" 101 "); break; }
                    if (head.size() > 4096) break;
                }
                o.put("handshake", head.toString("ISO-8859-1"));
                o.put("upgraded", upgraded);
                if (upgraded && text != null) {
                    byte[] raw = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    byte[] body; int lenField;
                    if (compress) {
                        java.util.zip.Deflater df = new java.util.zip.Deflater(6, true);
                        df.setInput(raw); df.finish();
                        byte[] tmp = new byte[raw.length + 100]; int n = df.deflate(tmp); df.end();
                        body = new byte[n]; System.arraycopy(tmp, 0, body, 0, n); lenField = n + 4;
                    } else { body = raw; lenField = raw.length; }
                    java.io.ByteArrayOutputStream fr = new java.io.ByteArrayOutputStream();
                    fr.write(0x80 | (compress ? 0x40 : 0) | type);
                    int lb = mask ? 0x80 : 0;
                    if (lenField <= 0x7d) fr.write(lb | lenField);
                    else if (lenField <= 0xffff) { fr.write(lb | 0x7e); fr.write((lenField >> 8) & 0xff); fr.write(lenField & 0xff); }
                    else { fr.write(lb | 0x7f); for (int i = 0; i < 4; i++) fr.write(0);
                           fr.write((lenField >> 24) & 0xff); fr.write((lenField >> 16) & 0xff); fr.write((lenField >> 8) & 0xff); fr.write(lenField & 0xff); }
                    byte[] pre = compress ? new byte[]{ (byte) (raw.length & 0xff), (byte) ((raw.length >> 8) & 0xff), (byte) ((raw.length >> 16) & 0xff), (byte) ((raw.length >> 24) & 0xff) } : new byte[0];
                    byte[] payload = new byte[pre.length + body.length];
                    System.arraycopy(pre, 0, payload, 0, pre.length); System.arraycopy(body, 0, payload, pre.length, body.length);
                    if (mask) {
                        byte[] mk = new byte[4]; new java.util.Random().nextBytes(mk); fr.write(mk, 0, 4);
                        for (int i = 0; i < payload.length; i++) payload[i] = (byte) (payload[i] ^ mk[i & 3]);
                    }
                    fr.write(payload, 0, payload.length);
                    os.write(fr.toByteArray()); os.flush();
                    o.put("sent", fr.size());
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[2048];
                    try { int n; while (bos.size() < 8192 && (n = is.read(buf)) > 0) { bos.write(buf, 0, n); if (System.currentTimeMillis() - t0 > waitMs) break; } }
                    catch (java.net.SocketTimeoutException ignored) {}
                    byte[] resp = bos.toByteArray();
                    StringBuilder hx = new StringBuilder(); StringBuilder pr = new StringBuilder();
                    for (int i = 0; i < resp.length; i++) { hx.append(String.format("%02x", resp[i] & 0xff)); if ((i & 1) == 1) hx.append(' ');
                        int ch = resp[i] & 0xff; pr.append(ch >= 32 && ch < 127 ? (char) ch : '.'); }
                    o.put("len", resp.length); o.put("hex", hx.toString()); o.put("text", pr.toString());
                    try {
                        if (resp.length > 2) {
                            int f = resp[0] & 0xff, p = 1, dlen = resp[1] & 0x7f;
                            if (dlen == 0x7e) { dlen = ((resp[2] & 0xff) << 8) | (resp[3] & 0xff); p = 4; }
                            else if (dlen == 0x7f) { dlen = ((resp[6] & 0xff) << 24) | ((resp[7] & 0xff) << 16) | ((resp[8] & 0xff) << 8) | (resp[9] & 0xff); p = 10; }
                            else p = 2;
                            o.put("respType", f & 0xf); o.put("respCompressed", (f & 0x40) != 0); o.put("respLen", dlen);
                            if ((f & 0x40) != 0 && resp.length > p + 4) {
                                java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                                inf.setInput(resp, p + 4, resp.length - p - 4);
                                byte[] out = new byte[65536]; int m = inf.inflate(out); inf.end();
                                o.put("body", new String(out, 0, m, java.nio.charset.StandardCharsets.UTF_8));
                            } else if (resp.length > p) o.put("body", new String(resp, p, Math.min(resp.length - p, 4096), java.nio.charset.StandardCharsets.UTF_8));
                        }
                    } catch (Throwable ignored) {}
                }
                o.put("ms", System.currentTimeMillis() - t0); o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // Отправка пакета В ТОЧНОСТИ как это делает официальный клиент 4pda:
    // байт0 = флаги(0x80 ответ ждём / 0x40 сжато) | тип(младшие 4 бита);
    // байт1 = длина (<=125 как есть; <=65535 — 0x7e + 2 байта; иначе 0x7f + 8 байт),
    // при сжатии сразу после заголовка идут 4 байта исходной длины (младшим байтом вперёд),
    // дальше сжатые данные (deflate без заголовка zlib, уровень 6). Ответ разбираем так же.
    @PluginMethod
    public void sendFrame(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.ru");
        final int port = call.getInt("port", 443);
        final int type = call.getInt("type", 1) & 0xf;
        final boolean compress = !Boolean.FALSE.equals(call.getBoolean("compress", true));
        final boolean flag80 = !Boolean.FALSE.equals(call.getBoolean("flag80", true));
        final String text = call.getString("text", "");
        final int waitMs = call.getInt("waitMs", 6000);
        final boolean tls = !Boolean.FALSE.equals(call.getBoolean("tls", true));   // на порту 993 у них без шифрования
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null; JSObject o = new JSObject(); long t0 = System.currentTimeMillis();
            try {
                byte[] raw = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                byte[] body; int lenField;
                if (compress) {
                    java.util.zip.Deflater df = new java.util.zip.Deflater(6, true);
                    df.setInput(raw); df.finish();
                    byte[] tmp = new byte[raw.length + 100];
                    int n = df.deflate(tmp); df.end();
                    body = new byte[n]; System.arraycopy(tmp, 0, body, 0, n);
                    lenField = n + 4;
                } else { body = raw; lenField = raw.length; }
                java.io.ByteArrayOutputStream hdr = new java.io.ByteArrayOutputStream();
                int b0 = (flag80 ? 0x80 : 0) | (compress ? 0x40 : 0) | type;
                hdr.write(b0);
                if (lenField <= 0x7d) hdr.write(lenField);
                else if (lenField <= 0xffff) { hdr.write(0x7e); hdr.write((lenField >> 8) & 0xff); hdr.write(lenField & 0xff); }
                else { hdr.write(0x7f); hdr.write(0); hdr.write(0); hdr.write(0); hdr.write(0);
                       hdr.write((lenField >> 24) & 0xff); hdr.write((lenField >> 16) & 0xff); hdr.write((lenField >> 8) & 0xff); hdr.write(lenField & 0xff); }
                if (compress) { hdr.write(raw.length & 0xff); hdr.write((raw.length >> 8) & 0xff); hdr.write((raw.length >> 16) & 0xff); hdr.write((raw.length >> 24) & 0xff); }
                if (tls) { sock = javax.net.ssl.SSLSocketFactory.getDefault().createSocket(host, port); }   // с именем хоста — иначе сервер закрывает связь
                else { sock = new java.net.Socket(); sock.connect(new java.net.InetSocketAddress(host, port), 8000); }
                sock.setSoTimeout(waitMs);
                if (tls) ((javax.net.ssl.SSLSocket) sock).startHandshake();
                int listenMs = call.getInt("listenMs", 3000);
                if (listenMs > 0) {   // слушаем приветствие сервера ДО отправки
                    sock.setSoTimeout(listenMs);
                    java.io.ByteArrayOutputStream hi = new java.io.ByteArrayOutputStream();
                    try { byte[] hb = new byte[1024]; int n; long h0 = System.currentTimeMillis();
                        while (hi.size() < 2048 && (n = sock.getInputStream().read(hb)) > 0) { hi.write(hb, 0, n); if (System.currentTimeMillis() - h0 > listenMs) break; } }
                    catch (java.net.SocketTimeoutException ignored) {}
                    byte[] hb2 = hi.toByteArray();
                    StringBuilder hh = new StringBuilder(), hp = new StringBuilder();
                    for (int i = 0; i < hb2.length; i++) { hh.append(String.format("%02x", hb2[i] & 0xff)); if ((i & 1) == 1) hh.append(' ');
                        int ch = hb2[i] & 0xff; hp.append(ch >= 32 && ch < 127 ? (char) ch : '.'); }
                    o.put("helloLen", hb2.length); o.put("helloHex", hh.toString()); o.put("helloText", hp.toString());
                    sock.setSoTimeout(waitMs);
                }
                sock.getOutputStream().write(hdr.toByteArray());
                if (body.length > 0) sock.getOutputStream().write(body);
                sock.getOutputStream().flush();
                o.put("sent", hdr.size() + body.length);
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                try { int n; while (bos.size() < 8192 && (n = sock.getInputStream().read(buf)) > 0) { bos.write(buf, 0, n); if (System.currentTimeMillis() - t0 > waitMs) break; } }
                catch (java.net.SocketTimeoutException ignored) {}
                byte[] resp = bos.toByteArray();
                StringBuilder hx = new StringBuilder(); StringBuilder pr = new StringBuilder();
                for (int i = 0; i < resp.length; i++) { hx.append(String.format("%02x", resp[i] & 0xff)); if ((i & 1) == 1) hx.append(' ');
                    int c = resp[i] & 0xff; pr.append(c >= 32 && c < 127 ? (char) c : '.'); }
                o.put("len", resp.length); o.put("hex", hx.toString()); o.put("text", pr.toString());
                // пробуем разобрать ответ тем же форматом
                try {
                    if (resp.length > 2) {
                        int f = resp[0] & 0xff, p = 1, dlen = resp[1] & 0xff;
                        if (dlen == 0x7e) { dlen = ((resp[2] & 0xff) << 8) | (resp[3] & 0xff); p = 4; }
                        else if (dlen == 0x7f) { dlen = ((resp[6] & 0xff) << 24) | ((resp[7] & 0xff) << 16) | ((resp[8] & 0xff) << 8) | (resp[9] & 0xff); p = 10; }
                        else p = 2;
                        o.put("respType", f & 0xf); o.put("respCompressed", (f & 0x40) != 0); o.put("respLen", dlen);
                        if ((f & 0x40) != 0 && resp.length > p + 4) {
                            int orig = (resp[p] & 0xff) | ((resp[p + 1] & 0xff) << 8) | ((resp[p + 2] & 0xff) << 16) | ((resp[p + 3] & 0xff) << 24);
                            java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
                            inf.setInput(resp, p + 4, resp.length - p - 4);
                            byte[] out = new byte[Math.max(16, Math.min(orig > 0 ? orig : 8192, 65536))];
                            int m = inf.inflate(out); inf.end();
                            o.put("body", new String(out, 0, m, java.nio.charset.StandardCharsets.UTF_8));
                        } else if (resp.length > p) {
                            o.put("body", new String(resp, p, Math.min(resp.length - p, 4096), java.nio.charset.StandardCharsets.UTF_8));
                        }
                    }
                } catch (Throwable ignored) {}
                o.put("ms", System.currentTimeMillis() - t0); o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false); o.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // ---- Отладка протокола официального клиента 4pda ----
    // Открывает обычное защищённое соединение с их сервером, шлёт заданные байты и возвращает ответ
    // в двух видах: шестнадцатеричном и печатном. Нужно, чтобы вслепую подобрать формат пакета.
    @PluginMethod
    public void rawSocket(final PluginCall call) {
        final String host = call.getString("host", "app.4pda.ru");
        final int port = call.getInt("port", 443);
        final boolean tls = !Boolean.FALSE.equals(call.getBoolean("tls", true));
        final String hex = call.getString("hex", "");
        final String text = call.getString("text", "");
        final int waitMs = call.getInt("waitMs", 5000);
        final int maxRead = call.getInt("maxRead", 4096);
        new Thread(new Runnable() { public void run() {
            java.net.Socket sock = null;
            JSObject o = new JSObject();
            long t0 = System.currentTimeMillis();
            try {
                sock = tls ? javax.net.ssl.SSLSocketFactory.getDefault().createSocket() : new java.net.Socket();
                sock.connect(new java.net.InetSocketAddress(host, port), 8000);
                sock.setSoTimeout(waitMs);
                if (sock instanceof javax.net.ssl.SSLSocket) ((javax.net.ssl.SSLSocket) sock).startHandshake();
                o.put("connected", true);
                byte[] data;
                if (hex != null && !hex.isEmpty()) {
                    String h = hex.replaceAll("[^0-9a-fA-F]", "");
                    data = new byte[h.length() / 2];
                    for (int i = 0; i < data.length; i++) data[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
                } else data = (text == null ? "" : text).getBytes(java.nio.charset.StandardCharsets.UTF_8);
                if (data.length > 0) { sock.getOutputStream().write(data); sock.getOutputStream().flush(); }
                o.put("sent", data.length);
                java.io.InputStream is = sock.getInputStream();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                try {
                    int n;
                    while (bos.size() < maxRead && (n = is.read(buf)) > 0) {
                        bos.write(buf, 0, n);
                        if (System.currentTimeMillis() - t0 > waitMs) break;
                    }
                } catch (java.net.SocketTimeoutException ignored) {}
                byte[] resp = bos.toByteArray();
                StringBuilder hx = new StringBuilder(); StringBuilder pr = new StringBuilder();
                for (int i = 0; i < resp.length; i++) {
                    hx.append(String.format("%02x", resp[i] & 0xff)); if ((i & 1) == 1) hx.append(' ');
                    int c = resp[i] & 0xff; pr.append(c >= 32 && c < 127 ? (char) c : '.');
                }
                o.put("len", resp.length);
                o.put("hex", hx.toString());
                o.put("text", pr.toString());
                o.put("ms", System.currentTimeMillis() - t0);
                o.put("ok", true);
            } catch (Throwable e) {
                o.put("ok", false);
                o.put("error", String.valueOf(e.getClass().getSimpleName()) + ": " + String.valueOf(e.getMessage()));
                o.put("ms", System.currentTimeMillis() - t0);
            } finally { try { if (sock != null) sock.close(); } catch (Exception ignored) {} }
            call.resolve(o);
        } }).start();
    }

    // Палитра Material You (Monet, Android 12+) + флаг ночного режима системы
    @PluginMethod
    public void monetPalette(PluginCall call) {
        JSObject o = new JSObject();
        try {
            boolean night = (getContext().getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
            o.put("night", night);
        } catch (Exception ignored) {}
        if (android.os.Build.VERSION.SDK_INT < 31) { o.put("ok", false); call.resolve(o); return; }
        try {
            android.content.Context c = getContext();
            java.util.Map<String, Integer> ids = new java.util.LinkedHashMap<>();
            ids.put("a1_200", android.R.color.system_accent1_200);
            ids.put("a1_600", android.R.color.system_accent1_600);
            ids.put("n1_10", android.R.color.system_neutral1_10);
            ids.put("n1_50", android.R.color.system_neutral1_50);
            ids.put("n1_100", android.R.color.system_neutral1_100);
            ids.put("n1_800", android.R.color.system_neutral1_800);
            ids.put("n1_900", android.R.color.system_neutral1_900);
            ids.put("n2_100", android.R.color.system_neutral2_100);
            ids.put("n2_200", android.R.color.system_neutral2_200);
            ids.put("n2_300", android.R.color.system_neutral2_300);
            ids.put("n2_600", android.R.color.system_neutral2_600);
            ids.put("n2_700", android.R.color.system_neutral2_700);
            for (java.util.Map.Entry<String, Integer> e : ids.entrySet()) {
                int col = c.getColor(e.getValue());
                o.put(e.getKey(), String.format("#%06X", col & 0xFFFFFF));
            }
            o.put("ok", true);
        } catch (Exception e) { o.put("ok", false); }
        call.resolve(o);
    }

    // Версии Google Play ПАЧКОЙ — один запрос на список пакетов (как в APKUpdater)
    @PluginMethod
    public void playVersions(final PluginCall call) {
        final JSArray inArr = call.getArray("packages");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    java.util.List<String> pkgs = new java.util.ArrayList<>();
                    try { java.util.List<Object> l = inArr != null ? inArr.toList() : null; if (l != null) for (Object o : l) { String p = String.valueOf(o); if (p != null && !p.isEmpty() && !"null".equals(p)) pkgs.add(p); } } catch (Exception ignored) {}
                    if (pkgs.isEmpty()) { JSObject e = new JSObject(); e.put("items", new JSArray()); call.resolve(e); return; }
                    java.util.List<String> res = PlayApi.versions(getContext(), pkgs);
                    JSArray arr = new JSArray();
                    for (String r : res) {
                        String[] p = r.split("\u0001", 3);
                        if (p.length < 2) continue;
                        JSObject o = new JSObject();
                        o.put("packageName", p[0]); o.put("versionName", p[1]);
                        if (p.length > 2) o.put("versionCode", p[2]);
                        arr.put(o);
                    }
                    JSObject ret = new JSObject(); ret.put("items", arr); call.resolve(ret);
                } catch (Throwable e) { call.reject(String.valueOf(e.getMessage())); }
            }
        }).start();
    }

    // Скачать файл из темы 4pda (с cookie логина) в «Загрузки»
    @PluginMethod
    public void removeDownload(PluginCall call) {
        try {
            long id = callId(call);
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null && id != 0) dm.remove(id);
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void openDownloads(PluginCall call) {
        try {
            android.content.Intent i = new android.content.Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void download(PluginCall call) {
        String url = call.getString("url");
        String name = call.getString("name");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
            if (url.contains("4pda.")) cookie = (cookie == null || cookie.isEmpty() ? "ngx_mb=0" : cookie + "; ngx_mb=0");
            if (cookie != null && !cookie.isEmpty()) r.addRequestHeader("Cookie", cookie);
            r.addRequestHeader("User-Agent", UA);
            if (url.contains("4pda.")) r.addRequestHeader("Referer", "https://4pda.to/forum/");
            if (name == null || name.isEmpty()) name = URLUtil.guessFileName(url, null, null);
            r.setTitle(name);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.allowScanningByMediaScanner();
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) dm.enqueue(r);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Браузерный UA, как у ForPDA — чтобы 4pda не отдавал bot-заглушку
    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
    private static final String UA_DESKTOP = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private static okhttp3.OkHttpClient noAuthHttp = null;
    private static boolean isAuthCookie(String name) {
        if (name == null) return false;
        String n = name.toLowerCase();
        return n.contains("member_id") || n.contains("pass_hash") || n.contains("session_id") || n.endsWith("session") || n.contains("ipsconnect");
    }
    // Снять сессионные куки 4pda из CookieManager и вернуть их строкой (для восстановления)
    private synchronized String stripAuthCookies() {
        try {
            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            String all = cm.getCookie("https://4pda.to");
            if (all == null || all.isEmpty()) return "";
            StringBuilder saved = new StringBuilder();
            for (String part : all.split(";")) {
                String kv = part.trim(); int eq = kv.indexOf('=');
                if (eq <= 0) continue;
                String nm = kv.substring(0, eq);
                if (!isAuthCookie(nm)) continue;
                if (saved.length() > 0) saved.append("; ");
                saved.append(kv);
                cm.setCookie("https://4pda.to", nm + "=; domain=.4pda.to; path=/; Max-Age=0");
                cm.setCookie("https://4pda.to", nm + "=; path=/; Max-Age=0");
            }
            try { cm.flush(); } catch (Exception ignored) {}
            return saved.toString();
        } catch (Exception e) { return ""; }
    }
    private synchronized void restoreAuthCookies(String saved) {
        try {
            if (saved == null || saved.isEmpty()) return;
            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            for (String part : saved.split(";")) {
                String kv = part.trim();
                if (kv.isEmpty()) continue;
                cm.setCookie("https://4pda.to", kv + "; domain=.4pda.to; path=/");
            }
            try { cm.flush(); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }
    private synchronized okhttp3.OkHttpClient noAuthClient() {           // как обычный, но сессионные куки не отправляем
        if (noAuthHttp != null) return noAuthHttp;
        noAuthHttp = ok().newBuilder().cookieJar(new okhttp3.CookieJar() {
            @Override public void saveFromResponse(okhttp3.HttpUrl url, java.util.List<okhttp3.Cookie> cookies) {
                try { android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance(); for (okhttp3.Cookie c : cookies) cm.setCookie(url.toString(), c.toString()); } catch (Exception ignored) {}
            }
            @Override public java.util.List<okhttp3.Cookie> loadForRequest(okhttp3.HttpUrl url) {
                java.util.ArrayList<okhttp3.Cookie> out = new java.util.ArrayList<>();
                try {
                    String raw = android.webkit.CookieManager.getInstance().getCookie(url.toString());
                    if (raw != null) for (String p : raw.split("; ")) {
                        int i = p.indexOf('=');
                        if (i <= 0) continue;
                        String nm = p.substring(0, i).trim();
                        if (isAuthCookie(nm)) continue;                   // сессию не прикладываем
                        okhttp3.Cookie ck = okhttp3.Cookie.parse(url, p);
                        if (ck != null) out.add(ck);
                    }
                } catch (Exception ignored) {}
                return out;
            }
        }).build();
        return noAuthHttp;
    }

    // Общий OkHttp-клиент; куки берём/сохраняем в CookieManager WebView (чтобы cf_clearance был общим)
    private static okhttp3.OkHttpClient OK;
    private okhttp3.OkHttpClient ok() {
        if (OK == null) {
            okhttp3.Dispatcher disp = new okhttp3.Dispatcher();
            disp.setMaxRequests(6); disp.setMaxRequestsPerHost(4);
            OK = new okhttp3.OkHttpClient.Builder()
                .dispatcher(disp)
                .connectionPool(new okhttp3.ConnectionPool(4, 30, java.util.concurrent.TimeUnit.SECONDS))
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .callTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true).followSslRedirects(true)
                .retryOnConnectionFailure(true)
                .cookieJar(new okhttp3.CookieJar() {
                    @Override public void saveFromResponse(okhttp3.HttpUrl url, java.util.List<okhttp3.Cookie> cookies) {
                        try {
                            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
                            String base = url.scheme() + "://" + url.host();
                            for (okhttp3.Cookie ck : cookies) cm.setCookie(base, ck.toString());
                            cm.flush();
                        } catch (Exception ignored) {}
                    }
                    @Override public java.util.List<okhttp3.Cookie> loadForRequest(okhttp3.HttpUrl url) {
                        java.util.List<okhttp3.Cookie> out = new java.util.ArrayList<>();
                        try {
                            String base = url.scheme() + "://" + url.host();
                            String cookie = android.webkit.CookieManager.getInstance().getCookie(base);
                            if (cookie != null) for (String part : cookie.split(";")) { okhttp3.Cookie c = okhttp3.Cookie.parse(url, part.trim()); if (c != null) out.add(c); }
                            if (url.host().contains("4pda")) { boolean has = false; for (okhttp3.Cookie c : out) if (c.name().equals("ngx_mb")) has = true; if (!has) { okhttp3.Cookie mb = okhttp3.Cookie.parse(url, "ngx_mb=0"); if (mb != null) out.add(mb); } }
                        } catch (Exception ignored) {}
                        return out;
                    }
                })
                .build();
        }
        return OK;
    }
    private okhttp3.OkHttpClient OKDL2;
    private okhttp3.OkHttpClient okDl() {
        if (OKDL2 == null) { OKDL2 = ok().newBuilder().callTimeout(0, java.util.concurrent.TimeUnit.SECONDS).readTimeout(60, java.util.concurrent.TimeUnit.SECONDS).build(); }
        return OKDL2;
    }
    private okhttp3.Request.Builder okReq(String url) {
        okhttp3.Request.Builder b = new okhttp3.Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept-Language", "ru,en;q=0.9");
        if (url.contains("4pda.")) b.header("Referer", "https://4pda.to/forum/");
        return b;
    }

    // ==== Свой докачивающий загрузчик (Range-резюме, авторизация куками) ====
    static class Dl {
        long id; String url, name, referer; java.io.File file;
        volatile android.net.Uri pubUri; volatile java.io.File pubFile; // опубликованная копия в общей папке (для удаления)
        volatile long total = -1, done = 0;
        volatile int status = 2; // 2=running,4=paused,8=done,16=error
        volatile long ts = System.currentTimeMillis(); // время старта — для сортировки в списке
        volatile String saveTree = ""; // SAF-папка назначения (пусто = общая /Download)
        volatile boolean canResume = false; // частичный файл дописан подряд (одиночное соединение) -> можно докачать по Range
        volatile boolean pauseReq = false, cancelReq = false;
        volatile java.net.HttpURLConnection conn; volatile java.io.InputStream stream; volatile Thread thread; volatile okhttp3.Call call;
        String error = "";
    }
    private static final java.util.Map<Long, Dl> DLS = new java.util.concurrent.ConcurrentHashMap<>();
    private static long DL_SEQ = 1;
    private static volatile boolean DLS_RESTORED = false;
    private static volatile long DLS_LAST_SAVE = 0;

    // как в AB Download Manager: состояние каждой загрузки постоянно сохраняется и восстанавливается после перезапуска процесса
    private void dlsSave(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - DLS_LAST_SAVE < 900) return;   // прогресс пишем не чаще раза в секунду
        DLS_LAST_SAVE = now;
        try {
            org.json.JSONArray arr = new org.json.JSONArray();
            for (Dl d : DLS.values()) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("id", d.id); o.put("url", d.url == null ? "" : d.url); o.put("name", d.name == null ? "" : d.name);
                o.put("referer", d.referer == null ? "" : d.referer);
                o.put("path", d.file != null ? d.file.getAbsolutePath() : "");
                o.put("total", d.total); o.put("done", d.done); o.put("status", d.status); o.put("ts", d.ts);
                o.put("canResume", d.canResume); o.put("error", d.error == null ? "" : d.error);
                o.put("pubUri", d.pubUri != null ? d.pubUri.toString() : "");
                o.put("pubPath", d.pubFile != null ? d.pubFile.getAbsolutePath() : "");
                arr.put(o);
            }
            getContext().getSharedPreferences("t4dl", Context.MODE_PRIVATE).edit().putString("list", arr.toString()).putLong("seq", DL_SEQ).apply();
        } catch (Exception ignored) {}
    }

    private void dlsRestore() {
        if (DLS_RESTORED) return; DLS_RESTORED = true;
        try {
            android.content.SharedPreferences sp = getContext().getSharedPreferences("t4dl", Context.MODE_PRIVATE);
            DL_SEQ = Math.max(DL_SEQ, sp.getLong("seq", 1));
            String raw = sp.getString("list", "");
            if (raw == null || raw.isEmpty()) return;
            org.json.JSONArray arr = new org.json.JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.getJSONObject(i);
                long id = o.optLong("id", 0); if (id <= 0 || DLS.containsKey(id)) continue;
                Dl d = new Dl();
                d.id = id; d.url = o.optString("url", ""); d.name = o.optString("name", ""); d.referer = o.optString("referer", "");
                String p = o.optString("path", ""); if (!p.isEmpty()) d.file = new java.io.File(p);
                d.total = o.optLong("total", -1); d.done = o.optLong("done", 0);
                int st = o.optInt("status", 4);
                d.status = (st == 2 || st == 1) ? 4 : st;   // процесс перезапускался — «качается» превращаем в «паузу», докачается по Range
                d.ts = o.optLong("ts", System.currentTimeMillis());
                d.canResume = o.optBoolean("canResume", false);
                d.error = o.optString("error", "");
                try { String pu = o.optString("pubUri", ""); if (!pu.isEmpty()) d.pubUri = android.net.Uri.parse(pu); } catch (Exception ignored) {}
                try { String pp = o.optString("pubPath", ""); if (!pp.isEmpty()) d.pubFile = new java.io.File(pp); } catch (Exception ignored) {}
                DLS.put(d.id, d);
                DL_SEQ = Math.max(DL_SEQ, d.id + 1);
            }
        } catch (Exception ignored) {}
        healRestored();
    }
    // Процесс мог быть убит системой (агрессивная экономия батареи) в самом конце закачки:
    // файл на диске уже целый, а в реестре осталось «качается», и в шторке навсегда застыло «98%».
    // При первом обращении после старта сверяем реальные файлы и приводим состояние к «Готово».
    private void healRestored() {
        final java.util.List<Dl> list = new java.util.ArrayList<>(DLS.values());
        new Thread(new Runnable() { public void run() {
            boolean ch = false;
            for (Dl d : list) {
                try {
                    if (d.status == 8) { cancelNotif(d); continue; }
                    boolean full = d.file != null && d.file.exists() && d.total > 0 && d.file.length() >= d.total;
                    boolean published = d.pubUri != null || (d.pubFile != null && d.pubFile.exists()) || (d.file != null && !d.file.exists() && findInDownloads(d.name) != null);
                    if (full) { publishToDownloads(d); d.status = 8; d.done = d.total; ch = true; }
                    else if (published && (d.file == null || !d.file.exists())) { d.status = 8; if (d.total > 0) d.done = d.total; ch = true; }
                    if (d.status == 8) cancelNotif(d); else notif(d, false);   // зависшее уведомление старого процесса перерисовываем/гасим
                } catch (Exception ignored) {}
            }
            if (ch) dlsSave(true);
        } }).start();
    }
    private void cancelNotif(Dl d) {
        try { ((android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancel((int) d.id + 9000); } catch (Exception ignored) {}
    }
    private static boolean DL_CH = false;

    private boolean doPauseI(long id) {
        Dl d = DLS.get(id);
        if (d == null) return false;
        d.pauseReq = true;
        if (d.status == 2 || d.status == 1) d.status = 4;
        try { if (d.call != null) d.call.cancel(); } catch (Exception ignored) {}
        try { if (d.stream != null) d.stream.close(); } catch (Exception ignored) {}
        try { if (d.thread != null) d.thread.interrupt(); } catch (Exception ignored) {}
        dlsSave(true);
        notif(d, false);                                        // перерисовать уведомление: появится «Возобновить»
        return true;
    }
    private boolean doResumeI(long id) {
        Dl d = DLS.get(id);
        if (d == null || !(d.status == 4 || d.status == 16)) return false;
        try { if (d.thread != null && d.thread.isAlive()) { d.thread.interrupt(); d.thread.join(800); } } catch (Exception ignored) {}
        d.error = ""; d.cancelReq = false; d.pauseReq = false;
        if (!d.canResume || d.file == null || !d.file.exists()) { try { if (d.file != null && d.file.exists()) d.file.delete(); } catch (Exception ignored) {} d.done = 0; d.total = -1; }
        d.status = 2; notif(d, false);                          // мгновенно перерисовать уведомление в «качается», не дожидаясь соединения
        startThread(d);
        return true;
    }
    private void doCancelI(long id, boolean delFile) {
        Dl d = DLS.get(id);
        if (d != null) {
            d.cancelReq = true; d.pauseReq = true;
            try { if (d.call != null) d.call.cancel(); } catch (Exception ignored) {}
            try { if (d.stream != null) d.stream.close(); } catch (Exception ignored) {}
            try { if (d.thread != null) d.thread.interrupt(); } catch (Exception ignored) {}
            DLS.remove(d.id);
            if (delFile) {
                try { if (d.file != null && d.file.exists()) d.file.delete(); } catch (Exception ignored) {}
                try { if (d.pubFile != null && d.pubFile.exists()) d.pubFile.delete(); } catch (Exception ignored) {}
                try { if (d.name != null) { java.io.File p2 = new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), d.name); if (p2.exists()) p2.delete(); } } catch (Exception ignored) {}
            }
        }
        DL_SPEED.remove(id);
        dlsSave(true);
        final int nid = (int) id + 9000;
        try { ((android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid); } catch (Exception ignored) {}
        try { new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() { @Override public void run() { try { ((android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid); } catch (Exception ignored) {} } }, 700); } catch (Exception ignored) {}
    }

    private static boolean DL_RCV = false;
    private static final String DL_ACTION = "leshugan.t4.DL_ACTION";
    private void ensureDlReceiver() {
        if (DL_RCV) return; DL_RCV = true;
        try {
            android.content.BroadcastReceiver r = new android.content.BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent i) {
                    try {
                        long id = i.getLongExtra("dlid", 0); String op = String.valueOf(i.getStringExtra("op"));
                        dlsRestore();
                        if ("pause".equals(op)) doPauseI(id);
                        else if ("resume".equals(op)) doResumeI(id);
                        else if ("cancel".equals(op)) doCancelI(id, true);
                    } catch (Exception ignored) {}
                }
            };
            android.content.IntentFilter f = new android.content.IntentFilter(DL_ACTION);
            if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
            else getContext().registerReceiver(r, f);
        } catch (Exception ignored) { DL_RCV = false; }
    }
    private android.app.PendingIntent dlActionPi(long id, String op, int slot) {
        Intent i = new Intent(DL_ACTION).setPackage(getContext().getPackageName()).putExtra("dlid", id).putExtra("op", op);
        int fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) fl |= android.app.PendingIntent.FLAG_IMMUTABLE;
        return android.app.PendingIntent.getBroadcast(getContext(), (int) id * 10 + slot, i, fl);
    }

    private void ensureChannel() {
        if (DL_CH) return;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                android.app.NotificationChannel ch = new android.app.NotificationChannel("dl", "Загрузки", android.app.NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(ch);
            }
            DL_CH = true;
        } catch (Exception ignored) {}
    }
    private void notif(Dl d, boolean done) {
        if (d == null || d.cancelReq || !DLS.containsKey(d.id)) return; // удалённая загрузка не должна слать уведомления
        try {
            ensureChannel();
            android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            android.app.Notification.Builder b;
            if (android.os.Build.VERSION.SDK_INT >= 26) b = new android.app.Notification.Builder(getContext(), "dl");
            else b = new android.app.Notification.Builder(getContext());
            b.setContentTitle(d.name).setOnlyAlertOnce(true);
            ensureDlReceiver();
            try {  // тап по уведомлению — открыть приложение на «Загрузках»
                Intent li = getContext().getPackageManager().getLaunchIntentForPackage(getContext().getPackageName());
                if (li != null) { li.putExtra("open_dl", true); li.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); int fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT; if (Build.VERSION.SDK_INT >= 23) fl |= android.app.PendingIntent.FLAG_IMMUTABLE; b.setContentIntent(android.app.PendingIntent.getActivity(getContext(), (int) d.id + 7000, li, fl)); }
            } catch (Exception ignored) {}
            int lay = 0; try { lay = getContext().getResources().getIdentifier("t4_notif_dl", "layout", getContext().getPackageName()); } catch (Exception ignored) {}
            boolean custom = Build.VERSION.SDK_INT >= 24 && lay != 0 && !done && (d.status == 2 || d.status == 1 || d.status == 4 || d.status == 16);
            if (custom) {  // кнопки справа — свой макет
                try {
                    android.widget.RemoteViews rv = new android.widget.RemoteViews(getContext().getPackageName(), lay);
                    int idT = getContext().getResources().getIdentifier("t4_title", "id", getContext().getPackageName());
                    int idP = getContext().getResources().getIdentifier("t4_prog", "id", getContext().getPackageName());
                    int idS = getContext().getResources().getIdentifier("t4_sub", "id", getContext().getPackageName());
                    int idB1 = getContext().getResources().getIdentifier("t4_b1", "id", getContext().getPackageName());
                    int idB2 = getContext().getResources().getIdentifier("t4_b2", "id", getContext().getPackageName());
                    int pct = d.total > 0 ? (int) (d.done * 100 / d.total) : 0;
                    rv.setTextViewText(idT, d.name == null ? "" : d.name);
                    rv.setProgressBar(idP, 100, pct, d.status == 2 && d.total <= 0);
                    rv.setTextViewText(idS, d.status == 4 ? "Пауза" : d.status == 16 ? "Ошибка" : (pct + "%"));
                    boolean running = (d.status == 2 || d.status == 1);
                    rv.setTextViewText(idB1, running ? "Пауза" : "Возобновить");
                    rv.setOnClickPendingIntent(idB1, dlActionPi(d.id, running ? "pause" : "resume", running ? 1 : 2));
                    rv.setTextViewText(idB2, "Отмена");
                    rv.setOnClickPendingIntent(idB2, dlActionPi(d.id, "cancel", 3));
                    // Цвет текста задаёт САМ макет через системные атрибуты (?android:attr/textColorPrimary) —
                    // шторка сама подбирает читаемый цвет под свою тему. uiMode приложения тут не годится:
                    // на части прошивок тема шторки не совпадает с ним (из-за этого текст выходил чёрным/серым).
                    b.setStyle(new android.app.Notification.DecoratedCustomViewStyle());
                    b.setCustomContentView(rv);
                    b.setSmallIcon(d.status == 16 ? android.R.drawable.stat_notify_error : android.R.drawable.stat_sys_download);
                    if (d.status == 16 && android.os.Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(6000);
                    nm.notify((int) d.id + 9000, b.build());
                    if (d.cancelReq || !DLS.containsKey(d.id)) { try { nm.cancel((int) d.id + 9000); } catch (Exception ignored) {} }
                    dlsSave(d.status != 2);
                    return;
                } catch (Exception ignored) {}
            }
            if (done) { b.setSmallIcon(android.R.drawable.stat_sys_download_done).setContentText("Готово").setProgress(0, 0, false).setAutoCancel(true); if (android.os.Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(4000); } // само исчезнет через 4с после завершения
            else if (d.status == 16) { b.setSmallIcon(android.R.drawable.stat_notify_error).setContentText("Ошибка загрузки").setProgress(0, 0, false).setAutoCancel(true); if (android.os.Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(6000); b.addAction(new android.app.Notification.Action.Builder(null, "Возобновить", dlActionPi(d.id, "resume", 2)).build()); b.addAction(new android.app.Notification.Action.Builder(null, "Отмена", dlActionPi(d.id, "cancel", 3)).build()); }
            else if (d.status == 4) { b.setSmallIcon(android.R.drawable.stat_sys_download); b.setContentText("Пауза").setProgress(100, d.total > 0 ? (int) (d.done * 100 / d.total) : 0, false); b.addAction(new android.app.Notification.Action.Builder(null, "Возобновить", dlActionPi(d.id, "resume", 2)).build()); b.addAction(new android.app.Notification.Action.Builder(null, "Отмена", dlActionPi(d.id, "cancel", 3)).build()); }
            else { b.setSmallIcon(android.R.drawable.stat_sys_download); int pct = d.total > 0 ? (int) (d.done * 100 / d.total) : 0; b.setContentText(pct + "%").setProgress(100, pct, d.total <= 0); b.addAction(new android.app.Notification.Action.Builder(null, "Пауза", dlActionPi(d.id, "pause", 1)).build()); b.addAction(new android.app.Notification.Action.Builder(null, "Отмена", dlActionPi(d.id, "cancel", 3)).build()); }
            nm.notify((int) d.id + 9000, b.build());
            dlsSave(done || d.status != 2);   // AB-принцип: состояние сохраняется по ходу — резюм переживает перезапуск
            if (d.cancelReq || !DLS.containsKey(d.id)) { try { nm.cancel((int) d.id + 9000); } catch (Exception ignored) {} } // отменили, пока строили — гасим сразу
        } catch (Exception ignored) {}
    }

    private void setDlHeaders(java.net.HttpURLConnection c, String url, Dl d) {
        try {
            String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
            if (url.contains("4pda.")) cookie = (cookie == null || cookie.isEmpty() ? "ngx_mb=0" : cookie + "; ngx_mb=0");
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        } catch (Exception ignored) {}
        c.setRequestProperty("User-Agent", UA);
        if (url.contains("4pda.")) c.setRequestProperty("Referer", (d.referer != null && !d.referer.isEmpty()) ? d.referer : "https://4pda.to/forum/");
        c.setRequestProperty("Accept", "*/*");
        c.setRequestProperty("Accept-Encoding", "identity");
    }
    // проба: следуем редиректам, узнаём финальный URL и поддержку Range + размер
    private Object[] probeDl(Dl d) {
        java.net.HttpURLConnection c = null;
        try {
            String url = d.url.trim().replace(" ", "%20");
            if (url.startsWith("//")) url = "https:" + url; else if (url.startsWith("/")) url = "https://4pda.to" + url;
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(15000); c.setReadTimeout(15000);
            setDlHeaders(c, url, d);
            c.setRequestProperty("Range", "bytes=0-0");
            c.connect();
            int code = c.getResponseCode();
            String finalUrl = c.getURL().toString();
            if (code == 206) {
                String cr = c.getHeaderField("Content-Range");
                if (cr != null && cr.contains("/")) { try { long t = Long.parseLong(cr.substring(cr.indexOf("/") + 1).trim()); return new Object[]{finalUrl, t}; } catch (Exception ignored) {} }
            }
            return new Object[]{finalUrl, -1L};
        } catch (Exception e) { return null; }
        finally { try { if (c != null) c.disconnect(); } catch (Exception ignored) {} }
    }
    private boolean downloadSegment(Dl d, String url, long start, long end, java.util.concurrent.atomic.AtomicLong done, boolean[] fail) {
        java.net.HttpURLConnection c = null; java.io.InputStream in = null; java.io.RandomAccessFile raf = null;
        try {
            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000); c.setReadTimeout(40000);
            setDlHeaders(c, url, d);
            c.setRequestProperty("Range", "bytes=" + start + "-" + end);
            c.connect();
            if (c.getResponseCode() != 206) { fail[0] = true; return false; }
            in = c.getInputStream();
            raf = new java.io.RandomAccessFile(d.file, "rw"); raf.seek(start);
            byte[] buf = new byte[65536]; int n;
            while ((n = in.read(buf)) != -1) {
                if (d.cancelReq || d.pauseReq || fail[0]) return false;
                raf.write(buf, 0, n); done.addAndGet(n);
            }
            return true;
        } catch (Exception e) { fail[0] = true; return false; }
        finally { try { if (in != null) in.close(); } catch (Exception ignored) {} try { if (raf != null) raf.close(); } catch (Exception ignored) {} try { if (c != null) c.disconnect(); } catch (Exception ignored) {} }
    }
    private boolean runSegmented(final Dl d, final String url, long total) {
        final int N = total > 80L * 1024 * 1024 ? 8 : total > 20L * 1024 * 1024 ? 6 : 4; // больше частей — для больших файлов
        final java.util.concurrent.atomic.AtomicLong done = new java.util.concurrent.atomic.AtomicLong(0);
        final boolean[] fail = {false};
        try { java.io.RandomAccessFile r0 = new java.io.RandomAccessFile(d.file, "rw"); r0.setLength(total); r0.close(); } catch (Exception e) { return false; }
        d.total = total; d.done = 0; d.status = 2;
        long chunk = total / N;
        Thread[] ts = new Thread[N];
        for (int i = 0; i < N; i++) {
            final long s = i * chunk; final long e = (i == N - 1) ? total - 1 : (s + chunk - 1);
            ts[i] = new Thread(new Runnable() { public void run() { downloadSegment(d, url, s, e, done, fail); } });
            ts[i].start();
        }
        while (true) {
            boolean alive = false; for (Thread t : ts) if (t.isAlive()) alive = true;
            d.done = done.get();
            if (d.cancelReq || d.pauseReq) { fail[0] = true; }
            if (!alive) break;
            notif(d, false);
            try { Thread.sleep(300); } catch (InterruptedException ex) { fail[0] = true; }
        }
        for (Thread t : ts) { try { t.join(2000); } catch (Exception ignored) {} }
        if (d.cancelReq) { try { d.file.delete(); } catch (Exception ignored) {} DLS.remove(d.id); return true; }
        if (d.pauseReq) { d.status = 4; notif(d, false); return true; }
        if (fail[0] || done.get() < total) return false; // не вышло — пусть попробует одно соединение
        d.done = total; d.status = 8; notif(d, true); return true;
    }
    private void runDl(final Dl d) {
        java.io.RandomAccessFile out = null; java.io.InputStream in = null; okhttp3.Response resp = null;
        try {
            long offset = d.file.exists() ? d.file.length() : 0;
            String url = d.url.trim().replace(" ", "%20").replace("[", "%5B").replace("]", "%5D").replace("|", "%7C");
            if (url.startsWith("//")) url = "https:" + url;
            else if (url.startsWith("/")) url = "https://4pda.to" + url;
            okhttp3.Request.Builder rb = okReq(url).header("Accept", "*/*").header("Accept-Encoding", "identity");
            try { String ck = android.webkit.CookieManager.getInstance().getCookie(url); if (url.contains("4pda.")) ck = (ck == null || ck.isEmpty()) ? "ngx_mb=0" : (ck); if (ck != null && !ck.isEmpty()) rb.header("Cookie", ck); } catch (Exception ignored) {}
            if (url.contains("4pda.") && d.referer != null && !d.referer.isEmpty()) rb.header("Referer", d.referer);
            if (offset > 0) rb.header("Range", "bytes=" + offset + "-");
            okhttp3.Call call = okDl().newCall(rb.build());
            d.call = call;
            resp = call.execute(); // OkHttp сам идёт по редиректам
            int code = resp.code();
            if (code >= 400) throw new Exception("HTTP " + code);
            String ctype = resp.header("Content-Type", "");
            if (offset == 0 && ctype != null && ctype.toLowerCase().contains("text/html")) throw new Exception("4pda вернул страницу, а не файл — войдите в 4pda через меню");
            boolean append = (code == 206 && offset > 0);
            long len = resp.body() != null ? resp.body().contentLength() : -1;
            if (append) d.total = offset + (len > 0 ? len : 0); else { d.total = (len > 0 ? len : -1); offset = 0; }
            out = new java.io.RandomAccessFile(d.file, "rw");
            if (append) out.seek(offset); else out.setLength(0);
            d.done = offset; d.status = 2;
            in = resp.body().byteStream(); d.stream = in;
            d.canResume = true; // пишем подряд одиночным соединением — потом можно докачать по Range
            if (d.cancelReq) { try { d.file.delete(); } catch (Exception ignored) {} DLS.remove(d.id); return; }
            byte[] buf = new byte[65536]; int n; long lastN = 0;
            while ((n = in.read(buf)) != -1) {
                if (d.cancelReq) { try { d.file.delete(); } catch (Exception ignored) {} DLS.remove(d.id); try { ((android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancel((int) d.id + 9000); } catch (Exception ignored) {} return; }
                if (d.pauseReq) { d.status = 4; notif(d, false); return; }
                out.write(buf, 0, n); d.done += n;
                if (d.done - lastN > 262144) { lastN = d.done; notif(d, false); }
            }
            d.status = 8; notif(d, true);
            try { android.media.MediaScannerConnection.scanFile(getContext(), new String[]{ d.file.getAbsolutePath() }, null, null); } catch (Exception ignored) {}
        } catch (Exception e) {
            if (d.cancelReq) { try { d.file.delete(); } catch (Exception ignored) {} DLS.remove(d.id); }
            else if (d.pauseReq) { d.status = 4; notif(d, false); }
            else { d.error = String.valueOf(e.getMessage()); d.status = 16; } // обрыв сети: НЕ шлём уведомление (внешний цикл повторит; финальную ошибку покажет startThread) — иначе спам
        } finally {
            d.stream = null; d.call = null;
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
            try { if (resp != null) resp.close(); } catch (Exception ignored) {}
        }
    }
    // Ищет наш файл в общих «Загрузках» через MediaStore и отдаёт content:// —
    // на Android 11+ приложение НЕ видит файл по пути (File.exists()==false), хотя в проводнике он есть.
    private android.net.Uri findInDownloads(String name) {
        if (name == null || name.isEmpty()) return null;
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return null;
            android.database.Cursor cur = getContext().getContentResolver().query(
                    android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{ android.provider.MediaStore.Downloads._ID },
                    android.provider.MediaStore.Downloads.DISPLAY_NAME + "=?", new String[]{ name },
                    android.provider.MediaStore.Downloads._ID + " DESC");
            if (cur != null) {
                try { if (cur.moveToFirst()) return android.content.ContentUris.withAppendedId(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cur.getLong(0)); }
                finally { try { cur.close(); } catch (Exception ignored) {} }
            }
        } catch (Exception ignored) {}
        return null;
    }
    // Переносит готовый файл из рабочей (приватной) папки в общую /Download через MediaStore — без спец-разрешений на Android 16.
    private void publishToDownloads(Dl d) {
        try {
            if (d.file == null || !d.file.exists() || d.file.length() == 0) return;
            if (d.saveTree != null && !d.saveTree.isEmpty()) {   // пользователь выбрал папку — пишем в неё (SAF)
                try {
                    Uri tree = Uri.parse(d.saveTree);
                    Uri docId = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
                    String mime = d.name.toLowerCase().endsWith(".apk") ? "application/vnd.android.package-archive" : "application/octet-stream";
                    Uri fileUri = DocumentsContract.createDocument(getContext().getContentResolver(), docId, mime, d.name);
                    if (fileUri != null) {
                        java.io.OutputStream os = getContext().getContentResolver().openOutputStream(fileUri);
                        java.io.FileInputStream is = new java.io.FileInputStream(d.file);
                        byte[] b = new byte[131072]; int n; while ((n = is.read(b)) != -1) os.write(b, 0, n);
                        is.close(); os.flush(); os.close();
                        d.pubUri = fileUri;
                        try { d.file.delete(); } catch (Exception ignored) {}
                        return;
                    }
                } catch (Exception ignored) {}   // не удалось — падаем в обычную публикацию ниже
            }
            try { java.io.File pubDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
                  if (pubDir != null && d.file.getAbsolutePath().startsWith(pubDir.getAbsolutePath())) { d.pubFile = d.file; try { android.media.MediaScannerConnection.scanFile(getContext(), new String[]{ d.file.getAbsolutePath() }, null, null); } catch (Exception ignored) {} return; } } catch (Exception ignored) {}
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, d.name);
                cv.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                cv.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);
                android.net.Uri uri = getContext().getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return;
                java.io.OutputStream os = getContext().getContentResolver().openOutputStream(uri);
                java.io.FileInputStream is = new java.io.FileInputStream(d.file);
                byte[] b = new byte[131072]; int n; while ((n = is.read(b)) != -1) os.write(b, 0, n);
                is.close(); os.flush(); os.close();
                cv.clear(); cv.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
                getContext().getContentResolver().update(uri, cv, null, null);
                d.pubUri = uri;
                try { d.file.delete(); } catch (Exception ignored) {}
            } else {
                java.io.File pub = new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), d.name);
                java.io.FileInputStream is = new java.io.FileInputStream(d.file); java.io.FileOutputStream os = new java.io.FileOutputStream(pub);
                byte[] b = new byte[131072]; int n; while ((n = is.read(b)) != -1) os.write(b, 0, n); is.close(); os.close();
                d.pubFile = pub;
                try { android.media.MediaScannerConnection.scanFile(getContext(), new String[]{ pub.getAbsolutePath() }, null, null); } catch (Exception ignored) {}
                try { d.file.delete(); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }
    private String treeName(Uri uri) {
        try { String id = DocumentsContract.getTreeDocumentId(uri); String x = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id; if (x.isEmpty()) x = id; return x.replace("/", " / "); } catch (Exception e) { try { return uri.getLastPathSegment(); } catch (Exception e2) { return "папка"; } }
    }
    @PluginMethod
    public void pickDownloadFolder(final PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(call, i, "onFolderPicked");
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }
    @ActivityCallback
    private void onFolderPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            Intent data = result != null ? result.getData() : null;
            Uri uri = (data != null) ? data.getData() : null;
            if (uri == null) { JSObject r = new JSObject(); r.put("ok", false); call.resolve(r); return; }
            try { getContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) {}
            getContext().getSharedPreferences("t4dl", Context.MODE_PRIVATE).edit().putString("saveTree", uri.toString()).apply();
            JSObject r = new JSObject(); r.put("ok", true); r.put("uri", uri.toString()); r.put("name", treeName(uri)); call.resolve(r);
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }
    @PluginMethod
    public void getDownloadFolder(PluginCall call) {
        String u = getContext().getSharedPreferences("t4dl", Context.MODE_PRIVATE).getString("saveTree", "");
        JSObject r = new JSObject();
        if (u == null || u.isEmpty()) { r.put("set", false); r.put("name", "Папка «Загрузки»"); }
        else { r.put("set", true); r.put("uri", u); try { r.put("name", treeName(Uri.parse(u))); } catch (Exception e) { r.put("name", "выбранная папка"); } }
        call.resolve(r);
    }
    @PluginMethod
    public void clearDownloadFolder(PluginCall call) {
        getContext().getSharedPreferences("t4dl", Context.MODE_PRIVATE).edit().remove("saveTree").apply();
        call.resolve();
    }
    private long callId(PluginCall call) {
        try { Object v = call.getData().opt("id"); if (v instanceof Number) return ((Number) v).longValue(); if (v != null) return Long.parseLong(String.valueOf(v)); } catch (Exception ignored) {}
        return 0L; // Capacitor-мост отдаёт JS-числа как Integer/Double — getLong их не видит и возвращал 0
    }

    private boolean hasNetwork() {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                android.net.Network n = cm.getActiveNetwork();
                if (n == null) return false;
                android.net.NetworkCapabilities c = cm.getNetworkCapabilities(n);
                return c != null && c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
            } else {
                android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
                return ni != null && ni.isConnected();
            }
        } catch (Exception e) { return true; }
    }

    // Сторож: бывает, что файл на диске уже полный, а чтение из сокета висит (сервер не закрыл поток) —
    // тогда прогресс замирает на 95-98%% и уведомление не сменяется на «Готово». Раз в 3с сверяем размер.
    private void startWatchdog(final Dl d) {
        new Thread(new Runnable() { public void run() {
            try {
                while (DLS.containsKey(d.id) && !d.cancelReq && !d.pauseReq && d.status != 8 && d.status != 16) {
                    try { Thread.sleep(3000); } catch (InterruptedException e) { return; }
                    if (d.total > 0 && d.file != null && d.file.exists() && d.file.length() >= d.total && d.status == 2) {
                        d.done = d.total; notif(d, false);
                        try { if (d.call != null) d.call.cancel(); } catch (Exception ignored) {}   // рвём зависшее чтение
                        try { if (d.stream != null) d.stream.close(); } catch (Exception ignored) {}
                        Thread.sleep(600);
                        if (d.status != 8) { publishToDownloads(d); d.status = 8; notif(d, true); dlsSave(true); }
                        return;
                    }
                }
            } catch (Exception ignored) {}
        } }).start();
    }
    private void startThread(final Dl d) {
        d.status = 2; d.pauseReq = false;
        startWatchdog(d);
        d.thread = new Thread(new Runnable() { public void run() {
            boolean okDone = false;
            int netFails = 0;
            while (!d.cancelReq && !d.pauseReq && !okDone) {
                // Одиночное соединение с докачкой по Range (стабильно, как ag4pda; сегментную качку убрали — она давала «то качает, то нет»)
                runDl(d);
                if (d.status == 8) { okDone = true; break; }
                if (d.cancelReq || d.pauseReq) break;                       // пауза/отмена пользователем — стоп
                // обрыв сети: как WorkManager у ProPDA — ждём возврата сети, НЕ тратя попытки; частичный файл сохранён
                int offlineWait = 0;
                while (!hasNetwork() && !d.cancelReq && !d.pauseReq && offlineWait < 7200) {
                    d.status = 4; notif(d, false);                          // «ожидание сети» (как пауза), не спамим ошибкой
                    try { Thread.sleep(3000); } catch (InterruptedException e) { break; }
                    offlineWait += 3;
                }
                if (d.cancelReq || d.pauseReq) break;
                d.status = 2;
                if (!hasNetwork()) { d.status = 16; d.error = "нет соединения — нажмите «Возобновить»"; notif(d, false); break; } // сеть так и не вернулась за 2 часа
                netFails++;                                                 // сеть есть, но скачать не вышло — считаем реальную попытку
                if (netFails > 20) { d.status = 16; d.error = "не удалось скачать — нажмите «Возобновить»"; notif(d, false); break; }
                try { Thread.sleep(Math.min(6000L, 1500L + netFails * 800L)); } catch (InterruptedException e) { break; }
            }
            // 3) Готово — переносим в общую папку /Download (видно в проводнике)
            if (okDone) {
                publishToDownloads(d); d.status = 8; if (d.total > 0) d.done = d.total; notif(d, true); dlsSave(true);
                try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
                cancelNotif(d);                                        // не все прошивки уважают setTimeoutAfter
            }
        } });
        d.thread.start();
    }

    @PluginMethod
    public void requestPerms(PluginCall call) {
        try {
            android.app.Activity act = getActivity();
            java.util.List<String> req = new java.util.ArrayList<>();
            if (android.os.Build.VERSION.SDK_INT >= 33) { req.add("android.permission.POST_NOTIFICATIONS"); req.add("android.permission.READ_MEDIA_IMAGES"); req.add("android.permission.READ_MEDIA_VIDEO"); req.add("android.permission.READ_MEDIA_AUDIO"); }
            else if (android.os.Build.VERSION.SDK_INT >= 29) { req.add(android.Manifest.permission.READ_EXTERNAL_STORAGE); }
            else { req.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE); req.add(android.Manifest.permission.READ_EXTERNAL_STORAGE); }
            if (act != null && !req.isEmpty()) {
                java.util.List<String> need = new java.util.ArrayList<>();
                for (String p : req) { try { if (act.checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) need.add(p); } catch (Exception ignored) {} }
                if (!need.isEmpty()) act.requestPermissions(need.toArray(new String[0]), 55);
            }
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }
    @PluginMethod
    public void requestAllFiles(PluginCall call) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
                android.content.Intent i = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
            call.resolve();
        } catch (Exception e) {
            try { android.content.Intent i2 = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION); i2.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i2); call.resolve(); } catch (Exception e2) { call.reject(String.valueOf(e2.getMessage())); }
        }
    }
    @PluginMethod
    public void requestInstall(PluginCall call) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26 && !getContext().getPackageManager().canRequestPackageInstalls()) {
                android.content.Intent i = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void checkSignature(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("match", true);
        try {
            String path = call.getString("path");
            String uriStr = call.getString("uri");
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            if ((path == null || path.isEmpty()) && uriStr != null) {
                if (uriStr.startsWith("file://")) { String u = uriStr.substring(7); if (u.indexOf('%') >= 0) { try { u = java.net.URLDecoder.decode(u, "UTF-8"); } catch (Exception ignored) {} } path = u; }
                else if (uriStr.startsWith("content://")) { // копируем content во временный файл, чтобы прочитать подпись
                    try { File tmp = new File(getContext().getCacheDir(), "sigcheck.apk"); java.io.InputStream is = getContext().getContentResolver().openInputStream(Uri.parse(uriStr)); java.io.FileOutputStream os = new java.io.FileOutputStream(tmp); byte[] b = new byte[131072]; int n; while ((n = is.read(b)) != -1) os.write(b, 0, n); is.close(); os.close(); path = tmp.getAbsolutePath(); } catch (Exception ignored) {}
                }
            }
            if (path != null && !new File(path).exists()) { try { File alt = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), new File(path).getName()); if (alt.exists()) path = alt.getAbsolutePath(); } catch (Exception ignored) {} }
            if (path == null || !path.toLowerCase().endsWith(".apk")) { ret.put("unknown", true); call.resolve(); return; }
            android.content.pm.PackageInfo fpi = pm.getPackageArchiveInfo(path, android.content.pm.PackageManager.GET_SIGNATURES);
            if (fpi == null || fpi.signatures == null || fpi.signatures.length == 0) { ret.put("unknown", true); call.resolve(); return; }
            String pkg = fpi.packageName;
            String fileSig = Integer.toHexString(fpi.signatures[0].hashCode());
            ret.put("package", pkg);
            String instSig = null;
            try {
                android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNATURES);
                if (pi.signatures != null && pi.signatures.length > 0) instSig = Integer.toHexString(pi.signatures[0].hashCode());
            } catch (Exception notInstalled) { ret.put("installed", false); call.resolve(); return; }
            ret.put("installed", true);
            ret.put("match", instSig != null && instSig.equals(fileSig));
            call.resolve();
        } catch (Exception e) { call.resolve(); }
    }

    @PluginMethod
    public void dlStart(PluginCall call) {
        dlsRestore();
        String url = call.getString("url"); String name = call.getString("name");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        Dl d = new Dl();
        synchronized (AppsPlugin.class) { d.id = DL_SEQ++; }
        d.url = url;
        d.referer = call.getString("referer", "");
        d.name = (name == null || name.isEmpty()) ? URLUtil.guessFileName(url, null, null) : name;
        d.ts = System.currentTimeMillis();
        d.saveTree = call.getString("saveDir", "");
        if (d.saveTree == null || d.saveTree.isEmpty()) d.saveTree = getContext().getSharedPreferences("t4dl", Context.MODE_PRIVATE).getString("saveTree", "");
        java.io.File dir = null;
        try { java.io.File pubDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
              if (pubDir != null) { if (!pubDir.exists()) pubDir.mkdirs(); if (pubDir.canWrite()) dir = pubDir; } } catch (Exception ignored) {} // общая папка загрузок
        if (dir == null) dir = getContext().getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getContext().getExternalFilesDir(null);
        try { if (dir != null && !dir.exists()) dir.mkdirs(); } catch (Exception ignored) {}
        d.file = new java.io.File(dir, d.name);
        try { if (d.file.exists()) d.file.delete(); } catch (Exception ignored) {}
        DLS.put(d.id, d);
        dlsSave(true);
        startThread(d);
        JSObject r = new JSObject(); r.put("id", d.id); call.resolve(r);
    }

    // Принудительное самолечение реестра: зовётся из JS при возврате в приложение —
    // завершившиеся в фоне загрузки помечаются готовыми, зависшие уведомления гаснут
    @PluginMethod
    public void dlHeal(PluginCall call) {
        try { dlsRestore(); healRestored(); } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void dlStatus(PluginCall call) {
        dlsRestore();
        JSArray arr = new JSArray();
        for (Dl d : DLS.values()) {
            JSObject o = new JSObject();
            o.put("id", d.id); o.put("title", d.name); o.put("status", d.status);
            o.put("total", d.total); o.put("done", d.done); o.put("date", d.ts);
            java.io.File real = (d.pubFile != null && d.pubFile.exists()) ? d.pubFile : d.file;
            if ((real == null || !real.exists()) && d.name != null) { java.io.File p2 = new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), d.name); if (p2.exists()) real = p2; }
            boolean realOk = real != null && real.exists() && real.canRead();
            android.net.Uri cu = d.pubUri;
            if (cu == null && !realOk) cu = findInDownloads(d.name);           // файл лежит в общих «Загрузках» — доступ только через MediaStore
            o.put("uri", realOk ? ("file://" + real.getAbsolutePath()) : (cu != null ? cu.toString() : (real != null ? "file://" + real.getAbsolutePath() : "")));
            o.put("pubUri", cu != null ? cu.toString() : "");
            o.put("name", d.name == null ? "" : d.name);
            if (realOk) o.put("path", real.getAbsolutePath());
            if (d.error != null && !d.error.isEmpty()) o.put("error", d.error);
            arr.put(o);
        }
        JSObject ret = new JSObject(); ret.put("items", arr); call.resolve(ret);
    }

    @PluginMethod
    public void dlPause(PluginCall call) {
        dlsRestore();
        boolean ok = doPauseI(callId(call));
        Dl d = ok ? DLS.get(callId(call)) : null;
        JSObject r = new JSObject(); r.put("found", ok);
        if (d == null) { Object v = null; try { v = call.getData().opt("id"); } catch (Exception ignored) {} r.put("gotId", callId(call)); r.put("gotType", v == null ? "null" : v.getClass().getSimpleName()); r.put("keys", String.valueOf(DLS.keySet())); }
        call.resolve(r);
    }

    @PluginMethod
    public void dlResume(PluginCall call) {
        dlsRestore();
        boolean ok = doResumeI(callId(call));
        JSObject r = new JSObject(); r.put("found", ok);
        if (!ok) { Object v = null; try { v = call.getData().opt("id"); } catch (Exception ignored) {} r.put("gotId", callId(call)); r.put("gotType", v == null ? "null" : v.getClass().getSimpleName()); r.put("keys", String.valueOf(DLS.keySet())); }
        call.resolve(r);
    }
    @PluginMethod
    public void setBars(final PluginCall call) {
        final String bg = call.getString("bg", "#000000");
        final boolean lightBg = Boolean.TRUE.equals(call.getBoolean("light", false));
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() { @Override public void run() {
                try {
                    android.view.Window w = getActivity().getWindow();
                    int col;
                    try { col = android.graphics.Color.parseColor(bg); } catch (Exception e) { col = lightBg ? android.graphics.Color.WHITE : android.graphics.Color.BLACK; }
                    try { w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(col)); } catch (Exception ignored) {}
                    try { if (getBridge() != null && getBridge().getWebView() != null) getBridge().getWebView().setBackgroundColor(col); } catch (Exception ignored) {}
                    android.view.View dv = w.getDecorView();
                    int vis = dv.getSystemUiVisibility();
                    if (lightBg) { vis |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; if (Build.VERSION.SDK_INT >= 26) vis |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; } // тёмные иконки на светлой теме
                    else { vis &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; if (Build.VERSION.SDK_INT >= 26) vis &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; }
                    dv.setSystemUiVisibility(vis);
                } catch (Exception ignored) {}
                call.resolve();
            } });
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }
    @PluginMethod
    public void clearCookies(final PluginCall call) {
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() { @Override public void run() {
                try {
                    final android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
                    if (android.os.Build.VERSION.SDK_INT >= 21) {
                        cm.removeAllCookies(new android.webkit.ValueCallback<Boolean>() { @Override public void onReceiveValue(Boolean v) {
                            try { cm.setAcceptCookie(true); cm.setCookie("https://4pda.to", "ngx_mb=0; path=/"); cm.flush(); } catch (Exception ignored) {}
                            call.resolve();
                        } });
                    } else {
                        cm.removeAllCookie();
                        cm.setAcceptCookie(true);
                        cm.setCookie("https://4pda.to", "ngx_mb=0; path=/");
                        call.resolve();
                    }
                } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
            } });
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void dlCancel(PluginCall call) {
        dlsRestore();
        long id = callId(call);
        boolean delFile = Boolean.TRUE.equals(call.getBoolean("deleteFile", true));
        boolean had = DLS.containsKey(id);
        doCancelI(id, delFile);
        JSObject r = new JSObject(); r.put("found", had);
        call.resolve(r);
    }
    @PluginMethod
    public void showPostView(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        final android.app.Activity act = getActivity();
        if (act == null) { call.reject("no activity"); return; }
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    android.widget.FrameLayout root = new android.widget.FrameLayout(act);
                    root.setBackgroundColor(0xFF1C1C1C);
                    final android.webkit.WebView wv = new android.webkit.WebView(act);
                    android.webkit.WebSettings s = wv.getSettings();
                    try { s.setUserAgentString(UA); } catch (Exception ignored) {}
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    s.setUseWideViewPort(true);
                    s.setLoadWithOverviewMode(true);
                    s.setSupportZoom(true);
                    s.setBuiltInZoomControls(true);
                    s.setDisplayZoomControls(false);
                    android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                    try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; domain=4pda.to; path=/"); android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/"); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                    final android.widget.ProgressBar pb = new android.widget.ProgressBar(act);
                    android.widget.FrameLayout.LayoutParams pbp = new android.widget.FrameLayout.LayoutParams(140, 140);
                    pbp.gravity = android.view.Gravity.CENTER;
                    String pid = null;
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:pid=|[?&]p=|entry)(\\d+)").matcher(url);
                    if (m.find()) pid = m.group(1);
                    final String fpid = pid;
                    wv.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override public void onPageFinished(android.webkit.WebView v, String u) {
                            pb.setVisibility(android.view.View.GONE);
                            if (fpid != null) v.evaluateJavascript("(function(){try{var e=document.getElementsByName('entry" + fpid + "')[0]||document.getElementById('entry" + fpid + "')||document.getElementById('p" + fpid + "');if(e){e.scrollIntoView(true);window.scrollBy(0,-10);}}catch(x){}})()", null);
                        }
                    });
                    root.addView(wv, new android.widget.FrameLayout.LayoutParams(-1, -1));
                    root.addView(pb, pbp);
                    wv.loadUrl(url);
                    android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(act)
                            .setView(root)
                            .setNegativeButton("Закрыть", new android.content.DialogInterface.OnClickListener() {
                                @Override public void onClick(android.content.DialogInterface d, int w) { d.dismiss(); }
                            })
                            .setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                                @Override public void onDismiss(android.content.DialogInterface d) { try { wv.destroy(); } catch (Exception ignored) {} }
                            })
                            .create();
                    dlg.show();
                    android.view.WindowManager.LayoutParams lp = dlg.getWindow().getAttributes();
                    lp.height = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.82);
                    lp.width = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.94);
                    dlg.getWindow().setAttributes(lp);
                } catch (Throwable e) { }
                call.resolve(new JSObject());
            }
        });
    }

    // Загрузить страницу через НАСТОЯЩИЙ WebView (проходит анти-бот/Cloudflare 4pda) и вернуть HTML.
    @PluginMethod
    public void webGet(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        final boolean noAuth = Boolean.TRUE.equals(call.getBoolean("noAuth", Boolean.FALSE));
        final String[] savedAuth = { null };
        if (noAuth) savedAuth[0] = stripAuthCookies();     // гостевой режим WebView: Cloudflare проходим, а сессии сайт не видит
        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(new Runnable() {
            @Override public void run() {
                try {
                    final android.webkit.WebView wv = new android.webkit.WebView(getContext());
                    android.webkit.WebSettings s = wv.getSettings();
                    try { s.setUserAgentString(UA); } catch (Exception ignored) {}
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                    try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; domain=4pda.to; path=/"); android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/"); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                    final boolean[] done = { false };
                    final int[] tries = { 0 };
                    final Runnable[] poll = new Runnable[1];
                    poll[0] = new Runnable() {
                        @Override public void run() {
                            if (done[0]) return;
                            wv.evaluateJavascript("(function(){return document.documentElement.outerHTML})()", new android.webkit.ValueCallback<String>() {
                                @Override public void onReceiveValue(String value) {
                                    if (done[0]) return;
                                    String html = jsUnquote(value);
                                    tries[0]++;
                                    boolean challenge = html.contains("Just a moment") || html.contains("challenge-platform")
                                            || html.contains("cf-browser-verification") || html.contains("_cf_chl")
                                            || html.contains("Checking your browser") || html.length() < 800;
                                    boolean realCaptcha = html.contains("g-recaptcha") || html.contains("recaptcha/api") || html.contains("hcaptcha");
                                    if (!challenge || realCaptcha || tries[0] >= 20) {
                                        done[0] = true;
                                        JSObject ret = new JSObject();
                                        ret.put("status", 200);
                                        ret.put("url", url);
                                        // капчей считаем ТОЛЬКО настоящую recaptcha/hcaptcha, а не интерстишл Cloudflare
                                        ret.put("captcha", realCaptcha);
                                        ret.put("body", html);
                                        if (noAuth) restoreAuthCookies(savedAuth[0]);
                                        call.resolve(ret);
                                        try { wv.destroy(); } catch (Exception ignored) {}
                                    } else {
                                        h.postDelayed(poll[0], 1500);
                                    }
                                }
                            });
                        }
                    };
                    wv.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override public void onPageFinished(android.webkit.WebView view, String u) {
                            if (done[0]) return;
                            h.postDelayed(poll[0], 1000);
                        }
                    });
                    h.postDelayed(new Runnable() { @Override public void run() {
                        if (!done[0]) { done[0] = true; try { wv.destroy(); } catch (Exception ignored) {} if (noAuth) restoreAuthCookies(savedAuth[0]); call.reject("timeout"); }
                    } }, 35000);
                    wv.loadUrl(url);
                } catch (Throwable e) { if (noAuth) restoreAuthCookies(savedAuth[0]); call.reject(String.valueOf(e.getMessage())); }
            }
        });
    }

    private String jsUnquote(String v) {
        if (v == null) return "";
        try { return new org.json.JSONArray("[" + v + "]").getString(0); } catch (Exception e) { return v; }
    }

    // Нативный попап с постом 4pda в WebView (как dlg_post_view у ag4pda): грузит URL поста,
    // делит cookie с логином (проходит Cloudflare), показывает именно этот пост.
    @PluginMethod
    public void saveTextFile(PluginCall call) {                      // текстовый файл в системные «Загрузки» (экспорт связей и т.п.)
        try {
            String name = call.getString("name", "export.txt");
            String text = call.getString("text", "");
            byte[] bytes = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            String shownAt;
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, name.endsWith(".json") ? "application/json" : "text/plain");
                cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                android.net.Uri uri = getContext().getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) { call.reject("не удалось создать файл"); return; }
                try (java.io.OutputStream os = getContext().getContentResolver().openOutputStream(uri)) { os.write(bytes); }
                shownAt = "Download/" + name;
            } else {
                java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                java.io.File f = new java.io.File(dir, name);
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) { fo.write(bytes); }
                shownAt = f.getAbsolutePath();
            }
            JSObject o = new JSObject(); o.put("path", shownAt); call.resolve(o);
        } catch (Exception e) { call.reject("saveTextFile: " + e.getMessage()); }
    }

    @PluginMethod
    public void writeCache(PluginCall call) {
        String name = call.getString("name", "cache.txt");
        String text = call.getString("text", "");
        try {
            java.io.File dir = getContext().getFilesDir();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(text.getBytes("UTF-8"));
            fos.close();
            JSObject ret = new JSObject(); ret.put("ok", true); ret.put("path", f.getAbsolutePath()); call.resolve(ret);
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void readCacheInfo(PluginCall call) {
        String name = call.getString("name", "cache.txt");
        JSObject ret = new JSObject();
        try { java.io.File f = new java.io.File(getContext().getFilesDir(), name); ret.put("size", f.exists() ? f.length() : 0); }
        catch (Exception e) { ret.put("size", 0); }
        call.resolve(ret);
    }
    @PluginMethod
    public void readCacheChunk(PluginCall call) {
        // кусок файла в base64: большие файлы (каталог ~13МБ) одной строкой через мост читаются нестабильно
        String name = call.getString("name", "cache.txt");
        long off = 0; int len = 2097152;
        try { Object o = call.getData().opt("offset"); if (o instanceof Number) off = ((Number) o).longValue(); else if (o != null) off = Long.parseLong(String.valueOf(o)); } catch (Exception ignored) {}
        try { Object o = call.getData().opt("len"); if (o instanceof Number) len = ((Number) o).intValue(); else if (o != null) len = Integer.parseInt(String.valueOf(o)); } catch (Exception ignored) {}
        try {
            java.io.File f = new java.io.File(getContext().getFilesDir(), name);
            JSObject ret = new JSObject();
            if (!f.exists() || off >= f.length()) { ret.put("b64", ""); call.resolve(ret); return; }
            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r");
            raf.seek(off);
            int want = (int) Math.min((long) len, f.length() - off);
            byte[] buf = new byte[want]; int got = 0;
            while (got < want) { int n = raf.read(buf, got, want - got); if (n <= 0) break; got += n; }
            raf.close();
            ret.put("b64", Base64.encodeToString(got == want ? buf : java.util.Arrays.copyOf(buf, got), Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }
    @PluginMethod
    public void readCache(PluginCall call) {
        String name = call.getString("name", "cache.txt");
        try {
            java.io.File f = new java.io.File(getContext().getFilesDir(), name);
            JSObject ret = new JSObject();
            if (!f.exists()) { ret.put("text", ""); call.resolve(ret); return; }
            java.io.FileInputStream fis = new java.io.FileInputStream(f);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[65536]; int n;
            while ((n = fis.read(buf)) != -1) bos.write(buf, 0, n);
            fis.close();
            ret.put("text", new String(bos.toByteArray(), "UTF-8"));
            call.resolve(ret);
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void saveText(PluginCall call) {
        String name = call.getString("name", "debug.txt");
        String text = call.getString("text", "");
        try {
            java.io.File dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (dir != null && !dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(text.getBytes("UTF-8"));
            fos.close();
            JSObject ret = new JSObject();
            ret.put("path", f.getAbsolutePath());
            call.resolve(ret);
        } catch (Exception e) {
            // запасной путь: app-specific dir (без разрешений)
            try {
                java.io.File dir2 = getContext().getExternalFilesDir(null);
                java.io.File f2 = new java.io.File(dir2, name);
                java.io.FileOutputStream fos2 = new java.io.FileOutputStream(f2);
                fos2.write(text.getBytes("UTF-8"));
                fos2.close();
                JSObject ret = new JSObject();
                ret.put("path", f2.getAbsolutePath());
                call.resolve(ret);
            } catch (Exception e2) { call.reject(String.valueOf(e2.getMessage())); }
        }
    }

    @PluginMethod
    public void openPostView(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        String p = "";
        try { java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:pid=|entry)(\\d+)").matcher(url); if (m.find()) p = m.group(1); } catch (Exception ignored) {}
        final String pid = p;
        final android.app.Activity act = getActivity();
        if (act == null) { call.reject("no activity"); return; }
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    final android.app.Dialog dlg = new android.app.Dialog(act);
                    if (dlg.getWindow() != null) dlg.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
                    android.widget.FrameLayout root = new android.widget.FrameLayout(act);
                    root.setBackgroundColor(0xFF1C140C);
                    final android.webkit.WebView wv = new android.webkit.WebView(act);
                    android.webkit.WebSettings s = wv.getSettings();
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    s.setUseWideViewPort(true);
                    s.setLoadWithOverviewMode(true);
                    s.setBuiltInZoomControls(true);
                    s.setDisplayZoomControls(false);
                    wv.setBackgroundColor(0xFF1C140C);
                    android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                    try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; domain=4pda.to; path=/"); android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/"); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                    final android.widget.ProgressBar pb = new android.widget.ProgressBar(act);
                    android.widget.FrameLayout.LayoutParams plp = new android.widget.FrameLayout.LayoutParams(-2, -2);
                    plp.gravity = android.view.Gravity.CENTER;
                    final String js = "(function(){try{"
                        + "if(document.body.getAttribute('data-cln'))return 'true';"
                        + "var pid='" + pid + "';var body=null;"
                        + "if(pid){var anc=document.querySelector('a[name=\"entry'+pid+'\"]')||document.getElementById('entry'+pid)||document.getElementById('p'+pid)||document.querySelector('[data-post=\"'+pid+'\"]');"
                        + "if(anc){var bs=document.querySelectorAll('.post_body,.postcolor');for(var j=0;j<bs.length;j++){if(anc.compareDocumentPosition(bs[j])&4){body=bs[j];break;}}"
                        + "if(!body){var e=anc;for(var i=0;i<12&&e&&!body;i++){if(e.querySelector)body=e.querySelector('.post_body,.postcolor');if(!body)e=e.parentElement;}}}}"
                        + "if(!body){body=document.querySelector('.post_body,.postcolor');}"
                        + "if(!body)return 'wait';"
                        + "var h=body.innerHTML;document.body.innerHTML=h;document.body.setAttribute('data-cln','1');"
                        + "document.body.setAttribute('style','margin:0;padding:14px;background:#1c140c;color:#d2d2d2;font:15px/1.55 -apple-system,Roboto,Arial,sans-serif;word-wrap:break-word;overflow-wrap:break-word');"
                        + "var st=document.createElement('style');st.innerHTML='a{color:#5ab0d8;text-decoration:none}img{max-width:100%;height:auto;border-radius:6px}b,strong{color:#ededed}table{max-width:100%}';document.head.appendChild(st);"
                        + "return 'true';}catch(e){return 'err';}})()";
                    final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                    final int[] tries = {0};
                    final Runnable[] poll = new Runnable[1];
                    poll[0] = new Runnable() {
                        @Override public void run() {
                            tries[0]++;
                            wv.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                                @Override public void onReceiveValue(String v) {
                                    boolean done = v != null && v.indexOf("true") >= 0;
                                    if (done) pb.setVisibility(android.view.View.GONE);
                                    if (!done && tries[0] < 30) h.postDelayed(poll[0], 1000);
                                }
                            });
                        }
                    };
                    wv.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override public void onPageFinished(android.webkit.WebView view, String u) { h.removeCallbacks(poll[0]); h.postDelayed(poll[0], 400); }
                    });
                    wv.setWebChromeClient(new android.webkit.WebChromeClient() {
                        @Override public void onProgressChanged(android.webkit.WebView view, int prog) { if (prog >= 100) h.postDelayed(poll[0], 300); }
                    });
                    root.addView(wv, new android.widget.FrameLayout.LayoutParams(-1, -1));
                    root.addView(pb, plp);
                    dlg.setContentView(root);
                    if (dlg.getWindow() != null) {
                        int dw = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.94);
                        int dh = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.82);
                        dlg.getWindow().setLayout(dw, dh);
                        dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF1C140C));
                    }
                    dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                        @Override public void onDismiss(android.content.DialogInterface d) { try { wv.destroy(); } catch (Exception ignored) {} }
                    });
                    wv.loadUrl(url);
                    dlg.show();
                    call.resolve();
                } catch (Throwable e) { call.reject(String.valueOf(e.getMessage())); }
            }
        });
    }

    // Нативный GET страницы 4pda с браузерным UA + cookie из WebView-логина.
    // Возвращает body (в правильной кодировке), status, финальный url и флаг captcha.
    @PluginMethod
    public void httpGet(final PluginCall call) {
        final String url = call.getString("url");
        final int maxBytes = call.getInt("maxBytes", 0); // >0: читаем только начало (для версии из шапки — не тянем всю тему)
        final boolean noAuth = Boolean.TRUE.equals(call.getBoolean("noAuth", false)); // фоновые чтения без сессии — история форума не засоряется
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                okhttp3.Response resp = null;
                try {
                    okhttp3.Request.Builder rqb = okReq(url).header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                    // условный запрос: если страница не менялась, сервер ответит 304 без тела (мгновенно и без трафика)
                    String inm = call.getString("ifNoneMatch", ""); if (inm != null && !inm.isEmpty()) rqb.header("If-None-Match", inm);
                    String ims = call.getString("ifModifiedSince", ""); if (ims != null && !ims.isEmpty()) rqb.header("If-Modified-Since", ims);
                    try { String ck = android.webkit.CookieManager.getInstance().getCookie(url); if (ck != null && !ck.isEmpty()) rqb.header("Cookie", ck); } catch (Exception ignored) {}
                    okhttp3.Request req = rqb.build();
                    resp = (noAuth ? noAuthClient() : ok()).newCall(req).execute();
                    int code = resp.code();
                    byte[] raw;
                    if (maxBytes > 0 && resp.body() != null) { // читаем только первые maxBytes (распакованных) и обрываем закачку
                        java.io.InputStream is = resp.body().byteStream();
                        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                        byte[] buf = new byte[16384]; int n, total = 0;
                        while (total < maxBytes && (n = is.read(buf, 0, Math.min(buf.length, maxBytes - total))) != -1) { bos.write(buf, 0, n); total += n; }
                        raw = bos.toByteArray();
                    } else {
                        raw = resp.body() != null ? resp.body().bytes() : new byte[0]; // OkHttp сам распаковывает gzip
                    }
                    // кодировка: форум 4pda — windows-1251; определяем по Content-Type / meta
                    String charset = "UTF-8";
                    String ct = resp.header("Content-Type");
                    String head = new String(raw, 0, Math.min(raw.length, 2048), java.nio.charset.StandardCharsets.ISO_8859_1).toLowerCase();
                    if ((ct != null && (ct.toLowerCase().contains("1251") || ct.toLowerCase().contains("windows-1251")))
                            || head.contains("charset=windows-1251") || head.contains("charset=cp1251")) {
                        charset = "windows-1251";
                    }
                    String body = new String(raw, charset);
                    boolean captcha = body.contains("g-recaptcha") || body.contains("recaptcha/api") || body.contains("www.google.com/recaptcha");
                    JSObject ret = new JSObject();
                    ret.put("status", code);
                    ret.put("url", resp.request().url().toString());
                    ret.put("captcha", captcha);
                    ret.put("charset", charset);
                    try { String et = resp.header("ETag"); if (et != null) ret.put("etag", et); } catch (Exception ignored) {}
                    try { String lm = resp.header("Last-Modified"); if (lm != null) ret.put("lastMod", lm); } catch (Exception ignored) {}
                    ret.put("notModified", code == 304);
                    ret.put("body", body);
                    call.resolve(ret);
                } catch (Exception e) {
                    call.reject(e.getMessage());
                } finally {
                    if (resp != null) try { resp.close(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    // ---- иконки → data:image/png;base64 (уменьшаем до 144px) ----

    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 96) {
            float sc = 96f / mx;
            b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try {
            if (d instanceof android.graphics.drawable.BitmapDrawable) {
                Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap();
                if (bm != null) return bm;
            }
        } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        return b;
    }

    // ===== Подпись/пакет APK: подпись установленного приложения + Range-чтение APK на 4pda =====

    private String sha256Hex(byte[] b) throws Exception {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
        byte[] h = md.digest(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : h) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    @PluginMethod
    public void appSignature(PluginCall call) {
        String pkg = call.getString("pkg");
        JSObject ret = new JSObject();
        try {
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            byte[] cert = null;
            // v1-схема (signatures[]) — та же, что читается из META-INF/*.RSA у файла (как в ag4pda), иначе подписи не сойдутся
            android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNATURES);
            if (pi.signatures != null && pi.signatures.length > 0) cert = pi.signatures[0].toByteArray();
            if (cert != null) ret.put("sig", sha256Hex(cert));
        } catch (Exception ignored) {}
        call.resolve(ret);
    }

    private byte[] httpRangeAbs(String url, long start, long end) throws Exception {
        okhttp3.Request.Builder rb = okReq(url).header("Range", "bytes=" + start + "-" + end);
        try { String ck = android.webkit.CookieManager.getInstance().getCookie(url); if (ck != null && !ck.isEmpty()) rb.header("Cookie", ck); } catch (Exception ignored) {}
        okhttp3.Response resp = ok().newCall(rb.build()).execute();
        int code = resp.code();
        if (code != 206) { resp.close(); throw new Exception("no206:" + code); } // сервер проигнорил Range — НЕ читаем тело, иначе скачается весь apk (засчитается как загрузка)
        byte[] body = resp.body() != null ? resp.body().bytes() : new byte[0];
        resp.close();
        return body;
    }

    private byte[] readZipEntry(String url, long lho, long compSize, int method, long uncSize) throws Exception {
        // один Range: локальный заголовок + запас на имя/extra + сами данные (реальный extra читаем из буфера)
        int PAD = 512;
        byte[] buf = httpRangeAbs(url, lho, lho + 30 + PAD + compSize - 1);
        if (buf.length < 30) return new byte[0];
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(buf).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        int nameLen = bb.getShort(26) & 0xFFFF; int extraLen = bb.getShort(28) & 0xFFFF;
        int dataStart = 30 + nameLen + extraLen;
        byte[] comp;
        if (dataStart + compSize <= buf.length) comp = java.util.Arrays.copyOfRange(buf, dataStart, (int) (dataStart + compSize));
        else { long dataOff = lho + dataStart; comp = httpRangeAbs(url, dataOff, dataOff + compSize - 1); } // запаса не хватило — доберём данные
        if (method == 0) return comp;
        java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
        inf.setInput(comp);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] tmp = new byte[16384];
        try { while (!inf.finished()) { int n = inf.inflate(tmp); if (n == 0) { if (inf.needsInput() || inf.needsDictionary()) break; } bos.write(tmp, 0, n); } } catch (Exception ignored) {}
        inf.end();
        return bos.toByteArray();
    }

    private java.util.List<String> axmlStrings(byte[] d, int chunkPos) {
        java.util.List<String> out = new java.util.ArrayList<>();
        try {
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(d).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            int stringCount = bb.getInt(chunkPos + 8);
            int flags = bb.getInt(chunkPos + 16);
            boolean utf8 = (flags & 0x100) != 0;
            int stringsStart = bb.getInt(chunkPos + 20);
            int offsetsBase = chunkPos + 28;
            int dataBase = chunkPos + stringsStart;
            for (int i = 0; i < stringCount; i++) {
                int off = bb.getInt(offsetsBase + i * 4);
                int sp = dataBase + off;
                if (sp < 0 || sp >= d.length) { out.add(""); continue; }
                if (utf8) {
                    int p = sp; int u = d[p] & 0xFF; p++; if ((u & 0x80) != 0) p++;
                    int blen = d[p] & 0xFF; p++; if ((blen & 0x80) != 0) { blen = ((blen & 0x7F) << 8) | (d[p] & 0xFF); p++; }
                    out.add(new String(d, p, Math.min(blen, d.length - p), "UTF-8"));
                } else {
                    int p = sp; int len = (d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8); p += 2; if ((len & 0x8000) != 0) { len = ((len & 0x7FFF) << 16) | ((d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8)); p += 2; }
                    out.add(new String(d, p, Math.min(len * 2, d.length - p), "UTF-16LE"));
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    private String parseAxmlPackage(byte[] d) {
        try {
            if (d == null || d.length < 8) return "";
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(d).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            java.util.List<String> strings = null;
            int pos = 8;
            while (pos + 8 <= d.length) {
                int type = bb.getShort(pos) & 0xFFFF;
                int size = bb.getInt(pos + 4);
                if (size <= 0 || pos + size > d.length) break;
                if (type == 0x0001) strings = axmlStrings(d, pos);
                else if (type == 0x0102 && strings != null) {
                    int nameIdx = bb.getInt(pos + 20);
                    int attrStart = bb.getShort(pos + 24) & 0xFFFF;
                    int attrCount = bb.getShort(pos + 28) & 0xFFFF;
                    String tag = (nameIdx >= 0 && nameIdx < strings.size()) ? strings.get(nameIdx) : "";
                    if ("manifest".equals(tag)) {
                        int ap = pos + 16 + attrStart;
                        for (int i = 0; i < attrCount; i++) {
                            int base = ap + i * 20;
                            if (base + 20 > d.length) break;
                            int aName = bb.getInt(base + 4);
                            int aRaw = bb.getInt(base + 8);
                            int aData = bb.getInt(base + 16);
                            String an = (aName >= 0 && aName < strings.size()) ? strings.get(aName) : "";
                            if ("package".equals(an)) {
                                if (aRaw >= 0 && aRaw < strings.size() && strings.get(aRaw).length() > 0) return strings.get(aRaw);
                                if (aData >= 0 && aData < strings.size()) return strings.get(aData);
                            }
                        }
                    }
                }
                pos += size;
            }
        } catch (Exception ignored) {}
        return "";
    }

    // читает целочисленный атрибут бинарного манифеста (напр. versionCode на <manifest>, minSdkVersion на <uses-sdk>)
    private int axmlIntAttr(byte[] d, String tagName, String attrName) {
        try {
            if (d == null || d.length < 8) return -1;
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(d).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            java.util.List<String> strings = null;
            int pos = 8;
            while (pos + 8 <= d.length) {
                int type = bb.getShort(pos) & 0xFFFF;
                int size = bb.getInt(pos + 4);
                if (size <= 0 || pos + size > d.length) break;
                if (type == 0x0001) strings = axmlStrings(d, pos);
                else if (type == 0x0102 && strings != null) {
                    int nameIdx = bb.getInt(pos + 20);
                    int attrStart = bb.getShort(pos + 24) & 0xFFFF;
                    int attrCount = bb.getShort(pos + 28) & 0xFFFF;
                    String tag = (nameIdx >= 0 && nameIdx < strings.size()) ? strings.get(nameIdx) : "";
                    if (tagName.equals(tag)) {
                        int ap = pos + 16 + attrStart;
                        for (int i = 0; i < attrCount; i++) {
                            int base = ap + i * 20;
                            if (base + 20 > d.length) break;
                            int aName = bb.getInt(base + 4);
                            int aData = bb.getInt(base + 16);
                            String an = (aName >= 0 && aName < strings.size()) ? strings.get(aName) : "";
                            if (attrName.equals(an)) return aData;
                        }
                    }
                }
                pos += size;
            }
        } catch (Exception ignored) {}
        return -1;
    }

    private String cp1251enc(String s) throws Exception {
        byte[] b = s.getBytes("windows-1251");
        StringBuilder sb = new StringBuilder();
        for (byte x : b) { int c = x & 0xFF; if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') sb.append((char) c); else sb.append('%').append(String.format("%02X", c)); }
        return sb.toString();
    }

    @PluginMethod
    public void authForm4pda(final PluginCall call) {
        new Thread(new Runnable() { public void run() {
            JSObject ret = new JSObject();
            try {
                okhttp3.Request.Builder req = okReq("https://4pda.to/forum/index.php?act=auth").header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                try { String ck = android.webkit.CookieManager.getInstance().getCookie("https://4pda.to"); if (ck != null && !ck.isEmpty()) req.header("Cookie", ck); } catch (Exception ignored) {}
                okhttp3.Response resp = ok().newCall(req.build()).execute();
                for (String sc : resp.headers("Set-Cookie")) { try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", sc); } catch (Exception ignored) {} }
                try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                String html = resp.body() != null ? resp.body().string() : "";
                resp.close();
                String time = "", sig = "", img = "";
                java.util.regex.Matcher cm = java.util.regex.Pattern.compile("captcha-time\" value=\"([^\"]*?)\"[\\s\\S]*?captcha-sig\" value=\"([^\"]*?)\"[\\s\\S]*?src=\"([^\"]*?)\"").matcher(html);
                if (cm.find()) { time = cm.group(1); sig = cm.group(2); img = cm.group(3); }
                if (!img.isEmpty()) { img = img.replace("&amp;", "&"); if (img.startsWith("//")) img = "https:" + img; else if (img.startsWith("/")) img = "https://4pda.to" + img; }
                boolean cf = html.contains("Just a moment") || html.contains("challenge-platform");
                ret.put("captchaTime", time); ret.put("captchaSig", sig); ret.put("captchaImage", img);
                ret.put("needCaptcha", !img.isEmpty() && !cf);
                ret.put("cf", cf);
            } catch (Exception ignored) {}
            call.resolve(ret);
        } }).start();
    }

    @PluginMethod
    public void login4pda(final PluginCall call) {
        final String nick = call.getString("nick", "");
        final String pass = call.getString("password", "");
        final String captcha = call.getString("captcha", "");
        final String ctime = call.getString("captchaTime", "");
        final String csig = call.getString("captchaSig", "");
        final boolean hidden = Boolean.TRUE.equals(call.getBoolean("hidden", false));
        new Thread(new Runnable() { public void run() {
            JSObject ret = new JSObject();
            try {
                String body = "return=minimal&remember=1&hidden=" + (hidden ? "1" : "0") + "&login=" + cp1251enc(nick) + "&password=" + cp1251enc(pass);
                if (!captcha.isEmpty()) body += "&captcha=" + cp1251enc(captcha) + "&captcha-time=" + cp1251enc(ctime) + "&captcha-sig=" + cp1251enc(csig);
                okhttp3.RequestBody rb = okhttp3.RequestBody.create(body.getBytes("ISO-8859-1"), okhttp3.MediaType.parse("application/x-www-form-urlencoded; charset=windows-1251"));
                okhttp3.Request.Builder req = okReq("https://4pda.to/forum/index.php?act=auth").post(rb).header("Content-Type", "application/x-www-form-urlencoded").header("Referer", "https://4pda.to/forum/index.php?act=auth").header("Origin", "https://4pda.to");
                try { String ck = android.webkit.CookieManager.getInstance().getCookie("https://4pda.to"); if (ck != null && !ck.isEmpty()) req.header("Cookie", ck); } catch (Exception ignored) {}
                okhttp3.Response resp = ok().newCall(req.build()).execute();
                for (String sc : resp.headers("Set-Cookie")) { try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", sc); } catch (Exception ignored) {} }
                try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                String html = resp.body() != null ? resp.body().string() : "";
                resp.close();
                boolean cf = html.contains("Just a moment") || html.contains("challenge-platform") || html.contains("Кто здесь");
                boolean captchaReq = html.contains("captcha-image") || html.contains("captcha-time") || html.contains("g-recaptcha");
                String ck2 = "";
                try { ck2 = android.webkit.CookieManager.getInstance().getCookie("https://4pda.to"); } catch (Exception ignored) {}
                boolean okLogged = ck2 != null && ck2.contains("member_id") && !ck2.contains("member_id=0") && !ck2.contains("member_id=deleted");
                ret.put("ok", okLogged);
                ret.put("captcha", captchaReq && !okLogged);
                ret.put("cf", cf && !okLogged);
            } catch (Exception e) { ret.put("ok", false); ret.put("error", String.valueOf(e.getMessage())); }
            call.resolve(ret);
        } }).start();
    }

    // отдаёт куки залогиненной 4pda-сессии (для экспорта в секрет CI FPDA_COOKIE)
    @PluginMethod
    public void exportAuth(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            String ck = android.webkit.CookieManager.getInstance().getCookie("https://4pda.to");
            ret.put("cookie", ck == null ? "" : ck);
        } catch (Exception e) { ret.put("cookie", ""); }
        try { ret.put("ua", android.webkit.WebSettings.getDefaultUserAgent(getContext())); } catch (Exception e) { ret.put("ua", ""); }
        call.resolve(ret);
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        final String text = call.getString("text", "");
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("4pda", text));
        } catch (Exception ignored) {}
        call.resolve();
    }

    // ищет v2 (0x7109871a) или v3 (0xf05368c0) блок в APK Signing Block и берёт SHA-256 первого сертификата
    private String sigFromSignBlock(byte[] block) {
        try {
            if (block == null || block.length < 32) return "";
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(block).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            int pos = 8; // пропускаем ведущий uint64 size
            while (pos + 12 <= block.length) {
                long pairLen = bb.getLong(pos);
                if (pairLen < 4 || pos + 8 + pairLen > block.length) break;
                int id = bb.getInt(pos + 8);
                if (id == 0x7109871a || id == 0xf05368c0) {
                    String sha = firstCertSha(block, pos + 12);
                    if (sha.length() > 0) return sha;
                }
                pos += (int) (8 + pairLen);
            }
        } catch (Exception ignored) {}
        return "";
    }

    // value: uint32 signers | signer(uint32){ signedData(uint32){ digests(uint32) certs(uint32){ cert(uint32) DER } ... } ... }
    private String firstCertSha(byte[] d, int base) {
        try {
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(d).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            int p = base;
            p += 4;                          // длина последовательности signers
            p += 4;                          // длина первого signer
            p += 4;                          // длина signed data
            int digestsLen = bb.getInt(p); p += 4;   // digests
            p += digestsLen;                 // пропускаем digests
            p += 4;                          // длина последовательности certificates
            int certLen = bb.getInt(p); p += 4;      // длина первого сертификата
            if (certLen <= 0 || p + certLen > d.length) return "";
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            md.update(d, p, certLen);        // SHA-256 от DER сертификата = как signatures[0].toByteArray()
            byte[] h = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte x : h) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception ignored) {}
        return "";
    }

    private String pkcs7CertSha(byte[] d) {
        try {
            java.security.cert.CertificateFactory cf = java.security.cert.CertificateFactory.getInstance("X.509");
            java.util.Collection<? extends java.security.cert.Certificate> certs = cf.generateCertificates(new java.io.ByteArrayInputStream(d));
            for (java.security.cert.Certificate c : certs) return sha256Hex(c.getEncoded());
        } catch (Exception ignored) {}
        return "";
    }

    @PluginMethod
    public void apkInfo(final PluginCall call) {
        final String url = call.getString("url");
        final boolean full = Boolean.TRUE.equals(call.getBoolean("full", true)); // full=false: только подпись+ABI (без манифеста) — для быстрого списка
        new Thread(new Runnable() { public void run() {
            JSObject ret = new JSObject();
            try {
                int TAIL = 65600; // ~64 КБ хвоста (минимум). Для больших apk каталог берётся догрузкой ниже (обёрнута — при сбое покажет why:cdfetch-fail)
                okhttp3.Request.Builder rb = okReq(url).header("Range", "bytes=-" + TAIL);
                try { String ck = android.webkit.CookieManager.getInstance().getCookie(url); if (ck != null && !ck.isEmpty()) rb.header("Cookie", ck); } catch (Exception ignored) {}
                okhttp3.Response resp = ok().newCall(rb.build()).execute();
                final String cdnUrl = resp.request().url().toString(); // финальный URL после редиректа шлюза = CDN; остальные куски читаем по нему (не по шлюзу — 4pda не считает это загрузкой)
                String cr = resp.header("Content-Range");
                String ctype = resp.header("Content-Type", "");
                int code = resp.code();
                // сервер не поддержал Range (нет 206/Content-Range) или это HTML (нужен вход) — не тянем весь файл
                if (code != 206 || cr == null || (ctype != null && ctype.toLowerCase().contains("text/html"))) {
                    String extra = "";
                    try { // страница вместо файла — вытащим сам текст ошибки 4pda
                        String body = resp.peekBody(65536).string();
                        String txt = body.replaceAll("(?s)<head.*?</head>", " ").replaceAll("(?s)<script.*?</script>", " ").replaceAll("(?s)<style.*?</style>", " ")
                                         .replaceAll("<[^>]+>", " ").replaceAll("&nbsp;", " ").replaceAll("&quot;", "\"").replaceAll("&amp;", "&").replaceAll("\\s+", " ").trim();
                        int i = txt.indexOf("Ошибка");
                        String cut = (i >= 0) ? txt.substring(i) : txt;
                        extra = cut.substring(0, Math.min(140, cut.length()));
                    } catch (Exception ignored) {}
                    ret.put("dbg", "no206:" + code + (cr == null ? "/nocr" : "") + ((ctype != null && ctype.toLowerCase().contains("text/html")) ? "/html" : "") + (extra.isEmpty() ? "" : " «" + extra + "»"));
                    resp.close(); call.resolve(ret); return;
                }
                byte[] tail = resp.body() != null ? resp.body().bytes() : new byte[0];
                resp.close();
                long tailStart = 0;
                if (cr.contains(" ") && cr.contains("-")) { String rng = cr.substring(cr.indexOf(' ') + 1); if (rng.contains("/")) rng = rng.substring(0, rng.indexOf('/')); tailStart = Long.parseLong(rng.substring(0, rng.indexOf('-')).trim()); }
                int eocd = -1;
                for (int i = tail.length - 22; i >= 0; i--) { if ((tail[i] & 0xFF) == 0x50 && (tail[i + 1] & 0xFF) == 0x4b && (tail[i + 2] & 0xFF) == 0x05 && (tail[i + 3] & 0xFF) == 0x06) { eocd = i; break; } }
                if (eocd < 0) { ret.put("dbg", "noeocd/tail" + tail.length); call.resolve(ret); return; }
                java.nio.ByteBuffer eb = java.nio.ByteBuffer.wrap(tail).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int cdSize = eb.getInt(eocd + 12); long cdOff = eb.getInt(eocd + 16) & 0xFFFFFFFFL;
                byte[] cd = null;
                long cdStartInTail = cdOff - tailStart;
                if (cdStartInTail >= 0 && cdStartInTail + cdSize <= tail.length) cd = java.util.Arrays.copyOfRange(tail, (int) cdStartInTail, (int) (cdStartInTail + cdSize));
                else if (full) { try { cd = httpRangeAbs(cdnUrl, cdOff, cdOff + cdSize - 1); } catch (Exception e) { ret.put("dbg", "cdfetch-fail:" + e.getClass().getSimpleName()); call.resolve(ret); return; } }
                // каталога нет в хвосте и режим быстрый (список) — не качаем его: для подписи v2/v3 нужен только cdOff
                // из центрального каталога: сертификат (подпись), манифест (версия/minSdk), реальные ABI из lib/
                long sigOff = -1, sigComp = 0; int sigMethod = 0;
                long manOff = -1, manComp = 0; int manMethod = 0;
                java.util.LinkedHashSet<String> abis = new java.util.LinkedHashSet<>();
                if (cd != null) {
                java.nio.ByteBuffer cb = java.nio.ByteBuffer.wrap(cd).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int p = 0;
                while (p + 46 <= cd.length) {
                    if (cb.getInt(p) != 0x02014b50) break;
                    int method = cb.getShort(p + 10) & 0xFFFF;
                    int compSize = cb.getInt(p + 20);
                    int nameLen = cb.getShort(p + 28) & 0xFFFF; int extraLen = cb.getShort(p + 30) & 0xFFFF; int commentLen = cb.getShort(p + 32) & 0xFFFF;
                    long lho = cb.getInt(p + 42) & 0xFFFFFFFFL;
                    String name = new String(cd, p + 46, Math.min(nameLen, cd.length - p - 46), "UTF-8");
                    if (sigOff < 0 && name.startsWith("META-INF/") && (name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC"))) { sigOff = lho; sigComp = compSize; sigMethod = method; }
                    else if (manOff < 0 && name.equals("AndroidManifest.xml")) { manOff = lho; manComp = compSize; manMethod = method; }
                    else if (name.startsWith("lib/")) { int s = name.indexOf('/', 4); if (s > 4) abis.add(name.substring(4, s)); }
                    p += 46 + nameLen + extraLen + commentLen;
                }
                StringBuilder ab = new StringBuilder();
                for (String a : abis) { if (ab.length() > 0) ab.append(","); ab.append(a); }
                ret.put("abis", ab.toString());
                }
                if (sigOff >= 0) { byte[] raw = readZipEntry(cdnUrl, sigOff, sigComp, sigMethod, -1); String sha = pkcs7CertSha(raw); if (sha.length() > 0) { ret.put("sig", sha); ret.put("dbg", "v1"); } else ret.put("dbg", "v1-parsefail"); }
                if (full && manOff >= 0) { byte[] raw = readZipEntry(cdnUrl, manOff, manComp, manMethod, -1); int vc = axmlIntAttr(raw, "manifest", "versionCode"); if (vc >= 0) ret.put("vercode", vc); int ms = axmlIntAttr(raw, "uses-sdk", "minSdkVersion"); if (ms >= 0) ret.put("minSdk", ms); }
                // нет v1 (META-INF/*.RSA) — у современных apk подпись только v2/v3 в APK Signing Block перед центральным каталогом
                if (!ret.has("sig")) {
                    try {
                        long fOff = cdOff - 24; // футер блока: uint64 size + "APK Sig Block 42"
                        byte[] footer; long fInTail = fOff - tailStart;
                        if (fInTail >= 0 && fInTail + 24 <= tail.length) footer = java.util.Arrays.copyOfRange(tail, (int) fInTail, (int) fInTail + 24);
                        else footer = httpRangeAbs(cdnUrl, fOff, cdOff - 1);
                        if (footer != null && footer.length >= 24 && "APK Sig Block 42".equals(new String(footer, 8, 16, "ISO-8859-1"))) {
                            long blockSize = java.nio.ByteBuffer.wrap(footer).order(java.nio.ByteOrder.LITTLE_ENDIAN).getLong(0);
                            long blockStart = cdOff - blockSize - 8;
                            if (blockStart >= 0 && blockSize < 8_000_000) {
                                byte[] block; long bInTail = blockStart - tailStart;
                                if (bInTail >= 0 && bInTail + blockSize + 8 <= tail.length) block = java.util.Arrays.copyOfRange(tail, (int) bInTail, (int) (bInTail + blockSize + 8));
                                else block = httpRangeAbs(cdnUrl, blockStart, cdOff - 1);
                                String sha = sigFromSignBlock(block);
                                if (sha.length() > 0) { ret.put("sig", sha); ret.put("dbg", "v2v3"); }
                                else ret.put("dbg", "sigblk-parsefail/len" + (block == null ? -1 : block.length));
                            } else ret.put("dbg", "sigblk-badsize/" + blockSize);
                        } else ret.put("dbg", "nosigblk/" + (footer == null ? "null" : ("magic=" + (footer.length >= 24 ? new String(footer, 8, 16, "ISO-8859-1").replaceAll("[^A-Za-z0-9 ]", "?") : "short"))));
                    } catch (Exception e) { ret.put("dbg", "sigblk-exc:" + e.getClass().getSimpleName()); }
                }
                // крупный apk со старой v1-подписью в быстром режиме: блока v2/v3 нет, каталог пропускали — дочитаем каталог и возьмём v1
                if (!ret.has("sig") && cd == null) {
                    try {
                        byte[] cd2 = httpRangeAbs(url, cdOff, cdOff + cdSize - 1);
                        if (cd2 != null) {
                            java.nio.ByteBuffer cb2 = java.nio.ByteBuffer.wrap(cd2).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                            int p2 = 0;
                            while (p2 + 46 <= cd2.length) {
                                if (cb2.getInt(p2) != 0x02014b50) break;
                                int method2 = cb2.getShort(p2 + 10) & 0xFFFF;
                                int compSize2 = cb2.getInt(p2 + 20);
                                int nameLen2 = cb2.getShort(p2 + 28) & 0xFFFF; int extraLen2 = cb2.getShort(p2 + 30) & 0xFFFF; int commentLen2 = cb2.getShort(p2 + 32) & 0xFFFF;
                                long lho2 = cb2.getInt(p2 + 42) & 0xFFFFFFFFL;
                                String name2 = new String(cd2, p2 + 46, Math.min(nameLen2, cd2.length - p2 - 46), "UTF-8");
                                if (name2.startsWith("META-INF/") && (name2.endsWith(".RSA") || name2.endsWith(".DSA") || name2.endsWith(".EC"))) {
                                    byte[] raw2 = readZipEntry(url, lho2, compSize2, method2, -1);
                                    String sha2 = pkcs7CertSha(raw2);
                                    if (sha2.length() > 0) { ret.put("sig", sha2); ret.put("dbg", "v1-late"); }
                                    break;
                                }
                                p2 += 46 + nameLen2 + extraLen2 + commentLen2;
                            }
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                if (!ret.has("dbg")) { String msg = e.getMessage(); ret.put("dbg", "exc:" + e.getClass().getSimpleName() + (msg != null ? ":" + msg.substring(0, Math.min(50, msg.length())) : "")); }
            }
            call.resolve(ret);
        } }).start();
    }
}
