package leshugan.a4pda;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.URLUtil;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

import androidx.core.content.FileProvider;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    // Список установленных на устройстве приложений.
    // Параметры: icons (грузить ли base64-иконки, по умолчанию true),
    //            system (включать ли системные, по умолчанию false — только запускаемые пользовательские).
    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        boolean withIcons = Boolean.TRUE.equals(call.getBoolean("icons", true));
        boolean incSystem = Boolean.TRUE.equals(call.getBoolean("system", false));
        boolean incHidden = Boolean.TRUE.equals(call.getBoolean("hidden", false));
        PackageManager pm = getContext().getPackageManager();

        JSArray apps = new JSArray();
        List<PackageInfo> pkgs;
        try {
            pkgs = pm.getInstalledPackages(0);
        } catch (Exception e) {
            call.reject("getInstalledPackages: " + e.getMessage());
            return;
        }

        String self = getContext().getPackageName();
        java.io.File iconDir = new java.io.File(getContext().getCacheDir(), "appicons");
        if (withIcons) iconDir.mkdirs();
        java.util.HashSet<String> valid = new java.util.HashSet<>();

        for (PackageInfo pi : pkgs) {
            try {
                ApplicationInfo ai = pi.applicationInfo;
                if (ai == null) continue;
                if (pi.packageName.equals(self)) continue;

                boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean launchable = pm.getLaunchIntentForPackage(pi.packageName) != null;
                long vc = (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : (long) pi.versionCode;
                String iconName = pi.packageName + "_" + vc + ".png";
                if (withIcons) valid.add(iconName);

                boolean show;
                if (isSystem) show = incSystem;
                else if (!launchable) show = incHidden;
                else show = true;
                if (!show) continue;

                JSObject o = new JSObject();
                o.put("packageName", pi.packageName);
                o.put("label", String.valueOf(ai.loadLabel(pm)));
                o.put("versionName", pi.versionName == null ? "" : pi.versionName);
                o.put("versionCode", vc);
                o.put("system", isSystem);
                o.put("launchable", launchable);
                boolean isGame = false;
                try {
                    if (Build.VERSION.SDK_INT >= 26) isGame = (ai.category == ApplicationInfo.CATEGORY_GAME);
                    if (!isGame) isGame = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                } catch (Exception ignored) {}
                o.put("isGame", isGame);
                o.put("enabled", ai.enabled);
                o.put("firstInstall", pi.firstInstallTime);
                o.put("lastUpdate", pi.lastUpdateTime);
                if (withIcons) {
                    try {
                        java.io.File f = new java.io.File(iconDir, iconName);
                        if (!f.exists()) {
                            Bitmap b = drawableToBitmap(pm.getApplicationIcon(ai));
                            if (b != null) {
                                int mx = Math.max(b.getWidth(), b.getHeight());
                                if (mx > 96) { float sc = 96f / mx; b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true); }
                                java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
                                b.compress(Bitmap.CompressFormat.PNG, 100, fos);
                                fos.flush(); fos.close();
                            }
                        }
                        if (f.exists()) o.put("iconFile", f.getAbsolutePath());
                    } catch (Exception ignored) {}
                }
                apps.put(o);
            } catch (Exception ignored) {}
        }

        // очистить кэш от иконок удалённых/обновлённых приложений
        if (withIcons) {
            try {
                java.io.File[] cached = iconDir.listFiles();
                if (cached != null) for (java.io.File cf : cached) { if (!valid.contains(cf.getName())) cf.delete(); }
            } catch (Exception ignored) {}
        }

        JSObject ret = new JSObject();
        ret.put("apps", apps);
        ret.put("count", apps.length());
        call.resolve(ret);
    }

    // Открыть ссылку во внешнем браузере (тема 4pda и т.п.)
    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // Открыть 4pda внутри приложения (поиск/тема, с сохранением логина, скачивание по тапу)
    @PluginMethod
    public void openWeb(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            Intent i = new Intent(getContext(), WebViewActivity.class);
            i.putExtra("url", url);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // Подробная информация о приложении (для диалога «Информация»)
    @PluginMethod
    public void appDetails(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            PackageManager pm = getContext().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            ApplicationInfo ai = pi.applicationInfo;
            JSObject o = new JSObject();
            o.put("packageName", pkg);
            o.put("label", String.valueOf(ai.loadLabel(pm)));
            o.put("versionName", pi.versionName == null ? "" : pi.versionName);
            long vc = (Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : (long) pi.versionCode;
            o.put("versionCode", vc);
            o.put("targetSdk", ai.targetSdkVersion);
            if (Build.VERSION.SDK_INT >= 24) o.put("minSdk", ai.minSdkVersion);
            o.put("enabled", ai.enabled);
            o.put("system", (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
            o.put("firstInstall", pi.firstInstallTime);
            o.put("lastUpdate", pi.lastUpdateTime);
            try { o.put("apkSize", new java.io.File(ai.sourceDir).length()); } catch (Exception ignored) {}
            String installer = "";
            try {
                if (Build.VERSION.SDK_INT >= 30) { android.content.pm.InstallSourceInfo isi = pm.getInstallSourceInfo(pkg); installer = isi.getInstallingPackageName(); }
                else installer = pm.getInstallerPackageName(pkg);
            } catch (Exception ignored) {}
            o.put("installer", installer == null ? "" : installer);
            call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Запустить установленное приложение
    @PluginMethod
    public void launchApp(PluginCall call) {        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { call.reject("нет интента запуска"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Системный экран «О приложении»
    @PluginMethod
    public void openAppInfo(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Удалить приложение (системный диалог)
    @PluginMethod
    public void uninstallApp(PluginCall call) {
        String pkg = call.getString("packageName");
        if (pkg == null) { call.reject("no package"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Список скачанных apk в папке «Загрузки»
    @PluginMethod
    public void listDownloads(PluginCall call) {        JSArray files = new JSArray();
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File[] arr = dir != null ? dir.listFiles() : null;
            if (arr != null) {
                for (File f : arr) {
                    if (f.isFile() && f.getName().toLowerCase().endsWith(".apk")) {
                        JSObject o = new JSObject();
                        o.put("name", f.getName());
                        o.put("path", f.getAbsolutePath());
                        o.put("size", f.length());
                        o.put("date", f.lastModified());
                        files.put(o);
                    }
                }
            }
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("files", files);
        call.resolve(ret);
    }

    // Статус загрузок DownloadManager (для экрана «Загрузки» с прогрессом)
    @PluginMethod
    public void downloadStatus(PluginCall call) {
        JSArray arr = new JSArray();
        try {
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            android.database.Cursor c = dm.query(new DownloadManager.Query());
            if (c != null) {
                while (c.moveToNext()) {
                    JSObject o = new JSObject();
                    o.put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                    o.put("title", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)));
                    o.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                    o.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                    o.put("done", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                    o.put("uri", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)));
                    try { o.put("src", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_URI))); } catch (Exception ignored) {}
                    o.put("date", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)));
                    arr.put(o);
                }
                c.close();
            }
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("items", arr);
        call.resolve(ret);
    }

    // Установить apk по пути (системный установщик)
    @PluginMethod
    public void installApk(PluginCall call) {
        String path = call.getString("path");
        if (path == null) { call.reject("no path"); return; }
        try {
            File f = new File(path);
            if (!f.exists()) { call.reject("file not found"); return; }
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Поддерживаемые архитектуры устройства (для выбора нужного apk)
    @PluginMethod
    public void deviceAbis(PluginCall call) {        JSArray arr = new JSArray();
        try {
            String[] abis = (Build.VERSION.SDK_INT >= 21) ? Build.SUPPORTED_ABIS : new String[]{ Build.CPU_ABI };
            if (abis != null) for (String a : abis) arr.put(a);
        } catch (Exception ignored) {}
        JSObject ret = new JSObject();
        ret.put("abis", arr);
        call.resolve(ret);
    }

    // Версия приложения из Google Play БЕЗ входа в аккаунт:
    // анонимный токен с раздатчика auroraoss + gplayapi (AppDetailsHelper).
    @PluginMethod
    public void playVersion(final PluginCall call) {
        final String pkg = call.getString("packageName");
        if (pkg == null || pkg.isEmpty()) { call.reject("no package"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String v = PlayApi.version(getContext(), pkg);
                    if (v == null || v.isEmpty()) { call.reject("no version"); return; }
                    String[] parts = v.split("\u0001", 2);
                    JSObject ret = new JSObject();
                    ret.put("versionName", parts[0]);
                    if (parts.length > 1) ret.put("versionCode", parts[1]);
                    call.resolve(ret);
                } catch (Throwable e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }


    // Скачать файл из темы 4pda (с cookie логина) в «Загрузки»
    @PluginMethod
    public void removeDownload(PluginCall call) {
        try {
            long id = call.getLong("id", 0L);
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null && id != 0) dm.remove(id);
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void openDownloads(PluginCall call) {
        try {
            android.content.Intent i = new android.content.Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void download(PluginCall call) {
        String url = call.getString("url");
        String name = call.getString("name");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
            if (url.contains("4pda.")) cookie = (cookie == null || cookie.isEmpty() ? "ngx_mb=0" : cookie + "; ngx_mb=0");
            if (cookie != null && !cookie.isEmpty()) r.addRequestHeader("Cookie", cookie);
            r.addRequestHeader("User-Agent", url.contains("4pda.") ? UA_DESKTOP : UA);
            if (url.contains("4pda.")) r.addRequestHeader("Referer", "https://4pda.to/forum/");
            if (name == null || name.isEmpty()) name = URLUtil.guessFileName(url, null, null);
            r.setTitle(name);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.allowScanningByMediaScanner();
            DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) dm.enqueue(r);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Браузерный UA, как у ForPDA — чтобы 4pda не отдавал bot-заглушку
    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
    private static final String UA_DESKTOP = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    // ==== Свой докачивающий загрузчик (Range-резюме, авторизация куками) ====
    static class Dl {
        long id; String url, name, referer; java.io.File file;
        volatile long total = -1, done = 0;
        volatile int status = 2; // 2=running,4=paused,8=done,16=error
        volatile boolean pauseReq = false, cancelReq = false;
        String error = "";
    }
    private static final java.util.Map<Long, Dl> DLS = new java.util.concurrent.ConcurrentHashMap<>();
    private static long DL_SEQ = 1;
    private static boolean DL_CH = false;

    private void ensureChannel() {
        if (DL_CH) return;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                android.app.NotificationChannel ch = new android.app.NotificationChannel("dl", "Загрузки", android.app.NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(ch);
            }
            DL_CH = true;
        } catch (Exception ignored) {}
    }
    private void notif(Dl d, boolean done) {
        try {
            ensureChannel();
            android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            android.app.Notification.Builder b;
            if (android.os.Build.VERSION.SDK_INT >= 26) b = new android.app.Notification.Builder(getContext(), "dl");
            else b = new android.app.Notification.Builder(getContext());
            b.setContentTitle(d.name).setOnlyAlertOnce(true);
            if (done) { b.setSmallIcon(android.R.drawable.stat_sys_download_done).setContentText("Готово").setProgress(0, 0, false).setAutoCancel(true); }
            else if (d.status == 16) { b.setSmallIcon(android.R.drawable.stat_notify_error).setContentText("Ошибка загрузки").setProgress(0, 0, false); }
            else { b.setSmallIcon(android.R.drawable.stat_sys_download); int pct = d.total > 0 ? (int) (d.done * 100 / d.total) : 0; b.setContentText(pct + "%").setProgress(100, pct, d.total <= 0); }
            nm.notify((int) d.id + 9000, b.build());
        } catch (Exception ignored) {}
    }

    private void runDl(final Dl d) {
        java.net.HttpURLConnection c = null; java.io.RandomAccessFile out = null; java.io.InputStream in = null;
        try {
            long offset = d.file.exists() ? d.file.length() : 0;
            String url = d.url.trim().replace(" ", "%20").replace("[", "%5B").replace("]", "%5D").replace("|", "%7C");
            if (url.startsWith("//")) url = "https:" + url;
            else if (url.startsWith("/")) url = "https://4pda.to" + url;
            int redirects = 0; int code = 0;
            while (true) {
                c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(20000); c.setReadTimeout(40000);
                String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
                if (url.contains("4pda.")) cookie = (cookie == null || cookie.isEmpty() ? "ngx_mb=0" : cookie + "; ngx_mb=0");
                if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
                c.setRequestProperty("User-Agent", url.contains("4pda.") ? UA_DESKTOP : UA);
                if (url.contains("4pda.")) c.setRequestProperty("Referer", (d.referer != null && !d.referer.isEmpty()) ? d.referer : "https://4pda.to/forum/");
                c.setRequestProperty("Accept", "*/*");
                c.setRequestProperty("Accept-Language", "ru,en;q=0.9");
                if (offset > 0) c.setRequestProperty("Range", "bytes=" + offset + "-");
                c.connect();
                code = c.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String loc = c.getHeaderField("Location");
                    try { c.disconnect(); } catch (Exception ignored) {}
                    if (loc == null || ++redirects > 8) throw new Exception("redirect loop");
                    if (loc.startsWith("//")) { loc = "https:" + loc; }
                    else if (loc.startsWith("/")) { java.net.URL b = new java.net.URL(url); loc = b.getProtocol() + "://" + b.getHost() + loc; }
                    url = loc; continue;
                }
                break;
            }
            if (code >= 400) throw new Exception("HTTP " + code);
            boolean append = (code == 206 && offset > 0);
            long len = c.getContentLength();
            if (append) d.total = offset + (len > 0 ? len : 0); else { d.total = (len > 0 ? len : -1); offset = 0; }
            out = new java.io.RandomAccessFile(d.file, "rw");
            if (append) out.seek(offset); else out.setLength(0);
            d.done = offset; d.status = 2;
            in = c.getInputStream();
            byte[] buf = new byte[65536]; int n; long lastN = 0;
            while ((n = in.read(buf)) != -1) {
                if (d.cancelReq) { try { d.file.delete(); } catch (Exception ignored) {} DLS.remove(d.id); try { ((android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancel((int) d.id + 9000); } catch (Exception ignored) {} return; }
                if (d.pauseReq) { d.status = 4; notif(d, false); return; }
                out.write(buf, 0, n); d.done += n;
                if (d.done - lastN > 262144) { lastN = d.done; notif(d, false); }
            }
            d.status = 8; notif(d, true);
        } catch (Exception e) {
            d.error = String.valueOf(e.getMessage()); d.status = 16; notif(d, false);
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
            try { if (c != null) c.disconnect(); } catch (Exception ignored) {}
        }
    }
    private void startThread(final Dl d) {
        d.status = 2; d.pauseReq = false;
        new Thread(new Runnable() { public void run() {
            int attempts = 0;
            while (attempts < 4) {
                attempts++;
                runDl(d);
                if (d.status != 16 || d.cancelReq || d.pauseReq) break;
                try { Thread.sleep(1500); } catch (InterruptedException e) { break; }
                if (d.cancelReq || d.pauseReq) break;
                d.status = 2;
            }
        } }).start();
    }

    @PluginMethod
    public void requestPerms(PluginCall call) {
        try {
            android.app.Activity act = getActivity();
            java.util.List<String> req = new java.util.ArrayList<>();
            if (android.os.Build.VERSION.SDK_INT >= 33) { req.add("android.permission.POST_NOTIFICATIONS"); req.add("android.permission.READ_MEDIA_IMAGES"); req.add("android.permission.READ_MEDIA_VIDEO"); req.add("android.permission.READ_MEDIA_AUDIO"); }
            else if (android.os.Build.VERSION.SDK_INT >= 29) { req.add(android.Manifest.permission.READ_EXTERNAL_STORAGE); }
            else { req.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE); req.add(android.Manifest.permission.READ_EXTERNAL_STORAGE); }
            if (act != null && !req.isEmpty()) {
                java.util.List<String> need = new java.util.ArrayList<>();
                for (String p : req) { try { if (act.checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) need.add(p); } catch (Exception ignored) {} }
                if (!need.isEmpty()) act.requestPermissions(need.toArray(new String[0]), 55);
            }
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }
    @PluginMethod
    public void requestAllFiles(PluginCall call) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
                android.content.Intent i = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
            call.resolve();
        } catch (Exception e) {
            try { android.content.Intent i2 = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION); i2.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i2); call.resolve(); } catch (Exception e2) { call.reject(String.valueOf(e2.getMessage())); }
        }
    }
    @PluginMethod
    public void requestInstall(PluginCall call) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26 && !getContext().getPackageManager().canRequestPackageInstalls()) {
                android.content.Intent i = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void checkSignature(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("match", true);
        try {
            String path = call.getString("path");
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            if (path == null || !path.toLowerCase().endsWith(".apk")) { ret.put("unknown", true); call.resolve(); return; }
            android.content.pm.PackageInfo fpi = pm.getPackageArchiveInfo(path, android.content.pm.PackageManager.GET_SIGNATURES);
            if (fpi == null || fpi.signatures == null || fpi.signatures.length == 0) { ret.put("unknown", true); call.resolve(); return; }
            String pkg = fpi.packageName;
            String fileSig = Integer.toHexString(fpi.signatures[0].hashCode());
            ret.put("package", pkg);
            String instSig = null;
            try {
                android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNATURES);
                if (pi.signatures != null && pi.signatures.length > 0) instSig = Integer.toHexString(pi.signatures[0].hashCode());
            } catch (Exception notInstalled) { ret.put("installed", false); call.resolve(); return; }
            ret.put("installed", true);
            ret.put("match", instSig != null && instSig.equals(fileSig));
            call.resolve();
        } catch (Exception e) { call.resolve(); }
    }

    @PluginMethod
    public void dlStart(PluginCall call) {
        String url = call.getString("url"); String name = call.getString("name");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        Dl d = new Dl();
        synchronized (AppsPlugin.class) { d.id = DL_SEQ++; }
        d.url = url;
        d.referer = call.getString("referer", "");
        d.name = (name == null || name.isEmpty()) ? URLUtil.guessFileName(url, null, null) : name;
        java.io.File dir = getContext().getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getContext().getExternalFilesDir(null);
        if (dir != null && !dir.exists()) dir.mkdirs();
        d.file = new java.io.File(dir, d.name);
        try { if (d.file.exists()) d.file.delete(); } catch (Exception ignored) {}
        DLS.put(d.id, d);
        if (d.url.contains("4pda.")) startViaWebView(d); else startThread(d);
        JSObject r = new JSObject(); r.put("id", d.id); call.resolve(r);
    }
    private void startViaWebView(final Dl d) {
        final android.app.Activity act = getActivity();
        if (act == null) { startThread(d); return; }
        act.runOnUiThread(new Runnable() { public void run() {
            try {
                final android.webkit.WebView wv = new android.webkit.WebView(getContext());
                android.webkit.WebSettings s = wv.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setUserAgentString(UA_DESKTOP);
                android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/");
                final boolean[] done = {false};
                final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                wv.setDownloadListener(new android.webkit.DownloadListener() {
                    public void onDownloadStart(String url2, String ua, String cd, String mime, long len) {
                        if (done[0]) return; done[0] = true;
                        d.url = url2;
                        if ((d.name == null || d.name.isEmpty()) && cd != null) { try { d.name = URLUtil.guessFileName(url2, cd, mime); } catch (Exception ignored) {} }
                        try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                        startThread(d);
                        h.postDelayed(new Runnable() { public void run() { try { wv.destroy(); } catch (Exception ignored) {} } }, 500);
                    }
                });
                wv.setWebViewClient(new android.webkit.WebViewClient() {
                    @Override public void onReceivedError(android.webkit.WebView v, int ec, String de, String fu) {
                        if (!done[0]) { done[0] = true; startThread(d); try { wv.destroy(); } catch (Exception ignored) {} }
                    }
                });
                wv.loadUrl(d.url, java.util.Collections.singletonMap("Referer", (d.referer != null && !d.referer.isEmpty()) ? d.referer : "https://4pda.to/forum/"));
                h.postDelayed(new Runnable() { public void run() { if (!done[0]) { done[0] = true; startThread(d); try { wv.destroy(); } catch (Exception ignored) {} } } }, 25000);
            } catch (Exception e) { startThread(d); }
        } });
    }
    @PluginMethod
    public void dlStatus(PluginCall call) {
        JSArray arr = new JSArray();
        for (Dl d : DLS.values()) {
            JSObject o = new JSObject();
            o.put("id", d.id); o.put("title", d.name); o.put("status", d.status);
            o.put("total", d.total); o.put("done", d.done);
            o.put("uri", d.file != null ? ("file://" + d.file.getAbsolutePath()) : "");
            o.put("src", d.url); o.put("date", d.file != null && d.file.exists() ? d.file.lastModified() : 0);
            o.put("error", d.error == null ? "" : d.error);
            o.put("error", d.error == null ? "" : d.error);
            arr.put(o);
        }
        JSObject ret = new JSObject(); ret.put("items", arr); call.resolve(ret);
    }
    @PluginMethod
    public void dlPause(PluginCall call) { Dl d = DLS.get(call.getLong("id", 0L)); if (d != null) d.pauseReq = true; call.resolve(); }
    @PluginMethod
    public void dlResume(PluginCall call) { Dl d = DLS.get(call.getLong("id", 0L)); if (d != null && (d.status == 4 || d.status == 16)) startThread(d); call.resolve(); }
    @PluginMethod
    public void dlCancel(PluginCall call) {
        Dl d = DLS.get(call.getLong("id", 0L));
        boolean delFile = call.getBoolean("deleteFile", true);
        if (d != null) {
            d.cancelReq = true; d.pauseReq = true;
            DLS.remove(d.id);
            if (delFile && d.file != null) { try { d.file.delete(); } catch (Exception ignored) {} }
            try { ((android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancel((int) d.id + 9000); } catch (Exception ignored) {}
        }
        call.resolve();
    }


    // Нативный попап с постом (как dlg_post_view у ag4pda): диалог с WebView, грузит пост и прокручивает к нему.
    @PluginMethod
    public void showPostView(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        final android.app.Activity act = getActivity();
        if (act == null) { call.reject("no activity"); return; }
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    android.widget.FrameLayout root = new android.widget.FrameLayout(act);
                    root.setBackgroundColor(0xFF1C1C1C);
                    final android.webkit.WebView wv = new android.webkit.WebView(act);
                    android.webkit.WebSettings s = wv.getSettings();
                    try { s.setUserAgentString("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"); } catch (Exception ignored) {}
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    s.setUseWideViewPort(true);
                    s.setLoadWithOverviewMode(true);
                    s.setSupportZoom(true);
                    s.setBuiltInZoomControls(true);
                    s.setDisplayZoomControls(false);
                    android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                    try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; domain=4pda.to; path=/"); android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/"); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                    final android.widget.ProgressBar pb = new android.widget.ProgressBar(act);
                    android.widget.FrameLayout.LayoutParams pbp = new android.widget.FrameLayout.LayoutParams(140, 140);
                    pbp.gravity = android.view.Gravity.CENTER;
                    String pid = null;
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:pid=|[?&]p=|entry)(\\d+)").matcher(url);
                    if (m.find()) pid = m.group(1);
                    final String fpid = pid;
                    wv.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override public void onPageFinished(android.webkit.WebView v, String u) {
                            pb.setVisibility(android.view.View.GONE);
                            if (fpid != null) v.evaluateJavascript("(function(){try{var e=document.getElementsByName('entry" + fpid + "')[0]||document.getElementById('entry" + fpid + "')||document.getElementById('p" + fpid + "');if(e){e.scrollIntoView(true);window.scrollBy(0,-10);}}catch(x){}})()", null);
                        }
                    });
                    root.addView(wv, new android.widget.FrameLayout.LayoutParams(-1, -1));
                    root.addView(pb, pbp);
                    wv.loadUrl(url);
                    android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(act)
                            .setView(root)
                            .setNegativeButton("Закрыть", new android.content.DialogInterface.OnClickListener() {
                                @Override public void onClick(android.content.DialogInterface d, int w) { d.dismiss(); }
                            })
                            .setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                                @Override public void onDismiss(android.content.DialogInterface d) { try { wv.destroy(); } catch (Exception ignored) {} }
                            })
                            .create();
                    dlg.show();
                    android.view.WindowManager.LayoutParams lp = dlg.getWindow().getAttributes();
                    lp.height = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.82);
                    lp.width = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.94);
                    dlg.getWindow().setAttributes(lp);
                } catch (Throwable e) { }
                call.resolve(new JSObject());
            }
        });
    }

    // Загрузить страницу через НАСТОЯЩИЙ WebView (проходит анти-бот/Cloudflare 4pda) и вернуть HTML.
    @PluginMethod
    public void webGet(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(new Runnable() {
            @Override public void run() {
                try {
                    final android.webkit.WebView wv = new android.webkit.WebView(getContext());
                    android.webkit.WebSettings s = wv.getSettings();
                    try { s.setUserAgentString("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"); } catch (Exception ignored) {}
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                    try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; domain=4pda.to; path=/"); android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/"); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                    final boolean[] done = { false };
                    final int[] tries = { 0 };
                    final Runnable[] poll = new Runnable[1];
                    poll[0] = new Runnable() {
                        @Override public void run() {
                            if (done[0]) return;
                            wv.evaluateJavascript("(function(){return document.documentElement.outerHTML})()", new android.webkit.ValueCallback<String>() {
                                @Override public void onReceiveValue(String value) {
                                    if (done[0]) return;
                                    String html = jsUnquote(value);
                                    tries[0]++;
                                    boolean challenge = html.contains("Just a moment") || html.contains("challenge-platform")
                                            || html.contains("cf-browser-verification") || html.contains("_cf_chl")
                                            || html.contains("Checking your browser") || html.length() < 800;
                                    boolean realCaptcha = html.contains("g-recaptcha") || html.contains("recaptcha/api") || html.contains("hcaptcha");
                                    if (!challenge || realCaptcha || tries[0] >= 20) {
                                        done[0] = true;
                                        JSObject ret = new JSObject();
                                        ret.put("status", 200);
                                        ret.put("url", url);
                                        // капчей считаем ТОЛЬКО настоящую recaptcha/hcaptcha, а не интерстишл Cloudflare
                                        ret.put("captcha", realCaptcha);
                                        ret.put("body", html);
                                        call.resolve(ret);
                                        try { wv.destroy(); } catch (Exception ignored) {}
                                    } else {
                                        h.postDelayed(poll[0], 1500);
                                    }
                                }
                            });
                        }
                    };
                    wv.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override public void onPageFinished(android.webkit.WebView view, String u) {
                            if (done[0]) return;
                            h.postDelayed(poll[0], 1000);
                        }
                    });
                    h.postDelayed(new Runnable() { @Override public void run() {
                        if (!done[0]) { done[0] = true; try { wv.destroy(); } catch (Exception ignored) {} call.reject("timeout"); }
                    } }, 45000);
                    wv.loadUrl(url);
                } catch (Throwable e) { call.reject(String.valueOf(e.getMessage())); }
            }
        });
    }

    private String jsUnquote(String v) {
        if (v == null) return "";
        try { return new org.json.JSONArray("[" + v + "]").getString(0); } catch (Exception e) { return v; }
    }

    // Нативный попап с постом 4pda в WebView (как dlg_post_view у ag4pda): грузит URL поста,
    // делит cookie с логином (проходит Cloudflare), показывает именно этот пост.
    @PluginMethod
    public void saveText(PluginCall call) {
        String name = call.getString("name", "debug.txt");
        String text = call.getString("text", "");
        try {
            java.io.File dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (dir != null && !dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(text.getBytes("UTF-8"));
            fos.close();
            JSObject ret = new JSObject();
            ret.put("path", f.getAbsolutePath());
            call.resolve(ret);
        } catch (Exception e) {
            // запасной путь: app-specific dir (без разрешений)
            try {
                java.io.File dir2 = getContext().getExternalFilesDir(null);
                java.io.File f2 = new java.io.File(dir2, name);
                java.io.FileOutputStream fos2 = new java.io.FileOutputStream(f2);
                fos2.write(text.getBytes("UTF-8"));
                fos2.close();
                JSObject ret = new JSObject();
                ret.put("path", f2.getAbsolutePath());
                call.resolve(ret);
            } catch (Exception e2) { call.reject(String.valueOf(e2.getMessage())); }
        }
    }

    @PluginMethod
    public void openPostView(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        String p = "";
        try { java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:pid=|entry)(\\d+)").matcher(url); if (m.find()) p = m.group(1); } catch (Exception ignored) {}
        final String pid = p;
        final android.app.Activity act = getActivity();
        if (act == null) { call.reject("no activity"); return; }
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    final android.app.Dialog dlg = new android.app.Dialog(act);
                    if (dlg.getWindow() != null) dlg.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
                    android.widget.FrameLayout root = new android.widget.FrameLayout(act);
                    root.setBackgroundColor(0xFF1C140C);
                    final android.webkit.WebView wv = new android.webkit.WebView(act);
                    android.webkit.WebSettings s = wv.getSettings();
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    s.setUseWideViewPort(true);
                    s.setLoadWithOverviewMode(true);
                    s.setBuiltInZoomControls(true);
                    s.setDisplayZoomControls(false);
                    wv.setBackgroundColor(0xFF1C140C);
                    android.webkit.CookieManager.getInstance().setAcceptCookie(true);
                    try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; domain=4pda.to; path=/"); android.webkit.CookieManager.getInstance().setCookie("https://4pda.to", "ngx_mb=0; path=/"); } catch (Exception ignored) {}
                    try { android.webkit.CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                    final android.widget.ProgressBar pb = new android.widget.ProgressBar(act);
                    android.widget.FrameLayout.LayoutParams plp = new android.widget.FrameLayout.LayoutParams(-2, -2);
                    plp.gravity = android.view.Gravity.CENTER;
                    final String js = "(function(){try{"
                        + "if(document.body.getAttribute('data-cln'))return 'true';"
                        + "var pid='" + pid + "';var body=null;"
                        + "if(pid){var anc=document.querySelector('a[name=\"entry'+pid+'\"]')||document.getElementById('entry'+pid)||document.getElementById('p'+pid)||document.querySelector('[data-post=\"'+pid+'\"]');"
                        + "if(anc){var bs=document.querySelectorAll('.post_body,.postcolor');for(var j=0;j<bs.length;j++){if(anc.compareDocumentPosition(bs[j])&4){body=bs[j];break;}}"
                        + "if(!body){var e=anc;for(var i=0;i<12&&e&&!body;i++){if(e.querySelector)body=e.querySelector('.post_body,.postcolor');if(!body)e=e.parentElement;}}}}"
                        + "if(!body){body=document.querySelector('.post_body,.postcolor');}"
                        + "if(!body)return 'wait';"
                        + "var h=body.innerHTML;document.body.innerHTML=h;document.body.setAttribute('data-cln','1');"
                        + "document.body.setAttribute('style','margin:0;padding:14px;background:#1c140c;color:#d2d2d2;font:15px/1.55 -apple-system,Roboto,Arial,sans-serif;word-wrap:break-word;overflow-wrap:break-word');"
                        + "var st=document.createElement('style');st.innerHTML='a{color:#5ab0d8;text-decoration:none}img{max-width:100%;height:auto;border-radius:6px}b,strong{color:#ededed}table{max-width:100%}';document.head.appendChild(st);"
                        + "return 'true';}catch(e){return 'err';}})()";
                    final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                    final int[] tries = {0};
                    final Runnable[] poll = new Runnable[1];
                    poll[0] = new Runnable() {
                        @Override public void run() {
                            tries[0]++;
                            wv.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                                @Override public void onReceiveValue(String v) {
                                    boolean done = v != null && v.indexOf("true") >= 0;
                                    if (done) pb.setVisibility(android.view.View.GONE);
                                    if (!done && tries[0] < 30) h.postDelayed(poll[0], 1000);
                                }
                            });
                        }
                    };
                    wv.setWebViewClient(new android.webkit.WebViewClient() {
                        @Override public void onPageFinished(android.webkit.WebView view, String u) { h.removeCallbacks(poll[0]); h.postDelayed(poll[0], 400); }
                    });
                    wv.setWebChromeClient(new android.webkit.WebChromeClient() {
                        @Override public void onProgressChanged(android.webkit.WebView view, int prog) { if (prog >= 100) h.postDelayed(poll[0], 300); }
                    });
                    root.addView(wv, new android.widget.FrameLayout.LayoutParams(-1, -1));
                    root.addView(pb, plp);
                    dlg.setContentView(root);
                    if (dlg.getWindow() != null) {
                        int dw = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.94);
                        int dh = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.82);
                        dlg.getWindow().setLayout(dw, dh);
                        dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF1C140C));
                    }
                    dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                        @Override public void onDismiss(android.content.DialogInterface d) { try { wv.destroy(); } catch (Exception ignored) {} }
                    });
                    wv.loadUrl(url);
                    dlg.show();
                    call.resolve();
                } catch (Throwable e) { call.reject(String.valueOf(e.getMessage())); }
            }
        });
    }

    // Нативный GET страницы 4pda с браузерным UA + cookie из WebView-логина.
    // Возвращает body (в правильной кодировке), status, финальный url и флаг captcha.
    @PluginMethod
    public void httpGet(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || url.isEmpty()) { call.reject("no url"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                java.net.HttpURLConnection c = null;
                try {
                    java.net.URL u = new java.net.URL(url);
                    c = (java.net.HttpURLConnection) u.openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", url.contains("4pda.") ? UA_DESKTOP : UA);
                    c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                    c.setRequestProperty("Accept-Language", "ru,en;q=0.9");
                    c.setRequestProperty("Accept-Encoding", "gzip, deflate");
                    if (url.contains("4pda.")) c.setRequestProperty("Referer", "https://4pda.to/forum/");
                    String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
                    if (url.contains("4pda.")) cookie = (cookie == null || cookie.isEmpty() ? "ngx_mb=0" : cookie + "; ngx_mb=0");
                    if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);

                    int code = c.getResponseCode();
                    java.io.InputStream is = (code >= 400) ? c.getErrorStream() : c.getInputStream();
                    if (is == null) is = c.getInputStream();
                    String enc = c.getContentEncoding();
                    if (enc != null && enc.toLowerCase().contains("gzip")) is = new java.util.zip.GZIPInputStream(is);
                    else if (enc != null && enc.toLowerCase().contains("deflate")) is = new java.util.zip.InflaterInputStream(is);

                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n;
                    while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
                    is.close();
                    byte[] raw = bos.toByteArray();

                    // кодировка: форум 4pda — windows-1251; определяем по Content-Type / meta
                    String charset = "UTF-8";
                    String ct = c.getContentType();
                    String head = new String(raw, 0, Math.min(raw.length, 2048), java.nio.charset.StandardCharsets.ISO_8859_1).toLowerCase();
                    if ((ct != null && (ct.toLowerCase().contains("1251") || ct.toLowerCase().contains("windows-1251")))
                            || head.contains("charset=windows-1251") || head.contains("charset=cp1251")) {
                        charset = "windows-1251";
                    }
                    String body = new String(raw, charset);
                    boolean captcha = body.contains("g-recaptcha") || body.contains("recaptcha/api") || body.contains("www.google.com/recaptcha");

                    JSObject ret = new JSObject();
                    ret.put("status", code);
                    ret.put("url", c.getURL().toString());
                    ret.put("captcha", captcha);
                    ret.put("charset", charset);
                    ret.put("body", body);
                    call.resolve(ret);
                } catch (Exception e) {
                    call.reject(e.getMessage());
                } finally {
                    if (c != null) try { c.disconnect(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    // ---- иконки → data:image/png;base64 (уменьшаем до 144px) ----

    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 96) {
            float sc = 96f / mx;
            b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try {
            if (d instanceof android.graphics.drawable.BitmapDrawable) {
                Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap();
                if (bm != null) return bm;
            }
        } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        return b;
    }
}
