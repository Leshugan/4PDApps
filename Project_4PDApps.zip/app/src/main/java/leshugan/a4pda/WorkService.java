package leshugan.a4pda;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Фоновая сверка обновлений с сервером App&Game (без открытого приложения). Пишет в базу и уведомляет числом. */
public class WorkService extends Service {
    private static final String CH = "updates";

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> { runCheck(this); stopSelf(); }).start();
        return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent intent) { return null;}

    /** Общая логика фоновой сверки — зовут и служба, и периодическая задача. */
    public static void runCheck(android.content.Context ctx) {
        try {
            Store store = Store.get(ctx);
            AgBackup.sync(ctx, store);
            AgServer ag = new AgServer(ctx);
            List<AppItem> apps = AppItem.scanInstalled(ctx, false);
            Map<String, Store.Row> known = store.loadAll();
            List<String> pkgs = new ArrayList<>();
            for (AppItem a : apps) pkgs.add(a.pkg);

            int updates = 0;
            for (int i = 0; i < pkgs.size(); i += 40) {
                List<String> part = pkgs.subList(i, Math.min(pkgs.size(), i + 40));
                Map<String, JSONObject> got = ag.getAppInfo(part);
                for (Map.Entry<String, JSONObject> e : got.entrySet()) {
                    JSONObject x = e.getValue();
                    String pkg = e.getKey();
                    long topic = x.optLong("topic_id", 0);
                    String ver = x.optString("ver", "");
                    String upd = x.optString("forum_update", "");
                    String desc = x.optString("description", "");
                    String date = "";
                    if (upd.length() == 8) date = upd.substring(6, 8) + "." + upd.substring(4, 6) + "." + upd.substring(2, 4);
                    store.applyInfo(pkg, topic, ver, date, desc, x.optString("group_name", ""), false);
                }
            }
            // посчитать обновления по свежей базе
            Map<String, Store.Row> fresh = store.loadAll();
            for (AppItem a : apps) {
                Store.Row r = fresh.get(a.pkg);
                if (r == null) continue;
                boolean hiddenAll = (r.hiddenUpd & 1) != 0;
                if (!hiddenAll && r.topicId > 0 && r.forumVer != null && !r.forumVer.isEmpty()
                        && Ver.cmp(r.forumVer, a.versionInstalled) > 0 && (r.hiddenUpd & 2) == 0) updates++;
            }
            Prefs.setLastCheck(ctx, System.currentTimeMillis());
            if (updates > 0) notify(ctx, updates);
        } catch (Throwable ignored) {}
    }

    private static void notify(android.content.Context ctx, int n) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Обновления", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(ctx, MainActivity.class);
        int flag = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, flag);
        Notification.Builder nb = (Build.VERSION.SDK_INT >= 26) ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
        nb.setContentTitle("4PDApps")
          .setContentText("Доступно обновлений: " + n)
          .setSmallIcon(android.R.drawable.stat_sys_download_done)
          .setAutoCancel(true)
          .setContentIntent(pi);
        nm.notify(1, nb.build());
    }
}
