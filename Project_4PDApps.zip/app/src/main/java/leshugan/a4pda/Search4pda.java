package leshugan.a4pda;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Поиск тем на 4pda (гостевой). Возвращает пары «номер темы → заголовок». */
public final class Search4pda {
    public static class Hit { public long topicId; public String title; public Hit(long t, String s){topicId=t;title=s;} }

    private static final Pattern LINK = Pattern.compile(
            "showtopic=(\\d+)[^\"']*[\"'][^>]*>([^<]{2,160})</a>", Pattern.CASE_INSENSITIVE);

    public static List<Hit> search(String query) {
        Map<Long, String> found = new LinkedHashMap<>();
        try {
            String url = "https://4pda.to/forum/index.php?act=search&source=all&result=topics&query="
                    + java.net.URLEncoder.encode(query, "windows-1251");
            String html = Net.getText(url);
            Matcher m = LINK.matcher(html);
            while (m.find()) {
                long id = Long.parseLong(m.group(1));
                String title = clean(m.group(2));
                if (title.isEmpty()) continue;
                if (!found.containsKey(id)) found.put(id, title);
                if (found.size() >= 40) break;
            }
        } catch (Throwable ignored) {}
        List<Hit> out = new ArrayList<>();
        for (Map.Entry<Long, String> e : found.entrySet()) out.add(new Hit(e.getKey(), e.getValue()));
        return out;
    }

    private static String clean(String s) {
        return s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&laquo;", "«").replace("&raquo;", "»").replace("&mdash;", "—")
                .replace("&nbsp;", " ").trim();
    }
}
