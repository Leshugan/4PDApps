package leshugan.a4pda;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Окно поста — как в IA: тело сообщения без обвязки форума, в цветах текущей темы;
 *  тап по ссылке на apk предлагает скачать. */
public class PostActivity extends Activity {
    public static void open(Context c, String url, String title) {
        Intent i = new Intent(c, PostActivity.class);
        i.putExtra("url", url); i.putExtra("title", title);
        c.startActivity(i);
    }

    private WebView web;
    private TextView status;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private String url = "", title = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        url = getIntent().getStringExtra("url");
        title = getIntent().getStringExtra("title");
        setContentView(buildUi());
        load();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        TextView back = new TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView t = new TextView(this);
        t.setText(title == null || title.isEmpty() ? "Сообщение" : title);
        t.setTextColor(Theme.TEXT); t.setTextSize(18);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setMaxLines(1); t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView open = new TextView(this);
        open.setText("На 4pda"); open.setTextColor(Theme.ACC); open.setTextSize(13.5f);
        open.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) {} });
        bar.addView(open);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56)));

        status = new TextView(this);
        status.setTextColor(Theme.SUB); status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        status.setText("Загрузка…");
        root.addView(status);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(false);
        web.setBackgroundColor(Theme.BG);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { return handleLink(u); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleLink(r.getUrl().toString());
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private boolean handleLink(String u) {
        if (u == null) return false;
        if (u.matches("(?i).*(/dl/post/|act=attach|\\.apk(\\?|#|$)).*")) { askDownload(u); return true; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Throwable ignored) {}
        return true;
    }

    private void askDownload(String fileUrl) {
        String name = fileUrl;
        int i = name.indexOf('?'); if (i > 0) name = name.substring(0, i);
        int j = name.lastIndexOf('/');
        final String fname = j >= 0 ? name.substring(j + 1) : name;
        new AlertDialog.Builder(this)
                .setTitle("Начать закачку?")
                .setMessage("Имя файла: " + fname)
                .setPositiveButton("Скачать", (d, w) -> {
                    try {
                        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(fileUrl));
                        req.setTitle(fname);
                        String ck = LoginActivity.cookies();
                        if (!ck.isEmpty()) req.addRequestHeader("Cookie", ck);
                        req.addRequestHeader("Referer", url);
                        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fname);
                        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                        if (dm != null) { dm.enqueue(req); Toast.makeText(this, "Закачка началась", Toast.LENGTH_SHORT).show(); }
                    } catch (Throwable ignored) {}
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void load() {
        work.execute(() -> {
            String html = Net.getText(url);
            String body = extractPost(html, url);
            String page = wrap(body);
            ui.post(() -> {
                status.setVisibility(body.isEmpty() ? View.VISIBLE : View.GONE);
                if (body.isEmpty()) status.setText("Не удалось прочитать сообщение");
                web.loadDataWithBaseURL("https://4pda.to/", page, "text/html", "UTF-8", null);
            });
        });
    }

    /** Тело нужного поста: по якорю entry<pid>, иначе первый .post_body/.postcolor — как в IA. */
    private static String extractPost(String html, String url) {
        if (html == null || html.isEmpty()) return "";
        String pid = find(url, "(?:pid=|entry|[?&]p=)(\\d+)");
        String cut = html;
        if (!pid.isEmpty()) {
            int a = html.indexOf("entry" + pid);
            if (a > 0) cut = html.substring(a);
        }
        String body = between(cut, "class=\"post_body\"", "</div>");
        if (body.isEmpty()) body = between(cut, "class=\"postcolor\"", "</div>");
        if (body.isEmpty()) body = between(html, "class=\"post_body\"", "</div>");
        if (body.isEmpty()) return "";
        int gt = body.indexOf('>');
        if (gt >= 0) body = body.substring(gt + 1);
        body = body.replaceAll("(?is)<script.*?</script>", "")
                   .replaceAll("(?is)Сообщение отредактировал.*$", "");
        return body;
    }

    private static String between(String s, String start, String end) {
        int a = s.indexOf(start);
        if (a < 0) return "";
        int b = s.indexOf(end, a);
        return b < 0 ? s.substring(a) : s.substring(a, b);
    }
    private static String find(String s, String re) {
        Matcher m = Pattern.compile(re).matcher(s == null ? "" : s);
        return m.find() ? m.group(1) : "";
    }

    /** Обёртка со стилями текущей темы — как чистый пост в IA. */
    private String wrap(String inner) {
        String bg = hex(Theme.BG), tx = hex(Theme.TEXT), a = hex(Theme.ACC), sub = hex(Theme.SUB),
               line = hex(Theme.BORDER), box = hex(Theme.CARD);
        return "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;padding:14px;background:" + bg + ";color:" + tx
                + ";font:15px/1.55 -apple-system,Roboto,Arial,sans-serif;word-wrap:break-word;overflow-wrap:break-word}"
                + "a{color:" + a + ";text-decoration:none}img{max-width:100%;height:auto;border-radius:6px}"
                + "b,strong{color:" + tx + "}"
                + ".post-block,.spoiler{border:1px solid " + line + ";border-radius:8px;margin:8px 0;padding:8px 10px;background:" + box + "}"
                + ".block-title,.spoiler-title,.title{font-weight:700;color:" + tx + "}"
                + "hr{border:none;border-top:1px solid " + line + "}"
                + "small,.edit{color:" + sub + "}</style></head><body>" + inner + "</body></html>";
    }

    private static String hex(int c) { return String.format("#%06X", 0xFFFFFF & c); }
}
