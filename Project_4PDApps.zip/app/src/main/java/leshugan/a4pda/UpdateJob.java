package leshugan.a4pda;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** Периодическая фоновая проверка обновлений (~раз в 6 часов), переживает перезагрузку. */
public class UpdateJob extends JobService {
    private static final int ID = 4201;

    public static void schedule(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            JobInfo.Builder b = new JobInfo.Builder(ID, new ComponentName(c, UpdateJob.class))
                    .setPeriodic(6 * 60 * 60 * 1000L)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true);
            js.schedule(b.build());
        } catch (Throwable ignored) {}
    }

    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> { WorkService.runCheck(this); jobFinished(params, false); }).start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return false; }
}
