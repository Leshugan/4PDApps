package leshugan.a4pda;

import android.content.Context;

import org.json.JSONObject;

import java.util.Iterator;

/** Готовая база связей с GitHub (ag4pda.json, её наполняет робот) — как agGithubLoad в вебной версии.
 *  Даёт пакет→тема/версия/описание МГНОВЕННО, даже если сервер App&Game молчит. Раз в 12 часов. */
public final class AgBackup {
    private static final String URL = "https://raw.githubusercontent.com/Leshugan/4PDApps/main/ag4pda.json";
    private static final long PERIOD = 12L * 60 * 60 * 1000;

    /** Скачать (не чаще раза в 12ч) и применить к базе. Возвращает true, если что-то применили. */
    public static boolean sync(Context ctx, Store store) {
        android.content.SharedPreferences sp = ctx.getSharedPreferences("t4", Context.MODE_PRIVATE);
        long last = sp.getLong("aggh", 0);
        if (System.currentTimeMillis() - last < PERIOD) return false;
        try {
            String s = Net.getText(URL);
            if (s == null || s.length() < 50) return false;
            JSONObject root = new JSONObject(s);
            JSONObject apps = root.optJSONObject("apps");
            if (apps == null) return false;
            int applied = 0;
            Iterator<String> it = apps.keys();
            while (it.hasNext()) {
                String pkg = it.next();
                JSONObject x = apps.optJSONObject(pkg);
                if (x == null) continue;
                long topic = x.optLong("topicId", x.optLong("topic_id", 0));
                if (topic <= 0) continue;
                String ver = x.optString("ver", "");
                String desc = x.optString("description", x.optString("desc", ""));
                String grp = x.optString("group_name", x.optString("group", ""));
                String upd = x.optString("forum_update", "");
                String date = upd.length() == 8 ? upd.substring(6, 8) + "." + upd.substring(4, 6) + "." + upd.substring(2, 4) : "";
                store.applyInfo(pkg, topic, ver, date, desc, grp, false);
                applied++;
            }
            sp.edit().putLong("aggh", System.currentTimeMillis()).apply();
            return applied > 0;
        } catch (Throwable t) { return false; }
    }
}
