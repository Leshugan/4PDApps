package leshugan.a4pda;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Экран «Тема» — как в IA: строка «Системная» сверху, ниже сетка 2×N с превью каждой темы. */
public class ThemesActivity extends Activity {
    public static void open(Context c) { c.startActivity(new Intent(c, ThemesActivity.class)); }

    private LinearLayout grid;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        setContentView(buildUi());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        TextView back = new TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Тема"); title.setTextColor(Theme.TEXT); title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56)));

        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 20));
        sc.addView(body, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        String cur = Prefs.theme(this);

        // строка «Системная»
        LinearLayout sys = new LinearLayout(this);
        sys.setOrientation(LinearLayout.HORIZONTAL);
        sys.setGravity(Gravity.CENTER_VERTICAL);
        sys.setPadding(Ui.dp(this, 14), Ui.dp(this, 13), Ui.dp(this, 14), Ui.dp(this, 13));
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(Theme.CARD);
        sbg.setCornerRadius(Ui.dp(this, 12));
        sbg.setStroke(Math.max(1, Ui.dp(this, 1)), "system".equals(cur) ? Theme.ACC : Theme.BORDER);
        sys.setBackground(sbg);
        TextView st = new TextView(this);
        st.setText("Системная (как на телефоне)"); st.setTextColor(Theme.TEXT); st.setTextSize(15);
        sys.addView(st, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if ("system".equals(cur)) {
            TextView ck = new TextView(this);
            ck.setText("\u2713"); ck.setTextColor(Theme.ACC); ck.setTextSize(16);
            ck.setTypeface(null, android.graphics.Typeface.BOLD);
            sys.addView(ck);
        }
        sys.setOnClickListener(v -> choose("system"));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.bottomMargin = Ui.dp(this, 12);
        body.addView(sys, slp);

        // сетка тем 2 в ряд
        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        body.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout rowBox = null;
        for (int i = 0; i < Palettes.ALL.length; i++) {
            if (i % 2 == 0) {
                rowBox = new LinearLayout(this);
                rowBox.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.bottomMargin = Ui.dp(this, 12);
                grid.addView(rowBox, rlp);
            }
            View tile = tile(Palettes.ALL[i], Palettes.ALL[i].id.equals(cur));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i % 2 == 0) tlp.rightMargin = Ui.dp(this, 6); else tlp.leftMargin = Ui.dp(this, 6);
            rowBox.addView(tile, tlp);
        }
        return root;
    }

    private void choose(String id) {
        Prefs.setTheme(this, id);
        Theme.load(this);
        recreate();
    }

    /** Плитка-превью темы: полоска-шапка, «карточка» с кругом акцента и полосками, подпись с названием. */
    private View tile(Palettes.P p, boolean on) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.card);
        bg.setCornerRadius(Ui.dp(this, 14));
        bg.setStroke(on ? Math.max(2, Ui.dp(this, 2.5f)) : Math.max(1, Ui.dp(this, 1)), on ? p.acc : p.border);
        box.setBackground(bg);
        box.setClipToOutline(true);

        // шапка
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setBackgroundColor(p.bar);
        head.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        View hl = new View(this);
        GradientDrawable hlb = new GradientDrawable(); hlb.setColor(p.text); hlb.setCornerRadius(Ui.dp(this, 2));
        hl.setBackground(hlb); hl.setAlpha(0.5f);
        head.addView(hl, new LinearLayout.LayoutParams(Ui.dp(this, 16), Ui.dp(this, 3)));
        head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        View dot = new View(this);
        GradientDrawable db = new GradientDrawable(); db.setShape(GradientDrawable.OVAL); db.setColor(p.acc);
        dot.setBackground(db);
        head.addView(dot, new LinearLayout.LayoutParams(Ui.dp(this, 6), Ui.dp(this, 6)));
        box.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 34)));

        // тело
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setBackgroundColor(p.bg);
        mid.setPadding(Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12));
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        View ic = new View(this);
        GradientDrawable icb = new GradientDrawable(); icb.setColor(p.acc); icb.setCornerRadius(Ui.dp(this, 7));
        ic.setBackground(icb);
        LinearLayout.LayoutParams iclp = new LinearLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 26));
        iclp.rightMargin = Ui.dp(this, 8);
        r1.addView(ic, iclp);
        LinearLayout lines = new LinearLayout(this);
        lines.setOrientation(LinearLayout.VERTICAL);
        View l1 = new View(this);
        GradientDrawable l1b = new GradientDrawable(); l1b.setColor(p.text); l1b.setCornerRadius(Ui.dp(this, 3));
        l1.setBackground(l1b); l1.setAlpha(0.85f);
        LinearLayout.LayoutParams l1p = new LinearLayout.LayoutParams(Ui.dp(this, 62), Ui.dp(this, 5));
        l1p.bottomMargin = Ui.dp(this, 4);
        lines.addView(l1, l1p);
        View l2 = new View(this);
        GradientDrawable l2b = new GradientDrawable(); l2b.setColor(p.sub); l2b.setCornerRadius(Ui.dp(this, 3));
        l2.setBackground(l2b);
        lines.addView(l2, new LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 4)));
        r1.addView(lines, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        mid.addView(r1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout card2 = new LinearLayout(this);
        card2.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable c2b = new GradientDrawable();
        c2b.setColor(p.card); c2b.setCornerRadius(Ui.dp(this, 7));
        c2b.setStroke(Math.max(1, Ui.dp(this, 1)), p.border);
        card2.setBackground(c2b);
        card2.setPadding(Ui.dp(this, 7), 0, Ui.dp(this, 7), 0);
        View l3 = new View(this);
        GradientDrawable l3b = new GradientDrawable(); l3b.setColor(p.sub); l3b.setCornerRadius(Ui.dp(this, 3));
        l3.setBackground(l3b);
        card2.addView(l3, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 4)));
        LinearLayout.LayoutParams c2p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 22));
        c2p.topMargin = Ui.dp(this, 7);
        mid.addView(card2, c2p);
        box.addView(mid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // подпись
        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setBackgroundColor(p.bar);
        foot.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        TextView nm = new TextView(this);
        nm.setText(p.name); nm.setTextColor(p.text); nm.setTextSize(13);
        nm.setTypeface(null, android.graphics.Typeface.BOLD);
        foot.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (on) {
            TextView ck = new TextView(this);
            ck.setText("\u2713"); ck.setTextColor(p.acc); ck.setTextSize(15);
            ck.setTypeface(null, android.graphics.Typeface.BOLD);
            foot.addView(ck);
        }
        box.addView(foot, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        box.setOnClickListener(v -> choose(p.id));
        return box;
    }
}
