package leshugan.a4pda;

import java.nio.charset.Charset;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/** Гостевые запросы к 4pda: без каких-либо кук, с обычным браузерным UA; страницы форума — windows-1251. */
public final class Net {
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).build();
    private static final String UA = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    /** GET без кук; текст раскодируется по charset из заголовка, по умолчанию windows-1251 (форум). */
    public static String getText(String url) {
        try {
            Request req = new Request.Builder().url(url).header("User-Agent", UA).build();
            try (Response r = HTTP.newCall(req).execute()) {
                if (r.body() == null) return "";
                byte[] raw = r.body().bytes();
                String ct = r.header("Content-Type", "");
                String cs = "windows-1251";
                if (ct != null) {
                    int i = ct.toLowerCase().indexOf("charset=");
                    if (i >= 0) cs = ct.substring(i + 8).trim();
                }
                try { return new String(raw, Charset.forName(cs)); }
                catch (Throwable t) { return new String(raw, Charset.forName("windows-1251")); }
            }
        } catch (Throwable t) { return ""; }
    }
}
