package leshugan.a4pda;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("t4", Context.MODE_PRIVATE); }
    public static boolean dark(Context c) { return sp(c).getBoolean("dark", false); }
    public static void setDark(Context c, boolean v) { sp(c).edit().putBoolean("dark", v).apply(); }
    public static boolean showSystem(Context c) { return sp(c).getBoolean("sys", false); }
    public static void setShowSystem(Context c, boolean v) { sp(c).edit().putBoolean("sys", v).apply(); }
    public static long lastCheck(Context c) { return sp(c).getLong("lastChk", 0); }
    public static void setLastCheck(Context c, long v) { sp(c).edit().putLong("lastChk", v).apply(); }
}
