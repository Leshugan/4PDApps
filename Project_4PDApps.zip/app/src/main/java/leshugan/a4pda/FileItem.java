package leshugan.a4pda;

/** Один файл темы: из вложений 4pda и/или из записи сервера App&Game. */
public class FileItem {
    public long aid = 0;            // id вложения (/dl/post/<id>/) — ключ слияния и порядок показа
    public String url = "";
    public String name = "";
    public String ver = "";         // version_name с сервера
    public long code = 0;           // version_code с сервера
    public String pkg = "";         // pack_name с сервера
    public String sig = "";         // md5 подписи с сервера (32 hex)
    public int minSdk = 0;
    public int flags = 0;           // маски процессоров App&Game
    public long sizeBytes = 0;      // с сервера
    public String sizeText = "";    // из таблицы вложений («7,98 МБ»)
    public long dl = -1;            // счётчик скачиваний
    public String crc = "";
    public String added = "";       // DD.MM.YY из таблицы вложений
    public long ts = 0;
    public boolean fromServer = false;
    public String postUrl = "";   // ссылка на сообщение, где лежит файл (findpost / pid)
}
