package leshugan.a4pda;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements AppsAdapter.Listener {
    private static final String[] TAB_NAMES = { "ИЗБРАННОЕ", "ПРИЛОЖЕНИЯ", "ИГРЫ", "ЭМУЛЯТОРЫ", "НЕ СВЯЗАННЫЕ" };
    private final List<AppItem> items = new ArrayList<>();   // все установленные
    private final List<AppItem> shown = new ArrayList<>();   // отфильтрованные по текущей вкладке
    private int tab = 1;                                     // по умолчанию «ПРИЛОЖЕНИЯ», как в IA
    private final TextView[] tabViews = new TextView[TAB_NAMES.length];
    private AppsAdapter adapter;
    private RecyclerView list;
    private SwipeRefreshLayout swipe;
    private TextView status;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService iconPool = Executors.newFixedThreadPool(4);
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private Store store;
    private AgServer ag;
    private ImageView navRefresh;
    private TextView navUpdates;
    private android.view.animation.Animation spin;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        store = Store.get(this);
        ag = new AgServer(this);
        setContentView(buildUi());
        adapter = new AppsAdapter(this, shown, this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        swipe.setOnRefreshListener(this::checkUpdates);
        attachTabSwipe();
        askNotifications();
        setTab(1);
        loadList();
        showCrashIfAny();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Приложения");
        title.setTextColor(Theme.TEXT);
        title.setTextSize(20);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView bSet = barBtn("⋮"); bSet.setOnClickListener(v -> SettingsActivity.open(this)); bar.addView(bSet);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // полоса вкладок (как в IA): горизонтальная прокрутка, подчёркивание активной
        android.widget.HorizontalScrollView tabScroll = new android.widget.HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setBackgroundColor(Theme.BAR);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int idx = i;
            TextView tv = new TextView(this);
            tv.setText(TAB_NAMES[i]);
            tv.setTextSize(13);
            tv.setAllCaps(false);
            tv.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
            tv.setOnClickListener(v -> setTab(idx));
            tabViews[i] = tv;
            tabs.addView(tv);
        }
        tabScroll.addView(tabs);
        root.addView(tabScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View tabLine = new View(this);
        tabLine.setBackgroundColor(Theme.DIVIDER);
        root.addView(tabLine, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(this, 1))));

        status = new TextView(this);
        status.setTextColor(Theme.SUB);
        status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        status.setText("Загрузка…");
        root.addView(status);

        swipe = new SwipeRefreshLayout(this);
        list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 16));
        swipe.addView(list, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(swipe, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // нижняя панель с иконками, как в IA: Системные / Скрытые / Загрузки / Поиск / Обновить / Обновления
        View botLine = new View(this);
        botLine.setBackgroundColor(Theme.BORDER);
        root.addView(botLine, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(this, 1))));
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(Theme.BAR);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setWeightSum(6);
        int navH = Ui.dp(this, 52);
        nav.addView(navIcon(R.drawable.ic_android, false, v -> { Prefs.setShowSystem(this, !Prefs.showSystem(this)); loadList(); }));
        nav.addView(navIcon(R.drawable.ic_eyeoff, false, v -> HiddenActivity.open(this)));
        nav.addView(navIcon(R.drawable.ic_download, false, v -> DownloadsActivity.open(this)));
        nav.addView(navIcon(R.drawable.ic_search, false, v -> SearchActivity.openSearch(this)));
        navRefresh = navIcon(R.drawable.ic_refresh, false, v -> checkUpdates());
        nav.addView(navRefresh);
        navUpdates = updatesBadge();
        nav.addView(navUpdates);
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, navH));
        return root;
    }

    private ImageView navIcon(int res, boolean unused, View.OnClickListener cl) {
        ImageView iv = new ImageView(this);
        android.graphics.drawable.Drawable d = getResources().getDrawable(res).mutate();
        d.setColorFilter(Theme.SUB, android.graphics.PorterDuff.Mode.SRC_IN);
        iv.setImageDrawable(d);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int pad = Ui.dp(this, 13);
        iv.setPadding(pad, pad, pad, pad);
        iv.setOnClickListener(cl);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        iv.setLayoutParams(lp);
        return iv;
    }

    /** Кружок со счётчиком обновлений (как в IA): красный при наличии, серый контур при нуле. */
    private TextView updatesBadge() {
        TextView tv = new TextView(this);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(14);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        tv.setOnClickListener(v -> UpdatesActivity.open(this));
        return tv;
    }

    private void renderUpdatesBadge() {
        if (navUpdates == null) return;
        int n = 0;
        for (AppItem a : items) if (a.needsUpdate()) n++;
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        int s = Ui.dp(this, 30);
        if (n > 0) { bg.setColor(Theme.RED); navUpdates.setTextColor(Color.WHITE); }
        else { bg.setColor(Color.TRANSPARENT); bg.setStroke(Math.max(2, Ui.dp(this, 2)), Theme.SUB); navUpdates.setTextColor(Theme.SUB); }
        // компактный кружок по центру ячейки
        android.graphics.drawable.InsetDrawable ins = new android.graphics.drawable.InsetDrawable(bg, Ui.dp(this, 11));
        navUpdates.setBackground(ins);
        navUpdates.setText(String.valueOf(n));
    }

    /** Свайп между вкладками (горизонтальный fling), как в IA. */
    private void attachTabSwipe() {
        final android.view.GestureDetector gd = new android.view.GestureDetector(this,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override public boolean onFling(android.view.MotionEvent e1, android.view.MotionEvent e2, float vx, float vy) {
                        if (e1 == null || e2 == null) return false;
                        float dx = e2.getX() - e1.getX(), dy = e2.getY() - e1.getY();
                        if (Math.abs(dx) > Math.abs(dy) * 1.3f && Math.abs(dx) > Ui.dp(MainActivity.this, 56) && Math.abs(vx) > 200) {
                            if (dx < 0 && tab < TAB_NAMES.length - 1) setTab(tab + 1);
                            else if (dx > 0 && tab > 0) setTab(tab - 1);
                            return true;
                        }
                        return false;
                    }
                });
        list.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override public boolean onInterceptTouchEvent(RecyclerView rv, android.view.MotionEvent e) { return gd.onTouchEvent(e); }
        });
    }

    /** Фильтр вкладки — как kindApp+linked в IA. 0 избранное, 1 программы, 2 игры, 3 эмуляторы, 4 не связанные. */
    private boolean matchesTab(AppItem a) {
        boolean linked = a.topicId > 0;
        switch (tab) {
            case 0: return a.fav;
            case 1: return linked && a.category().equals("apps");
            case 2: return linked && a.category().equals("games");
            case 3: return linked && a.category().equals("emu");
            case 4: return !linked;
            default: return true;
        }
    }

    private void setTab(int t) {
        tab = t;
        for (int i = 0; i < tabViews.length; i++) {
            if (tabViews[i] == null) continue;
            boolean on = i == t;
            tabViews[i].setTextColor(on ? Theme.ACC : Theme.SUB);
            tabViews[i].setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
        refilter();
    }

    private void refilter() {
        shown.clear();
        for (AppItem a : items) if (matchesTab(a)) shown.add(a);
        if (adapter != null) adapter.notifyDataSetChanged();
        if (status != null) status.setText(shown.size() + " приложений");
    }

    /** На Android 13+ уведомление об обновлениях без разрешения не покажется — спрашиваем один раз. */
    private void askNotifications() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{ "android.permission.POST_NOTIFICATIONS" }, 77);
            }
        } catch (Throwable ignored) {}
    }

    /** Если прошлый запуск упал — показать причину (текст можно скопировать и прислать). */
    private void showCrashIfAny() {
        String crash = T4App.takeCrash(this);
        if (crash == null) return;
        new android.app.AlertDialog.Builder(this)
                .setTitle("Прошлый запуск упал")
                .setMessage(crash)
                .setPositiveButton("Скопировать", (d, w) -> {
                    try {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", crash));
                    } catch (Throwable ignored) {}
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private TextView barBtn(String t) {
        TextView tv = new TextView(this);
        tv.setText(t); tv.setTextColor(Theme.ACC); tv.setTextSize(14);
        tv.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4));
        return tv;
    }


    /** Мгновенно: список из системы + всё известное из локальной базы (как app_install_list у ag4pda). */
    private void loadList() {
        work.execute(() -> {
            List<AppItem> scan = AppItem.scanInstalled(this, Prefs.showSystem(this));
            Map<String, Store.Row> known = store.loadAll();
            for (AppItem a : scan) {
                Store.Row r = known.get(a.pkg);
                if (r != null) {
                    a.topicId = r.topicId;
                    a.versionForum = r.forumVer == null ? "" : r.forumVer;
                    a.versionPlay = r.playVer == null ? "" : r.playVer;
                    a.desc = r.desc == null ? "" : r.desc;
                    a.forumDate = r.forumDate == null ? "" : r.forumDate;
                    a.manualLink = r.manual;
                    a.group = r.grp == null ? "" : r.grp;
                    a.fav = (r.flags & 1) != 0;
                    a.hidden = (r.flags & 2) != 0;
                    a.hideUpd = r.hiddenUpd;
                }
            }
            java.util.Collections.sort(scan, (x, y) -> x.label.compareToIgnoreCase(y.label));
            ui.post(() -> {
                items.clear();
                items.addAll(scan);
                refilter();
                renderUpdatesBadge();
                checkUpdates();
            });
        });
    }

    /** Фоновая сверка версий с сервером App&Game — пакетно, как у ag4pda (packages=). */
    private void checkUpdates() {
        swipe.setRefreshing(true);
        startSpin();
        work.execute(() -> {
            // готовая база связей с GitHub (мгновенно, даже если сервер молчит) — как в вебной версии
            if (AgBackup.sync(this, store)) {
                Map<String, Store.Row> fresh = store.loadAll();
                for (AppItem a : new ArrayList<>(items)) {
                    Store.Row r = fresh.get(a.pkg);
                    if (r == null || r.topicId <= 0) continue;
                    final Store.Row fr = r;
                    ui.post(() -> applyToItem(fr.pkg, fr.topicId, fr.forumVer == null ? "" : fr.forumVer,
                            fr.forumDate == null ? "" : fr.forumDate, fr.desc == null ? "" : fr.desc,
                            fr.grp == null ? "" : fr.grp));
                }
            }
            List<String> pkgs = new ArrayList<>();
            for (AppItem a : items) pkgs.add(a.pkg);
            int done = 0;
            for (int i = 0; i < pkgs.size(); i += 40) {
                List<String> part = pkgs.subList(i, Math.min(pkgs.size(), i + 40));
                Map<String, JSONObject> got = ag.getAppInfo(part);
                for (Map.Entry<String, JSONObject> e : got.entrySet()) {
                    JSONObject x = e.getValue();
                    String pkg = e.getKey();
                    long topic = x.optLong("topic_id", 0);
                    String ver = x.optString("ver", "");
                    String upd = x.optString("forum_update", "");     // YYYYMMDD
                    String desc = x.optString("description", "");
                    String grp = x.optString("group_name", "");
                    String date = "";
                    if (upd.length() == 8) date = upd.substring(6, 8) + "." + upd.substring(4, 6) + "." + upd.substring(2, 4);
                    store.applyInfo(pkg, topic, ver, date, desc, grp, false);
                    final String fVer = ver, fDate = date, fDesc = desc, fGrp = grp; final long fTopic = topic;
                    ui.post(() -> applyToItem(pkg, fTopic, fVer, fDate, fDesc, fGrp));
                }
                done += part.size();
                final int fd = done;
                ui.post(() -> status.setText("Проверка обновлений: " + fd + "/" + pkgs.size()));
            }
            // Google Play — пачками по 20 (как APKUpdater); токен анонимный, хранится на диске
            for (int i = 0; i < pkgs.size(); i += 20) {
                List<String> part = pkgs.subList(i, Math.min(pkgs.size(), i + 20));
                java.util.List<String> res;
                try { res = PlayApi.versions(this, part); } catch (Throwable t) { res = new ArrayList<>(); }
                for (String line : res) {
                    String[] p2 = line.split("\u0001");
                    if (p2.length < 2) continue;
                    String pkg = p2[0], ver = p2[1];
                    store.setPlay(pkg, ver);
                    ui.post(() -> applyPlay(pkg, ver));
                }
            }
            ui.post(() -> { swipe.setRefreshing(false); stopSpin(); refilter(); renderUpdatesBadge(); });
        });
        UpdateJob.schedule(this);   // включить периодическую фоновую проверку
    }

    private void startSpin() {
        if (navRefresh == null) return;
        if (spin == null) {
            spin = new android.view.animation.RotateAnimation(0, 360, android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f, android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f);
            spin.setDuration(900); spin.setRepeatCount(android.view.animation.Animation.INFINITE);
            spin.setInterpolator(new android.view.animation.LinearInterpolator());
        }
        navRefresh.startAnimation(spin);
    }
    private void stopSpin() { if (navRefresh != null) navRefresh.clearAnimation(); }

    private void applyPlay(String pkg, String ver) { applyPlayRow(pkg, ver); }

    private void applyToItem(String pkg, long topic, String ver, String date, String desc, String grp) {
        for (AppItem a : items) {
            if (!a.pkg.equals(pkg)) continue;
            boolean wasShown = shown.contains(a);
            if (topic > 0 && !(a.manualLink && a.topicId > 0)) a.topicId = topic;
            if (!ver.isEmpty()) a.versionForum = ver;
            if (!date.isEmpty()) a.forumDate = date;
            if (!desc.isEmpty() && a.desc.isEmpty()) a.desc = desc;
            if (!grp.isEmpty()) a.group = grp;
            boolean nowShown = matchesTab(a);
            if (wasShown && nowShown) { int idx = shown.indexOf(a); if (idx >= 0) adapter.notifyItemChanged(idx); }
            else refilter();   // состав вкладки изменился (появилась категория/связь)
            renderUpdatesBadge();
            return;
        }
    }

    private void applyPlayRow(String pkg, String ver) {
        for (AppItem a : items) if (a.pkg.equals(pkg)) {
            a.versionPlay = ver;
            int idx = shown.indexOf(a);
            if (idx >= 0) adapter.notifyItemChanged(idx);
            return;
        }
    }

    // ---- Listener ----
    @Override public void onOpen(AppItem a) {
        if (a.topicId > 0) FilesActivity.open(this, a.pkg, a.label, a.topicId);
        else onOpenTopic(a);   // темы нет — открываем поиск по названию на 4pda
    }

    @Override public void onIconNeeded(AppItem a, int pos) {
        iconPool.execute(() -> {
            android.graphics.drawable.Drawable d = AppItem.loadIcon(this, a.pkg);
            if (d == null) return;
            a.icon = d;
            ui.post(() -> {
                int idx = shown.indexOf(a);
                if (idx >= 0) adapter.notifyItemChanged(idx);
            });
        });
    }

    @Override public void onFlag(AppItem a, String col, int val) {
        work.execute(() -> {
            if (col.equals("fav")) { a.fav = val != 0; store.setFlag(a.pkg, "flags", (a.fav ? 1 : 0) | (a.hidden ? 2 : 0)); }
            else if (col.equals("hidden")) { a.hidden = val != 0; store.setFlag(a.pkg, "flags", (a.fav ? 1 : 0) | (a.hidden ? 2 : 0)); }
            else if (col.equals("hidden_updates")) { a.hideUpd = val; store.setFlag(a.pkg, "hidden_updates", val); }
            ui.post(this::refilter);   // fav/hidden/скрытые обновления меняют состав вкладки
        });
    }

    @Override public void onLink(AppItem a) { SearchActivity.openLink(this, a.pkg, a.label); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == SearchActivity.REQ_LINK && res == RESULT_OK && data != null) {
            String pkg = data.getStringExtra("pkg");
            long topic = data.getLongExtra("topic", 0);
            for (AppItem a : items) if (a.pkg.equals(pkg)) {
                a.topicId = topic; a.manualLink = true;
                refilter();
                checkUpdates();
                break;
            }
        }
    }

    @Override public void onUninstall(AppItem a) {
        try { startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))); } catch (Throwable ignored) {}
    }

    @Override public void onLaunch(AppItem a) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(a.pkg);
            if (i != null) startActivity(i);
        } catch (Throwable ignored) {}
    }

    @Override public void onOpenTopic(AppItem a) {
        String url = a.topicId > 0 ? "https://4pda.to/forum/index.php?showtopic=" + a.topicId
                : "https://4pda.to/forum/index.php?act=search&source=all&query=" + Uri.encode(a.label);
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        UpdateJob.runOnce(this);
    }
}
