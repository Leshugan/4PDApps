package leshugan.a4pda;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements AppsAdapter.Listener {
    private final List<AppItem> items = new ArrayList<>();
    private AppsAdapter adapter;
    private RecyclerView list;
    private SwipeRefreshLayout swipe;
    private TextView status;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService iconPool = Executors.newFixedThreadPool(4);
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private Store store;
    private AgServer ag;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        store = Store.get(this);
        ag = new AgServer(this);
        setContentView(buildUi());
        adapter = new AppsAdapter(this, items, this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        swipe.setOnRefreshListener(this::checkUpdates);
        loadList();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Приложения");
        title.setTextColor(Theme.TEXT);
        title.setTextSize(20);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView bSearch = barBtn("Поиск"); bSearch.setOnClickListener(v -> SearchActivity.openSearch(this)); bar.addView(bSearch);
        TextView bDl = barBtn("Загрузки"); bDl.setOnClickListener(v -> DownloadsActivity.open(this)); bar.addView(bDl);
        TextView bSet = barBtn("⋮"); bSet.setOnClickListener(v -> settings()); bar.addView(bSet);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB);
        status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        status.setText("Загрузка…");
        root.addView(status);

        swipe = new SwipeRefreshLayout(this);
        list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 12));
        swipe.addView(list, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(swipe, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private TextView barBtn(String t) {
        TextView tv = new TextView(this);
        tv.setText(t); tv.setTextColor(Theme.ACC); tv.setTextSize(14);
        tv.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4));
        return tv;
    }

    private void settings() {
        final boolean[] dark = { Prefs.dark(this) };
        final boolean[] sys = { Prefs.showSystem(this) };
        new android.app.AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setMultiChoiceItems(new CharSequence[]{ "Тёмная тема", "Показывать системные" },
                        new boolean[]{ dark[0], sys[0] }, (d, which, checked) -> {
                            if (which == 0) dark[0] = checked; else sys[0] = checked;
                        })
                .setPositiveButton("Применить", (d, w) -> {
                    boolean themeChanged = dark[0] != Prefs.dark(this);
                    boolean sysChanged = sys[0] != Prefs.showSystem(this);
                    Prefs.setDark(this, dark[0]);
                    Prefs.setShowSystem(this, sys[0]);
                    if (themeChanged) recreate();
                    else if (sysChanged) loadList();
                })
                .setNeutralButton("Проверить обновления", (d, w) -> checkUpdates())
                .setNegativeButton(LoginActivity.loggedIn() ? "Выйти из 4pda" : "Войти на 4pda", (d, w) -> {
                    if (LoginActivity.loggedIn()) { LoginActivity.logout(); android.widget.Toast.makeText(this, "Вы вышли", android.widget.Toast.LENGTH_SHORT).show(); }
                    else LoginActivity.open(this);
                })
                .show();
    }

    /** Мгновенно: список из системы + всё известное из локальной базы (как app_install_list у ag4pda). */
    private void loadList() {
        work.execute(() -> {
            List<AppItem> scan = AppItem.scanInstalled(this, Prefs.showSystem(this));
            Map<String, Store.Row> known = store.loadAll();
            for (AppItem a : scan) {
                Store.Row r = known.get(a.pkg);
                if (r != null) {
                    a.topicId = r.topicId;
                    a.versionForum = r.forumVer == null ? "" : r.forumVer;
                    a.versionPlay = r.playVer == null ? "" : r.playVer;
                    a.desc = r.desc == null ? "" : r.desc;
                    a.forumDate = r.forumDate == null ? "" : r.forumDate;
                    a.manualLink = r.manual;
                    a.fav = (r.flags & 1) != 0;
                    a.hidden = (r.flags & 2) != 0;
                    a.hideUpd = r.hiddenUpd;
                }
            }
            scan.sort((x, y) -> x.label.compareToIgnoreCase(y.label));
            ui.post(() -> {
                items.clear();
                items.addAll(scan);
                adapter.notifyDataSetChanged();
                status.setText(items.size() + " приложений");
                checkUpdates();
            });
        });
    }

    /** Фоновая сверка версий с сервером App&Game — пакетно, как у ag4pda (packages=). */
    private void checkUpdates() {
        swipe.setRefreshing(true);
        work.execute(() -> {
            List<String> pkgs = new ArrayList<>();
            for (AppItem a : items) pkgs.add(a.pkg);
            int done = 0;
            for (int i = 0; i < pkgs.size(); i += 40) {
                List<String> part = pkgs.subList(i, Math.min(pkgs.size(), i + 40));
                Map<String, JSONObject> got = ag.getAppInfo(part);
                for (Map.Entry<String, JSONObject> e : got.entrySet()) {
                    JSONObject x = e.getValue();
                    String pkg = e.getKey();
                    long topic = x.optLong("topic_id", 0);
                    String ver = x.optString("ver", "");
                    String upd = x.optString("forum_update", "");     // YYYYMMDD
                    String desc = x.optString("description", "");
                    String date = "";
                    if (upd.length() == 8) date = upd.substring(6, 8) + "." + upd.substring(4, 6) + "." + upd.substring(2, 4);
                    store.applyInfo(pkg, topic, ver, date, desc, false);
                    final String fVer = ver, fDate = date, fDesc = desc; final long fTopic = topic;
                    ui.post(() -> applyToItem(pkg, fTopic, fVer, fDate, fDesc));
                }
                done += part.size();
                final int fd = done;
                ui.post(() -> status.setText("Проверка обновлений: " + fd + "/" + pkgs.size()));
            }
            // Google Play — пачками по 20 (как APKUpdater); токен анонимный, хранится на диске
            for (int i = 0; i < pkgs.size(); i += 20) {
                List<String> part = pkgs.subList(i, Math.min(pkgs.size(), i + 20));
                java.util.List<String> res;
                try { res = PlayApi.versions(this, part); } catch (Throwable t) { res = new ArrayList<>(); }
                for (String line : res) {
                    String[] p2 = line.split("\u0001");
                    if (p2.length < 2) continue;
                    String pkg = p2[0], ver = p2[1];
                    store.setPlay(pkg, ver);
                    ui.post(() -> applyPlay(pkg, ver));
                }
            }
            ui.post(() -> { swipe.setRefreshing(false); status.setText(items.size() + " приложений"); });
        });
        UpdateJob.schedule(this);   // включить периодическую фоновую проверку
    }

    private void applyPlay(String pkg, String ver) {
        for (int i = 0; i < items.size(); i++) if (items.get(i).pkg.equals(pkg)) {
            items.get(i).versionPlay = ver; adapter.notifyItemChanged(i); return;
        }
    }

    private void applyToItem(String pkg, long topic, String ver, String date, String desc) {
        for (int i = 0; i < items.size(); i++) {
            AppItem a = items.get(i);
            if (!a.pkg.equals(pkg)) continue;
            if (topic > 0 && !(a.manualLink && a.topicId > 0)) a.topicId = topic;
            if (!ver.isEmpty()) a.versionForum = ver;
            if (!date.isEmpty()) a.forumDate = date;
            if (!desc.isEmpty() && a.desc.isEmpty()) a.desc = desc;
            adapter.notifyItemChanged(i);   // ТОЧЕЧНОЕ обновление строки — без пересборки списка
            return;
        }
    }

    // ---- Listener ----
    @Override public void onOpen(AppItem a) {
        if (a.topicId > 0) FilesActivity.open(this, a.pkg, a.label, a.topicId);
        else onOpenTopic(a);   // темы нет — открываем поиск по названию на 4pda
    }

    @Override public void onIconNeeded(AppItem a, int pos) {
        iconPool.execute(() -> {
            android.graphics.drawable.Drawable d = AppItem.loadIcon(this, a.pkg);
            if (d == null) return;
            a.icon = d;
            ui.post(() -> {
                int idx = items.indexOf(a);
                if (idx >= 0) adapter.notifyItemChanged(idx);
            });
        });
    }

    @Override public void onFlag(AppItem a, String col, int val) {
        work.execute(() -> {
            if (col.equals("fav")) { a.fav = val != 0; store.setFlag(a.pkg, "flags", (a.fav ? 1 : 0) | (a.hidden ? 2 : 0)); }
            else if (col.equals("hidden")) { a.hidden = val != 0; store.setFlag(a.pkg, "flags", (a.fav ? 1 : 0) | (a.hidden ? 2 : 0)); }
            else if (col.equals("hidden_updates")) { a.hideUpd = val; store.setFlag(a.pkg, "hidden_updates", val); }
            int idx = items.indexOf(a);
            if (idx >= 0) ui.post(() -> adapter.notifyItemChanged(idx));
        });
    }

    @Override public void onLink(AppItem a) { SearchActivity.openLink(this, a.pkg, a.label); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == SearchActivity.REQ_LINK && res == RESULT_OK && data != null) {
            String pkg = data.getStringExtra("pkg");
            long topic = data.getLongExtra("topic", 0);
            for (int i = 0; i < items.size(); i++) if (items.get(i).pkg.equals(pkg)) {
                items.get(i).topicId = topic; items.get(i).manualLink = true;
                adapter.notifyItemChanged(i);
                checkUpdates();
                break;
            }
        }
    }

    @Override public void onUninstall(AppItem a) {
        try { startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))); } catch (Throwable ignored) {}
    }

    @Override public void onLaunch(AppItem a) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(a.pkg);
            if (i != null) startActivity(i);
        } catch (Throwable ignored) {}
    }

    @Override public void onOpenTopic(AppItem a) {
        String url = a.topicId > 0 ? "https://4pda.to/forum/index.php?showtopic=" + a.topicId
                : "https://4pda.to/forum/index.php?act=search&source=all&query=" + Uri.encode(a.label);
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        try { startService(new Intent(this, WorkService.class)); } catch (Throwable ignored) {}
    }
}
