package leshugan.a4pda;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;
import java.util.Map;

/** Локальная база — по образцу app_install_list у ag4pda: связь пакет→тема, версии, пометки, скрытые обновления. */
public class Store extends SQLiteOpenHelper {
    private static Store INST;
    public static synchronized Store get(Context c) {
        if (INST == null) INST = new Store(c.getApplicationContext());
        return INST;
    }
    private Store(Context c) { super(c, "t4pda.db", null, 2); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE app_install_list(" +
                "package_name TEXT PRIMARY KEY, topic_id INTEGER DEFAULT 0, description TEXT DEFAULT ''," +
                "forum_version TEXT DEFAULT '', play_version TEXT DEFAULT '', forum_date TEXT DEFAULT ''," +
                "flags INTEGER DEFAULT 0, hidden_updates INTEGER DEFAULT 0, manual INTEGER DEFAULT 0," +
                "grp TEXT DEFAULT '', chk INTEGER DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int a, int b) {
        if (a < 2) { try { db.execSQL("ALTER TABLE app_install_list ADD COLUMN grp TEXT DEFAULT ''"); } catch (Throwable ignored) {} }
    }

    /** Прочитать всё известное про пакеты в карту. */
    public Map<String, Row> loadAll() {
        Map<String, Row> m = new HashMap<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM app_install_list", null);
        while (c.moveToNext()) {
            Row r = new Row();
            r.pkg = c.getString(c.getColumnIndexOrThrow("package_name"));
            r.topicId = c.getLong(c.getColumnIndexOrThrow("topic_id"));
            r.desc = c.getString(c.getColumnIndexOrThrow("description"));
            r.forumVer = c.getString(c.getColumnIndexOrThrow("forum_version"));
            r.playVer = c.getString(c.getColumnIndexOrThrow("play_version"));
            r.forumDate = c.getString(c.getColumnIndexOrThrow("forum_date"));
            r.flags = c.getInt(c.getColumnIndexOrThrow("flags"));
            r.hiddenUpd = c.getInt(c.getColumnIndexOrThrow("hidden_updates"));
            r.manual = c.getInt(c.getColumnIndexOrThrow("manual")) != 0;
            r.grp = col(c, "grp");
            m.put(r.pkg, r);
        }
        c.close();
        return m;
    }

    /** Убедиться, что строка пакета существует (пустая), чтобы дальше делать UPDATE. */
    private void ensureRow(String pkg) {
        ContentValues v = new ContentValues();
        v.put("package_name", pkg);
        getWritableDatabase().insertWithOnConflict("app_install_list", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void applyInfo(String pkg, long topicId, String forumVer, String forumDate, String desc, String grp, boolean manual) {
        Row cur = one(pkg);
        ensureRow(pkg);
        SQLiteDatabase db = getWritableDatabase();
        // ручную привязку сервер не перетирает; версию/дату дописываем; описание — только если пусто
        if (topicId > 0 && !(cur != null && cur.topicId > 0 && cur.manual))
            db.execSQL("UPDATE app_install_list SET topic_id=? WHERE package_name=?", new Object[]{ topicId, pkg });
        if (forumVer != null && !forumVer.isEmpty())
            db.execSQL("UPDATE app_install_list SET forum_version=? WHERE package_name=?", new Object[]{ forumVer, pkg });
        if (forumDate != null && !forumDate.isEmpty())
            db.execSQL("UPDATE app_install_list SET forum_date=? WHERE package_name=?", new Object[]{ forumDate, pkg });
        if (desc != null && !desc.isEmpty() && (cur == null || cur.desc == null || cur.desc.isEmpty()))
            db.execSQL("UPDATE app_install_list SET description=? WHERE package_name=?", new Object[]{ desc, pkg });
        if (grp != null && !grp.isEmpty())
            db.execSQL("UPDATE app_install_list SET grp=? WHERE package_name=?", new Object[]{ grp, pkg });
        if (manual)
            db.execSQL("UPDATE app_install_list SET manual=1 WHERE package_name=?", new Object[]{ pkg });
        db.execSQL("UPDATE app_install_list SET chk=? WHERE package_name=?", new Object[]{ System.currentTimeMillis(), pkg });
    }

    public void setPlay(String pkg, String playVer) {
        ensureRow(pkg);
        getWritableDatabase().execSQL("UPDATE app_install_list SET play_version=? WHERE package_name=?",
                new Object[]{ playVer == null ? "" : playVer, pkg });
    }

    public void setFlag(String pkg, String col, int val) {
        ensureRow(pkg);
        getWritableDatabase().execSQL("UPDATE app_install_list SET " + col + "=? WHERE package_name=?", new Object[]{ val, pkg });
    }

    public void setManualLink(String pkg, long topicId) {
        ContentValues v = new ContentValues();
        v.put("package_name", pkg);
        v.put("topic_id", topicId);
        v.put("manual", 1);
        getWritableDatabase().insertWithOnConflict("app_install_list", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public Row one(String pkg) {
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM app_install_list WHERE package_name=?", new String[]{pkg});
        Row r = null;
        if (c.moveToFirst()) {
            r = new Row();
            r.pkg = pkg;
            r.topicId = c.getLong(c.getColumnIndexOrThrow("topic_id"));
            r.desc = c.getString(c.getColumnIndexOrThrow("description"));
            r.forumVer = c.getString(c.getColumnIndexOrThrow("forum_version"));
            r.playVer = c.getString(c.getColumnIndexOrThrow("play_version"));
            r.forumDate = c.getString(c.getColumnIndexOrThrow("forum_date"));
            r.flags = c.getInt(c.getColumnIndexOrThrow("flags"));
            r.hiddenUpd = c.getInt(c.getColumnIndexOrThrow("hidden_updates"));
            r.manual = c.getInt(c.getColumnIndexOrThrow("manual")) != 0;
            r.grp = col(c, "grp");
        }
        c.close();
        return r;
    }

    public static class Row {
        public String pkg, desc = "", forumVer = "", playVer = "", forumDate = "";
        public long topicId = 0;
        public int flags = 0, hiddenUpd = 0;
        public boolean manual = false;
        public String grp = "";
    }

    private static String col(Cursor c, String name) {
        int i = c.getColumnIndex(name); if (i < 0) return "";
        String v = c.getString(i); return v == null ? "" : v;
    }
}
