package leshugan.a4pda;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Экран поиска тем. Режим link=true — выбранная тема возвращается вызвавшему (для связывания). */
public class SearchActivity extends Activity {
    public static final int REQ_LINK = 71;

    public static void openSearch(Context c) { c.startActivity(new Intent(c, SearchActivity.class)); }
    public static void openLink(Activity a, String pkg, String label) {
        Intent i = new Intent(a, SearchActivity.class);
        i.putExtra("link", true); i.putExtra("pkg", pkg); i.putExtra("label", label);
        a.startActivityForResult(i, REQ_LINK);
    }

    private final List<Search4pda.Hit> hits = new ArrayList<>();
    private HitAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private boolean linkMode;
    private String pkg = "", label = "";
    private TextView status;
    private int gen = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        linkMode = getIntent().getBooleanExtra("link", false);
        pkg = getIntent().getStringExtra("pkg");
        label = getIntent().getStringExtra("label");
        setContentView(buildUi());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        TextView back = new TextView(this);
        back.setText("‹"); back.setTextSize(26); back.setTextColor(Theme.TEXT);
        back.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), Ui.dp(this, 2));
        back.setOnClickListener(v -> finish());
        bar.addView(back);

        EditText input = new EditText(this);
        input.setHint(linkMode ? "Поиск темы для: " + (label == null ? "" : label) : "Поиск по 4pda");
        input.setSingleLine(true);
        input.setTextColor(Theme.TEXT);
        input.setHintTextColor(Theme.SUB);
        input.setBackgroundColor(0);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        bar.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB); status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        root.addView(status);

        RecyclerView list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        adapter = new HitAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        input.setOnEditorActionListener((v, actionId, ev) -> { run(input.getText().toString()); return true; });
        // предзаполнить и сразу искать в режиме связывания
        if (linkMode && label != null && !label.isEmpty()) { input.setText(label); run(label); }
        return root;
    }

    private void run(String q) {
        final String query = q == null ? "" : q.trim();
        if (query.isEmpty()) return;
        final int my = ++gen;
        status.setText("Поиск…");
        hits.clear(); adapter.notifyDataSetChanged();
        work.execute(() -> {
            List<Search4pda.Hit> res = Search4pda.search(query);
            ui.post(() -> {
                if (my != gen) return;
                hits.clear(); hits.addAll(res);
                adapter.notifyDataSetChanged();
                status.setText(res.isEmpty() ? "Ничего не найдено" : "Найдено: " + res.size());
            });
        });
    }

    private void pick(Search4pda.Hit h) {
        if (linkMode) {
            Store.get(this).setManualLink(pkg, h.topicId);
            Intent res = new Intent();
            res.putExtra("pkg", pkg); res.putExtra("topic", h.topicId); res.putExtra("title", h.title);
            setResult(RESULT_OK, res);
            finish();
        } else {
            FilesActivity.open(this, "", h.title, h.topicId);
        }
    }

    private class HitAdapter extends RecyclerView.Adapter<HitAdapter.VH> {
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) {
            TextView tv = new TextView(SearchActivity.this);
            RecyclerMargins.apply(tv, SearchActivity.this);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(Theme.CARD); bg.setCornerRadius(Ui.dp(SearchActivity.this, 10)); bg.setStroke(Ui.dp(SearchActivity.this, 1), Theme.BORDER);
            tv.setBackground(bg);
            tv.setPadding(Ui.dp(SearchActivity.this, 14), Ui.dp(SearchActivity.this, 12), Ui.dp(SearchActivity.this, 14), Ui.dp(SearchActivity.this, 12));
            tv.setTextColor(Theme.TEXT); tv.setTextSize(14.5f);
            return new VH(tv);
        }
        @Override public int getItemCount() { return hits.size(); }
        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            Search4pda.Hit hit = hits.get(pos);
            ((TextView) h.itemView).setText(hit.title);
            h.itemView.setOnClickListener(v -> pick(hit));
        }
        class VH extends RecyclerView.ViewHolder { VH(View v){ super(v);} }
    }
}
