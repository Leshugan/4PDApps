package leshugan.a4pda;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Экран поиска тем — вёрстка как в IA: шапка «Поиск на сайте : N», карточки 44px с описанием,
 *  строка ввода ВНИЗУ с лупой. Режим link=true — выбранная тема возвращается для связывания. */
public class SearchActivity extends Activity {
    public static final int REQ_LINK = 71;

    public static void openSearch(Context c) { c.startActivity(new Intent(c, SearchActivity.class)); }
    public static void openLink(Activity a, String pkg, String label) {
        Intent i = new Intent(a, SearchActivity.class);
        i.putExtra("link", true); i.putExtra("pkg", pkg); i.putExtra("label", label);
        a.startActivityForResult(i, REQ_LINK);
    }

    private final List<Search4pda.Hit> hits = new ArrayList<>();
    private HitAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private boolean linkMode;
    private String pkg = "", label = "";
    private TextView title;
    private EditText input;
    private int gen = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        linkMode = getIntent().getBooleanExtra("link", false);
        pkg = getIntent().getStringExtra("pkg");
        label = getIntent().getStringExtra("label");
        setContentView(buildUi());
        if (linkMode && label != null && !label.isEmpty()) { input.setText(label); run(label); }
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        // шапка, как в IA: ← + «Поиск на сайте : N»
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        TextView back = new TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 12), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        title = new TextView(this);
        title.setText(linkMode ? "Связать тему" : "Поиск на сайте");
        title.setTextColor(Theme.TEXT);
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56)));

        RecyclerView list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 12));
        adapter = new HitAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // строка ввода ВНИЗУ (как в IA)
        View line = new View(this);
        line.setBackgroundColor(Theme.BORDER);
        root.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(this, 1))));
        LinearLayout bot = new LinearLayout(this);
        bot.setBackgroundColor(Theme.BAR);
        bot.setGravity(Gravity.CENTER_VERTICAL);
        bot.setPadding(Ui.dp(this, 12), Ui.dp(this, 5), Ui.dp(this, 12), Ui.dp(this, 5));

        input = new EditText(this);
        input.setHint("Поиск на 4pda");
        input.setSingleLine(true);
        input.setTextColor(Theme.TEXT);
        input.setHintTextColor(Theme.SUB);
        input.setTextSize(15);
        GradientDrawable ib = new GradientDrawable();
        ib.setColor(Theme.DARK ? Theme.CARD : Color.WHITE);
        ib.setCornerRadius(Ui.dp(this, 10));
        ib.setStroke(Math.max(1, Ui.dp(this, 1)), Theme.BORDER);
        input.setBackground(ib);
        input.setPadding(Ui.dp(this, 12), Ui.dp(this, 9), Ui.dp(this, 12), Ui.dp(this, 9));
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setOnEditorActionListener((v, a, e) -> { run(input.getText().toString()); return true; });
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ilp.rightMargin = Ui.dp(this, 10);
        bot.addView(input, ilp);

        ImageView go = new ImageView(this);
        android.graphics.drawable.Drawable d = getResources().getDrawable(R.drawable.ic_search).mutate();
        d.setColorFilter(Theme.ACC, android.graphics.PorterDuff.Mode.SRC_IN);
        go.setImageDrawable(d);
        go.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        go.setOnClickListener(v -> run(input.getText().toString()));
        bot.addView(go);
        root.addView(bot, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return root;
    }

    private void run(String q) {
        final String query = q == null ? "" : q.trim();
        if (query.isEmpty()) return;
        final int my = ++gen;
        title.setText((linkMode ? "Связать тему" : "Поиск на сайте") + " …");
        hits.clear(); adapter.notifyDataSetChanged();
        work.execute(() -> {
            List<Search4pda.Hit> res = Search4pda.search(query);
            ui.post(() -> {
                if (my != gen) return;
                hits.clear(); hits.addAll(res);
                adapter.notifyDataSetChanged();
                title.setText((linkMode ? "Связать тему" : "Поиск на сайте") + (res.isEmpty() ? "" : " : " + res.size()));
            });
        });
    }

    private void pick(Search4pda.Hit h) {
        if (linkMode) {
            Store.get(this).setManualLink(pkg, h.topicId);
            Intent res = new Intent();
            res.putExtra("pkg", pkg); res.putExtra("topic", h.topicId); res.putExtra("title", h.title);
            setResult(RESULT_OK, res);
            finish();
        } else {
            FilesActivity.open(this, "", h.title, h.topicId);
        }
    }

    /** Цветная плитка с первой буквой — как tileColor в IA (когда иконки темы нет). */
    private static int tileColor(String s) {
        int h = 0;
        for (int i = 0; i < s.length(); i++) h = (h * 31 + s.charAt(i));
        float hue = Math.abs(h % 360);
        return Color.HSVToColor(new float[]{ hue, 0.42f, 0.42f });
    }

    private class HitAdapter extends RecyclerView.Adapter<HitAdapter.VH> {
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) { return new VH(rowView()); }
        @Override public int getItemCount() { return hits.size(); }
        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            Search4pda.Hit hit = hits.get(pos);
            h.title.setText(hit.title);
            h.desc.setText("4pda · тема " + hit.topicId);
            String first = hit.title == null || hit.title.trim().isEmpty() ? "?" : hit.title.trim().substring(0, 1).toUpperCase();
            GradientDrawable tile = new GradientDrawable();
            tile.setColor(tileColor(hit.title == null ? String.valueOf(hit.topicId) : hit.title));
            tile.setCornerRadius(Ui.dp(SearchActivity.this, 11));
            h.tile.setBackground(tile);
            h.tile.setText(first);
            h.itemView.setOnClickListener(v -> pick(hit));
        }
        class VH extends RecyclerView.ViewHolder {
            TextView title, desc, tile;
            VH(View v) { super(v); title = v.findViewWithTag("t"); desc = v.findViewWithTag("d"); tile = v.findViewWithTag("i"); }
        }
    }

    /** Карточка результата — как в IA: плитка 44, название 15.5 + описание 12.5 в 2 строки. */
    private View rowView() {
        Context c = this;
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(c, 7);
        card.setLayoutParams(lp);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.CARD);
        bg.setCornerRadius(Ui.dp(c, 10));
        bg.setStroke(Math.max(1, Ui.dp(c, 1)), Theme.BORDER);
        card.setBackground(bg);
        card.setPadding(Ui.dp(c, 10), Ui.dp(c, 9), Ui.dp(c, 10), Ui.dp(c, 9));

        TextView tile = new TextView(c);
        tile.setTag("i");
        tile.setGravity(Gravity.CENTER);
        tile.setTextColor(Color.parseColor("#EAEAEA"));
        tile.setTextSize(19);
        tile.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44));
        tlp.rightMargin = Ui.dp(c, 10);
        card.addView(tile, tlp);

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        card.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView t = new TextView(c); t.setTag("t"); t.setTextSize(15.5f); t.setTextColor(Theme.TEXT);
        t.setMaxLines(1); t.setEllipsize(android.text.TextUtils.TruncateAt.END); mid.addView(t);
        TextView d = new TextView(c); d.setTag("d"); d.setTextSize(12.5f); d.setTextColor(Theme.SUB);
        d.setMaxLines(2); d.setEllipsize(android.text.TextUtils.TruncateAt.END); mid.addView(d);
        return card;
    }
}
