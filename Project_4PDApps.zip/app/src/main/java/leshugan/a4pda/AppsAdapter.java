package leshugan.a4pda;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/** Родной список: RecyclerView с точечным обновлением строк (notifyItemChanged), как у ag4pda. */
public class AppsAdapter extends RecyclerView.Adapter<AppsAdapter.VH> {
    public interface Listener {
        void onOpen(AppItem a);
        void onIconNeeded(AppItem a, int pos);
        void onFlag(AppItem a, String col, int val);
        void onLink(AppItem a);
        void onUninstall(AppItem a);
        void onLaunch(AppItem a);
        void onOpenTopic(AppItem a);
    }

    private final Context ctx;
    private final List<AppItem> items;
    private final Listener cb;

    public AppsAdapter(Context ctx, List<AppItem> items, Listener cb) {
        this.ctx = ctx; this.items = items; this.cb = cb;
        setHasStableIds(true);
    }

    @Override public long getItemId(int position) { return items.get(position).pkg.hashCode(); }
    @Override public int getItemCount() { return items.size(); }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(Ui.row(ctx));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        AppItem a = items.get(pos);
        h.name.setText(a.label != null ? a.label : a.pkg);
        String sub = !a.desc.isEmpty() ? a.desc : a.pkg;
        h.desc.setText(sub);
        h.date.setText(a.forumDate);

        if (a.icon != null) h.icon.setImageDrawable(a.icon);
        else { h.icon.setImageDrawable(null); cb.onIconNeeded(a, pos); }

        // левая красная полоска — как inset-бар у веб-версии, если есть обновление
        h.itemView.setBackgroundColor(Theme.CARD);
        h.bar.setBackgroundColor(a.needsUpdate() ? Theme.RED : Color.TRANSPARENT);

        // строка версий: установленная / форум / Play
        setVer(h.vInst, a.versionInstalled, false, false);
        boolean fHidden = (a.hideUpd & 1) != 0 || (a.hideUpd & 2) != 0;
        boolean pHidden = (a.hideUpd & 1) != 0 || (a.hideUpd & 4) != 0;
        setVer(h.vForum, a.versionForum, a.hasForumUpdate(), fHidden);
        setVer(h.vPlay, a.versionPlay, a.hasPlayUpdate(), pHidden);

        h.itemView.setOnClickListener(v -> cb.onOpen(a));
        h.menu.setOnClickListener(v -> showMenu(v, a));
    }

    private void setVer(TextView tv, String val, boolean newer, boolean hidden) {
        if (val == null || val.isEmpty()) { tv.setText("—"); tv.setTextColor(Theme.SUB); tv.setPaintFlags(tv.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG); return; }
        tv.setText(Ui.shortVer(val));
        // как у ag4pda: активное обновление — красным; скрытое — обычный серый + зачёркивание
        if (hidden) { tv.setTextColor(Theme.SUB); tv.setPaintFlags(tv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG); }
        else { tv.setTextColor(newer ? Theme.RED : Theme.TEXT); tv.setPaintFlags(tv.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG); }
    }

    private void showMenu(View anchor, AppItem a) {
        PopupMenu pm = new PopupMenu(ctx, anchor);
        pm.getMenu().add(0, 1, 0, "Открыть приложение");
        pm.getMenu().add(0, 2, 0, "Открыть тему на 4pda");
        pm.getMenu().add(0, 3, 0, "Связать тему");
        pm.getMenu().add(0, 4, 0, a.fav ? "Убрать из избранного" : "В избранное");
        pm.getMenu().add(0, 5, 0, a.hidden ? "Показать" : "Скрыть приложение");
        pm.getMenu().add(0, 6, 0, "Скрыть все обновления").setCheckable(true).setChecked((a.hideUpd & 1) != 0);
        pm.getMenu().add(0, 7, 0, "Удалить");
        pm.setOnMenuItemClickListener(mi -> {
            switch (mi.getItemId()) {
                case 1: cb.onLaunch(a); return true;
                case 2: cb.onOpenTopic(a); return true;
                case 3: cb.onLink(a); return true;
                case 4: cb.onFlag(a, "fav", a.fav ? 0 : 1); return true;
                case 5: cb.onFlag(a, "hidden", a.hidden ? 0 : 1); return true;
                case 6: cb.onFlag(a, "hidden_updates", (a.hideUpd & 1) != 0 ? 0 : 1); return true;
                case 7: cb.onUninstall(a); return true;
            }
            return false;
        });
        pm.show();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView icon; TextView name, desc, date, vInst, vForum, vPlay; View menu, bar;
        VH(View v) {
            super(v);
            icon = v.findViewWithTag("icon");
            name = v.findViewWithTag("name");
            desc = v.findViewWithTag("desc");
            date = v.findViewWithTag("date");
            vInst = v.findViewWithTag("vinst");
            vForum = v.findViewWithTag("vforum");
            vPlay = v.findViewWithTag("vplay");
            menu = v.findViewWithTag("menu");
            bar = v.findViewWithTag("bar");
        }
    }
}
