package leshugan.a4pda;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/** Родной список: RecyclerView с точечным обновлением строк (notifyItemChanged), как у ag4pda. */
public class AppsAdapter extends RecyclerView.Adapter<AppsAdapter.VH> {
    public interface Listener {
        void onOpen(AppItem a);
        void onIconNeeded(AppItem a, int pos);
        void onFlag(AppItem a, String col, int val);
        void onLink(AppItem a);
        void onUninstall(AppItem a);
        void onLaunch(AppItem a);
        void onOpenTopic(AppItem a);
    }

    private final Context ctx;
    private final List<AppItem> items;
    private final Listener cb;

    public AppsAdapter(Context ctx, List<AppItem> items, Listener cb) {
        this.ctx = ctx; this.items = items; this.cb = cb;
        setHasStableIds(true);
    }

    @Override public long getItemId(int position) { return items.get(position).pkg.hashCode(); }
    @Override public int getItemCount() { return items.size(); }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(Ui.row(ctx));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        AppItem a = items.get(pos);
        h.name.setText(a.label != null ? a.label : a.pkg);
        h.desc.setText(!a.desc.isEmpty() ? a.desc : a.pkg);
        h.date.setText(a.forumDate);

        if (a.icon != null) h.icon.setImageDrawable(a.icon);
        else { h.icon.setImageDrawable(null); cb.onIconNeeded(a, pos); }

        // левая красная полоска-индикатор обновления (inset 3px), как в вебной IA
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.CARD);
        bg.setCornerRadius(Ui.dp(ctx, 10));
        bg.setStroke(Math.max(1, Ui.dp(ctx, 1.5f)), Theme.BORDER);
        h.itemView.setBackground(bg);
        h.itemView.setPadding(a.needsUpdate() ? Ui.dp(ctx, 3) : 0, 0, 0, 0);
        h.itemView.setBackgroundColor(0);   // сбрасываем, чтобы inset рисовать поверх
        // inset реализуем фоном карточки со «вставкой»: проще — левый цветной кант через layer
        h.itemView.setBackground(insetBg(a.needsUpdate()));

        setVer(h.vInst, a.versionInstalled, false, false);
        boolean fHidden = (a.hideUpd & 1) != 0 || (a.hideUpd & 2) != 0;
        boolean pHidden = (a.hideUpd & 1) != 0 || (a.hideUpd & 4) != 0;
        setVer(h.vForum, a.versionForum, a.hasForumUpdate(), fHidden);
        setVer(h.vPlay, a.versionPlay, a.hasPlayUpdate(), pHidden);

        h.top.setOnClickListener(v -> cb.onOpen(a));
        h.menu.setOnClickListener(v -> showMenu(v, a));
    }

    private android.graphics.drawable.Drawable insetBg(boolean upd) {
        GradientDrawable card = new GradientDrawable();
        card.setColor(Theme.CARD);
        card.setCornerRadius(Ui.dp(ctx, 10));
        card.setStroke(Math.max(1, Ui.dp(ctx, 1.5f)), Theme.BORDER);
        if (!upd) return card;
        GradientDrawable bar = new GradientDrawable();
        bar.setColor(Theme.RED);
        bar.setCornerRadius(Ui.dp(ctx, 10));
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{ bar, card });
        ld.setLayerInset(1, Ui.dp(ctx, 3), 0, 0, 0);   // карточка сдвинута вправо на 3dp → слева видна красная полоса
        return ld;
    }

    private void setVer(TextView tv, String val, boolean newer, boolean hidden) {
        if (val == null || val.isEmpty()) {
            tv.setText("\u2014"); tv.setTextColor(Theme.TEXT);
            tv.setPaintFlags(tv.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG); return;
        }
        tv.setText(Ui.shortVer(val));
        if (hidden) { tv.setTextColor(Theme.SUB); tv.setPaintFlags(tv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG); }
        else { tv.setTextColor(newer ? Theme.RED : Theme.TEXT); tv.setPaintFlags(tv.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG); }
    }

    private void showMenu(View anchor, AppItem a) {
        PopupMenu pm = new PopupMenu(ctx, anchor);
        pm.getMenu().add(0, 1, 0, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435");
        pm.getMenu().add(0, 2, 0, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0442\u0435\u043c\u0443 \u043d\u0430 4pda");
        pm.getMenu().add(0, 3, 0, "\u0421\u0432\u044f\u0437\u0430\u0442\u044c \u0442\u0435\u043c\u0443");
        pm.getMenu().add(0, 4, 0, a.fav ? "\u0423\u0431\u0440\u0430\u0442\u044c \u0438\u0437 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e" : "\u0412 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435");
        pm.getMenu().add(0, 5, 0, a.hidden ? "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c" : "\u0421\u043a\u0440\u044b\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435");
        pm.getMenu().add(0, 6, 0, "\u0421\u043a\u0440\u044b\u0442\u044c \u0432\u0441\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f").setCheckable(true).setChecked((a.hideUpd & 1) != 0);
        pm.getMenu().add(0, 7, 0, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c");
        pm.setOnMenuItemClickListener(mi -> {
            switch (mi.getItemId()) {
                case 1: cb.onLaunch(a); return true;
                case 2: cb.onOpenTopic(a); return true;
                case 3: cb.onLink(a); return true;
                case 4: cb.onFlag(a, "fav", a.fav ? 0 : 1); return true;
                case 5: cb.onFlag(a, "hidden", a.hidden ? 0 : 1); return true;
                case 6: cb.onFlag(a, "hidden_updates", (a.hideUpd & 1) != 0 ? 0 : 1); return true;
                case 7: cb.onUninstall(a); return true;
            }
            return false;
        });
        pm.show();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView icon; TextView name, desc, date, vInst, vForum, vPlay; View menu, top;
        VH(View v) {
            super(v);
            icon = v.findViewWithTag("icon");
            name = v.findViewWithTag("name");
            desc = v.findViewWithTag("desc");
            date = v.findViewWithTag("date");
            vInst = v.findViewWithTag("vinst");
            vForum = v.findViewWithTag("vforum");
            vPlay = v.findViewWithTag("vplay");
            menu = v.findViewWithTag("menu");
            top = v.findViewWithTag("top");
        }
    }
}
