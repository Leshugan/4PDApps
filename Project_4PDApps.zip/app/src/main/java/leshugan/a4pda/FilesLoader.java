package leshugan.a4pda;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Загрузка файлов темы — как у ag4pda: записи их сервера (getFileInfo) + вложения самой темы
 * (act=attach постранично), слияние по id вложения, порядок по id по убыванию.
 */
public final class FilesLoader {
    public interface Sink { void publish(List<FileItem> items); }

    private static final Pattern AID = Pattern.compile("/dl/post/(\\d+)/");
    private static final Pattern HREF = Pattern.compile("href=\"([^\"]*?/dl/post/\\d+/[^\"]*?\\.apk)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern ADDED = Pattern.compile("Добавлено\\s+(\\d{1,2})\\.(\\d{1,2})\\.(\\d{2,4})(?:,\\s*(\\d{1,2}):(\\d{2}))?");
    private static final Pattern SIZE = Pattern.compile("([\\d.,]+\\s*(?:ГБ|МБ|Мб|КБ|Кб|GB|MB|KB))");

    /** Полная загрузка: сперва сервер (одним запросом), затем страницы вложений; после каждого шага publish. */
    public static void load(AgServer ag, long topicId, Sink sink) {
        Map<Long, FileItem> byAid = new HashMap<>();

        // 1) сервер App&Game — мгновенно даёт подписи/версии/скачивания (в т.ч. сборки, которых нет во вложениях)
        JSONArray data = ag.getFileInfo(topicId);
        if (data != null) {
            for (int i = 0; i < data.length(); i++) {
                JSONObject x = data.optJSONObject(i);
                if (x == null) continue;
                FileItem f = new FileItem();
                f.url = x.optString("file_name", "");
                Matcher m = AID.matcher(f.url);
                if (m.find()) try { f.aid = Long.parseLong(m.group(1)); } catch (Exception ignored) {}
                f.name = tail(f.url);
                f.ver = x.optString("version_name", "");
                f.code = x.optLong("version_code", 0);
                f.pkg = x.optString("pack_name", x.optString("package_name", ""));
                f.sig = x.optString("signature", "");
                f.minSdk = x.optInt("min_sdk", 0);
                f.flags = x.optInt("flags", 0);
                f.sizeBytes = x.optLong("file_size", 0);
                f.dl = x.optLong("downloads_count", -1);
                f.crc = x.optString("crc32", "");
                f.fromServer = true;
                if (f.aid > 0) byAid.put(f.aid, f);
            }
            sink.publish(sorted(byAid));
        }

        // 2) вложения темы — постранично (st=0,100,…), только .apk; добавляем отсутствующие, дописываем дату
        int pageSize = 100;
        for (int page = 0; page < 40; page++) {
            String html = Net.getText("https://4pda.to/forum/index.php?act=attach&code=showtopic&tid=" + topicId + (page > 0 ? "&st=" + (page * pageSize) : ""));
            if (html == null || html.length() < 200) break;
            int got = 0;
            for (String row : html.split("</tr>")) {
                Matcher h = HREF.matcher(row);
                if (!h.find()) continue;
                String url = h.group(1).replace("&amp;", "&");
                if (url.startsWith("//")) url = "https:" + url;
                else if (!url.startsWith("http")) url = "https://4pda.to" + (url.startsWith("/") ? "" : "/") + url;
                long aid = 0;
                Matcher am = AID.matcher(url);
                if (am.find()) try { aid = Long.parseLong(am.group(1)); } catch (Exception ignored) {}
                if (aid == 0) continue;
                got++;
                FileItem f = byAid.get(aid);
                boolean fresh = f == null;
                if (fresh) { f = new FileItem(); f.aid = aid; f.url = url; f.name = tail(url); }
                Matcher ad = ADDED.matcher(row.replaceAll("\\s+", " "));
                if (ad.find()) {
                    int y = Integer.parseInt(ad.group(3)); if (y < 100) y += 2000;
                    f.added = pad(ad.group(1)) + "." + pad(ad.group(2)) + "." + String.valueOf(y).substring(2);
                }
                if (f.sizeText.isEmpty()) {
                    String txt = row.replaceAll("<[^>]+>", " ");
                    Matcher sm = SIZE.matcher(txt);
                    if (sm.find()) f.sizeText = sm.group(1);
                }
                if (fresh) byAid.put(aid, f);
            }
            sink.publish(sorted(byAid));
            if (got < pageSize) break;                       // неполная страница — вложения кончились
            try { Thread.sleep(250); } catch (InterruptedException e) { break; }
        }
    }

    private static List<FileItem> sorted(Map<Long, FileItem> m) {
        List<FileItem> out = new ArrayList<>(m.values());
        out.sort((a, b) -> Long.compare(b.aid, a.aid));      // как ag4pda: по id вложения по убыванию
        return out;
    }

    private static String tail(String url) {
        String s = url;
        int q = s.indexOf('?'); if (q > 0) s = s.substring(0, q);
        int i = s.lastIndexOf('/');
        s = i >= 0 ? s.substring(i + 1) : s;
        try { s = java.net.URLDecoder.decode(s, "UTF-8"); } catch (Throwable ignored) {}
        return s.replace('+', ' ').trim();
    }

    private static String pad(String s) { return s.length() == 1 ? "0" + s : s; }
}
