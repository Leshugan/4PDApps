package leshugan.a4pda;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    // маски процессоров сервера App&Game — проверены декомпилом ag4pda (i/a)
    public static final int AG_ARM = 0x200, AG_ARM64 = 0x10000, AG_X86 = 0x2000, AG_X64 = 0x8000, AG_MIPS = 0x4000;

    /** Версия Android по номеру SDK — для строки «Android X+». */
    public static String sdkName(int sdk) {
        switch (sdk) {
            case 9: case 10: return "2.3";
            case 14: case 15: return "4.0";
            case 16: return "4.1"; case 17: return "4.2"; case 18: return "4.3"; case 19: return "4.4";
            case 21: return "5.0"; case 22: return "5.1"; case 23: return "6.0";
            case 24: return "7.0"; case 25: return "7.1"; case 26: return "8.0"; case 27: return "8.1";
            case 28: return "9"; case 29: return "10"; case 30: return "11"; case 31: return "12";
            case 32: return "12L"; case 33: return "13"; case 34: return "14"; case 35: return "15";
            default: return sdk > 0 ? String.valueOf(sdk) : "";
        }
    }

    public static String sizeFmt(long bytes) {
        if (bytes <= 0) return "";
        double mb = bytes / 1048576.0;
        if (mb >= 1024) return String.format(java.util.Locale.US, "%.2f ГБ", mb / 1024);
        if (mb >= 1) return String.format(java.util.Locale.US, "%.2f МБ", mb);
        return String.format(java.util.Locale.US, "%.0f КБ", bytes / 1024.0);
    }

    /** Строка требований как у ag4pda: «Android X+ (ARM/64 X86/64 MIPS)», поддерживаемые файлом — жирные,
     *  остальные приглушённые; при пустых данных возвращает null (ничего не выдумываем). */
    public static CharSequence reqLine(int flags, int minSdk) {
        String ver = sdkName(minSdk);
        boolean hasAbi = flags != 0;
        if (ver.isEmpty() && !hasAbi) return null;
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
        if (!ver.isEmpty()) sb.append("Android ").append(ver).append("+");
        if (hasAbi) {
            if (sb.length() > 0) sb.append(" ");
            sb.append("(");
            abi(sb, "ARM", (flags & AG_ARM) != 0); sb.append("/");
            abi(sb, "64", (flags & AG_ARM64) != 0); sb.append(" ");
            abi(sb, "X86", (flags & AG_X86) != 0); sb.append("/");
            abi(sb, "64", (flags & AG_X64) != 0); sb.append(" ");
            abi(sb, "MIPS", (flags & AG_MIPS) != 0);
            sb.append(")");
        }
        return sb;
    }
    private static void abi(android.text.SpannableStringBuilder sb, String t, boolean on) {
        int s = sb.length();
        sb.append(t);
        sb.setSpan(new android.text.style.ForegroundColorSpan(on ? Theme.TEXT : Theme.SUB), s, sb.length(), 0);
        if (on) sb.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), s, sb.length(), 0);
    }

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    public static String shortVer(String v) {
        if (v == null) return "";
        return v.length() > 16 ? v.substring(0, 16) + "…" : v;
    }

    /** Карточка приложения — верхняя строка (иконка/название/описание/дата/⋮) + полоса версий. */
    public static View row(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        RecyclerMargins.apply(card, c);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.CARD);
        bg.setCornerRadius(dp(c, 10));
        bg.setStroke(dp(c, 1), Theme.BORDER);
        card.setBackground(bg);

        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(c, 10), dp(c, 9), dp(c, 8), dp(c, 6));

        // левая полоска-индикатор обновления
        View bar = new View(c);
        bar.setTag("bar");
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(c, 3), dp(c, 40));
        blp.rightMargin = dp(c, 8);
        top.addView(bar, blp);

        ImageView icon = new ImageView(c);
        icon.setTag("icon");
        top.addView(icon, new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mlp.leftMargin = dp(c, 10);
        top.addView(mid, mlp);

        TextView name = new TextView(c);
        name.setTag("name");
        name.setTextColor(Theme.TEXT);
        name.setTextSize(16);
        name.setMaxLines(1);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mid.addView(name);

        TextView desc = new TextView(c);
        desc.setTag("desc");
        desc.setTextColor(Theme.SUB);
        desc.setTextSize(12.5f);
        desc.setMaxLines(2);
        desc.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mid.addView(desc);

        LinearLayout right = new LinearLayout(c);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);

        TextView date = new TextView(c);
        date.setTag("date");
        date.setTextColor(Theme.SUB);
        date.setTextSize(12);
        right.addView(date);

        TextView menu = new TextView(c);
        menu.setTag("menu");
        menu.setText("⋮");
        menu.setTextColor(Theme.SUB);
        menu.setTextSize(20);
        menu.setPadding(dp(c, 10), dp(c, 2), dp(c, 4), dp(c, 2));
        menu.setGravity(Gravity.CENTER);
        right.addView(menu);

        top.addView(right);
        card.addView(top);

        // полоса версий
        LinearLayout ver = new LinearLayout(c);
        ver.setOrientation(LinearLayout.HORIZONTAL);
        ver.setPadding(dp(c, 10), dp(c, 2), dp(c, 10), dp(c, 8));
        ver.addView(verCell(c, "vinst"));
        ver.addView(verCell(c, "vforum"));
        ver.addView(verCell(c, "vplay"));
        card.addView(ver);

        return card;
    }

    private static View verCell(Context c, String tag) {
        TextView t = new TextView(c);
        t.setTag(tag);
        t.setTextSize(12.5f);
        t.setTextColor(Theme.SUB);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        t.setLayoutParams(lp);
        return t;
    }
}
