package leshugan.a4pda;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int AG_ARM = 0x200, AG_ARM64 = 0x10000, AG_X86 = 0x2000, AG_X64 = 0x8000, AG_MIPS = 0x4000;

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    public static String shortVer(String v) {
        if (v == null) return "";
        return v.length() > 16 ? v.substring(0, 16) + "\u2026" : v;
    }

    public static String sdkName(int sdk) {
        switch (sdk) {
            case 9: case 10: return "2.3";
            case 14: case 15: return "4.0";
            case 16: return "4.1"; case 17: return "4.2"; case 18: return "4.3"; case 19: return "4.4";
            case 21: return "5.0"; case 22: return "5.1"; case 23: return "6.0";
            case 24: return "7.0"; case 25: return "7.1"; case 26: return "8.0"; case 27: return "8.1";
            case 28: return "9"; case 29: return "10"; case 30: return "11"; case 31: return "12";
            case 32: return "12L"; case 33: return "13"; case 34: return "14"; case 35: return "15";
            default: return sdk > 0 ? String.valueOf(sdk) : "";
        }
    }

    public static String sizeFmt(long bytes) {
        if (bytes <= 0) return "";
        double mb = bytes / 1048576.0;
        if (mb >= 1024) return String.format(java.util.Locale.US, "%.2f \u0413\u0411", mb / 1024);
        if (mb >= 1) return String.format(java.util.Locale.US, "%.2f \u041c\u0411", mb);
        return String.format(java.util.Locale.US, "%.0f \u041a\u0411", bytes / 1024.0);
    }

    public static CharSequence reqLine(int flags, int minSdk) {
        String ver = sdkName(minSdk);
        boolean hasAbi = flags != 0;
        if (ver.isEmpty() && !hasAbi) return null;
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
        if (!ver.isEmpty()) sb.append("Android ").append(ver).append("+");
        if (hasAbi) {
            if (sb.length() > 0) sb.append(" ");
            sb.append("(");
            abi(sb, "ARM", (flags & AG_ARM) != 0); sb.append("/");
            abi(sb, "64", (flags & AG_ARM64) != 0); sb.append(" ");
            abi(sb, "X86", (flags & AG_X86) != 0); sb.append("/");
            abi(sb, "64", (flags & AG_X64) != 0); sb.append(" ");
            abi(sb, "MIPS", (flags & AG_MIPS) != 0);
            sb.append(")");
        }
        return sb;
    }
    private static void abi(android.text.SpannableStringBuilder sb, String t, boolean on) {
        int s = sb.length();
        sb.append(t);
        sb.setSpan(new android.text.style.ForegroundColorSpan(on ? Theme.TEXT : Theme.SUB), s, sb.length(), 0);
        if (on) sb.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), s, sb.length(), 0);
    }

    /** Карточка приложения — как в вебной IA: иконка 44 / название 16 / описание 12.5 (2 строки),
     *  справа дата сверху и три точки снизу; внизу полоса из 3 версий с цветными значками. */
    public static View row(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        RecyclerMargins.apply(card, c);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.CARD);
        bg.setCornerRadius(dp(c, 10));
        bg.setStroke(Math.max(1, dp(c, 1.5f)), Theme.BORDER);
        card.setBackground(bg);

        LinearLayout top = new LinearLayout(c);
        top.setTag("top");
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(c, 10), dp(c, 9), dp(c, 10), dp(c, 9));

        ImageView icon = new ImageView(c);
        icon.setTag("icon");
        top.addView(icon, new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mlp.leftMargin = dp(c, 10);
        top.addView(mid, mlp);

        TextView name = new TextView(c);
        name.setTag("name");
        name.setTextColor(Theme.TEXT);
        name.setTextSize(16);
        name.setMaxLines(1);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mid.addView(name);

        TextView desc = new TextView(c);
        desc.setTag("desc");
        desc.setTextColor(Theme.SUB);
        desc.setTextSize(12.5f);
        desc.setMaxLines(2);
        desc.setLineSpacing(0, 1.05f);
        desc.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mid.addView(desc);

        LinearLayout right = new LinearLayout(c);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        right.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView date = new TextView(c);
        date.setTag("date");
        date.setTextColor(Theme.SUB);
        date.setTextSize(12);
        right.addView(date);

        View spacer = new View(c);
        right.addView(spacer, new LinearLayout.LayoutParams(0, 0, 1f));

        LinearLayout dots = new LinearLayout(c);
        dots.setTag("menu");
        dots.setOrientation(LinearLayout.VERTICAL);
        dots.setGravity(Gravity.CENTER);
        dots.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 34), dp(c, 30)));
        for (int i = 0; i < 3; i++) {
            View d = new View(c);
            GradientDrawable dd = new GradientDrawable();
            dd.setShape(GradientDrawable.OVAL);
            dd.setColor(Theme.SUB);
            d.setBackground(dd);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(c, 3.5f), dp(c, 3.5f));
            p.topMargin = i == 0 ? 0 : dp(c, 3);
            dots.addView(d, p);
        }
        right.addView(dots);
        top.addView(right);
        card.addView(top);

        LinearLayout ver = new LinearLayout(c);
        ver.setTag("verbar");
        ver.setOrientation(LinearLayout.HORIZONTAL);
        ver.setPadding(dp(c, 10), 0, dp(c, 10), dp(c, 8));
        ver.addView(verCell(c, 0));
        ver.addView(sep(c));
        ver.addView(verCell(c, 1));
        ver.addView(sep(c));
        ver.addView(verCell(c, 2));
        card.addView(ver);
        return card;
    }

    private static View sep(Context c) {
        View v = new View(c);
        v.setBackgroundColor(Theme.DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Math.max(1, dp(c, 1)), dp(c, 16));
        lp.gravity = Gravity.CENTER_VERTICAL;
        v.setLayoutParams(lp);
        return v;
    }

    private static View verCell(Context c, int kind) {
        LinearLayout cell = new LinearLayout(c);
        cell.setOrientation(LinearLayout.HORIZONTAL);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(dp(c, 4), dp(c, 6), dp(c, 4), dp(c, 6));
        cell.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView badge = new ImageView(c);
        badge.setImageDrawable(new BadgeDrawable(kind));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(c, 14), dp(c, 14));
        blp.rightMargin = dp(c, 5);
        cell.addView(badge, blp);

        TextView tv = new TextView(c);
        tv.setTag(kind == 0 ? "vinst" : kind == 1 ? "vforum" : "vplay");
        tv.setTextSize(12.5f);
        tv.setTextColor(Theme.TEXT);
        tv.setMaxLines(1);
        cell.addView(tv);
        return cell;
    }

    /** Значки версий кодом: зелёный робот / синий «4» / триколор-треугольник Play. */
    static class BadgeDrawable extends Drawable {
        private final int kind; private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        BadgeDrawable(int kind) { this.kind = kind; }
        @Override public void draw(Canvas cv) {
            android.graphics.Rect b = getBounds();
            float w = b.width(), h = b.height();
            if (kind == 0) {
                p.setColor(Color.parseColor("#3DDC84"));
                RectF body = new RectF(b.left + w * 0.12f, b.top + h * 0.35f, b.right - w * 0.12f, b.bottom - h * 0.05f);
                cv.drawRoundRect(body, w * 0.12f, h * 0.12f, p);
                cv.drawArc(new RectF(b.left + w * 0.12f, b.top + h * 0.12f, b.right - w * 0.12f, b.top + h * 0.62f), 180, 180, true, p);
            } else if (kind == 1) {
                p.setColor(Theme.ACC);
                cv.drawRoundRect(new RectF(b.left, b.top, b.right, b.bottom), w * 0.22f, h * 0.22f, p);
                p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
                p.setFakeBoldText(true); p.setTextSize(h * 0.78f);
                cv.drawText("4", b.exactCenterX(), b.exactCenterY() + h * 0.28f, p);
            } else {
                p.setColor(Color.parseColor("#00C3FF"));
                android.graphics.Path left = new android.graphics.Path();
                left.moveTo(b.left + w * 0.16f, b.top + h * 0.06f);
                left.lineTo(b.left + w * 0.16f, b.bottom - h * 0.06f);
                left.lineTo(b.right - w * 0.10f, b.exactCenterY());
                left.close(); cv.drawPath(left, p);
                p.setColor(Color.parseColor("#00D97D"));
                android.graphics.Path tp = new android.graphics.Path();
                tp.moveTo(b.left + w * 0.16f, b.top + h * 0.06f);
                tp.lineTo(b.exactCenterX() + w * 0.10f, b.exactCenterY() - h * 0.10f);
                tp.lineTo(b.left + w * 0.42f, b.exactCenterY());
                tp.close(); cv.drawPath(tp, p);
                p.setColor(Color.parseColor("#FF3A44"));
                android.graphics.Path bt = new android.graphics.Path();
                bt.moveTo(b.left + w * 0.16f, b.bottom - h * 0.06f);
                bt.lineTo(b.exactCenterX() + w * 0.10f, b.exactCenterY() + h * 0.10f);
                bt.lineTo(b.left + w * 0.42f, b.exactCenterY());
                bt.close(); cv.drawPath(bt, p);
                p.setColor(Color.parseColor("#FFCE00"));
                android.graphics.Path rt = new android.graphics.Path();
                rt.moveTo(b.exactCenterX() + w * 0.10f, b.exactCenterY() - h * 0.10f);
                rt.lineTo(b.right - w * 0.10f, b.exactCenterY());
                rt.lineTo(b.exactCenterX() + w * 0.10f, b.exactCenterY() + h * 0.10f);
                rt.close(); cv.drawPath(rt, p);
            }
        }
        @Override public void setAlpha(int a) {} @Override public void setColorFilter(android.graphics.ColorFilter cf) {}
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}
