package leshugan.a4pda;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

/** Одна установленная программа + всё, что мы про неё знаем (из сервера App&Game и локальной базы). */
public class AppItem {
    public String pkg;            // имя пакета
    public String label;          // название на устройстве
    public String versionInstalled = "";
    public long versionCode = 0;
    public long installDate = 0;
    public boolean system = false;
    public Drawable icon;         // иконка с устройства (грузим лениво в фоне)

    // данные с сервера / из базы
    public long topicId = 0;
    public String versionForum = "";
    public String versionPlay = "";
    public String desc = "";
    public String forumDate = "";   // DD.MM.YY
    public boolean manualLink = false;
    public String group = "";      // group_name с сервера App&Game (для вкладок)

    /** Категория для вкладок: emu / games / apps — по названию раздела 4pda. */
    public String category() {
        String g = group == null ? "" : group.toLowerCase();
        if (g.matches(".*(\u044d\u043c\u0443\u043b|emul).*")) return "emu";
        if (g.matches(".*(\u0438\u0433\u0440|game).*")) return "games";
        return "apps";
    }

    // пользовательские пометки
    public boolean fav = false;
    public boolean hidden = false;
    public int hideUpd = 0;         // битовые флаги: 1=все, 2=форум, 4=play

    public boolean hasForumUpdate() {
        return topicId > 0 && !versionForum.isEmpty() && Ver.cmp(versionForum, versionInstalled) > 0;
    }
    public boolean hasPlayUpdate() {
        return !versionPlay.isEmpty() && Ver.cmp(versionPlay, versionInstalled) > 0;
    }
    public boolean needsUpdate() {
        boolean f = hasForumUpdate() && (hideUpd & 1) == 0 && (hideUpd & 2) == 0;
        boolean p = hasPlayUpdate() && (hideUpd & 1) == 0 && (hideUpd & 4) == 0;
        return f || p;
    }

    /** Сканирование установленных приложений — БЕЗ иконок (иконки грузим отдельно пулом потоков). */
    public static List<AppItem> scanInstalled(Context ctx, boolean includeSystem) {
        PackageManager pm = ctx.getPackageManager();
        List<AppItem> out = new ArrayList<>();
        List<PackageInfo> pkgs = pm.getInstalledPackages(0);
        String self = ctx.getPackageName();
        for (PackageInfo pi : pkgs) {
            if (pi.applicationInfo == null) continue;
            boolean sys = (pi.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            if (sys && !includeSystem) continue;
            if (pi.packageName.equals(self)) continue;
            AppItem a = new AppItem();
            a.pkg = pi.packageName;
            a.label = String.valueOf(pi.applicationInfo.loadLabel(pm));
            a.versionInstalled = pi.versionName != null ? pi.versionName : "";
            a.versionCode = (android.os.Build.VERSION.SDK_INT >= 28) ? pi.getLongVersionCode() : pi.versionCode;
            a.installDate = pi.firstInstallTime;
            a.system = sys;
            out.add(a);
        }
        return out;
    }

    public static Drawable loadIcon(Context ctx, String pkg) {
        try { return ctx.getPackageManager().getApplicationIcon(pkg); }
        catch (Throwable t) { return null; }
    }
}
