package leshugan.a4pda;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Экран «Скрытые» — список приложений, помеченных как скрытые. */
public class HiddenActivity extends Activity implements AppsAdapter.Listener {
    public static void open(Context c) { c.startActivity(new Intent(c, HiddenActivity.class)); }

    private final List<AppItem> items = new ArrayList<>();
    private AppsAdapter adapter;
    private RecyclerView list;
    private TextView status;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService iconPool = Executors.newFixedThreadPool(3);
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private Store store;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        store = Store.get(this);
        setContentView(buildUi());
        adapter = new AppsAdapter(this, items, this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        load();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        TextView back = new TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Скрытые"); title.setTextColor(Theme.TEXT); title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB); status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        root.addView(status);

        list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void load() {
        work.execute(() -> {
            List<AppItem> scan = AppItem.scanInstalled(this, true);
            Map<String, Store.Row> known = store.loadAll();
            List<AppItem> hidden = new ArrayList<>();
            for (AppItem a : scan) {
                Store.Row r = known.get(a.pkg);
                if (r == null) continue;
                boolean h = (r.flags & 2) != 0;
                if (!h) continue;
                a.hidden = true;
                a.fav = (r.flags & 1) != 0;
                a.topicId = r.topicId;
                a.versionForum = r.forumVer == null ? "" : r.forumVer;
                a.versionPlay = r.playVer == null ? "" : r.playVer;
                a.desc = r.desc == null ? "" : r.desc;
                a.forumDate = r.forumDate == null ? "" : r.forumDate;
                a.hideUpd = r.hiddenUpd;
                a.group = r.grp == null ? "" : r.grp;
                hidden.add(a);
            }
            java.util.Collections.sort(hidden, (x, y) -> x.label.compareToIgnoreCase(y.label));
            ui.post(() -> {
                items.clear(); items.addAll(hidden);
                adapter.notifyDataSetChanged();
                status.setText(items.isEmpty() ? "Скрытых нет" : items.size() + " скрыто");
            });
        });
    }

    @Override public void onOpen(AppItem a) { if (a.topicId > 0) FilesActivity.open(this, a.pkg, a.label, a.topicId); }
    @Override public void onIconNeeded(AppItem a, int pos) {
        iconPool.execute(() -> {
            android.graphics.drawable.Drawable d = AppItem.loadIcon(this, a.pkg);
            if (d == null) return; a.icon = d;
            ui.post(() -> { int i = items.indexOf(a); if (i >= 0) adapter.notifyItemChanged(i); });
        });
    }
    @Override public void onFlag(AppItem a, String col, int val) {
        work.execute(() -> {
            if (col.equals("fav")) { a.fav = val != 0; store.setFlag(a.pkg, "flags", (a.fav ? 1 : 0) | (a.hidden ? 2 : 0)); }
            else if (col.equals("hidden")) { a.hidden = val != 0; store.setFlag(a.pkg, "flags", (a.fav ? 1 : 0) | (a.hidden ? 2 : 0)); }
            else if (col.equals("hidden_updates")) { a.hideUpd = val; store.setFlag(a.pkg, "hidden_updates", val); }
            ui.post(this::load);   // разкрыли — уходит из списка
        });
    }
    @Override public void onLink(AppItem a) { SearchActivity.openLink(this, a.pkg, a.label); }
    @Override public void onUninstall(AppItem a) { try { startActivity(new Intent(Intent.ACTION_DELETE, android.net.Uri.parse("package:" + a.pkg))); } catch (Throwable ignored) {} }
    @Override public void onLaunch(AppItem a) { try { Intent i = getPackageManager().getLaunchIntentForPackage(a.pkg); if (i != null) startActivity(i); } catch (Throwable ignored) {} }
    @Override public void onOpenTopic(AppItem a) {
        String url = a.topicId > 0 ? "https://4pda.to/forum/index.php?showtopic=" + a.topicId : "https://4pda.to/forum/index.php?act=search&query=" + android.net.Uri.encode(a.label);
        try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))); } catch (Throwable ignored) {}
    }
}
