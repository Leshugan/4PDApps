package leshugan.a4pda;

import android.content.Context;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;

public final class RecyclerMargins {
    public static void apply(android.view.View card, Context c) {
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(c, 7);
        lp.leftMargin = Ui.dp(c, 10);
        lp.rightMargin = Ui.dp(c, 10);
        card.setLayoutParams(lp);
    }
}
