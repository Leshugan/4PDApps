package leshugan.a4pda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Установка/удаление любой программы — тихая фоновая сверка (как ManifestPackageReceiver у ag4pda). */
public class PackageChangeReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        try { c.startService(new Intent(c, WorkService.class)); } catch (Throwable ignored) {}
    }
}
