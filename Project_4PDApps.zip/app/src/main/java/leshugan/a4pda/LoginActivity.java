package leshugan.a4pda;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Вход на 4pda: обычная страница входа в WebView; куки сохраняет система (CookieManager),
 *  дальше скачивание закрытых файлов идёт с этими куками. */
public class LoginActivity extends Activity {
    public static void open(Context c) { c.startActivity(new Intent(c, LoginActivity.class)); }

    /** Куки 4pda для заголовка при скачивании; пусто, если входа не было. */
    public static String cookies() {
        try {
            String ck = CookieManager.getInstance().getCookie("https://4pda.to");
            return ck == null ? "" : ck;
        } catch (Throwable t) { return ""; }
    }

    public static boolean loggedIn() { return cookies().contains("member_id="); }

    /** Выход: гасим сессионные куки 4pda (точечно, не трогая остальное). */
    public static void logout() {
        try {
            CookieManager cm = CookieManager.getInstance();
            String[] names = { "member_id", "pass_hash", "session_id", "ipsconnect_4pda" };
            for (String host : new String[]{ "https://4pda.to", "https://.4pda.to" })
                for (String n : names)
                    cm.setCookie(host, n + "=; Max-Age=0; path=/");
            cm.flush();
        } catch (Throwable ignored) {}
    }

    private WebView web;
    private boolean was;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        was = loggedIn();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21)
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                CookieManager.getInstance().flush();
                if (!was && loggedIn()) {
                    Toast.makeText(LoginActivity.this, "Вход выполнен", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
        setContentView(wrapUi(web));
        web.loadUrl("https://4pda.to/forum/index.php?act=auth");
    }

    /** Шапка «← Вход на 4pda» в цветах темы, как на прочих экранах IA. */
    private android.view.View wrapUi(WebView w) {
        Theme.load(this);
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        android.widget.LinearLayout bar = new android.widget.LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        android.widget.TextView back = new android.widget.TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        android.widget.TextView t = new android.widget.TextView(this);
        t.setText("Вход на 4pda"); t.setTextColor(Theme.TEXT); t.setTextSize(20);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(t, new android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(bar, new android.widget.LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56)));

        root.addView(w, new android.widget.LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
