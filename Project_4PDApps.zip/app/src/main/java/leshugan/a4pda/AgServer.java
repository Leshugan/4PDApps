package leshugan.a4pda;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Клиент сервера App&Game (freeman42). Форма запроса — ровно та, что доказана в вебной версии:
 * key/hash/app_ver в СТРОКЕ ЗАПРОСА, device_info в ТЕЛЕ POST; app_ver обязательно с кодом сборки в скобках.
 * key = reverse(base64(ANDROID_ID)), hash = md5(ANDROID_ID).
 */
public class AgServer {
    private static final String BASE = "https://srv1.freeman42.ru/app4pda.v3/";
    private static final String APP_VER = "5.3 beta 9 (539)";
    private static final String UA = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).build();
    private final String key, hash, deviceInfo;

    public AgServer(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("t4ag", Context.MODE_PRIVATE);
        String raw = sp.getString("raw", null);
        if (raw == null || raw.isEmpty()) {
            try { raw = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID); } catch (Throwable ignored) {}
            if (raw == null || raw.isEmpty()) raw = Long.toHexString(System.nanoTime());
            sp.edit().putString("raw", raw).apply();
        }
        this.key = reverse(base64(raw));
        this.hash = md5(raw);
        this.deviceInfo = buildDeviceInfo(ctx, raw);
    }

    /** device_info РОВНО как в доказанной вебной форме: 13 полей через «|»,
     *  пустые заменяются на unknown — сервер разбирает их по частям и с неполным набором ломается. */
    private static String buildDeviceInfo(Context ctx, String aid) {
        int dens = 320, w = 1080, h = 1920;
        try {
            android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
            dens = dm.densityDpi; w = dm.widthPixels; h = dm.heightPixels;
        } catch (Throwable ignored) {}
        String[] parts = new String[] {
                aid,
                android.os.Build.MANUFACTURER,
                android.os.Build.MODEL,
                android.os.Build.DEVICE,
                android.os.Build.PRODUCT,
                android.os.Build.BRAND,
                android.os.Build.HARDWARE,
                android.os.Build.BOARD,
                android.os.Build.VERSION.RELEASE,
                java.util.Locale.getDefault().toString(),
                String.valueOf(android.os.Build.VERSION.SDK_INT),
                String.valueOf(dens),
                w + "x" + h
        };
        StringBuilder db = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            String v = parts[i] == null || parts[i].isEmpty() ? "unknown" : parts[i];
            if (i > 0) db.append("|");
            db.append(v);
        }
        return db.toString();
    }

    private String auth() {
        return "key=" + enc(key) + "&hash=" + hash + "&app_ver=" + enc(APP_VER);
    }

    /** Пакетный запрос сведений по списку пакетов (до 40). Возвращает pkg -> {topicId, ver, upd(YYYYMMDD), desc, name, iconUrl}. */
    public Map<String, JSONObject> getAppInfo(List<String> packages) {
        Map<String, JSONObject> out = new HashMap<>();
        if (packages.isEmpty()) return out;
        StringBuilder joined = new StringBuilder();
        for (int i = 0; i < packages.size(); i++) { if (i > 0) joined.append("|"); joined.append(packages.get(i)); }
        try {
            String url = BASE + "getAppInfo.php?" + auth() + "&packages=" + enc(joined.toString());
            RequestBody body = RequestBody.create(("device_info=" + enc(deviceInfo)).getBytes("UTF-8"),
                    okhttp3.MediaType.parse("application/x-www-form-urlencoded"));
            Request req = new Request.Builder().url(url)
                    .header("User-Agent", UA)
                    .post(body).build();
            try (Response r = http.newCall(req).execute()) {
                String s = r.body() != null ? r.body().string() : "";
                JSONObject o = new JSONObject(s);
                JSONArray data = o.optJSONArray("data");
                if (data != null) for (int i = 0; i < data.length(); i++) {
                    JSONObject x = data.optJSONObject(i);
                    if (x == null) continue;
                    String pk = x.optString("pack_name", "");
                    if (!pk.isEmpty()) out.put(pk, x);
                }
            }
        } catch (Throwable ignored) {}
        return out;
    }

    /** Файлы темы (getFileInfo?topic_id=). Возвращает список записей как есть. */
    public JSONArray getFileInfo(long topicId) {
        try {
            String url = BASE + "getFileInfo.php?" + auth() + "&topic_id=" + topicId;
            RequestBody body = RequestBody.create(("device_info=" + enc(deviceInfo)).getBytes("UTF-8"),
                    okhttp3.MediaType.parse("application/x-www-form-urlencoded"));
            Request req = new Request.Builder().url(url)
                    .header("User-Agent", UA)
                    .post(body).build();
            try (Response r = http.newCall(req).execute()) {
                String s = r.body() != null ? r.body().string() : "";
                JSONObject o = new JSONObject(s);
                return o.optJSONArray("data");
            }
        } catch (Throwable ignored) { return null; }
    }

    // helpers
    private static String enc(String s) { try { return java.net.URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; } }
    private static String base64(String s) {
        try { return android.util.Base64.encodeToString(s.getBytes("UTF-8"), android.util.Base64.NO_WRAP); }
        catch (Exception e) { return ""; }
    }
    private static String reverse(String s) { return new StringBuilder(s).reverse().toString(); }
    private static String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
}
