package leshugan.a4pda;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Сравнение версий как в вебной версии: числовая база + ранг пре-релиза (alpha/beta/rc) + номер сборки. */
public final class Ver {
    private static final Pattern NUM = Pattern.compile("\\d+");

    private static int rank(String s) {
        s = s.toLowerCase();
        if (s.contains("alpha") || s.contains("preview")) return 1;
        if (s.contains("beta") || Pattern.compile("\\bb\\d").matcher(s).find()) return 2;
        if (s.contains("rc")) return 3;
        return 9; // релиз
    }

    private static long buildNum(String s) {
        Matcher m = Pattern.compile("(?:build|beta|alpha|rc|b)[\\s._-]*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(s);
        long last = 0;
        while (m.find()) { try { last = Long.parseLong(m.group(1)); } catch (Exception ignored) {} }
        return last;
    }

    public static int cmp(String a, String b) {
        if (a == null) a = ""; if (b == null) b = "";
        if (a.equals(b)) return 0;
        int[] pa = nums(a), pb = nums(b);
        int n = Math.max(pa.length, pb.length);
        for (int i = 0; i < n; i++) {
            int x = i < pa.length ? pa[i] : 0;
            int y = i < pb.length ? pb[i] : 0;
            if (x != y) return x < y ? -1 : 1;
        }
        int ra = rank(a), rb = rank(b);
        if (ra != rb) return ra < rb ? -1 : 1;
        long ba = buildNum(a), bb = buildNum(b);
        if (ba != bb) return ba < bb ? -1 : 1;
        return 0;
    }

    private static int[] nums(String s) {
        // берём числовую базу ДО первого пре-релизного слова, чтобы 5.3 и 5.3beta9 сравнивались корректно
        String base = s.split("(?i)(alpha|beta|preview|rc|\\bb\\d)")[0];
        Matcher m = NUM.matcher(base);
        java.util.List<Integer> l = new java.util.ArrayList<>();
        while (m.find()) { try { l.add(Integer.parseInt(m.group())); } catch (Exception e) { l.add(0); } }
        int[] out = new int[l.size()];
        for (int i = 0; i < out.length; i++) out[i] = l.get(i);
        return out;
    }
}
