package leshugan.a4pda;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Экран настроек — вёрстка IA: шапка «← Настройки», секции с заголовком 13.5 bold,
 *  строки-переключатели с пилюлей 42×24 и строки-переходы с шевроном ›. */
public class SettingsActivity extends Activity {
    public static void open(Context c) { c.startActivity(new Intent(c, SettingsActivity.class)); }

    private LinearLayout body;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        setContentView(buildUi());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        TextView back = new TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Настройки"); title.setTextColor(Theme.TEXT); title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56)));

        ScrollView sc = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, 0, 0, Ui.dp(this, 24));
        sc.addView(body, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        build();
        return root;
    }

    private void build() {
        body.removeAllViews();

        // Вид
        LinearLayout secView = section("Вид");
        String tid = Prefs.theme(this);
        String tname = "system".equals(tid) ? "Системная" : Palettes.byId(tid).name;
        secView.addView(rowArrow("Тема", tname, () -> ThemesActivity.open(this)));

        // Разделы
        LinearLayout secSec = section("Разделы");
        secSec.addView(toggle("Показывать системные приложения", Prefs.showSystem(this), on -> Prefs.setShowSystem(this, on)));

        // 4pda
        LinearLayout sec4 = section("4pda");
        boolean in = LoginActivity.loggedIn();
        sec4.addView(rowArrow(in ? "Выйти из аккаунта" : "Войти на 4pda",
                in ? "Вход выполнен — закрытые файлы качаются" : "Нужен для закрытых файлов", () -> {
            if (LoginActivity.loggedIn()) {
                LoginActivity.logout();
                Toast.makeText(this, "Вы вышли", Toast.LENGTH_SHORT).show();
                build();
            } else LoginActivity.open(this);
        }));

        // Обновления
        LinearLayout secUpd = section("Обновления");
        secUpd.addView(rowArrow("Проверить сейчас", "Сверка версий с App&Game и Google Play", () -> {
            UpdateJob.runOnce(this);
            Toast.makeText(this, "Проверка запущена", Toast.LENGTH_SHORT).show();
        }));
        long last = Prefs.lastCheck(this);
        String when = last > 0 ? android.text.format.DateFormat.format("dd.MM.yy HH:mm", last).toString() : "ещё не было";
        secUpd.addView(rowArrow("Последняя проверка", when, () -> {}));
    }

    private LinearLayout section(String name) {
        LinearLayout sec = new LinearLayout(this);
        sec.setOrientation(LinearLayout.VERTICAL);
        sec.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16));
        View line = new View(this);
        line.setBackgroundColor(Theme.DIVIDER);
        body.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(this, 1))));
        TextView t = new TextView(this);
        t.setText(name); t.setTextColor(Theme.TEXT); t.setTextSize(13.5f);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, 0, 0, Ui.dp(this, 10));
        sec.addView(t);
        body.addView(sec, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sec;
    }

    interface OnToggle { void set(boolean on); }

    /** Строка-переключатель с пилюлей 42×24, как в IA. */
    private View toggle(String label, boolean on, OnToggle cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));

        TextView t = new TextView(this);
        t.setText(label); t.setTextColor(Theme.SUB); t.setTextSize(13.5f);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final FrameLikePill pill = new FrameLikePill(this, on);
        row.addView(pill.view, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 24)));

        row.setOnClickListener(v -> { pill.toggle(); cb.set(pill.on); });
        return row;
    }

    /** Строка-переход со стрелкой ›, как в IA (заголовок + подпись). */
    private View rowArrow(String label, String sub, Runnable go) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(label); t.setTextColor(Theme.TEXT); t.setTextSize(15);
        mid.addView(t);
        if (sub != null && !sub.isEmpty()) {
            TextView s = new TextView(this);
            s.setText(sub); s.setTextColor(Theme.SUB); s.setTextSize(12.5f);
            mid.addView(s);
        }
        row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView ch = new TextView(this);
        ch.setText("\u203a"); ch.setTextColor(Theme.SUB); ch.setTextSize(22);
        row.addView(ch);
        row.setOnClickListener(v -> go.run());
        return row;
    }

    /** Пилюля-переключатель: фон акцент/серый, кружок слева-справа. */
    private class FrameLikePill {
        final LinearLayout view;
        final View knob;
        boolean on;
        FrameLikePill(Context c, boolean on) {
            this.on = on;
            view = new LinearLayout(c);
            view.setGravity(Gravity.CENTER_VERTICAL);
            knob = new View(c);
            GradientDrawable k = new GradientDrawable();
            k.setShape(GradientDrawable.OVAL);
            k.setColor(Color.WHITE);
            knob.setBackground(k);
            LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(Ui.dp(c, 20), Ui.dp(c, 20));
            klp.leftMargin = Ui.dp(c, 2);
            view.addView(knob, klp);
            render();
        }
        void toggle() { on = !on; render(); }
        void render() {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(Ui.dp(SettingsActivity.this, 12));
            bg.setColor(on ? Theme.ACC : (Theme.DARK ? Color.parseColor("#3A3128") : Color.parseColor("#C9D0D8")));
            view.setBackground(bg);
            LinearLayout.LayoutParams klp = (LinearLayout.LayoutParams) knob.getLayoutParams();
            klp.leftMargin = Ui.dp(SettingsActivity.this, on ? 20 : 2);
            knob.setLayoutParams(klp);
        }
    }
}
