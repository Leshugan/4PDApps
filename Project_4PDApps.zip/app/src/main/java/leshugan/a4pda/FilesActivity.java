package leshugan.a4pda;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Экран «Скачать»: все файлы темы + вкладка «Другая подпись», диалог «Начать закачку?». */
public class FilesActivity extends Activity {
    public static void open(Context c, String pkg, String label, long topicId) {
        Intent i = new Intent(c, FilesActivity.class);
        i.putExtra("pkg", pkg); i.putExtra("label", label); i.putExtra("topic", topicId);
        c.startActivity(i);
    }

    private final List<FileItem> all = new ArrayList<>();
    private final List<FileItem> shown = new ArrayList<>();
    private FilesAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private String pkg = "", label = "", mySig = "";
    private long topicId = 0;
    private int tab = 0;               // 0 = все файлы, 1 = другая подпись
    private TextView tabAll, tabDiff, status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pkg = getIntent().getStringExtra("pkg");
        label = getIntent().getStringExtra("label");
        topicId = getIntent().getLongExtra("topic", 0);
        mySig = mySigMd5(pkg);
        setContentView(buildUi());
        load();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTextColor(Theme.TEXT);
        back.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 14), Ui.dp(this, 2));
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Скачать · " + (label == null ? "" : label));
        title.setTextColor(Theme.TEXT);
        title.setTextSize(18);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setBackgroundColor(Theme.BAR);
        tabs.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 8));
        tabAll = tabView("Все файлы");
        tabDiff = tabView("Другая подпись");
        tabAll.setOnClickListener(v -> setTab(0));
        tabDiff.setOnClickListener(v -> setTab(1));
        tabs.addView(tabAll);
        tabs.addView(tabDiff);
        root.addView(tabs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB);
        status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        status.setText("Загрузка…");
        root.addView(status);

        RecyclerView list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        adapter = new FilesAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private TextView tabView(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(14);
        tv.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 22), Ui.dp(this, 6));
        return tv;
    }

    private void setTab(int t) {
        tab = t;
        tabAll.setTextColor(t == 0 ? Theme.ACC : Theme.SUB);
        tabAll.setTypeface(null, t == 0 ? Typeface.BOLD : Typeface.NORMAL);
        tabDiff.setTextColor(t == 1 ? Theme.ACC : Theme.SUB);
        tabDiff.setTypeface(null, t == 1 ? Typeface.BOLD : Typeface.NORMAL);
        refilter();
    }

    /** «differ» — сервер знает подпись этого файла, файл того же пакета, а подпись другая. */
    private int sigState(FileItem f) {
        if (f.sig == null || f.sig.isEmpty() || mySig.isEmpty()) return 0;      // неизвестно
        if (f.pkg != null && !f.pkg.isEmpty() && !f.pkg.equals(pkg)) return 0;  // другой пакет — сравнивать не с чем
        return f.sig.equalsIgnoreCase(mySig) ? 1 : 2;                           // 1=совпадает, 2=другая
    }

    private void refilter() {
        shown.clear();
        for (FileItem f : all) {
            int s = sigState(f);
            if (tab == 1 ? s == 2 : s != 2) shown.add(f);
        }
        adapter.notifyDataSetChanged();
        int diff = 0;
        for (FileItem f : all) if (sigState(f) == 2) diff++;
        tabAll.setText("Все файлы " + (all.size() - diff));
        tabDiff.setText("Другая подпись" + (diff > 0 ? " " + diff : ""));
    }

    private void load() {
        work.execute(() -> {
            AgServer ag = new AgServer(this);
            FilesLoader.load(ag, topicId, items -> ui.post(() -> {
                all.clear(); all.addAll(items);
                status.setText(all.size() + " файлов");
                refilter();
            }));
            ui.post(() -> { if (all.isEmpty()) status.setText("Файлы не найдены"); });
        });
    }

    private void showDialog(FileItem f) {
        SpannableStringBuilder msg = new SpannableStringBuilder();
        String appName = label == null ? "" : label;
        line(msg, "Название", appName);
        line(msg, "Имя файла", f.name);
        String ver = f.ver == null ? "" : f.ver;
        if (f.code > 0) ver = ver.isEmpty() ? "(" + f.code + ")" : ver + " (" + f.code + ")";
        line(msg, "Версия", ver);
        String size = !f.sizeText.isEmpty() ? f.sizeText : Ui.sizeFmt(f.sizeBytes);
        line(msg, "Размер", size);
        line(msg, "Имя пакета", f.pkg);
        CharSequence req = Ui.reqLine(f.flags, f.minSdk);
        if (req != null) { msg.append("Требования: ").append(req).append("\n"); }
        line(msg, "CRC32", f.crc);
        line(msg, "Добавлено", f.added);
        int s = sigState(f);
        if (s == 2) msg.append("\nПодпись не совпадает с установленной — поверх не встанет.\n");
        if (s == 1) msg.append("\nПодпись совпадает с установленной.\n");

        new AlertDialog.Builder(this)
                .setTitle("Начать закачку?")
                .setMessage(msg)
                .setPositiveButton("Скачать", (d, w) -> download(f))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private static void line(SpannableStringBuilder sb, String k, String v) {
        if (v == null || v.isEmpty()) return;
        sb.append(k).append(": ").append(v).append("\n");
    }

    private void download(FileItem f) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(f.url));
            req.setTitle(f.name);
            String ck = LoginActivity.cookies();                            // вход выполнен — закрытые файлы качаются с сессией
            if (!ck.isEmpty()) req.addRequestHeader("Cookie", ck);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, f.name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) { dm.enqueue(req); Toast.makeText(this, "Закачка началась", Toast.LENGTH_SHORT).show(); }
        } catch (Throwable t) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(f.url))); } catch (Throwable ignored) {}
        }
    }

    private String mySigMd5(String pkg) {
        try {
            android.content.pm.PackageInfo pi;
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                pi = getPackageManager().getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
                android.content.pm.Signature[] ss = pi.signingInfo != null ? pi.signingInfo.getApkContentsSigners() : null;
                if (ss == null || ss.length == 0) return "";
                return md5(ss[0].toByteArray());
            } else {
                pi = getPackageManager().getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNATURES);
                if (pi.signatures == null || pi.signatures.length == 0) return "";
                return md5(pi.signatures[0].toByteArray());
            }
        } catch (Throwable t) { return ""; }
    }
    private static String md5(byte[] b) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02X", x));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    // ---- список ----
    private class FilesAdapter extends RecyclerView.Adapter<FilesAdapter.VH> {
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) { return new VH(rowView()); }
        @Override public int getItemCount() { return shown.size(); }
        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            FileItem f = shown.get(pos);
            int s = sigState(f);
            String title = (f.ver != null && !f.ver.isEmpty()) ? (appTitle() + " " + f.ver) : f.name;
            h.title.setText((s == 1 ? "✓ " : "") + title);
            h.title.setTextColor(s == 2 ? Theme.ACC : Theme.TEXT);
            h.sub.setText(f.name);
            StringBuilder meta = new StringBuilder();
            if (f.dl >= 0) meta.append("Скачиваний: ").append(f.dl);
            if (!f.added.isEmpty()) { if (meta.length() > 0) meta.append(" · "); meta.append("Добавлено: ").append(f.added); }
            h.meta.setText(meta.toString());
            h.meta.setVisibility(meta.length() > 0 ? View.VISIBLE : View.GONE);
            CharSequence req = Ui.reqLine(f.flags, f.minSdk);
            h.req.setText(req == null ? "" : req);
            h.req.setVisibility(req == null ? View.GONE : View.VISIBLE);
            String size = !f.sizeText.isEmpty() ? f.sizeText : Ui.sizeFmt(f.sizeBytes);
            h.size.setText(size);
            h.itemView.setOnClickListener(v -> showDialog(f));
        }
        private String appTitle() { return label == null || label.isEmpty() ? "" : label; }

        class VH extends RecyclerView.ViewHolder {
            TextView title, sub, meta, req, size;
            VH(View v) {
                super(v);
                title = v.findViewWithTag("t"); sub = v.findViewWithTag("s");
                meta = v.findViewWithTag("m"); req = v.findViewWithTag("r"); size = v.findViewWithTag("z");
            }
        }
    }

    private View rowView() {
        Context c = this;
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.HORIZONTAL);
        RecyclerMargins.apply(card, c);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Theme.CARD);
        bg.setCornerRadius(Ui.dp(c, 10));
        bg.setStroke(Ui.dp(c, 1), Theme.BORDER);
        card.setBackground(bg);
        card.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        card.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView t = new TextView(c); t.setTag("t"); t.setTextSize(15); t.setTextColor(Theme.TEXT); mid.addView(t);
        TextView s = new TextView(c); s.setTag("s"); s.setTextSize(12); s.setTextColor(Theme.SUB);
        s.setMaxLines(1); s.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); mid.addView(s);
        TextView m = new TextView(c); m.setTag("m"); m.setTextSize(12); m.setTextColor(Theme.SUB); mid.addView(m);
        TextView r = new TextView(c); r.setTag("r"); r.setTextSize(12); r.setTextColor(Theme.SUB); mid.addView(r);

        TextView z = new TextView(c); z.setTag("z"); z.setTextSize(12.5f); z.setTextColor(Theme.SUB);
        z.setGravity(Gravity.END);
        LinearLayout.LayoutParams zlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        zlp.leftMargin = Ui.dp(c, 10);
        card.addView(z, zlp);
        return card;
    }
}
