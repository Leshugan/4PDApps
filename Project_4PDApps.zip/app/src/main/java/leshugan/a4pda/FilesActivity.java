package leshugan.a4pda;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Экран «Скачать»: все файлы темы + вкладка «Другая подпись», диалог «Начать закачку?». */
public class FilesActivity extends Activity {
    public static void open(Context c, String pkg, String label, long topicId) {
        Intent i = new Intent(c, FilesActivity.class);
        i.putExtra("pkg", pkg); i.putExtra("label", label); i.putExtra("topic", topicId);
        c.startActivity(i);
    }

    private final List<FileItem> all = new ArrayList<>();
    private final List<FileItem> shown = new ArrayList<>();
    private FilesAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private String pkg = "", label = "", mySig = "";
    private long topicId = 0;
    private int tab = 0;               // 0 = все файлы, 1 = другая подпись
    private int fShow = 300;           // показываем порциями, как IA (кнопка «Показать ещё»)
    private int deviceAbiMask = 0;     // маска процессоров устройства в терминах флагов App&Game
    private TextView tabAll, tabDiff, status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        pkg = getIntent().getStringExtra("pkg");
        label = getIntent().getStringExtra("label");
        topicId = getIntent().getLongExtra("topic", 0);
        mySig = mySigMd5(pkg);
        deviceAbiMask = deviceAbis();
        setContentView(buildUi());
        load();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        TextView back = new TextView(this);
        back.setText("\u2190");
        back.setTextSize(24);
        back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Скачать · " + (label == null ? "" : label));
        title.setTextColor(Theme.TEXT);
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setBackgroundColor(Theme.BAR);
        tabs.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 8));
        tabAll = tabView("Все файлы");
        tabDiff = tabView("Другая подпись");
        tabAll.setOnClickListener(v -> setTab(0));
        tabDiff.setOnClickListener(v -> setTab(1));
        tabs.addView(tabAll);
        tabs.addView(tabDiff);
        root.addView(tabs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB);
        status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        status.setText("Загрузка…");
        root.addView(status);

        RecyclerView list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        adapter = new FilesAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private TextView tabView(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(14);
        tv.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 22), Ui.dp(this, 6));
        return tv;
    }

    private void setTab(int t) {
        tab = t;
        fShow = 300;
        tabAll.setTextColor(t == 0 ? Theme.ACC : Theme.SUB);
        tabAll.setTypeface(null, t == 0 ? Typeface.BOLD : Typeface.NORMAL);
        tabDiff.setTextColor(t == 1 ? Theme.ACC : Theme.SUB);
        tabDiff.setTypeface(null, t == 1 ? Typeface.BOLD : Typeface.NORMAL);
        refilter();
    }

    /** Маска процессоров устройства в терминах флагов сервера App&Game. */
    private int deviceAbis() {
        int m = 0;
        try {
            for (String a : android.os.Build.SUPPORTED_ABIS) {
                if (a == null) continue;
                switch (a) {
                    case "armeabi": case "armeabi-v7a": m |= Ui.AG_ARM; break;
                    case "arm64-v8a": m |= Ui.AG_ARM64; break;
                    case "x86": m |= Ui.AG_X86; break;
                    case "x86_64": m |= Ui.AG_X64; break;
                    case "mips": case "mips64": m |= Ui.AG_MIPS; break;
                }
            }
        } catch (Throwable ignored) {}
        return m;
    }

    /** Файл под ЧУЖОЙ процессор: у файла заданы ABI, но ни один не совпадает с устройством. */
    private boolean badArch(FileItem f) {
        if (f.flags == 0 || deviceAbiMask == 0) return false;
        return (f.flags & deviceAbiMask) == 0;
    }

    /** «differ» — сервер знает подпись этого файла, файл того же пакета, а подпись другая. */
    private int sigState(FileItem f) {
        if (f.sig == null || f.sig.isEmpty() || mySig.isEmpty()) return 0;      // неизвестно
        if (f.pkg != null && !f.pkg.isEmpty() && !f.pkg.equals(pkg)) return 0;  // другой пакет — сравнивать не с чем
        return f.sig.equalsIgnoreCase(mySig) ? 1 : 2;                           // 1=совпадает, 2=другая
    }

    private void refilter() {
        shown.clear();
        for (FileItem f : all) {
            int s = sigState(f);
            if (tab == 1 ? s == 2 : s != 2) shown.add(f);
        }
        adapter.notifyDataSetChanged();
        int diff = 0;
        for (FileItem f : all) if (sigState(f) == 2) diff++;
        tabAll.setText("Все файлы " + (all.size() - diff));
        tabDiff.setText("Другая подпись" + (diff > 0 ? " " + diff : ""));
    }

    private void load() {
        work.execute(() -> {
            AgServer ag = new AgServer(this);
            FilesLoader.load(ag, topicId, items -> ui.post(() -> {
                all.clear(); all.addAll(items);
                status.setText(all.size() + " файлов");
                refilter();
            }));
            ui.post(() -> { if (all.isEmpty()) status.setText("Файлы не найдены"); });
        });
    }

    private void showDialog(FileItem f) {
        SpannableStringBuilder msg = new SpannableStringBuilder();
        line(msg, "Название", label == null ? "" : label);
        line(msg, "Имя файла", f.name);
        String ver = f.ver == null ? "" : f.ver;
        if (f.code > 0) ver = ver.isEmpty() ? "(" + f.code + ")" : ver + " (" + f.code + ")";
        line(msg, "Версия", ver);
        String size = !f.sizeText.isEmpty() ? f.sizeText : Ui.sizeFmt(f.sizeBytes);
        line(msg, "Размер", size);
        line(msg, "Имя пакета", f.pkg);
        CharSequence req = Ui.reqLine(f.flags, f.minSdk);
        if (req != null) { msg.append("Требования: ").append(req).append("\n"); }
        if (f.crc != null && !f.crc.isEmpty()) {
            try { line(msg, "CRC32", Long.toHexString(Long.parseLong(f.crc)).toUpperCase()); }
            catch (Throwable t) { line(msg, "CRC32", f.crc); }
        }
        line(msg, "Добавлено", f.added);
        // предупреждения как в IA
        if (badArch(f)) {
            msg.append("\nЭтот файл предназначен для другого типа процессора, на вашем устройстве он не заработает.\n");
        } else {
            int s = sigState(f);
            if (f.pkg != null && !f.pkg.isEmpty() && !f.pkg.equals(pkg))
                msg.append("\nЭто отдельное приложение (").append(f.pkg).append("), у вас оно не установлено — подпись сравнивать не с чем.\n");
            else if (s == 2)
                msg.append("\nПодпись у этого файла не совпадает с подписью установленной версии. Перед установкой нужно будет удалить установленную программу.\n");
        }

        new AlertDialog.Builder(this)
                .setTitle("Начать закачку?")
                .setMessage(msg)
                .setPositiveButton("Скачать", (d, w) -> download(f))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private static void line(SpannableStringBuilder sb, String k, String v) {
        if (v == null || v.isEmpty()) return;
        sb.append(k).append(": ").append(v).append("\n");
    }

    private void download(FileItem f) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(f.url));
            req.setTitle(f.name);
            String ck = LoginActivity.cookies();                            // вход выполнен — закрытые файлы качаются с сессией
            if (!ck.isEmpty()) req.addRequestHeader("Cookie", ck);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, f.name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) { dm.enqueue(req); Toast.makeText(this, "Закачка началась", Toast.LENGTH_SHORT).show(); }
        } catch (Throwable t) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(f.url))); } catch (Throwable ignored) {}
        }
    }

    private String mySigMd5(String pkg) {
        try {
            android.content.pm.PackageInfo pi;
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                pi = getPackageManager().getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
                android.content.pm.Signature[] ss = pi.signingInfo != null ? pi.signingInfo.getApkContentsSigners() : null;
                if (ss == null || ss.length == 0) return "";
                return md5(ss[0].toByteArray());
            } else {
                pi = getPackageManager().getPackageInfo(pkg, android.content.pm.PackageManager.GET_SIGNATURES);
                if (pi.signatures == null || pi.signatures.length == 0) return "";
                return md5(pi.signatures[0].toByteArray());
            }
        } catch (Throwable t) { return ""; }
    }
    private static String md5(byte[] b) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02X", x));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    // ---- список ----
    private static final int T_ROW = 0, T_MORE = 1;

    private class FilesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemCount() {
            int n = Math.min(shown.size(), fShow);
            return n + (shown.size() > fShow ? 1 : 0);
        }
        @Override public int getItemViewType(int pos) {
            return (pos == Math.min(shown.size(), fShow) && shown.size() > fShow) ? T_MORE : T_ROW;
        }
        @NonNull @Override public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int vt) {
            if (vt == T_MORE) return new MoreVH(moreView());
            return new VH(rowView());
        }
        @Override public void onBindViewHolder(@NonNull RecyclerView.ViewHolder hv, int pos) {
            if (hv instanceof MoreVH) {
                ((MoreVH) hv).tv.setText("Показать ещё (" + (shown.size() - fShow) + ")");
                ((MoreVH) hv).tv.setOnClickListener(v -> { fShow += 300; notifyDataSetChanged(); });
                return;
            }
            VH h = (VH) hv;
            FileItem f = shown.get(pos);
            int st = sigState(f);
            boolean bad = badArch(f);
            // цвет названия как в IA: чужой процессор → красный; другая подпись → голубой; совпадение → серый+✓; иначе обычный
            int nameColor = Theme.TEXT;
            if (st == 1) nameColor = Theme.SUB;
            if (st == 2) nameColor = Theme.ACC;
            if (bad) nameColor = Theme.RED;
            String ver = (f.ver != null && !f.ver.isEmpty()) ? f.ver : "";
            String head = (st == 1 ? "✓ " : "") + appTitle() + (ver.isEmpty() ? "" : " " + Ui.shortVer(ver));
            h.title.setText(head.trim());
            h.title.setTextColor(nameColor);
            h.sub.setText(f.name);
            h.sub.setTextColor(bad ? Theme.RED : Theme.SUB);
            StringBuilder meta = new StringBuilder();
            if (f.dl >= 0) meta.append("Скачиваний: ").append(f.dl);
            if (!f.added.isEmpty()) { if (meta.length() > 0) meta.append(" · "); meta.append("Добавлено: ").append(f.added); }
            h.meta.setText(meta.toString());
            h.meta.setVisibility(meta.length() > 0 ? View.VISIBLE : View.GONE);
            String size = !f.sizeText.isEmpty() ? f.sizeText : Ui.sizeFmt(f.sizeBytes);
            h.size.setText(size);
            CharSequence req = Ui.reqLine(f.flags, f.minSdk);
            h.req.setText(req == null ? "" : req);
            h.req.setVisibility(req == null ? View.GONE : View.VISIBLE);
            h.itemView.setOnClickListener(v -> showDialog(f));
            boolean hasPost = f.postUrl != null && !f.postUrl.isEmpty();
            h.info.setVisibility(hasPost ? View.VISIBLE : View.GONE);
            h.info.setOnClickListener(v -> PostActivity.open(FilesActivity.this,
                    hasPost ? f.postUrl : ("https://4pda.to/forum/index.php?showtopic=" + topicId), f.name));
        }
        private String appTitle() { return label == null ? "" : label; }

        class VH extends RecyclerView.ViewHolder {
            TextView title, sub, meta, req, size, info;
            VH(View v) {
                super(v);
                title = v.findViewWithTag("t"); sub = v.findViewWithTag("s");
                meta = v.findViewWithTag("m"); req = v.findViewWithTag("r"); size = v.findViewWithTag("z");
                info = v.findViewWithTag("info");
            }
        }
        class MoreVH extends RecyclerView.ViewHolder { TextView tv; MoreVH(View v){ super(v); tv=(TextView)v; } }
    }

    /** Строка файла — плоская, с верхним разделителем, как в IA (не карточка). */
    private View rowView() {
        Context c = this;
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.setBackgroundColor(Theme.CARD);
        row.setPadding(Ui.dp(c, 18), Ui.dp(c, 12), Ui.dp(c, 18), Ui.dp(c, 12));

        View top = new View(c);
        top.setBackgroundColor(Theme.BORDER);
        row.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(c, 0.5f))));

        TextView t = new TextView(c); t.setTag("t"); t.setTextSize(15); t.setTextColor(Theme.TEXT);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(c, 6); row.addView(t, tlp);

        TextView s = new TextView(c); s.setTag("s"); s.setTextSize(13); s.setTextColor(Theme.SUB); row.addView(s);

        LinearLayout metaRow = new LinearLayout(c);
        metaRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams mrlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mrlp.topMargin = Ui.dp(c, 2); row.addView(metaRow, mrlp);
        TextView m = new TextView(c); m.setTag("m"); m.setTextSize(12.5f); m.setTextColor(Theme.SUB);
        metaRow.addView(m, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView z = new TextView(c); z.setTag("z"); z.setTextSize(12.5f); z.setTextColor(Theme.SUB); z.setGravity(Gravity.END);
        metaRow.addView(z);
        TextView info = new TextView(c); info.setTag("info"); info.setText("!");
        info.setTextColor(Theme.ACC); info.setTextSize(14); info.setTypeface(null, android.graphics.Typeface.BOLD);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(Ui.dp(c, 26), Ui.dp(c, 20));
        ilp.leftMargin = Ui.dp(c, 8);
        metaRow.addView(info, ilp);

        TextView r = new TextView(c); r.setTag("r"); r.setTextSize(12.5f); r.setTextColor(Theme.SUB);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(c, 2); row.addView(r, rlp);
        return row;
    }

    private View moreView() {
        TextView tv = new TextView(this);
        tv.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tv.setText("Показать ещё");
        tv.setTextColor(Theme.ACC);
        tv.setTextSize(14);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, Ui.dp(this, 13), 0, Ui.dp(this, 13));
        return tv;
    }

}
