package leshugan.a4pda;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;

/** Активная палитра приложения. Темы и цвета — те же, что в вебной IA (см. Palettes). */
public final class Theme {
    public static boolean DARK = false;
    public static int BG, BAR, CARD, BORDER, DIVIDER, TEXT, SUB, ACC, RED, ONACC, NAV, BLUE, GREEN;

    public static void load(Context c) {
        String id = Prefs.theme(c);
        if ("system".equals(id)) {
            int mode = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            id = (mode == Configuration.UI_MODE_NIGHT_YES) ? "dark" : "light";
        }
        apply(Palettes.byId(id));
    }

    public static void apply(Palettes.P p) {
        BG = p.bg; BAR = p.bar; CARD = p.card; BORDER = p.border; DIVIDER = p.divider;
        TEXT = p.text; SUB = p.sub; ACC = p.acc; NAV = p.nav; BLUE = p.blue; GREEN = p.green;
        DARK = !p.light;
        RED = p.light ? Color.parseColor("#d14343") : Color.parseColor("#e5675e");
        ONACC = p.light ? Color.parseColor("#ffffff") : Color.parseColor("#1c1710");
    }
}
