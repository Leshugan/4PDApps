package leshugan.a4pda;

import android.graphics.Color;

/** Единая палитра. Светлая — бело-голубая (эталон YevGallery): фон #EEF1F4, панели #FFFFFF, акцент #2F80ED. */
public final class Theme {
    public static boolean DARK = false;
    public static int BG, BAR, CARD, BORDER, DIVIDER, TEXT, SUB, ACC, RED, ONACC;

    /** Светлая — бело-голубая (эталон YevGallery): фон #EEF1F4, панели #FFFFFF, акцент #2F80ED. Тёмная — мягкая. */
    public static void load(android.content.Context c) {
        DARK = Prefs.dark(c);
        if (DARK) {
            BG = Color.parseColor("#15181C"); BAR = Color.parseColor("#1E2329"); CARD = Color.parseColor("#22272E");
            BORDER = Color.parseColor("#2E353D"); DIVIDER = Color.parseColor("#2A3037");
            TEXT = Color.parseColor("#DCDCDC"); SUB = Color.parseColor("#8A929C");
            ACC = Color.parseColor("#4D9FFF"); RED = Color.parseColor("#E5675E"); ONACC = Color.parseColor("#0E1116");
        } else {
            BG = Color.parseColor("#EEF1F4"); BAR = Color.parseColor("#FFFFFF"); CARD = Color.parseColor("#FFFFFF");
            BORDER = Color.parseColor("#D3D8DE"); DIVIDER = Color.parseColor("#E2E6EA");
            TEXT = Color.parseColor("#1E2329"); SUB = Color.parseColor("#6B7280");
            ACC = Color.parseColor("#2F80ED"); RED = Color.parseColor("#D14343"); ONACC = Color.parseColor("#FFFFFF");
        }
    }
}

