package leshugan.a4pda;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Экран «Загрузки»: список из системного DownloadManager, установка готового, корзина. */
public class DownloadsActivity extends Activity {
    public static void open(Context c) { c.startActivity(new Intent(c, DownloadsActivity.class)); }

    static class Dl { long id; String name; int status; long total, done; String localPath; }

    private final List<Dl> items = new ArrayList<>();
    private DlAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private DownloadManager dm;
    private TextView status;
    private final Runnable poll = new Runnable() {
        @Override public void run() { refresh(); ui.postDelayed(this, 1200); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        setContentView(buildUi());
    }
    @Override protected void onResume() { super.onResume(); ui.post(poll); }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(poll); }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        TextView back = new TextView(this);
        back.setText("‹"); back.setTextSize(26); back.setTextColor(Theme.TEXT);
        back.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 14), Ui.dp(this, 2));
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Загрузки"); title.setTextColor(Theme.TEXT); title.setTextSize(18);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView trash = new TextView(this);
        trash.setText("Очистить"); trash.setTextColor(Theme.ACC); trash.setTextSize(14);
        trash.setOnClickListener(v -> clearDialog());
        bar.addView(trash);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB); status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        root.addView(status);

        RecyclerView list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        adapter = new DlAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void refresh() {
        items.clear();
        if (dm != null) {
            Cursor c = null;
            try {
                c = dm.query(new DownloadManager.Query());
                if (c != null) while (c.moveToNext()) {
                    Dl d = new Dl();
                    d.id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                    d.status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    d.total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    d.done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    d.name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    String uriStr = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                    if (uriStr != null) { try { d.localPath = Uri.parse(uriStr).getPath(); } catch (Throwable ignored) {} }
                    if (d.name == null || d.name.isEmpty()) d.name = d.localPath != null ? new File(d.localPath).getName() : ("#" + d.id);
                    items.add(d);
                }
            } catch (Throwable ignored) {} finally { if (c != null) c.close(); }
        }
        adapter.notifyDataSetChanged();
        status.setText(items.isEmpty() ? "Список пуст" : items.size() + " в списке");
    }

    private void clearDialog() {
        if (items.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Очистить загрузки?")
                .setItems(new CharSequence[]{ "Только список", "Вместе с файлами" }, (d, which) -> {
                    for (Dl it : items) {
                        if (which == 1 && it.localPath != null) { try { new File(it.localPath).delete(); } catch (Throwable ignored) {} }
                        try { dm.remove(it.id); } catch (Throwable ignored) {}
                    }
                    refresh();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private String statusText(Dl d) {
        switch (d.status) {
            case DownloadManager.STATUS_SUCCESSFUL: return "Готово";
            case DownloadManager.STATUS_FAILED: return "Ошибка";
            case DownloadManager.STATUS_PAUSED: return "Пауза";
            case DownloadManager.STATUS_PENDING: return "Ожидание";
            default:
                if (d.total > 0) return (int) (d.done * 100 / d.total) + "%";
                return "Качается";
        }
    }

    private class DlAdapter extends RecyclerView.Adapter<DlAdapter.VH> {
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) { return new VH(row()); }
        @Override public int getItemCount() { return items.size(); }
        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            Dl d = items.get(pos);
            h.name.setText(d.name);
            h.sub.setText(statusText(d) + (d.total > 0 ? " · " + Ui.sizeFmt(d.total) : ""));
            boolean ready = d.status == DownloadManager.STATUS_SUCCESSFUL && d.localPath != null;
            h.action.setVisibility(ready ? View.VISIBLE : View.GONE);
            h.action.setOnClickListener(v -> { if (d.localPath != null) ApkInstall.install(DownloadsActivity.this, new File(d.localPath)); });
        }
        class VH extends RecyclerView.ViewHolder {
            TextView name, sub, action;
            VH(View v) { super(v); name = v.findViewWithTag("n"); sub = v.findViewWithTag("s"); action = v.findViewWithTag("a"); }
        }
    }

    private View row() {
        Context c = this;
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        RecyclerMargins.apply(card, c);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Theme.CARD); bg.setCornerRadius(Ui.dp(c, 10)); bg.setStroke(Ui.dp(c, 1), Theme.BORDER);
        card.setBackground(bg);
        card.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        card.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView n = new TextView(c); n.setTag("n"); n.setTextSize(14.5f); n.setTextColor(Theme.TEXT);
        n.setMaxLines(1); n.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); mid.addView(n);
        TextView s = new TextView(c); s.setTag("s"); s.setTextSize(12); s.setTextColor(Theme.SUB); mid.addView(s);

        TextView a = new TextView(c); a.setTag("a"); a.setText("Установить");
        a.setTextColor(Theme.ACC); a.setTextSize(14);
        a.setPadding(Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4));
        card.addView(a);
        return card;
    }
}
