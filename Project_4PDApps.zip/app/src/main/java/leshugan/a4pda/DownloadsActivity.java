package leshugan.a4pda;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Экран «Загрузки»: список из системного DownloadManager, установка готового, корзина. */
public class DownloadsActivity extends Activity {
    public static void open(Context c) { c.startActivity(new Intent(c, DownloadsActivity.class)); }

    static class Dl { long id; String name; int status; long total, done; String localPath; }

    private final List<Dl> items = new ArrayList<>();
    private DlAdapter adapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private DownloadManager dm;
    private TextView status;
    private final Runnable poll = new Runnable() {
        @Override public void run() { refresh(); ui.postDelayed(this, 1200); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        setContentView(buildUi());
    }
    @Override protected void onResume() { super.onResume(); ui.post(poll); }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(poll); }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        TextView back = new TextView(this);
        back.setText("\u2190"); back.setTextSize(24); back.setTextColor(Theme.TEXT);
        back.setPadding(0, 0, Ui.dp(this, 14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = new TextView(this);
        title.setText("Загрузки"); title.setTextColor(Theme.TEXT); title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView trash = new TextView(this);
        trash.setText("Очистить"); trash.setTextColor(Theme.ACC); trash.setTextSize(14);
        trash.setOnClickListener(v -> clearDialog());
        bar.addView(trash);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Theme.SUB); status.setTextSize(12);
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        root.addView(status);

        RecyclerView list = new RecyclerView(this);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        adapter = new DlAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void refresh() {
        items.clear();
        if (dm != null) {
            Cursor c = null;
            try {
                c = dm.query(new DownloadManager.Query());
                if (c != null) while (c.moveToNext()) {
                    Dl d = new Dl();
                    d.id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                    d.status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    d.total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    d.done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    d.name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    String uriStr = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                    if (uriStr != null) { try { d.localPath = Uri.parse(uriStr).getPath(); } catch (Throwable ignored) {} }
                    if (d.name == null || d.name.isEmpty()) d.name = d.localPath != null ? new File(d.localPath).getName() : ("#" + d.id);
                    items.add(d);
                }
            } catch (Throwable ignored) {} finally { if (c != null) c.close(); }
        }
        adapter.notifyDataSetChanged();
        status.setText(items.isEmpty() ? "Список пуст" : items.size() + " в списке");
    }

    private void clearDialog() {
        if (items.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Очистить загрузки?")
                .setItems(new CharSequence[]{ "Только список", "Вместе с файлами" }, (d, which) -> {
                    for (Dl it : items) {
                        if (which == 1 && it.localPath != null) { try { new File(it.localPath).delete(); } catch (Throwable ignored) {} }
                        try { dm.remove(it.id); } catch (Throwable ignored) {}
                    }
                    refresh();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private String statusText(Dl d) {
        switch (d.status) {
            case DownloadManager.STATUS_SUCCESSFUL: return "Готово";
            case DownloadManager.STATUS_FAILED: return "Ошибка";
            case DownloadManager.STATUS_PAUSED: return "Пауза";
            case DownloadManager.STATUS_PENDING: return "Ожидание";
            default:
                if (d.total > 0) return (int) (d.done * 100 / d.total) + "%";
                return "Качается";
        }
    }

    private class DlAdapter extends RecyclerView.Adapter<DlAdapter.VH> {
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) { return new VH(row()); }
        @Override public int getItemCount() { return items.size(); }
        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            Dl d = items.get(pos);
            h.name.setText(d.name);
            h.sub.setText(d.total > 0 ? Ui.sizeFmt(d.done) + " / " + Ui.sizeFmt(d.total) : "");
            h.sub.setVisibility(d.total > 0 ? View.VISIBLE : View.GONE);
            boolean ready = d.status == DownloadManager.STATUS_SUCCESSFUL && d.localPath != null;
            boolean running = d.status == DownloadManager.STATUS_RUNNING || d.status == DownloadManager.STATUS_PENDING;
            int pct = d.total > 0 ? (int) (d.done * 100 / d.total) : 0;
            h.progress.setVisibility(running || (d.done > 0 && !ready) ? View.VISIBLE : View.GONE);
            int p1 = Math.max(0, Math.min(100, pct));
            h.progressFill.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(DownloadsActivity.this, 6), p1));
            h.progressRest.setLayoutParams(new LinearLayout.LayoutParams(0, Ui.dp(DownloadsActivity.this, 6), 100 - p1));
            h.state.setText(ready ? "Готово — нажми, чтобы установить" : statusText(d));
            h.state.setTextColor(ready ? Theme.ACC : d.status == DownloadManager.STATUS_FAILED ? Theme.RED : Theme.SUB);
            // иконка-плитка слева
            h.tile.setText(ready ? "\u2713" : "\u2193");
            h.tile.setTextColor(ready ? Theme.ACC : d.status == DownloadManager.STATUS_FAILED ? Theme.RED : Theme.SUB);
            h.itemView.setOnClickListener(v -> { if (ready) ApkInstall.install(DownloadsActivity.this, new File(d.localPath)); });
        }
        class VH extends RecyclerView.ViewHolder {
            TextView name, sub, state, tile; View progress, progressFill, progressRest;
            VH(View v) {
                super(v);
                name = v.findViewWithTag("n"); sub = v.findViewWithTag("s"); state = v.findViewWithTag("st");
                tile = v.findViewWithTag("i");
                progress = v.findViewWithTag("p"); progressFill = v.findViewWithTag("pf"); progressRest = v.findViewWithTag("pr");
            }
        }
    }

    /** Карточка загрузки — как в IA: плитка 42, название, размеры, полоса прогресса, строка состояния. */
    private View row() {
        Context c = this;
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(c, 10); lp.leftMargin = Ui.dp(c, 10); lp.rightMargin = Ui.dp(c, 10);
        card.setLayoutParams(lp);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Theme.CARD); bg.setCornerRadius(Ui.dp(c, 12));
        bg.setStroke(Math.max(1, Ui.dp(c, 1)), Theme.BORDER);
        card.setBackground(bg);
        card.setPadding(Ui.dp(c, 12), Ui.dp(c, 11), Ui.dp(c, 12), Ui.dp(c, 11));

        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView tile = new TextView(c);
        tile.setTag("i");
        tile.setGravity(Gravity.CENTER);
        tile.setTextSize(20);
        android.graphics.drawable.GradientDrawable tb = new android.graphics.drawable.GradientDrawable();
        tb.setColor(Theme.DARK ? android.graphics.Color.parseColor("#2C2016") : android.graphics.Color.parseColor("#E8EDF3"));
        tb.setCornerRadius(Ui.dp(c, 10));
        tile.setBackground(tb);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(Ui.dp(c, 42), Ui.dp(c, 42));
        tlp.rightMargin = Ui.dp(c, 11);
        head.addView(tile, tlp);

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        head.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView n = new TextView(c); n.setTag("n"); n.setTextSize(15.5f); n.setTextColor(Theme.TEXT);
        n.setTypeface(null, android.graphics.Typeface.BOLD);
        n.setMaxLines(1); n.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); mid.addView(n);
        TextView sb = new TextView(c); sb.setTag("s"); sb.setTextSize(12.5f); sb.setTextColor(Theme.SUB);
        sb.setMaxLines(1); mid.addView(sb);

        // полоса прогресса
        LinearLayout prog = new LinearLayout(c);
        prog.setTag("p");
        prog.setOrientation(LinearLayout.HORIZONTAL);
        prog.setWeightSum(100);
        android.graphics.drawable.GradientDrawable pb = new android.graphics.drawable.GradientDrawable();
        pb.setColor(Theme.BORDER); pb.setCornerRadius(Ui.dp(c, 4));
        prog.setBackground(pb);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 6));
        plp.topMargin = Ui.dp(c, 10);
        card.addView(prog, plp);
        View fill = new View(c); fill.setTag("pf");
        android.graphics.drawable.GradientDrawable fb = new android.graphics.drawable.GradientDrawable();
        fb.setColor(Theme.ACC); fb.setCornerRadius(Ui.dp(c, 4));
        fill.setBackground(fb);
        prog.addView(fill, new LinearLayout.LayoutParams(0, Ui.dp(c, 6), 1f));
        View rest = new View(c); rest.setTag("pr");
        prog.addView(rest, new LinearLayout.LayoutParams(0, Ui.dp(c, 6), 1f));

        TextView st = new TextView(c); st.setTag("st"); st.setTextSize(13); st.setTextColor(Theme.SUB);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(c, 7);
        card.addView(st, slp);
        return card;
    }
}
