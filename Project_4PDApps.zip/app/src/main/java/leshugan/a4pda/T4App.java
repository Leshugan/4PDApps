package leshugan.a4pda;

import android.app.Application;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Ловушка падений: любой необработанный сбой записывается в файл,
 *  при следующем запуске MainActivity покажет его текст — чтобы чинить без logcat. */
public class T4App extends Application {
    @Override public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                File f = new File(getFilesDir(), "crash.txt");
                FileOutputStream out = new FileOutputStream(f);
                out.write(("Поток: " + t.getName() + "\n" + sw).getBytes("UTF-8"));
                out.close();
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
            else { android.os.Process.killProcess(android.os.Process.myPid()); System.exit(10); }
        });
    }

    public static String takeCrash(android.content.Context c) {
        try {
            File f = new File(c.getFilesDir(), "crash.txt");
            if (!f.exists()) return null;
            byte[] b = new byte[(int) Math.min(f.length(), 60000)];
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            int n = in.read(b);
            in.close();
            f.delete();
            return n > 0 ? new String(b, 0, n, "UTF-8") : null;
        } catch (Throwable t) { return null; }
    }
}
