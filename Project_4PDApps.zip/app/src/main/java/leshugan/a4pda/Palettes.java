package leshugan.a4pda;

import android.graphics.Color;

/** Все темы IA — те же id, названия и цвета (THEMES из вебной версии). */
public final class Palettes {
    public static class P {
        public final String id, name;
        public final int bg, bar, card, border, text, sub, date, active, nav, acc, blue, green, divider;
        public final boolean light;
        P(String id, String name, String bg, String bar, String card, String border, String text, String sub,
          String date, String active, String nav, String acc, String blue, String green, String divider, boolean light) {
            this.id = id; this.name = name; this.light = light;
            this.bg = Color.parseColor(bg); this.bar = Color.parseColor(bar); this.card = Color.parseColor(card);
            this.border = Color.parseColor(border); this.text = Color.parseColor(text); this.sub = Color.parseColor(sub);
            this.date = Color.parseColor(date); this.active = Color.parseColor(active); this.nav = Color.parseColor(nav);
            this.acc = Color.parseColor(acc); this.blue = Color.parseColor(blue); this.green = Color.parseColor(green);
            this.divider = Color.parseColor(divider);
        }
    }

    public static final P[] ALL = new P[] {
        new P("dark","Тёмная","#161009","#20180f","#241a11","#342617","#e9e6e2","#9a8f82","#887d70","#ffffff","#cbc3ba","#c8892e","#1e88e5","#43a047","#342617",false),
        new P("amoled","AMOLED","#000000","#000000","#0c0c0c","#1e1a15","#d4d1cc","#8a8178","#786f65","#e4e1dc","#aaa299","#c8892e","#1e88e5","#43a047","#141414",false),
        new P("light","Светлая","#eef1f4","#ffffff","#ffffff","#d3d8de","#1e2329","#6b7280","#6b7280","#1e2329","#3d4754","#2f80ed","#2f80ed","#2e7d32","#e2e6ea",true),
        new P("gruvbox","Gruvbox","#282828","#32302f","#3c3836","#504945","#ebdbb2","#a89984","#a89984","#fbf1c7","#d5c4a1","#fe8019","#83a598","#b8bb26","#504945",false),
        new P("dracula","Dracula","#282a36","#343746","#44475a","#4d5066","#f8f8f2","#a9adc4","#a9adc4","#ffffff","#d0d2e0","#bd93f9","#8be9fd","#50fa7b","#44475a",false),
        new P("nord","Nord","#2e3440","#3b4252","#3b4252","#434c5e","#eceff4","#a9b1c2","#a9b1c2","#ffffff","#d8dee9","#88c0d0","#81a1c1","#a3be8c","#434c5e",false),
        new P("rosepine","Rosé Pine","#191724","#1f1d2e","#26233a","#302d44","#e0def4","#a29fc0","#a29fc0","#ffffff","#d5d3ea","#c4a7e7","#9ccfd8","#31748f","#26233a",false),
        new P("solarized","Solarized","#002b36","#073642","#073642","#0e4b5a","#93a1a1","#6a8286","#6a8286","#eee8d5","#93a1a1","#268bd2","#268bd2","#859900","#0e4b5a",false),
        new P("sepia","Sepia","#f4ecd8","#fff9ee","#fff9ee","#d6c5ae","#5b4636","#8a7359","#8a7359","#3b2c1e","#6b5842","#8a5a2b","#4f7896","#6b7d3a","#e2d4bd",true),
        new P("greencare","Green Care","#c8e6c9","#dff0e1","#dff0e1","#aacdad","#1b3a2b","#4a6b52","#4a6b52","#0f2a1c","#3a5a44","#2e7d4f","#2b6ca0","#2e7d32","#b8d6bb",true),
    };

    public static P byId(String id) {
        for (P p : ALL) if (p.id.equals(id)) return p;
        return ALL[0];
    }
}
