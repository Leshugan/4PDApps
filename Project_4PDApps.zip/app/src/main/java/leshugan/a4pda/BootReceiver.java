package leshugan.a4pda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** После перезагрузки телефона — тихая фоновая проверка обновлений. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        UpdateJob.runOnce(c);   // через планировщик — из приёмника служба на Android 8+ запрещена
    }
}
