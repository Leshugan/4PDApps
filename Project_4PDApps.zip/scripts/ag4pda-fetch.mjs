// Робот: собирает сведения с сервера App&Game 4PDA и складывает их в ag4pda.json репозитория.
// Ничего не скачивает — только спрашивает готовые данные (тема, пакет, версия, подпись и т.д.).
// Запускается по расписанию из .github/workflows/ag4pda.yml. Токен не нужен.
import fs from "fs";
import crypto from "crypto";

const SRV = "https://srv1.freeman42.ru/app4pda.v3/";
const APP_VER = "5.3 beta 9 (539)";
const OUT = "ag4pda_fucker.json";
const CAT = "catalog.json";
const PER_RUN = +(process.env.PER_RUN || 2500);      // тем за один запуск
const PAUSE = +(process.env.PAUSE_MS || 120);

const rawId = process.env.AG_DEVICE_ID || "t4pdapps-robot-0001";
const key = Buffer.from(rawId, "utf8").toString("base64").split("").reverse().join("");
const hash = crypto.createHash("md5").update(rawId).digest("hex");
const auth = `key=${encodeURIComponent(key)}&hash=${hash}&app_ver=${encodeURIComponent(APP_VER)}`;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function ask(method, extraQuery) {
  const url = `${SRV}${method}?${auth}&${extraQuery}`;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: "" });
      const t = await r.text();
      return JSON.parse(t);
    } catch { await sleep(500 * (attempt + 1)); }
  }
  return null;
}

function load(file, def) { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return def; } }

const db = load(OUT, { v: 1, updated: "", cursor: 0, apps: {}, files: {} });
const cat = load(CAT, null);

// список тем: из каталога, по кругу — за каждый запуск обрабатываем следующий кусок
let topics = [];
function extractTopics(obj) {
  const out = new Set();
  const walk = (v) => {
    if (!v) return;
    if (Array.isArray(v)) { v.forEach(walk); return; }
    if (typeof v === "object") {
      for (const k in v) {
        if (/^\d{4,9}$/.test(k)) out.add(k);
        const x = v[k];
        if ((k === "t" || k === "topicId" || k === "topic_id" || k === "id") && /^\d{4,9}$/.test(String(x))) out.add(String(x));
        walk(x);
      }
      return;
    }
    if (typeof v === "string" && /^\d{4,9}$/.test(v)) out.add(v);
  };
  walk(obj);
  return [...out];
}
if (cat) topics = extractTopics(cat);
if (!topics.length) {                                   // каталога рядом нет — качаем его с GitHub
  try {
    const r = await fetch("https://raw.githubusercontent.com/Leshugan/4PDApps/main/catalog.json");
    if (r.ok) topics = extractTopics(JSON.parse(await r.text()));
  } catch {}
}
if (!topics.length) { console.log("список тем не найден: положи catalog.json в корень или проверь ссылку"); process.exit(0); }

const start = (db.cursor || 0) % topics.length;
const slice = [];
for (let i = 0; i < Math.min(PER_RUN, topics.length); i++) slice.push(topics[(start + i) % topics.length]);
console.log(`тем всего: ${topics.length}, беру ${slice.length}, начиная с позиции ${start}`);

let ok = 0, empty = 0;
for (const tid of slice) {
  const o = await ask("getFileInfo.php", `topic_id=${tid}`);
  const data = o && Array.isArray(o.data) ? o.data : null;
  if (!data || !data.length) { empty++; await sleep(PAUSE); continue; }
  db.files[tid] = data.map((x) => ({
    id: String(x.file_id || ""), url: String(x.file_name || ""), ver: String(x.version_name || ""),
    code: +(x.version_code || 0), pkg: String(x.pack_name || ""), sig: String(x.signature || ""),
    minSdk: +(x.min_sdk || 0), flags: +(x.flags || 0), size: +(x.file_size || 0), dl: +(x.downloads_count || 0),
    crc: String(x.crc32 || ""),
  }));
  for (const f of data) {
    const pkg = String(f.pack_name || "");
    if (!pkg) continue;
    const prev = db.apps[pkg];
    if (!prev || +(f.version_code || 0) >= (prev.code || 0)) {
      db.apps[pkg] = { topicId: String(tid), ver: String(f.version_name || ""), code: +(f.version_code || 0), sig: String(f.signature || ""), name: String(f.app_name || "") };
    }
  }
  ok++;
  await sleep(PAUSE);
}

// ВТОРОЙ ЭТАП: по накопленным пакетам добираем карточки (название, описание, категория, иконка, дата)
const pkgs = Object.keys(db.apps).filter((p2) => !db.apps[p2].desc);
console.log(`пакетов без карточки: ${pkgs.length}`);
for (let i = 0; i < Math.min(pkgs.length, 2000); i += 40) {
  const part = pkgs.slice(i, i + 40);
  const o = await ask("getAppInfo.php", `packages=${encodeURIComponent(part.join("|"))}`);
  const data = o && Array.isArray(o.data) ? o.data : null;
  if (data) for (const x of data) {
    const pkg = String(x.pack_name || ""); if (!pkg) continue;
    db.apps[pkg] = {
      ...(db.apps[pkg] || {}),
      topicId: String(x.topic_id || (db.apps[pkg] || {}).topicId || ""),
      name: String(x.name || (db.apps[pkg] || {}).name || ""),
      desc: String(x.description || ""),
      ver: String(x.ver || (db.apps[pkg] || {}).ver || ""),
      icon: String(x.icon || "").replace(/^http:/, "https:"),
      group: String(x.group_name || ""),
      upd: String(x.forum_update || ""),
    };
  }
  await sleep(PAUSE);
}

const nextCursor = (start + slice.length) % topics.length;
db.cursor = nextCursor;
db.total = topics.length;
db.done = nextCursor === 0 || (db.roundStart != null && start < db.roundStart);   // круг закончен
if (db.done) { db.roundStart = 0; db.finishedAt = new Date().toISOString(); }
else db.roundStart = db.roundStart || 0;
db.updated = new Date().toISOString();
fs.writeFileSync(OUT, JSON.stringify(db));
console.log("файл записан:", OUT);
console.log(`готово: тем с данными ${ok}, пустых ${empty}; всего пакетов в базе ${Object.keys(db.apps).length}, тем ${Object.keys(db.files).length}`);
