// Выгрузка каталога App&Game: категории по страницам → темы → файлы.
// Ничего не берёт из нашей базы: список тем строится из ответов их сервера.
import crypto from "crypto";
import fs from "fs";
const fsr = (p2) => { try { return fs.readFileSync(p2, "utf8"); } catch { return ""; } };
const fsw = (p2, v) => { try { fs.writeFileSync(p2, v); } catch {} };

const SRV = "https://srv1.freeman42.ru/app4pda.v3/";
const APP_VER = "5.3 beta 9 (539)";
const BASE = process.env.SINK_BASE || "https://little-violet-11d7.leshugan.workers.dev";
const BULK = BASE + "/bulk";
const BATCH = +(process.env.BATCH || 150);
let buf = [];
const PAUSE = +(process.env.PAUSE_MS || 150);
const GROUPS = +(process.env.GROUPS || 40);        // сколько номеров категорий перебрать
const TOPICS_PER_ASK = 8;                          // тем за один запрос файлов

const rawId = process.env.AG_DEVICE_ID || "t4pdapps-robot-0001";
const key = Buffer.from(rawId, "utf8").toString("base64").split("").reverse().join("");
const hash = crypto.createHash("md5").update(rawId).digest("hex");
const auth = `key=${encodeURIComponent(key)}&hash=${hash}&app_ver=${encodeURIComponent(APP_VER)}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function ask(method, q) {
  for (let t = 0; t < 3; t++) {
    try {
      const r = await fetch(`${SRV}${method}?${auth}&${q}`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "device_info=robot",
      });
      return JSON.parse(await r.text());
    } catch { await sleep(500 * (t + 1)); }
  }
  return null;
}

async function flush() {                                   // отправляем накопленное одной пачкой
  if (!buf.length) return 0;
  const part = buf; buf = [];
  for (let t = 0; t < 3; t++) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), 20000);
    try {
      const r = await fetch(BULK, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(part), signal: ac.signal });
      clearTimeout(timer);
      if (r.ok) return part.length;
      if (r.status === 429) { await sleep(3000); continue; }
      return 0;
    } catch { clearTimeout(timer); await sleep(1500); }
  }
  return 0;
}
async function send(rec) {
  for (let t = 0; t < 2; t++) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), 12000);       // не ждём вечно
    try {
      const r = await fetch(SINK, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(rec), signal: ac.signal });
      clearTimeout(timer);
      if (r.ok) return true;
      if (r.status === 429) { await sleep(2000); continue; }  // приёмник просит подождать
      return false;
    } catch { clearTimeout(timer); await sleep(1000); }
  }
  return false;
}

const STATE = "ag-export-state.json";
const topics = new Set();
let cards = 0, files = 0, sent = 0;

// 1) каталог по категориям и страницам — так их сервер отдаёт весь список
for (let g = 1; g <= GROUPS; g++) {
  let page = 0, total = 0;
  do {
    const o = await ask("getAppInfo.php", `group_id=${g}&page=${page}`);
    const arr = (o && o.data) || [];
    for (const m of ((o && o.meta) || [])) if (m && m.found_rows) total = +m.found_rows;
    if (!arr.length) break;
    for (const x of arr) { if (x.topic_id) topics.add(String(x.topic_id)); cards++; }
    try {                                                   // связи из их каталога — в наш общий список
      const links = arr.filter((x) => x.pack_name && x.topic_id)
        .map((x) => ({ pkg: String(x.pack_name), topicId: +x.topic_id, title: String(x.name || "") }));
      if (links.length) {
        const ac = new AbortController();
        const tm = setTimeout(() => ac.abort(), 20000);
        await fetch(BASE + "/links-bulk", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(links), signal: ac.signal });
        clearTimeout(tm);
      }
    } catch {}
    console.log(`категория ${g}, страница ${page}: ${arr.length} шт (всего ${total})`);
    page++;
    await sleep(PAUSE);
  } while (page * 100 < total && page < 60);
}
console.log(`карточек: ${cards}, уникальных тем: ${topics.size}`);

// 2) файлы по темам — пачками, их сервер принимает несколько номеров сразу
const list = [...topics];
let start = 0;
try { start = +(JSON.parse(fsr("ag-export-state.json") || "{}").cursor || 0); } catch {}
if (start >= list.length) start = 0;
console.log(`продолжаю с темы ${start}`);
for (let i = start; i < list.length; i += TOPICS_PER_ASK) {
  const part = list.slice(i, i + TOPICS_PER_ASK);
  const o = await ask("getFileInfo.php", `topic_id=${part.join("|")}`);
  for (const x of ((o && o.data) || [])) {
    const url = String(x.file_name || "");
    const aid = +(((url.match(/\/dl\/post\/(\d+)\//) || [])[1]) || 0);
    if (!aid || !x.pack_name || !x.signature) continue;
    files++;
    buf.push({
      topicId: +(x.topic_id || 0), aid, url, name: url.split("/").pop(),
      app_name: x.app_name || "", pkg: x.pack_name, ver: x.version_name || "",
      code: +(x.version_code || 0), sig: x.signature, minSdk: +(x.min_sdk || 0),
      abis: "", size: +(x.file_size || 0), crc32: x.crc32 || "",
    });
    if (buf.length >= BATCH) sent += await flush();
  }
  if (i % 80 === 0) {
    console.log(`темы ${i}/${list.length} · файлов ${files} · отправлено ${sent}`);
    try { fsw("ag-export-state.json", JSON.stringify({ cursor: i })); } catch {}
  }
  await sleep(PAUSE);
}
sent += await flush();
fsw("ag-export-state.json", JSON.stringify({ cursor: 0 }));
console.log(`ГОТОВО: карточек ${cards}, файлов ${files}, отправлено ${sent}`);
