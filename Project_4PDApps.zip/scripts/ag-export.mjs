// Выгрузка каталога App&Game: категории по страницам → темы → файлы.
// Ничего не берёт из нашей базы: список тем строится из ответов их сервера.
import crypto from "crypto";

const SRV = "https://srv1.freeman42.ru/app4pda.v3/";
const APP_VER = "5.3 beta 9 (539)";
const SINK = process.env.SINK || "https://little-violet-11d7.leshugan.workers.dev/add";
const PAUSE = +(process.env.PAUSE_MS || 150);
const GROUPS = +(process.env.GROUPS || 40);        // сколько номеров категорий перебрать
const TOPICS_PER_ASK = 8;                          // тем за один запрос файлов

const rawId = process.env.AG_DEVICE_ID || "t4pdapps-robot-0001";
const key = Buffer.from(rawId, "utf8").toString("base64").split("").reverse().join("");
const hash = crypto.createHash("md5").update(rawId).digest("hex");
const auth = `key=${encodeURIComponent(key)}&hash=${hash}&app_ver=${encodeURIComponent(APP_VER)}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function ask(method, q) {
  for (let t = 0; t < 3; t++) {
    try {
      const r = await fetch(`${SRV}${method}?${auth}&${q}`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "device_info=robot",
      });
      return JSON.parse(await r.text());
    } catch { await sleep(500 * (t + 1)); }
  }
  return null;
}

async function send(rec) {
  try {
    const r = await fetch(SINK, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(rec) });
    return r.ok;
  } catch { return false; }
}

const topics = new Set();
let cards = 0, files = 0, sent = 0;

// 1) каталог по категориям и страницам — так их сервер отдаёт весь список
for (let g = 1; g <= GROUPS; g++) {
  let page = 0, total = 0;
  do {
    const o = await ask("getAppInfo.php", `group_id=${g}&page=${page}`);
    const arr = (o && o.data) || [];
    for (const m of ((o && o.meta) || [])) if (m && m.found_rows) total = +m.found_rows;
    if (!arr.length) break;
    for (const x of arr) { if (x.topic_id) topics.add(String(x.topic_id)); cards++; }
    console.log(`категория ${g}, страница ${page}: ${arr.length} шт (всего ${total})`);
    page++;
    await sleep(PAUSE);
  } while (page * 100 < total && page < 60);
}
console.log(`карточек: ${cards}, уникальных тем: ${topics.size}`);

// 2) файлы по темам — пачками, их сервер принимает несколько номеров сразу
const list = [...topics];
for (let i = 0; i < list.length; i += TOPICS_PER_ASK) {
  const part = list.slice(i, i + TOPICS_PER_ASK);
  const o = await ask("getFileInfo.php", `topic_id=${part.join("|")}`);
  for (const x of ((o && o.data) || [])) {
    const url = String(x.file_name || "");
    const aid = +(((url.match(/\/dl\/post\/(\d+)\//) || [])[1]) || 0);
    if (!aid || !x.pack_name || !x.signature) continue;
    files++;
    if (await send({
      topicId: +(x.topic_id || 0), aid, url, name: url.split("/").pop(),
      app_name: x.app_name || "", pkg: x.pack_name, ver: x.version_name || "",
      code: +(x.version_code || 0), sig: x.signature, minSdk: +(x.min_sdk || 0),
      abis: "", size: +(x.file_size || 0), crc32: x.crc32 || "",
    })) sent++;
  }
  if (i % 80 === 0) console.log(`темы ${i}/${list.length} · файлов ${files} · отправлено ${sent}`);
  await sleep(PAUSE);
}
console.log(`ГОТОВО: карточек ${cards}, файлов ${files}, отправлено ${sent}`);
