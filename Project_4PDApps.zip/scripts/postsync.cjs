// Хук Capacitor: выполняется автоматически ПОСЛЕ `cap sync/copy` (см. scripts в package.json).
// Перезаписывает макет уведомления загрузки ПОВЕРХ того, что создал старый шаг build.yml, —
// build.yml править не нужно. Цвета текста задают стили androidx для уведомлений:
// они корректно подстраиваются под светлую и тёмную шторку на любой прошивке.
const fs = require("fs");
const path = require("path");
const dir = path.join(__dirname, "..", "android", "app", "src", "main", "res", "layout");
const xml = `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent" android:layout_height="wrap_content"
    android:orientation="vertical"
    android:paddingStart="2dp" android:paddingEnd="2dp" android:paddingTop="4dp" android:paddingBottom="2dp">
  <TextView android:id="@+id/t4_title" style="@style/TextAppearance.Compat.Notification.Title"
      android:layout_width="match_parent" android:layout_height="wrap_content"
      android:textSize="13sp" android:maxLines="1" android:ellipsize="end"/>
  <ProgressBar android:id="@+id/t4_prog" style="?android:attr/progressBarStyleHorizontal"
      android:layout_width="match_parent" android:layout_height="4dp" android:layout_marginTop="6dp" android:max="100"/>
  <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content"
      android:orientation="horizontal" android:gravity="center_vertical" android:layout_marginTop="2dp">
    <TextView android:id="@+id/t4_sub" style="@style/TextAppearance.Compat.Notification.Info"
        android:layout_width="0dp" android:layout_height="wrap_content"
        android:layout_weight="1" android:textSize="11sp" android:maxLines="1"/>
    <TextView android:id="@+id/t4_b1" style="@style/TextAppearance.Compat.Notification.Title"
        android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:minHeight="44dp" android:minWidth="64dp" android:gravity="center"
        android:textSize="14sp" android:textStyle="bold" android:textAllCaps="true"
        android:paddingStart="12dp" android:paddingEnd="12dp"/>
    <TextView android:id="@+id/t4_b2" style="@style/TextAppearance.Compat.Notification.Title"
        android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:minHeight="44dp" android:minWidth="64dp" android:gravity="center"
        android:textSize="14sp" android:textStyle="bold" android:textAllCaps="true"
        android:paddingStart="12dp" android:paddingEnd="12dp"/>
  </LinearLayout>
</LinearLayout>
`;
try {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "t4_notif_dl.xml"), xml);
  console.log("t4_notif_dl.xml перезаписан (системные цвета текста)");
} catch (e) { console.log("postsync: " + e.message); }

// право «не спать» — иначе система тормозит закачку при свёрнутом приложении
try {
  const fs2 = require("fs");
  const man = "android/app/src/main/AndroidManifest.xml";
  if (fs2.existsSync(man)) {
    let m = fs2.readFileSync(man, "utf8");
    if (!m.includes("WAKE_LOCK")) {
      m = m.replace("<application", '<uses-permission android:name="android.permission.WAKE_LOCK" />\n    <application');
      fs2.writeFileSync(man, m);
      console.log("добавлено право WAKE_LOCK");
    }
  }
} catch (e) { console.log("манифест не поправлен:", e.message); }
